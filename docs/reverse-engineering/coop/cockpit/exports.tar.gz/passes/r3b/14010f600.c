/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14010f600; RVA 0x10f600
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14010f600(longlong param_1,byte param_2,byte param_3,byte param_4)

{
  undefined1 auVar1 [16];
  byte bVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  char cVar5;
  uint uVar6;
  float fVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  float fVar11;
  undefined1 auVar12 [16];
  undefined1 auVar13 [64];
  float fVar14;
  undefined4 uVar15;
  float fVar16;
  undefined4 uVar17;
  float fVar18;
  undefined4 uVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  
  cVar5 = *(char *)(param_1 + 0x432);
  uVar6 = (uint)param_2;
  if (cVar5 == '\0') {
    auVar12 = *(undefined1 (*) [16])(param_1 + 0x3d8);
    auVar1 = *(undefined1 (*) [16])(param_1 + 0x3c8);
    *(int *)(param_1 + 0x250) = auVar1._0_4_;
    uVar15 = vextractps_avx(auVar1,1);
    *(undefined4 *)(param_1 + 0x254) = uVar15;
    uVar15 = vextractps_avx(auVar1,2);
    *(undefined4 *)(param_1 + 600) = uVar15;
    uVar15 = vextractps_avx(auVar1,3);
    *(undefined4 *)(param_1 + 0x25c) = uVar15;
    *(int *)(param_1 + 0x260) = auVar12._0_4_;
    uVar15 = vextractps_avx(auVar12,1);
    *(undefined4 *)(param_1 + 0x264) = uVar15;
    uVar15 = vextractps_avx(auVar12,2);
    *(undefined4 *)(param_1 + 0x268) = uVar15;
    uVar15 = vextractps_avx(auVar12,3);
    *(undefined4 *)(param_1 + 0x26c) = uVar15;
    FUN_140110bd0(param_1 + 0x250,uVar6);
    *(undefined4 *)(param_1 + 0x3c8) = *(undefined4 *)(param_1 + 0x250);
    *(undefined4 *)(param_1 + 0x3cc) = *(undefined4 *)(param_1 + 0x254);
    *(undefined4 *)(param_1 + 0x3d0) = *(undefined4 *)(param_1 + 600);
    *(undefined4 *)(param_1 + 0x3d4) = *(undefined4 *)(param_1 + 0x25c);
    *(undefined4 *)(param_1 + 0x3d8) = *(undefined4 *)(param_1 + 0x260);
    *(undefined4 *)(param_1 + 0x3dc) = *(undefined4 *)(param_1 + 0x264);
    *(undefined4 *)(param_1 + 0x3e0) = *(undefined4 *)(param_1 + 0x268);
    *(undefined4 *)(param_1 + 0x3e4) = *(undefined4 *)(param_1 + 0x26c);
LAB_14010f8d2:
    *(undefined8 *)(param_1 + 1000) = 0;
    *(undefined4 *)(param_1 + 0x3f0) = 0;
    *(undefined4 *)(param_1 + 0x3f4) = 0x3f800000;
    return;
  }
  if (cVar5 == '\x03') {
    *(undefined4 *)(param_1 + 0x180) = *(undefined4 *)(param_1 + 0x3c8);
    *(undefined4 *)(param_1 + 0x184) = *(undefined4 *)(param_1 + 0x3cc);
    *(undefined4 *)(param_1 + 0x188) = *(undefined4 *)(param_1 + 0x3d0);
    *(undefined4 *)(param_1 + 0x18c) = *(undefined4 *)(param_1 + 0x3d4);
    *(undefined4 *)(param_1 + 400) = *(undefined4 *)(param_1 + 0x3d8);
    *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x3dc);
    *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x3e0);
    *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x3e4);
    *(undefined8 *)(param_1 + 1000) = 0;
    *(undefined4 *)(param_1 + 0x3f0) = 0;
    *(undefined4 *)(param_1 + 0x3f4) = 0x3f800000;
    return;
  }
  if (cVar5 == '\x01') {
    *(uint *)(param_1 + 0x388) = uVar6;
    *(undefined8 *)(param_1 + 0x380) = 0;
    auVar12 = *(undefined1 (*) [16])(param_1 + 0x3d8);
    auVar1 = *(undefined1 (*) [16])(param_1 + 0x3c8);
    *(int *)(param_1 + 0x310) = auVar1._0_4_;
    uVar15 = vextractps_avx(auVar1,1);
    *(undefined4 *)(param_1 + 0x314) = uVar15;
    uVar15 = vextractps_avx(auVar1,2);
    *(undefined4 *)(param_1 + 0x318) = uVar15;
    uVar15 = vextractps_avx(auVar1,3);
    *(undefined4 *)(param_1 + 0x31c) = uVar15;
    *(int *)(param_1 + 800) = auVar12._0_4_;
    uVar15 = vextractps_avx(auVar12,1);
    *(undefined4 *)(param_1 + 0x324) = uVar15;
    uVar15 = vextractps_avx(auVar12,2);
    *(undefined4 *)(param_1 + 0x328) = uVar15;
    uVar15 = vextractps_avx(auVar12,3);
    *(undefined4 *)(param_1 + 0x32c) = uVar15;
    FUN_140110f80();
    *(undefined4 *)(param_1 + 0x3c8) = *(undefined4 *)(param_1 + 0x310);
    *(undefined4 *)(param_1 + 0x3cc) = *(undefined4 *)(param_1 + 0x314);
    *(undefined4 *)(param_1 + 0x3d0) = *(undefined4 *)(param_1 + 0x318);
    *(undefined4 *)(param_1 + 0x3d4) = *(undefined4 *)(param_1 + 0x31c);
    *(undefined4 *)(param_1 + 0x3d8) = *(undefined4 *)(param_1 + 800);
    *(undefined4 *)(param_1 + 0x3dc) = *(undefined4 *)(param_1 + 0x324);
    *(undefined4 *)(param_1 + 0x3e0) = *(undefined4 *)(param_1 + 0x328);
    *(undefined4 *)(param_1 + 0x3e4) = *(undefined4 *)(param_1 + 0x32c);
    *(undefined4 *)(param_1 + 0x41c) = *(undefined4 *)(param_1 + 0x38c);
    *(float *)(param_1 + 0x418) =
         SQRT(*(float *)(param_1 + 0x33c) * *(float *)(param_1 + 0x33c) +
              *(float *)(param_1 + 0x338) * *(float *)(param_1 + 0x338) +
              *(float *)(param_1 + 0x334) * *(float *)(param_1 + 0x334) +
              *(float *)(param_1 + 0x330) * *(float *)(param_1 + 0x330)) * DAT_1402d2610;
    *(undefined4 *)(param_1 + 0x424) = *(undefined4 *)(param_1 + 0x390);
    *(undefined4 *)(param_1 + 0x420) = *(undefined4 *)(param_1 + 0x394);
    *(undefined4 *)(param_1 + 0x428) = *(undefined4 *)(param_1 + 0x398);
    goto LAB_14010f8d2;
  }
  if (cVar5 != '\x02') {
    return;
  }
  *(undefined4 *)(param_1 + 0x180) = *(undefined4 *)(param_1 + 0x3c8);
  *(undefined4 *)(param_1 + 0x184) = *(undefined4 *)(param_1 + 0x3cc);
  *(undefined4 *)(param_1 + 0x188) = *(undefined4 *)(param_1 + 0x3d0);
  *(undefined4 *)(param_1 + 0x18c) = *(undefined4 *)(param_1 + 0x3d4);
  *(undefined4 *)(param_1 + 400) = *(undefined4 *)(param_1 + 0x3d8);
  *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x3dc);
  *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x3e0);
  *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x3e4);
  if ((*(byte *)(*(longlong *)
                  (*(longlong *)(**(longlong **)(param_1 + 0x410) + (ulonglong)param_3 * 8) + 0x110)
                 + 0x1f0 + (ulonglong)param_4 * 0x520) & 2) == 0) {
    fVar14 = 0.0;
    fVar18 = 0.0;
    fVar22 = 0.0;
  }
  else {
    bVar2 = *(byte *)(param_1 + 0x433);
    *(byte *)(param_1 + 0x433) = bVar2 & 0xfd;
    uVar9 = FUN_140187ec0((ulonglong)param_4 * 0x520,uVar6,0x15);
    uVar10 = FUN_140187ec0(uVar9,param_2,0x16);
    fVar14 = (float)uVar9;
    uVar9 = FUN_140187ec0(uVar10,param_2,0x14);
    fVar16 = (float)uVar10;
    uVar10 = FUN_140187ec0(uVar9,param_2,0x13);
    fVar18 = (float)uVar9;
    uVar9 = FUN_140187ec0(uVar10,param_2,0x11);
    fVar20 = (float)uVar10;
    uVar10 = FUN_140187ec0(uVar9,param_2,0x12);
    fVar11 = (float)uVar9;
    uVar9 = FUN_140187ec0(uVar10,param_2,0x18);
    fVar21 = (float)uVar10;
    fVar7 = (float)FUN_140187ec0(uVar9,param_2,0x17);
    fVar22 = (float)uVar9;
    cVar5 = FUN_140187a40(DAT_14032c8f0,uVar6,0x24);
    if (((bVar2 & 1) != 0) || (cVar5 != '\0')) {
      fVar18 = *(float *)(param_1 + 0x3e0);
      fVar14 = DAT_1402d2d2c;
      if ((fVar18 < DAT_1402d2cec) || (fVar14 = DAT_1402d2168, DAT_1402d2054 < fVar18)) {
LAB_14010fb68:
        fVar18 = 0.0;
      }
      else {
        if ((DAT_1402d1f34 < fVar18) || (fVar18 < DAT_1402d2ca4)) {
          fVar14 = fVar18 * DAT_1402d2414;
        }
        else {
          fVar14 = 0.0;
        }
        fVar18 = *(float *)(param_1 + 0x3d8);
        if (DAT_1402d2cb4 <= fVar18) {
          if (DAT_1402d1f80 < fVar18) {
            fVar18 = DAT_1402d2d2c;
          }
          else {
            if ((fVar18 <= DAT_1402d1dc8) && (DAT_1402d2c6c <= fVar18)) goto LAB_14010fb68;
            fVar18 = fVar18 * DAT_1402d2e00;
          }
        }
        else {
          fVar18 = DAT_1402d2168;
        }
      }
      fVar22 = 0.0;
      fVar7 = *(float *)(param_1 + 0x42c);
      *(byte *)(param_1 + 0x433) = bVar2 & 0xfd | 2;
      goto LAB_14010fb95;
    }
    fVar14 = fVar14 - fVar16;
    fVar18 = fVar18 - fVar20;
    fVar22 = fVar22 - fVar7;
    fVar7 = fVar11 - fVar21;
    if ((bVar2 & 4) == 0) goto LAB_14010fb95;
    if (DAT_1402d1ff8 < fVar11) {
      *(byte *)(param_1 + 0x433) = bVar2 & 0xf9;
      goto LAB_14010fb95;
    }
  }
  fVar7 = DAT_1402d2d64;
LAB_14010fb95:
  auVar13 = ZEXT1664(*(undefined1 (*) [16])(param_1 + 0x180));
  *(float *)(param_1 + 0x220) = fVar18;
  *(float *)(param_1 + 0x224) = fVar14;
  *(float *)(param_1 + 0x228) = fVar22;
  *(float *)(param_1 + 0x22c) = fVar7;
  FUN_14012aa30(param_1);
  auVar12 = *(undefined1 (*) [16])(param_1 + 0x180);
  auVar1 = vshufps_avx(auVar12,auVar12,0x55);
  auVar3 = vshufps_avx(auVar12,auVar12,0xaa);
  auVar4 = vshufps_avx(auVar12,auVar12,0xff);
  *(float *)(param_1 + 0x180) = auVar12._0_4_ + *(float *)(param_1 + 0x3f8);
  *(float *)(param_1 + 0x18c) = auVar4._0_4_ + *(float *)(param_1 + 0x404);
  *(float *)(param_1 + 0x184) = auVar1._0_4_ + *(float *)(param_1 + 0x3fc);
  *(float *)(param_1 + 0x188) = auVar3._0_4_ + *(float *)(param_1 + 0x400);
  auVar12 = *(undefined1 (*) [16])(param_1 + 0x1a0);
  auVar1 = vshufps_avx(auVar12,auVar12,0x55);
  auVar3 = vshufps_avx(auVar12,auVar12,0xaa);
  auVar4 = vshufps_avx(auVar12,auVar12,0xff);
  *(float *)(param_1 + 0x1a0) = auVar12._0_4_ + *(float *)(param_1 + 0x3f8);
  *(float *)(param_1 + 0x1a4) = auVar1._0_4_ + *(float *)(param_1 + 0x3fc);
  *(float *)(param_1 + 0x1a8) = auVar3._0_4_ + *(float *)(param_1 + 0x400);
  *(float *)(param_1 + 0x1ac) = auVar4._0_4_ + *(float *)(param_1 + 0x404);
  FUN_1401295b0(param_1);
  auVar12 = auVar13._0_16_;
  uVar15 = *(undefined4 *)(param_1 + 0x238);
  uVar17 = *(undefined4 *)(param_1 + 0x23c);
  uVar19 = *(undefined4 *)(param_1 + 0x240);
  if (DAT_14033bd60 == '\0') {
    FUN_14010fe60();
    auVar12 = auVar13._0_16_;
  }
  if (*(short *)(param_1 + 0x430) == 1000) {
    *(int *)(param_1 + 0x180) = auVar12._0_4_;
    uVar8 = vextractps_avx(auVar12,1);
    *(undefined4 *)(param_1 + 0x184) = uVar8;
    uVar8 = vextractps_avx(auVar12,2);
    *(undefined4 *)(param_1 + 0x188) = uVar8;
    uVar8 = vextractps_avx(auVar12,3);
    *(undefined4 *)(param_1 + 0x18c) = uVar8;
    *(undefined8 *)(param_1 + 0x1a0) = 0;
    *(undefined8 *)(param_1 + 0x1a8) = 0;
  }
  *(undefined4 *)(param_1 + 0x3c8) = *(undefined4 *)(param_1 + 0x180);
  *(undefined4 *)(param_1 + 0x3cc) = *(undefined4 *)(param_1 + 0x184);
  *(undefined4 *)(param_1 + 0x3d0) = *(undefined4 *)(param_1 + 0x188);
  *(undefined4 *)(param_1 + 0x3d4) = *(undefined4 *)(param_1 + 0x18c);
  *(undefined4 *)(param_1 + 0x3d8) = *(undefined4 *)(param_1 + 400);
  *(undefined4 *)(param_1 + 0x3dc) = *(undefined4 *)(param_1 + 0x194);
  *(undefined4 *)(param_1 + 0x3e0) = *(undefined4 *)(param_1 + 0x198);
  *(undefined4 *)(param_1 + 0x3e4) = *(undefined4 *)(param_1 + 0x19c);
  fVar14 = DAT_1402d26b4;
  fVar18 = (float)*(byte *)(param_1 + 0x244) * *(float *)(param_1 + 0x210) * DAT_1402d21d0;
  *(undefined4 *)(param_1 + 0x41c) = *(undefined4 *)(param_1 + 0x230);
  *(float *)(param_1 + 0x418) = fVar18;
  uVar8 = DAT_1402d22d0;
  if (fVar18 <= fVar14 / (float)*(byte *)(param_1 + 0x434)) {
    *(undefined8 *)(param_1 + 1000) = 0;
    *(undefined4 *)(param_1 + 0x3f0) = 0;
    *(undefined4 *)(param_1 + 0x41c) = 0;
  }
  else {
    *(undefined4 *)(param_1 + 1000) = *(undefined4 *)(param_1 + 0x1e0);
    *(undefined4 *)(param_1 + 0x3ec) = *(undefined4 *)(param_1 + 0x1e4);
    *(undefined4 *)(param_1 + 0x3f0) = *(undefined4 *)(param_1 + 0x1e8);
    uVar8 = *(undefined4 *)(param_1 + 0x1ec);
  }
  *(undefined4 *)(param_1 + 0x3f4) = uVar8;
  *(undefined4 *)(param_1 + 0x420) = uVar15;
  *(undefined4 *)(param_1 + 0x424) = uVar17;
  *(undefined4 *)(param_1 + 0x428) = uVar19;
  return;
}

