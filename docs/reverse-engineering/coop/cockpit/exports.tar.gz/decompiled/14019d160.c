/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14019d160; RVA 0x19d160
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14019d160(undefined8 param_1,longlong param_2,int param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  uint uVar3;
  uint *puVar4;
  uint uVar5;
  uint *puVar6;
  int iVar7;
  int iVar8;
  
  if (0 < param_3) {
    iVar8 = 0;
    do {
      puVar4 = DAT_14031cf20;
      uVar3 = *(uint *)(param_2 + (longlong)iVar8 * 4);
      lVar2 = param_2 + (longlong)iVar8 * 4;
      uVar5 = uVar3 >> 0x18 & 0x7f;
      if ((uVar5 == 0x50) || (uVar5 == 0x51)) {
        FUN_140196530(&DAT_14031cf38,lVar2 + 4,uVar3 & 0xffff,param_4);
        iVar8 = iVar8 + (uVar3 & 0xffff) * 4;
      }
      else if (uVar5 != 0) {
        if (uVar5 == 1) {
          DAT_14031cf28 = (undefined1)(uVar3 >> 8);
          DAT_14031cf29 = (char)uVar3;
        }
        else if (uVar5 == 2) {
          _DAT_14031cf30 = (ushort)uVar3 & 0x3ff;
          _DAT_14031cf2a = _DAT_14031cf30 + DAT_14031cf2e;
          DAT_14031cf2c = DAT_14031cf2e;
          DAT_14031cf32 = 0;
        }
        else if (uVar5 == 3) {
          DAT_14031cf2e = (ushort)uVar3 & 0x3ff;
        }
        else if (1 < uVar5 - 0x10) {
          if (uVar5 == 0x20) {
            _DAT_14031cf34 = *(undefined4 *)(param_2 + 4 + (longlong)iVar8 * 4);
            iVar8 = iVar8 + 1;
          }
          else if (uVar5 == 0x4a) {
            uVar1 = lVar2 + 4;
            uVar5 = uVar3 >> 0x10 & 0xff;
            puVar6 = &DAT_14031d7a8;
            if ((char)(uVar3 >> 0x10) == '\0') {
              uVar5 = 0x100;
            }
            iVar7 = 0;
            do {
              if ((*(ulonglong *)(puVar6 + -2) <= uVar1) &&
                 (uVar1 < (ulonglong)*puVar6 + *(ulonglong *)(puVar6 + -2))) {
                DAT_14033bbf0 = iVar7;
                if ((iVar7 == -1) ||
                   (*(undefined1 *)(*(longlong *)(DAT_14031cf20 + 0x20) + 0x750) = 1,
                   (&PTR__guard_check_icall_14031d7b0)[(longlong)iVar7 * 9] == (undefined *)0x0))
                goto LAB_14019d2c8;
                goto LAB_14019d2e0;
              }
              iVar7 = iVar7 + 1;
              puVar6 = puVar6 + 0x12;
            } while (iVar7 < 0xe);
            DAT_14033bbf0 = -1;
LAB_14019d2c8:
            FUN_140277ba0(*(longlong *)(puVar4 + 0x1c) + (ulonglong)(uVar3 & 0xffff) * 8,uVar1,
                          uVar5 * 8);
LAB_14019d2e0:
            iVar8 = iVar8 + uVar5 * 2;
          }
          else if (uVar5 == 0x14) {
            *DAT_14031cf20 = uVar3 & 0xffff;
            FUN_14019cbf0();
          }
          else if (uVar5 == 0x17) {
            FUN_14019cbf0(DAT_14031cf20);
          }
          else if (uVar5 == 0x1f) {
            FUN_14020ea20(DAT_14030cab8,CONCAT31((int3)(uVar3 >> 8),(char)uVar3 == '\0'));
          }
          else if (((byte)(uVar3 >> 0x18) & 0x60) == 0x60) {
            iVar7 = FUN_14019cd40(uVar5 - 0x10,lVar2);
            iVar8 = iVar8 + iVar7;
          }
        }
      }
      iVar8 = iVar8 + 1;
    } while (iVar8 < param_3);
  }
  return;
}

