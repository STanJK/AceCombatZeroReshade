/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400c80e0; RVA 0xc80e0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_1400c80e0(longlong param_1)

{
  undefined *puVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  longlong *plVar5;
  char cVar6;
  byte bVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  int *piVar10;
  undefined *puVar11;
  longlong lVar12;
  uint uVar13;
  char *pcVar14;
  longlong lVar15;
  longlong lVar16;
  char *pcVar17;
  longlong lVar18;
  longlong lVar19;
  char *pcVar20;
  longlong lVar21;
  longlong lVar22;
  longlong lVar23;
  int iVar24;
  longlong lVar25;
  longlong lVar26;
  int *piVar27;
  longlong lVar28;
  longlong local_res20;
  undefined8 in_stack_ffffffffffffffa0;
  undefined4 uVar29;
  
  piVar4 = *(int **)(param_1 + 0xa88e8);
  cVar6 = *(char *)(param_1 + 0xa8824);
  iVar2 = *piVar4;
  if (cVar6 != '\0') {
    if (cVar6 == '\x01') {
      cVar6 = FUN_140089c30(param_1 + 0x67250,*(undefined8 *)(param_1 + 0x67140));
      if (cVar6 == '\x01') {
        *(undefined1 *)(param_1 + 0xa8824) = 2;
        return 0;
      }
      return 0;
    }
    if (cVar6 != '\x02') {
      if (cVar6 == '\x03') {
        *(undefined1 *)(param_1 + 0xa8824) = 0;
        return 1;
      }
      return 0;
    }
    if ((*(char *)(param_1 + 0xa8828) == '\x02') &&
       (cVar6 = FUN_140089c30(param_1 + 0x680e0,*(longlong *)(param_1 + 0x67140) + 0x1c8),
       cVar6 != '\x01')) {
      return 0;
    }
    *(undefined1 *)(param_1 + 0xa8824) = 3;
    return 0;
  }
  lVar12 = 0;
  piVar27 = (int *)0x0;
  if ((0x26 < iVar2) && (piVar4[0x27] != 0)) {
    piVar27 = (int *)((longlong)piVar4 + (longlong)piVar4[0x27]);
  }
  bVar7 = (*piVar27 != 0) + 1;
  *(byte *)(param_1 + 0xa8828) = bVar7;
  uVar9 = DAT_14032c8f8;
  uVar8 = FUN_140200de0(DAT_14032c8f8,(uint)bVar7 * 5000,0x10);
  *(undefined8 *)(param_1 + 0x67130) = uVar8;
  uVar8 = FUN_140200de0(uVar9,*(char *)(param_1 + 0xa8828) * 0xd10,0x10);
  *(undefined8 *)(param_1 + 0x67138) = uVar8;
  uVar8 = FUN_140200de0(uVar9,*(char *)(param_1 + 0xa8828) * 0x1c8,0x10);
  *(undefined8 *)(param_1 + 0x67140) = uVar8;
  uVar8 = FUN_140200de0(uVar9,*(char *)(param_1 + 0xa8828) * 0x140,0x10);
  *(undefined8 *)(param_1 + 0x67148) = uVar8;
  uVar8 = FUN_140200de0(uVar9,*(char *)(param_1 + 0xa8828) * 0x18,0x10);
  *(undefined8 *)(param_1 + 0x67170) = uVar8;
  uVar9 = FUN_140200de0(uVar9,*(char *)(param_1 + 0xa8828) * 0x28,0x10);
  uVar13 = (uint)((ulonglong)in_stack_ffffffffffffffa0 >> 0x20);
  *(undefined8 *)(param_1 + 0x67178) = uVar9;
  if ('\0' < *(char *)(param_1 + 0xa8828)) {
    lVar23 = 0;
    local_res20 = 0;
    lVar22 = 0;
    lVar26 = 0;
    lVar28 = 0;
    iVar24 = 0;
    do {
      lVar18 = *(longlong *)(param_1 + 0x67140) + lVar28;
      lVar15 = local_res20 + *(longlong *)(param_1 + 0x67138);
      lVar21 = *(longlong *)(param_1 + 0x67148) + lVar26;
      lVar19 = *(longlong *)(param_1 + 0x67170);
      lVar16 = *(longlong *)(param_1 + 0x67178);
      lVar25 = (longlong)iVar24 * 5000 + *(longlong *)(param_1 + 0x67130);
      FUN_1400c4330(lVar25);
      FUN_1400c5240();
      uVar13 = (uint)((ulonglong)in_stack_ffffffffffffffa0 >> 0x20);
      *(undefined8 *)(lVar18 + 0x68) = 0;
      *(undefined8 *)(lVar18 + 0x70) = 0;
      *(undefined8 *)(lVar18 + 0x78) = 0;
      *(undefined8 *)(lVar18 + 0x60) = 0;
      *(undefined8 *)(lVar18 + 0x80) = 0;
      *(undefined8 *)(lVar18 + 0x88) = 0;
      *(undefined8 *)(lVar18 + 0x90) = 0;
      *(undefined4 *)(lVar18 + 0x98) = 1;
      *(undefined1 *)(lVar18 + 0x9c) = 1;
      *(undefined4 *)(lVar18 + 0xa0) = 0;
      *(undefined8 *)(lVar18 + 0xb8) = 0;
      *(undefined8 *)(lVar18 + 0xc0) = 0;
      *(undefined8 *)(lVar18 + 200) = 0;
      *(undefined8 *)(lVar18 + 0xb0) = 0;
      *(undefined8 *)(lVar18 + 0xd0) = 0;
      *(undefined8 *)(lVar18 + 0xd8) = 0;
      *(undefined8 *)(lVar18 + 0xe0) = 0;
      *(undefined4 *)(lVar18 + 0xe8) = 1;
      *(undefined1 *)(lVar18 + 0xec) = 1;
      *(undefined4 *)(lVar18 + 0xf0) = 0;
      *(undefined8 *)(lVar18 + 0xa8) = 0;
      *(undefined8 *)(lVar21 + 0x60) = 0;
      *(undefined8 *)(lVar21 + 0x68) = 0;
      *(undefined8 *)(lVar21 + 0x70) = 0;
      *(undefined8 *)(lVar21 + 0x58) = 0;
      *(undefined8 *)(lVar21 + 0x78) = 0;
      *(undefined8 *)(lVar21 + 0x80) = 0;
      *(undefined8 *)(lVar21 + 0x88) = 0;
      *(undefined4 *)(lVar21 + 0x90) = 1;
      *(undefined1 *)(lVar21 + 0x94) = 1;
      *(undefined4 *)(lVar21 + 0x98) = 0;
      *(undefined4 *)(lVar21 + 0xa0) = 0;
      *(undefined4 *)(lVar21 + 0xc0) = 0;
      *(undefined4 *)(lVar21 + 0xe0) = 0;
      *(undefined4 *)(lVar21 + 0x100) = 0;
      *(undefined8 *)(lVar22 + lVar19) = 0;
      *(undefined8 *)(lVar22 + 8 + lVar19) = 0;
      *(undefined1 *)(lVar22 + 0x10 + lVar19) = 0;
      *(undefined8 *)(lVar23 + lVar16) = 0;
      *(undefined8 *)(lVar23 + 8 + lVar16) = 0;
      *(undefined8 *)(lVar23 + 0x10 + lVar16) = 0;
      *(undefined8 *)(lVar23 + 0x20 + lVar16) = 0;
      *(undefined8 *)(lVar23 + 0x18 + lVar16) = 0;
      if ((*(char *)(param_1 + 0xa8794) == '\x1c') || (*(char *)(param_1 + 0xa8794) == 'F')) {
        bVar7 = *(byte *)(lVar22 + 0x10 + lVar19) | 1;
      }
      else {
        bVar7 = *(byte *)(lVar22 + 0x10 + lVar19) & 0xfe;
      }
      iVar24 = iVar24 + 1;
      *(byte *)(lVar22 + 0x10 + lVar19) = bVar7;
      local_res20 = local_res20 + 0xd10;
      *(longlong *)(lVar15 + 0xd08) = lVar25;
      lVar28 = lVar28 + 0x1c8;
      *(longlong *)(lVar18 + 0x18) = lVar25;
      lVar26 = lVar26 + 0x140;
      *(longlong *)(lVar21 + 0x18) = lVar25;
      *(longlong *)(lVar22 + lVar19) = lVar18;
      *(longlong *)(lVar22 + 8 + lVar19) = lVar21;
      lVar22 = lVar22 + 0x18;
      *(longlong *)(lVar23 + lVar16) = lVar25;
      *(longlong *)(lVar23 + 8 + lVar16) = lVar18;
      *(longlong *)(lVar23 + 0x10 + lVar16) = lVar21;
      lVar23 = lVar23 + 0x28;
    } while (iVar24 < *(char *)(param_1 + 0xa8828));
  }
  if (iVar2 < 0x13) {
    lVar22 = 0;
    *(undefined8 *)(param_1 + 0x67190) = 0;
LAB_1400c8527:
    *(undefined8 *)(param_1 + 0x67198) = 0;
    if (0xb < iVar2) goto LAB_1400c857c;
    *(undefined8 *)(param_1 + 0x671b0) = 0;
    **(longlong **)(param_1 + 0x67130) = lVar22 + 0x2f0;
    lVar23 = *(longlong *)(param_1 + 0x67130);
    if (10 < iVar2) goto LAB_1400c85af;
    lVar26 = 0;
  }
  else {
    if (piVar4[0x13] == 0) {
      lVar22 = 0;
    }
    else {
      lVar22 = (longlong)piVar4 + (longlong)piVar4[0x13];
    }
    if (piVar4[0x13] == 0) {
      lVar23 = 0;
    }
    else {
      lVar23 = (longlong)piVar4[0x13] + (longlong)piVar4;
    }
    *(longlong *)(param_1 + 0x67190) = lVar23;
    if (iVar2 < 0x26) goto LAB_1400c8527;
    if (piVar4[0x26] == 0) {
      *(undefined8 *)(param_1 + 0x67198) = 0;
    }
    else {
      *(longlong *)(param_1 + 0x67198) = (longlong)piVar4[0x26] + (longlong)piVar4;
    }
LAB_1400c857c:
    if (piVar4[0xc] == 0) {
      *(undefined8 *)(param_1 + 0x671b0) = 0;
    }
    else {
      *(longlong *)(param_1 + 0x671b0) = (longlong)piVar4[0xc] + (longlong)piVar4;
    }
    **(longlong **)(param_1 + 0x67130) = lVar22 + 0x2f0;
    lVar23 = *(longlong *)(param_1 + 0x67130);
LAB_1400c85af:
    lVar26 = 0;
    if (piVar4[0xb] != 0) {
      lVar26 = (longlong)piVar4 + (longlong)piVar4[0xb];
    }
  }
  if (*(char *)(lVar26 + 0x13) != '\x1b') {
    *(undefined1 *)(lVar26 + 0x13) = 0x1b;
  }
  FUN_1402038c0(lVar23 + 0x238);
  if (*(undefined2 **)(lVar23 + 0x248) != (undefined2 *)0x0) {
    **(undefined2 **)(lVar23 + 0x248) = 0x1e00;
    if (*(undefined2 **)(lVar23 + 0x250) != (undefined2 *)0x0) {
      **(undefined2 **)(lVar23 + 0x250) = 0x3f04;
    }
    FUN_140203a40(lVar23 + 0x238);
  }
  if (iVar2 < 0x25) {
    piVar10 = (int *)0x0;
  }
  else if (piVar4[0x25] == 0) {
    piVar10 = (int *)0x0;
  }
  else {
    piVar10 = (int *)((longlong)piVar4[0x25] + (longlong)piVar4);
  }
  lVar23 = *(longlong *)(param_1 + 0x67130);
  if (*piVar10 == 0) {
    *(undefined8 *)(lVar23 + 0x1380) = 0;
    piVar10 = (int *)0x0;
  }
  *(int **)(lVar23 + 0x1378) = piVar10;
  lVar23 = 0;
  if (iVar2 < 0x14) {
    if (0xb < iVar2) goto LAB_1400c865c;
    lVar26 = 0;
  }
  else {
    if (piVar4[0x14] != 0) {
      lVar23 = (longlong)piVar4 + (longlong)piVar4[0x14];
    }
LAB_1400c865c:
    lVar26 = 0;
    if (piVar4[0xc] != 0) {
      lVar26 = (longlong)piVar4 + (longlong)piVar4[0xc];
    }
  }
  FUN_14007fc50(*(undefined8 *)(param_1 + 0x67138),lVar22 + 0x30,lVar26,lVar23);
  *(longlong *)(*(longlong *)(param_1 + 0x67138) + 0xa98) = param_1 + 0x240;
  **(longlong **)(param_1 + 0x67140) = lVar22;
  if (iVar2 < 9) {
    lVar23 = 0;
    if (7 < iVar2) goto LAB_1400c876c;
    lVar26 = 0;
    if (6 < iVar2) goto LAB_1400c877b;
    lVar28 = 0;
    if (5 < iVar2) goto LAB_1400c878a;
    FUN_1400c45c0(*(undefined8 *)(param_1 + 0x67140),0,0,0,0,(ulonglong)uVar13 << 0x20);
    lVar23 = *(longlong *)(param_1 + 0x67140);
    if (4 < iVar2) goto LAB_1400c87b1;
    lVar26 = 0;
    if (3 < iVar2) goto LAB_1400c87c0;
    lVar28 = 0;
    if (2 < iVar2) goto LAB_1400c87d0;
    *(undefined8 *)(lVar23 + 0x108) = 0;
    *(undefined8 *)(lVar23 + 0x110) = 0;
    *(undefined8 *)(lVar23 + 0x118) = 0;
    lVar23 = *(longlong *)(param_1 + 0x67140);
    if (1 < iVar2) goto LAB_1400c8802;
    lVar28 = 0;
    if (0 < iVar2) goto LAB_1400c8812;
    *(undefined8 *)(lVar23 + 0x120) = 0;
    *(undefined8 *)(lVar23 + 0x128) = 0;
    lVar23 = *(longlong *)(param_1 + 0x67140);
  }
  else {
    if (piVar4[9] == 0) {
      lVar23 = 0;
    }
    else {
      lVar23 = (longlong)piVar4[9] + (longlong)piVar4;
    }
LAB_1400c876c:
    lVar26 = 0;
    if (piVar4[8] != 0) {
      lVar26 = (longlong)piVar4 + (longlong)piVar4[8];
    }
LAB_1400c877b:
    lVar28 = 0;
    if (piVar4[7] != 0) {
      lVar28 = (longlong)piVar4 + (longlong)piVar4[7];
    }
LAB_1400c878a:
    if (piVar4[6] == 0) {
      lVar19 = 0;
    }
    else {
      lVar19 = (longlong)piVar4[6] + (longlong)piVar4;
    }
    FUN_1400c45c0(*(undefined8 *)(param_1 + 0x67140),lVar19,lVar28,lVar26,lVar23,
                  (ulonglong)uVar13 << 0x20);
    lVar23 = *(longlong *)(param_1 + 0x67140);
LAB_1400c87b1:
    lVar26 = 0;
    if (piVar4[5] != 0) {
      lVar26 = (longlong)piVar4 + (longlong)piVar4[5];
    }
LAB_1400c87c0:
    if (piVar4[4] == 0) {
      lVar28 = 0;
    }
    else {
      lVar28 = (longlong)piVar4[4] + (longlong)piVar4;
    }
LAB_1400c87d0:
    iVar24 = piVar4[3];
    *(longlong *)(lVar23 + 0x110) = lVar28;
    *(longlong *)(lVar23 + 0x118) = lVar26;
    if (iVar24 == 0) {
      *(undefined8 *)(lVar23 + 0x108) = 0;
    }
    else {
      *(longlong *)(lVar23 + 0x108) = (longlong)piVar4 + (longlong)iVar24;
    }
    lVar23 = *(longlong *)(param_1 + 0x67140);
LAB_1400c8802:
    if (piVar4[2] == 0) {
      lVar28 = 0;
    }
    else {
      lVar28 = (longlong)piVar4[2] + (longlong)piVar4;
    }
LAB_1400c8812:
    if (piVar4[1] == 0) {
      lVar26 = 0;
    }
    else {
      lVar26 = (longlong)piVar4[1] + (longlong)piVar4;
    }
    *(longlong *)(lVar23 + 0x120) = lVar26;
    *(longlong *)(lVar23 + 0x128) = lVar28;
    lVar23 = *(longlong *)(param_1 + 0x67140);
    if (iVar2 < 0xd) {
      lVar26 = 0;
    }
    else {
      lVar26 = 0;
      if (piVar4[0xd] != 0) {
        lVar26 = (longlong)piVar4 + (longlong)piVar4[0xd];
      }
    }
  }
  FUN_1402038c0(lVar23 + 0xb0,lVar26);
  if (*(undefined2 **)(lVar23 + 0xc0) != (undefined2 *)0x0) {
    **(undefined2 **)(lVar23 + 0xc0) = 0x3980;
    if (*(undefined2 **)(lVar23 + 200) != (undefined2 *)0x0) {
      **(undefined2 **)(lVar23 + 200) = 0x3f08;
    }
    FUN_140203a40(lVar23 + 0xb0);
  }
  lVar23 = 0;
  *(undefined4 *)(**(longlong **)(param_1 + 0x67140) + 4) = 0x46000000;
  lVar26 = *(longlong *)(param_1 + 0x67140);
  if ((9 < iVar2) && (piVar4[10] != 0)) {
    lVar23 = (longlong)piVar4 + (longlong)piVar4[10];
  }
  FUN_1402038c0(lVar26 + 0x60,lVar23);
  if (*(undefined2 **)(lVar26 + 0x70) != (undefined2 *)0x0) {
    **(undefined2 **)(lVar26 + 0x70) = 0x39a0;
    if (*(undefined2 **)(lVar26 + 0x78) != (undefined2 *)0x0) {
      **(undefined2 **)(lVar26 + 0x78) = 0x3f0c;
    }
    FUN_140203a40(lVar26 + 0x60);
  }
  **(longlong **)(param_1 + 0x67148) = lVar22 + 0x20;
  if (iVar2 < 0x12) {
    lVar23 = 0;
    if (0x10 < iVar2) goto LAB_1400c8933;
    lVar26 = 0;
    if (0xf < iVar2) goto LAB_1400c8943;
    lVar28 = 0;
    if (0xe < iVar2) goto LAB_1400c8952;
    lVar19 = 0;
    if (0xd < iVar2) goto LAB_1400c8961;
    lVar16 = 0;
  }
  else {
    if (piVar4[0x12] == 0) {
      lVar23 = 0;
    }
    else {
      lVar23 = (longlong)piVar4[0x12] + (longlong)piVar4;
    }
LAB_1400c8933:
    if (piVar4[0x11] == 0) {
      lVar26 = 0;
    }
    else {
      lVar26 = (longlong)piVar4[0x11] + (longlong)piVar4;
    }
LAB_1400c8943:
    lVar28 = 0;
    if (piVar4[0x10] != 0) {
      lVar28 = (longlong)piVar4 + (longlong)piVar4[0x10];
    }
LAB_1400c8952:
    lVar19 = 0;
    if (piVar4[0xf] != 0) {
      lVar19 = (longlong)piVar4 + (longlong)piVar4[0xf];
    }
LAB_1400c8961:
    if (piVar4[0xe] == 0) {
      lVar16 = 0;
    }
    else {
      lVar16 = (longlong)piVar4[0xe] + (longlong)piVar4;
    }
  }
  FUN_14007e0f0(*(undefined8 *)(param_1 + 0x67148),lVar16,lVar19,lVar28,lVar26,lVar23);
  uVar29 = (undefined4)((ulonglong)lVar23 >> 0x20);
  puVar1 = (undefined *)(lVar22 + 0x310);
  *(undefined **)(param_1 + 0x67e08) = puVar1;
  puVar11 = &DAT_14031edb0;
  if (puVar1 != (undefined *)0x0) {
    puVar11 = puVar1;
  }
  *(undefined **)(param_1 + 0x67e18) = puVar11;
  lVar22 = FUN_140189320();
  if (*(char *)(lVar22 + 0x27) != '\0') {
    lVar22 = 0;
    if (iVar2 < 2) {
      if (0 < iVar2) goto LAB_1400c89d8;
LAB_1400c8b1b:
      lVar22 = 0;
      if (0x1d < iVar2) goto LAB_1400c8b3e;
      lVar23 = 0;
      if (0x1c < iVar2) goto LAB_1400c8b4d;
LAB_1400c8b82:
      lVar22 = 0;
      if (0x20 < iVar2) goto LAB_1400c8ba8;
      lVar23 = 0;
      if (0x1f < iVar2) goto LAB_1400c8bba;
    }
    else {
      if (piVar4[2] != 0) {
        lVar22 = (longlong)piVar4 + (longlong)piVar4[2];
      }
LAB_1400c89d8:
      lVar23 = 0;
      if (piVar4[1] != 0) {
        lVar23 = (longlong)piVar4 + (longlong)piVar4[1];
      }
      if (((5 < iVar2) && (piVar4[6] != 0)) &&
         (lVar26 = (longlong)piVar4[6] + (longlong)piVar4, lVar26 != 0)) {
        *(longlong *)(param_1 + 0x67e40) = lVar26;
        _DAT_1403283c0 = 0;
        if (lVar23 != 0) {
          *(longlong *)(param_1 + 0x67e48) = lVar23;
          _DAT_1403283c4 = 0;
          if (lVar22 != 0) {
            *(longlong *)(param_1 + 0x67e50) = lVar22;
          }
        }
      }
      pcVar14 = (char *)0x0;
      if (iVar2 < 0x1c) {
        if (0x1a < iVar2) goto LAB_1400c8a52;
        pcVar17 = (char *)0x0;
        if (0x19 < iVar2) goto LAB_1400c8a61;
      }
      else {
        if (piVar4[0x1c] != 0) {
          pcVar14 = (char *)((longlong)piVar4 + (longlong)piVar4[0x1c]);
        }
LAB_1400c8a52:
        pcVar17 = (char *)0x0;
        if (piVar4[0x1b] != 0) {
          pcVar17 = (char *)((longlong)piVar4 + (longlong)piVar4[0x1b]);
        }
LAB_1400c8a61:
        if (((((piVar4[0x1a] != 0) &&
              (pcVar20 = (char *)((longlong)piVar4[0x1a] + (longlong)piVar4), pcVar20 != (char *)0x0
              )) && (pcVar17 != (char *)0x0)) &&
            (((*pcVar20 != 'd' || (pcVar20[1] != 'u')) ||
             ((pcVar20[2] != 'm' || ((pcVar20[3] != 'm' || (pcVar20[4] != 'y')))))))) &&
           ((*pcVar17 != 'd' ||
            ((((pcVar17[1] != 'u' || (pcVar17[2] != 'm')) || (pcVar17[3] != 'm')) ||
             (pcVar17[4] != 'y')))))) {
          *(char **)(param_1 + 0x680c0) = pcVar20;
          *(char **)(param_1 + 0x680b8) = pcVar17;
          *(undefined1 *)(param_1 + 0x680c8) = 1;
          *(undefined1 *)(param_1 + 0x6809a) = 1;
          _DAT_1403283e4 = 0;
        }
      }
      if ((pcVar14 != (char *)0x0) &&
         (((*pcVar14 != 'd' || (pcVar14[1] != 'u')) ||
          ((pcVar14[2] != 'm' || ((pcVar14[3] != 'm' || (pcVar14[4] != 'y')))))))) {
        *(char **)(param_1 + 0x680a0) = pcVar14;
        *(undefined1 *)(param_1 + 0x680a8) = 1;
        *(undefined1 *)(param_1 + 0x6809b) = 1;
        _DAT_1403283ec = 0;
      }
      if (iVar2 < 0x1f) goto LAB_1400c8b1b;
      lVar22 = 0;
      if (piVar4[0x1f] != 0) {
        lVar22 = (longlong)piVar4 + (longlong)piVar4[0x1f];
      }
LAB_1400c8b3e:
      lVar23 = 0;
      if (piVar4[0x1e] != 0) {
        lVar23 = (longlong)piVar4 + (longlong)piVar4[0x1e];
      }
LAB_1400c8b4d:
      if ((piVar4[0x1d] != 0) && (lVar26 = (longlong)piVar4[0x1d] + (longlong)piVar4, lVar26 != 0))
      {
        *(longlong *)(param_1 + 0x67378) = lVar26;
      }
      if (lVar23 != 0) {
        *(longlong *)(param_1 + 0x67758) = lVar23;
      }
      if (lVar22 != 0) {
        *(longlong *)(param_1 + 0x67b38) = lVar22;
      }
      if (iVar2 < 0x22) goto LAB_1400c8b82;
      lVar22 = 0;
      if (piVar4[0x22] != 0) {
        lVar22 = (longlong)piVar4 + (longlong)piVar4[0x22];
      }
LAB_1400c8ba8:
      lVar23 = 0;
      if (piVar4[0x21] != 0) {
        lVar23 = (longlong)piVar4 + (longlong)piVar4[0x21];
      }
LAB_1400c8bba:
      if ((piVar4[0x20] != 0) && (lVar26 = (longlong)piVar4[0x20] + (longlong)piVar4, lVar26 != 0))
      {
        *(longlong *)(param_1 + 0x67380) = lVar26;
      }
      if (lVar23 != 0) {
        *(longlong *)(param_1 + 0x67760) = lVar23;
      }
      if (lVar22 != 0) {
        *(longlong *)(param_1 + 0x67b40) = lVar22;
      }
    }
    FUN_140089ac0(param_1 + 0x67250,*(undefined8 *)(param_1 + 0x67140));
  }
  if (iVar2 < 0x19) {
    lVar22 = 0;
  }
  else if (piVar4[0x19] == 0) {
    lVar22 = 0;
  }
  else {
    lVar22 = (longlong)piVar4[0x19] + (longlong)piVar4;
  }
  *(longlong *)(param_1 + 0xa8700) = lVar22;
  *(undefined8 *)(param_1 + 0xa8708) = 0;
  lVar22 = FUN_140189320();
  if (*(char *)(lVar22 + 0x32) != '\0') {
    pcVar14 = (char *)0x0;
    if (iVar2 < 0x24) {
      if (0x22 < iVar2) goto LAB_1400c8c83;
    }
    else {
      if (piVar4[0x24] != 0) {
        pcVar14 = (char *)((longlong)piVar4 + (longlong)piVar4[0x24]);
      }
LAB_1400c8c83:
      if (((((piVar4[0x23] != 0) &&
            (pcVar17 = (char *)((longlong)piVar4[0x23] + (longlong)piVar4), pcVar17 != (char *)0x0))
           && (pcVar14 != (char *)0x0)) &&
          (((*pcVar17 != 'd' || (pcVar17[1] != 'u')) ||
           ((pcVar17[2] != 'm' || ((pcVar17[3] != 'm' || (pcVar17[4] != 'y')))))))) &&
         (((*pcVar14 != 'd' || (((pcVar14[1] != 'u' || (pcVar14[2] != 'm')) || (pcVar14[3] != 'm')))
           ) || (pcVar14[4] != 'y')))) {
        *(char **)(param_1 + 0x69598) = pcVar17;
        *(char **)(param_1 + 0x695a0) = pcVar14;
        *(undefined1 *)(param_1 + 0x695a8) = 1;
        goto LAB_1400c8c49;
      }
    }
    *(undefined1 *)(param_1 + 0x695a8) = 0;
  }
LAB_1400c8c49:
  if (*(char *)(param_1 + 0xa8828) != '\x02') goto LAB_1400c9475;
  iVar24 = *piVar27;
  if (iVar24 < 0x13) {
    lVar22 = 0;
    *(undefined8 *)(param_1 + 0x671a0) = 0;
LAB_1400c8d26:
    *(undefined8 *)(param_1 + 0x671a8) = 0;
    if (0xb < iVar24) goto LAB_1400c8d7d;
    *(undefined8 *)(param_1 + 0x671b8) = 0;
    *(longlong *)(*(longlong *)(param_1 + 0x67130) + 5000) = lVar22 + 0x2f0;
    lVar23 = *(longlong *)(param_1 + 0x67130);
    if (10 < iVar24) goto LAB_1400c8db4;
    lVar26 = 0;
  }
  else {
    if (piVar27[0x13] == 0) {
      lVar22 = 0;
    }
    else {
      lVar22 = (longlong)piVar27 + (longlong)piVar27[0x13];
    }
    if (piVar27[0x13] == 0) {
      lVar23 = 0;
    }
    else {
      lVar23 = (longlong)piVar27[0x13] + (longlong)piVar27;
    }
    *(longlong *)(param_1 + 0x671a0) = lVar23;
    if (iVar24 < 0x26) goto LAB_1400c8d26;
    if (piVar27[0x26] == 0) {
      *(undefined8 *)(param_1 + 0x671a8) = 0;
    }
    else {
      *(longlong *)(param_1 + 0x671a8) = (longlong)piVar27[0x26] + (longlong)piVar27;
    }
LAB_1400c8d7d:
    if (piVar27[0xc] == 0) {
      *(undefined8 *)(param_1 + 0x671b8) = 0;
    }
    else {
      *(longlong *)(param_1 + 0x671b8) = (longlong)piVar27[0xc] + (longlong)piVar27;
    }
    *(longlong *)(*(longlong *)(param_1 + 0x67130) + 5000) = lVar22 + 0x2f0;
    lVar23 = *(longlong *)(param_1 + 0x67130);
LAB_1400c8db4:
    lVar26 = 0;
    if (piVar27[0xb] != 0) {
      lVar26 = (longlong)piVar27 + (longlong)piVar27[0xb];
    }
  }
  if (*(char *)(lVar26 + 0x13) != '\x1b') {
    *(undefined1 *)(lVar26 + 0x13) = 0x1b;
  }
  FUN_1402038c0(lVar23 + 0x15c0);
  if (*(undefined2 **)(lVar23 + 0x15d0) != (undefined2 *)0x0) {
    **(undefined2 **)(lVar23 + 0x15d0) = 0x1e00;
    if (*(undefined2 **)(lVar23 + 0x15d8) != (undefined2 *)0x0) {
      **(undefined2 **)(lVar23 + 0x15d8) = 0x3f04;
    }
    FUN_140203a40(lVar23 + 0x15c0);
  }
  if (iVar24 < 0x25) {
    piVar10 = (int *)0x0;
  }
  else if (piVar27[0x25] == 0) {
    piVar10 = (int *)0x0;
  }
  else {
    piVar10 = (int *)((longlong)piVar27[0x25] + (longlong)piVar27);
  }
  lVar23 = *(longlong *)(param_1 + 0x67130);
  if (*piVar10 == 0) {
    *(undefined8 *)(lVar23 + 0x2708) = 0;
    piVar10 = (int *)0x0;
  }
  *(int **)(lVar23 + 0x2700) = piVar10;
  lVar23 = 0;
  if (iVar24 < 0x14) {
    if (0xb < iVar24) goto LAB_1400c8e6c;
    lVar26 = 0;
  }
  else {
    if (piVar27[0x14] != 0) {
      lVar23 = (longlong)piVar27 + (longlong)piVar27[0x14];
    }
LAB_1400c8e6c:
    lVar26 = 0;
    if (piVar27[0xc] != 0) {
      lVar26 = (longlong)piVar27 + (longlong)piVar27[0xc];
    }
  }
  FUN_14007fc50(*(longlong *)(param_1 + 0x67138) + 0xd10,lVar22 + 0x30,lVar26,lVar23);
  *(longlong *)(*(longlong *)(param_1 + 0x67138) + 0x17a8) = param_1 + 0x240;
  *(longlong *)(*(longlong *)(param_1 + 0x67140) + 0x1c8) = lVar22;
  lVar23 = *(longlong *)(param_1 + 0x67140) + 0x1c8;
  if (iVar24 < 9) {
    lVar26 = 0;
    if (7 < iVar24) goto LAB_1400c8f7b;
    lVar28 = 0;
    if (6 < iVar24) goto LAB_1400c8f8a;
    lVar19 = 0;
    if (5 < iVar24) goto LAB_1400c8f99;
    FUN_1400c45c0(lVar23,0,0,0,0,CONCAT44(uVar29,1));
    lVar23 = *(longlong *)(param_1 + 0x67140);
    if (4 < iVar24) goto LAB_1400c8fc4;
    lVar26 = 0;
    if (3 < iVar24) goto LAB_1400c8fd3;
    lVar28 = 0;
    if (2 < iVar24) goto LAB_1400c8fe3;
    *(undefined8 *)(lVar23 + 0x2d0) = 0;
    *(undefined8 *)(lVar23 + 0x2d8) = 0;
    *(undefined8 *)(lVar23 + 0x2e0) = 0;
    lVar23 = *(longlong *)(param_1 + 0x67140);
    if (1 < iVar24) goto LAB_1400c9015;
    lVar28 = 0;
    if (0 < iVar24) goto LAB_1400c9025;
    *(undefined8 *)(lVar23 + 0x2e8) = 0;
    *(undefined8 *)(lVar23 + 0x2f0) = 0;
    lVar23 = *(longlong *)(param_1 + 0x67140);
  }
  else {
    if (piVar27[9] == 0) {
      lVar26 = 0;
    }
    else {
      lVar26 = (longlong)piVar27[9] + (longlong)piVar27;
    }
LAB_1400c8f7b:
    lVar28 = 0;
    if (piVar27[8] != 0) {
      lVar28 = (longlong)piVar27 + (longlong)piVar27[8];
    }
LAB_1400c8f8a:
    lVar19 = 0;
    if (piVar27[7] != 0) {
      lVar19 = (longlong)piVar27 + (longlong)piVar27[7];
    }
LAB_1400c8f99:
    if (piVar27[6] == 0) {
      lVar16 = 0;
    }
    else {
      lVar16 = (longlong)piVar27[6] + (longlong)piVar27;
    }
    FUN_1400c45c0(lVar23,lVar16,lVar19,lVar28,lVar26,CONCAT44(uVar29,1));
    lVar23 = *(longlong *)(param_1 + 0x67140);
LAB_1400c8fc4:
    lVar26 = 0;
    if (piVar27[5] != 0) {
      lVar26 = (longlong)piVar27 + (longlong)piVar27[5];
    }
LAB_1400c8fd3:
    if (piVar27[4] == 0) {
      lVar28 = 0;
    }
    else {
      lVar28 = (longlong)piVar27[4] + (longlong)piVar27;
    }
LAB_1400c8fe3:
    iVar3 = piVar27[3];
    *(longlong *)(lVar23 + 0x2d8) = lVar28;
    *(longlong *)(lVar23 + 0x2e0) = lVar26;
    if (iVar3 == 0) {
      *(undefined8 *)(lVar23 + 0x2d0) = 0;
    }
    else {
      *(longlong *)(lVar23 + 0x2d0) = (longlong)piVar27 + (longlong)iVar3;
    }
    lVar23 = *(longlong *)(param_1 + 0x67140);
LAB_1400c9015:
    if (piVar27[2] == 0) {
      lVar28 = 0;
    }
    else {
      lVar28 = (longlong)piVar27[2] + (longlong)piVar27;
    }
LAB_1400c9025:
    if (piVar27[1] == 0) {
      lVar26 = 0;
    }
    else {
      lVar26 = (longlong)piVar27[1] + (longlong)piVar27;
    }
    *(longlong *)(lVar23 + 0x2e8) = lVar26;
    *(longlong *)(lVar23 + 0x2f0) = lVar28;
    lVar23 = *(longlong *)(param_1 + 0x67140);
    if (iVar24 < 0xd) {
      lVar26 = 0;
    }
    else {
      lVar26 = 0;
      if (piVar27[0xd] != 0) {
        lVar26 = (longlong)piVar27 + (longlong)piVar27[0xd];
      }
    }
  }
  FUN_1402038c0(lVar23 + 0x278,lVar26);
  if (*(undefined2 **)(lVar23 + 0x288) != (undefined2 *)0x0) {
    **(undefined2 **)(lVar23 + 0x288) = 0x3980;
    if (*(undefined2 **)(lVar23 + 0x290) != (undefined2 *)0x0) {
      **(undefined2 **)(lVar23 + 0x290) = 0x3f08;
    }
    FUN_140203a40(lVar23 + 0x278);
  }
  lVar23 = 0;
  *(undefined4 *)(*(longlong *)(*(longlong *)(param_1 + 0x67140) + 0x1c8) + 4) = 0x46000000;
  lVar26 = *(longlong *)(param_1 + 0x67140);
  if ((9 < iVar24) && (piVar27[10] != 0)) {
    lVar23 = (longlong)piVar27 + (longlong)piVar27[10];
  }
  FUN_1402038c0(lVar26 + 0x228,lVar23);
  if (*(undefined2 **)(lVar26 + 0x238) != (undefined2 *)0x0) {
    **(undefined2 **)(lVar26 + 0x238) = 0x39a0;
    if (*(undefined2 **)(lVar26 + 0x240) != (undefined2 *)0x0) {
      **(undefined2 **)(lVar26 + 0x240) = 0x3f0c;
    }
    FUN_140203a40(lVar26 + 0x228);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x67148) + 0x140) = lVar22 + 0x20;
  if (iVar24 < 0x12) {
    lVar23 = 0;
    if (0x10 < iVar24) goto LAB_1400c915a;
    lVar26 = 0;
    if (0xf < iVar24) goto LAB_1400c916a;
    lVar28 = 0;
    if (0xe < iVar24) goto LAB_1400c9179;
    lVar19 = 0;
    if (0xd < iVar24) goto LAB_1400c9188;
    lVar16 = 0;
  }
  else {
    if (piVar27[0x12] == 0) {
      lVar23 = 0;
    }
    else {
      lVar23 = (longlong)piVar27[0x12] + (longlong)piVar27;
    }
LAB_1400c915a:
    if (piVar27[0x11] == 0) {
      lVar26 = 0;
    }
    else {
      lVar26 = (longlong)piVar27[0x11] + (longlong)piVar27;
    }
LAB_1400c916a:
    lVar28 = 0;
    if (piVar27[0x10] != 0) {
      lVar28 = (longlong)piVar27 + (longlong)piVar27[0x10];
    }
LAB_1400c9179:
    lVar19 = 0;
    if (piVar27[0xf] != 0) {
      lVar19 = (longlong)piVar27 + (longlong)piVar27[0xf];
    }
LAB_1400c9188:
    if (piVar27[0xe] == 0) {
      lVar16 = 0;
    }
    else {
      lVar16 = (longlong)piVar27[0xe] + (longlong)piVar27;
    }
  }
  FUN_14007e0f0(*(longlong *)(param_1 + 0x67148) + 0x140,lVar16,lVar19,lVar28,lVar26,lVar23);
  puVar1 = (undefined *)(lVar22 + 0x310);
  *(undefined **)(param_1 + 0x68c98) = puVar1;
  puVar11 = &DAT_14031edb0;
  if (puVar1 != (undefined *)0x0) {
    puVar11 = puVar1;
  }
  *(undefined **)(param_1 + 0x68ca8) = puVar11;
  lVar22 = FUN_140189320();
  if ((*(char *)(lVar22 + 0x27) != '\0') && ((*(byte *)(param_1 + 0x68f70) & 1) == 0)) {
    lVar22 = 0;
    if (iVar24 < 2) {
      if (0 < iVar24) goto LAB_1400c920a;
LAB_1400c9348:
      lVar22 = 0;
      if (0x1d < iVar24) goto LAB_1400c9369;
      lVar23 = 0;
      if (0x1c < iVar24) goto LAB_1400c9378;
LAB_1400c93ac:
      lVar22 = 0;
      if (0x20 < iVar24) goto LAB_1400c93d0;
      lVar23 = 0;
      if (0x1f < iVar24) goto LAB_1400c93e2;
    }
    else {
      if (piVar27[2] != 0) {
        lVar22 = (longlong)piVar27 + (longlong)piVar27[2];
      }
LAB_1400c920a:
      lVar23 = 0;
      if (piVar27[1] != 0) {
        lVar23 = (longlong)piVar27 + (longlong)piVar27[1];
      }
      if (((5 < iVar24) && (piVar27[6] != 0)) &&
         (lVar26 = (longlong)piVar27[6] + (longlong)piVar27, lVar26 != 0)) {
        *(longlong *)(param_1 + 0x68cd0) = lVar26;
        _DAT_1403283c0 = 0;
        if (lVar23 != 0) {
          *(longlong *)(param_1 + 0x68cd8) = lVar23;
          _DAT_1403283c4 = 0;
          if (lVar22 != 0) {
            *(longlong *)(param_1 + 0x68ce0) = lVar22;
          }
        }
      }
      pcVar14 = (char *)0x0;
      if (iVar24 < 0x1c) {
        if (0x1a < iVar24) goto LAB_1400c9280;
        pcVar17 = (char *)0x0;
        if (0x19 < iVar24) goto LAB_1400c928f;
      }
      else {
        if (piVar27[0x1c] != 0) {
          pcVar14 = (char *)((longlong)piVar27 + (longlong)piVar27[0x1c]);
        }
LAB_1400c9280:
        pcVar17 = (char *)0x0;
        if (piVar27[0x1b] != 0) {
          pcVar17 = (char *)((longlong)piVar27 + (longlong)piVar27[0x1b]);
        }
LAB_1400c928f:
        if ((((piVar27[0x1a] != 0) &&
             (pcVar20 = (char *)((longlong)piVar27[0x1a] + (longlong)piVar27),
             pcVar20 != (char *)0x0)) && (pcVar17 != (char *)0x0)) &&
           ((((*pcVar20 != 'd' || (pcVar20[1] != 'u')) ||
             ((pcVar20[2] != 'm' || ((pcVar20[3] != 'm' || (pcVar20[4] != 'y')))))) &&
            ((*pcVar17 != 'd' ||
             ((((pcVar17[1] != 'u' || (pcVar17[2] != 'm')) || (pcVar17[3] != 'm')) ||
              (pcVar17[4] != 'y')))))))) {
          *(char **)(param_1 + 0x68f50) = pcVar20;
          *(char **)(param_1 + 0x68f48) = pcVar17;
          *(undefined1 *)(param_1 + 0x68f58) = 1;
          *(undefined1 *)(param_1 + 0x68f2a) = 1;
          _DAT_1403283e4 = 0;
        }
      }
      if ((pcVar14 != (char *)0x0) &&
         (((*pcVar14 != 'd' || (pcVar14[1] != 'u')) ||
          ((pcVar14[2] != 'm' || ((pcVar14[3] != 'm' || (pcVar14[4] != 'y')))))))) {
        *(char **)(param_1 + 0x68f30) = pcVar14;
        *(undefined1 *)(param_1 + 0x68f38) = 1;
        *(undefined1 *)(param_1 + 0x68f2b) = 1;
        _DAT_1403283ec = 0;
      }
      if (iVar24 < 0x1f) goto LAB_1400c9348;
      lVar22 = 0;
      if (piVar27[0x1f] != 0) {
        lVar22 = (longlong)piVar27 + (longlong)piVar27[0x1f];
      }
LAB_1400c9369:
      lVar23 = 0;
      if (piVar27[0x1e] != 0) {
        lVar23 = (longlong)piVar27 + (longlong)piVar27[0x1e];
      }
LAB_1400c9378:
      if ((piVar27[0x1d] != 0) &&
         (lVar26 = (longlong)piVar27[0x1d] + (longlong)piVar27, lVar26 != 0)) {
        *(longlong *)(param_1 + 0x68208) = lVar26;
      }
      if (lVar23 != 0) {
        *(longlong *)(param_1 + 0x685e8) = lVar23;
      }
      if (lVar22 != 0) {
        *(longlong *)(param_1 + 0x689c8) = lVar22;
      }
      if (iVar24 < 0x22) goto LAB_1400c93ac;
      lVar22 = 0;
      if (piVar27[0x22] != 0) {
        lVar22 = (longlong)piVar27 + (longlong)piVar27[0x22];
      }
LAB_1400c93d0:
      lVar23 = 0;
      if (piVar27[0x21] != 0) {
        lVar23 = (longlong)piVar27 + (longlong)piVar27[0x21];
      }
LAB_1400c93e2:
      if ((piVar27[0x20] != 0) &&
         (lVar26 = (longlong)piVar27[0x20] + (longlong)piVar27, lVar26 != 0)) {
        *(longlong *)(param_1 + 0x68210) = lVar26;
      }
      if (lVar23 != 0) {
        *(longlong *)(param_1 + 0x685f0) = lVar23;
      }
      if (lVar22 != 0) {
        *(longlong *)(param_1 + 0x689d0) = lVar22;
      }
    }
    FUN_140089ac0(param_1 + 0x680e0,*(longlong *)(param_1 + 0x67140) + 0x1c8);
  }
  if (iVar24 < 0x19) {
    lVar22 = 0;
  }
  else if (piVar27[0x19] == 0) {
    lVar22 = 0;
  }
  else {
    lVar22 = (longlong)piVar27[0x19] + (longlong)piVar27;
  }
  *(longlong *)(param_1 + 0xa8708) = lVar22;
  lVar22 = FUN_140189320();
  if (*(char *)(lVar22 + 0x32) == '\0') goto LAB_1400c9475;
  pcVar14 = (char *)0x0;
  if (iVar24 < 0x24) {
    if (0x22 < iVar24) goto LAB_1400c94b8;
  }
  else {
    if (piVar27[0x24] != 0) {
      pcVar14 = (char *)((longlong)piVar27 + (longlong)piVar27[0x24]);
    }
LAB_1400c94b8:
    if (((((piVar27[0x23] != 0) &&
          (pcVar17 = (char *)((longlong)piVar27[0x23] + (longlong)piVar27), pcVar17 != (char *)0x0))
         && (pcVar14 != (char *)0x0)) &&
        (((*pcVar17 != 'd' || (pcVar17[1] != 'u')) ||
         ((pcVar17[2] != 'm' || ((pcVar17[3] != 'm' || (pcVar17[4] != 'y')))))))) &&
       (((*pcVar14 != 'd' || (((pcVar14[1] != 'u' || (pcVar14[2] != 'm')) || (pcVar14[3] != 'm'))))
        || (pcVar14[4] != 'y')))) {
      *(char **)(param_1 + 0x695b0) = pcVar17;
      *(char **)(param_1 + 0x695b8) = pcVar14;
      *(undefined1 *)(param_1 + 0x695c0) = 1;
      goto LAB_1400c9475;
    }
  }
  *(undefined1 *)(param_1 + 0x695c0) = 0;
LAB_1400c9475:
  if (iVar2 < 0x15) {
    FUN_1400c2730(param_1 + 0x240,0);
    FUN_1400c2730(param_1 + 0x339b0,0);
    lVar22 = 0;
  }
  else {
    lVar22 = 0;
    if (piVar4[0x15] != 0) {
      lVar22 = (longlong)piVar4 + (longlong)piVar4[0x15];
    }
    FUN_1400c2730(param_1 + 0x240,lVar22);
    FUN_1400c2730(param_1 + 0x339b0,lVar22);
    if (iVar2 < 0x16) {
      lVar22 = 0;
    }
    else if (piVar4[0x16] == 0) {
      lVar22 = 0;
    }
    else {
      lVar22 = (longlong)piVar4[0x16] + (longlong)piVar4;
    }
  }
  *(longlong *)(param_1 + 0x2fee0) = lVar22;
  *(undefined4 *)(param_1 + 0x2fee8) = 0x3e003000;
  *(longlong *)(param_1 + 0x63650) = lVar22;
  *(undefined4 *)(param_1 + 0x63658) = 0x3e003000;
  if (iVar2 < 0x17) {
    lVar22 = 0;
  }
  else if (piVar4[0x17] == 0) {
    lVar22 = 0;
  }
  else {
    lVar22 = (longlong)piVar4[0x17] + (longlong)piVar4;
  }
  *(longlong *)(param_1 + 0x2fef0) = lVar22;
  *(undefined4 *)(param_1 + 0x2fef8) = 0x3e043100;
  *(longlong *)(param_1 + 0x63660) = lVar22;
  *(undefined4 *)(param_1 + 0x63668) = 0x3e043100;
  if ((0x17 < iVar2) && (piVar4[0x18] != 0)) {
    lVar12 = (longlong)piVar4 + (longlong)piVar4[0x18];
  }
  *(longlong *)(param_1 + 0x2ff00) = lVar12;
  *(undefined4 *)(param_1 + 0x2ff08) = 0x3e083200;
  *(longlong *)(param_1 + 0x63670) = lVar12;
  *(undefined4 *)(param_1 + 0x63678) = 0x3e083200;
  plVar5 = *(longlong **)(param_1 + 0x67140);
  *(longlong **)(param_1 + 0x33920) = plVar5;
  *(longlong **)(param_1 + 0x67090) = plVar5;
  uVar29 = *(undefined4 *)(*plVar5 + 8);
  *(undefined4 *)(param_1 + 0x3393c) = uVar29;
  *(undefined4 *)(param_1 + 0x670ac) = uVar29;
  uVar13 = ~(uint)*(ushort *)(*plVar5 + 2) & 1;
  *(uint *)(param_1 + 0x33940) = uVar13;
  *(uint *)(param_1 + 0x670b0) = uVar13;
  lVar12 = *(longlong *)(param_1 + 0x67138) + 0x7c8;
  *(longlong *)(param_1 + 0x1be80) = lVar12;
  *(longlong *)(param_1 + 0x4f5f0) = lVar12;
  *(undefined1 *)(param_1 + 0xa8824) = 1;
  return 0;
}

