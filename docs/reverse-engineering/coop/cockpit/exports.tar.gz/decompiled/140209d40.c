/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140209d40; RVA 0x209d40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140209d40(ulonglong param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined4 uVar3;
  ulonglong uVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 uVar7;
  int iVar8;
  ulonglong uVar9;
  undefined8 *puVar10;
  ulonglong uVar11;
  longlong lVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined1 local_88 [16];
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined2 uStack_48;
  undefined2 uStack_46;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined8 uStack_38;
  undefined8 uStack_30;
  undefined4 uStack_28;
  
  if ((((*(char *)(param_1 + 0x40) != '\0') || (*(int *)(param_1 + 0x28c) != DAT_1403566dc)) ||
      (*(int *)(param_1 + 0x2ac) != DAT_1403566e0)) || (*(int *)(param_1 + 0x2b0) != DAT_1403566d8))
  {
    puVar1 = (undefined8 *)(param_1 + 0x20);
    plVar2 = *(longlong **)(DAT_14033da48 + 0x10);
    puVar10 = puVar1;
    if (0xf < *(ulonglong *)(param_1 + 0x38)) {
      puVar10 = (undefined8 *)*puVar1;
    }
    uVar11 = 0xcbf29ce484222325;
    uVar4 = 0;
    uVar9 = param_1;
    if (*(ulonglong *)(param_1 + 0x30) != 0) {
      do {
        uVar9 = (ulonglong)*(byte *)(uVar4 + (longlong)puVar10);
        uVar4 = uVar4 + 1;
        uVar11 = (uVar11 ^ uVar9) * 0x100000001b3;
      } while (uVar4 < *(ulonglong *)(param_1 + 0x30));
    }
    lVar5 = FUN_140212800(uVar9,local_88,puVar1,uVar11);
    lVar12 = DAT_140356768;
    if (*(longlong *)(lVar5 + 8) != 0) {
      lVar12 = *(longlong *)(lVar5 + 8);
    }
    (**(code **)(*plVar2 + 0xf0))(plVar2,*(undefined8 *)(lVar12 + 0xb8));
    *(undefined8 *)(param_1 + 0x48) = *(undefined8 *)(lVar12 + 0xb8);
    lVar5 = *(longlong *)(lVar12 + 0x70);
    lVar6 = *(longlong *)(lVar12 + 0x78);
    *(longlong *)(param_1 + 0x50) = lVar5;
    *(longlong *)(param_1 + 0x58) = lVar6 - lVar5;
    lVar5 = *(longlong *)(lVar12 + 0x88);
    lVar6 = *(longlong *)(lVar12 + 0x90) - lVar5;
    if (lVar6 == 0) {
      lVar5 = 0;
    }
    *(longlong *)(param_1 + 0x60) = lVar5;
    *(longlong *)(param_1 + 0x68) = lVar6;
    lVar5 = *(longlong *)(lVar12 + 0xa0);
    lVar6 = *(longlong *)(lVar12 + 0xa8) - lVar5;
    if (lVar6 == 0) {
      lVar5 = 0;
    }
    *(longlong *)(param_1 + 0x90) = lVar5;
    *(longlong *)(param_1 + 0x98) = lVar6;
    *(int *)(param_1 + 0x28c) = DAT_1403566dc;
    iVar8 = -DAT_1403566d8;
    if (-DAT_1403566d8 < 0) {
      iVar8 = DAT_1403566d8;
    }
    *(int *)(param_1 + 0x2b0) = iVar8;
    uVar3 = 0;
    if (DAT_1403566d8 != 1) {
      uVar3 = DAT_14032c90c;
    }
    *(undefined4 *)(param_1 + 0x2b4) = uVar3;
    iVar8 = DAT_1403566e0;
    *(int *)(param_1 + 0x2ac) = DAT_1403566e0;
    *(uint *)(param_1 + 0x228) = (uint)(1 < DAT_1403566d8);
    uVar7 = _UNK_1402d2fc8;
    if (iVar8 == 0) {
      local_78 = *(undefined8 *)(param_1 + 0x238);
      uStack_70 = *(undefined8 *)(param_1 + 0x240);
      uStack_68 = *(undefined8 *)(param_1 + 0x248);
      uStack_60 = *(undefined8 *)(param_1 + 0x250);
      local_58 = _DAT_1402d2fc0;
      uStack_50 = _UNK_1402d2fc8;
      uStack_44 = (undefined4)DAT_1402d3ac0;
      uStack_40 = DAT_1402d3ac0._4_8_;
      uStack_38 = DAT_1402d3ac0._12_8_;
      uStack_30 = DAT_1402d3ac0._20_8_;
      uStack_28 = DAT_1402d3ac0._28_4_;
      uVar3 = *(undefined4 *)(param_1 + 0x268);
      uVar13 = *(undefined8 *)(param_1 + 600);
      uVar14 = *(undefined8 *)(param_1 + 0x260);
      uStack_48 = 0xffff;
      *(undefined8 *)(param_1 + 0x238) = _DAT_1402d2fc0;
      *(undefined8 *)(param_1 + 0x240) = uVar7;
      *(ulonglong *)(param_1 + 0x248) = CONCAT44(uStack_44,CONCAT22(uStack_46,0xffff));
      *(undefined8 *)(param_1 + 0x250) = uStack_40;
      *(undefined8 *)(param_1 + 600) = uStack_38;
      *(undefined8 *)(param_1 + 0x260) = uStack_30;
      *(undefined4 *)(param_1 + 0x268) = uStack_28;
      *(undefined4 *)(param_1 + 0x238) = 0;
      *(undefined4 *)(param_1 + 0x254) = 3;
      *(undefined4 *)(param_1 + 0x264) = 3;
      uVar7 = FUN_140209bc0(lVar12 + 0x30);
      *(undefined8 *)(param_1 + 0x238) = local_78;
      *(undefined8 *)(param_1 + 0x240) = uStack_70;
      *(undefined8 *)(param_1 + 0x248) = uStack_68;
      *(undefined8 *)(param_1 + 0x250) = uStack_60;
      *(undefined8 *)(param_1 + 600) = uVar13;
      *(undefined8 *)(param_1 + 0x260) = uVar14;
      *(undefined4 *)(param_1 + 0x268) = uVar3;
    }
    else {
      uVar7 = FUN_140209bc0(lVar12 + 0x30);
    }
    *(undefined8 *)(param_1 + 0x2e8) = uVar7;
    (**(code **)(*plVar2 + 200))(plVar2,uVar7);
    *(undefined1 *)(param_1 + 0x40) = 0;
  }
  return;
}

