/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140193240; RVA 0x193240
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Removing unreachable block (ram,0x0001401935a0) */
/* WARNING: Removing unreachable block (ram,0x00014019365a) */
/* WARNING: Removing unreachable block (ram,0x000140193566) */
/* WARNING: Removing unreachable block (ram,0x00014019360f) */

void FUN_140193240(longlong param_1,uint param_2,ulonglong param_3)

{
  undefined8 *puVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  uint uVar8;
  longlong lVar9;
  short *psVar10;
  ulonglong uVar11;
  int iVar12;
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined8 uVar15;
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  
  uVar11 = (ulonglong)param_2;
  param_3 = param_3 & *(ulonglong *)(param_1 + 0x3e0 + uVar11 * 8);
  if (param_2 - 4 < 2) {
    *(ulonglong *)(param_1 + 200 + uVar11 * 8) = param_3;
    if (param_2 == 4) {
      uVar11 = *(ulonglong *)(param_1 + 0xe8);
      bVar3 = (byte)(uVar11 >> 0x38);
      auVar16._0_4_ = (float)((uint)(uVar11 >> 0x20) & 0xffffff);
      auVar16._4_12_ = SUB1612(ZEXT816(0),4);
      uVar15 = auVar16._0_8_;
    }
    else {
      bVar3 = *(byte *)(param_1 + 0x11f);
      uVar11 = *(ulonglong *)(param_1 + 0xf0);
      auVar17._0_4_ = (float)(uVar11 >> 0x20);
      auVar17._4_12_ = SUB1612(ZEXT816(0),4);
      uVar15 = auVar17._0_8_;
    }
    auVar14._0_4_ = (float)(ushort)(uVar11 >> 0x10);
    auVar14._4_12_ = SUB1612(ZEXT816(0),4);
    auVar13._0_4_ = (float)(uVar11 & 0xffff);
    auVar13._4_12_ = SUB1612(ZEXT816(0),4);
    FUN_140192920(param_1,auVar13._0_8_,auVar14._0_8_,uVar15,(float)bVar3);
    return;
  }
  if (param_2 - 0xc < 2) {
    *(ulonglong *)(param_1 + 200 + uVar11 * 8) = param_3;
    uVar8 = (uint)*(undefined8 *)(param_1 + 200) & 7;
    if (uVar8 == 6) {
      if (*(int *)(param_1 + 0x714) != 0) {
        *(undefined4 *)(param_1 + 0x714) = 0;
        return;
      }
    }
    else {
      if (uVar8 == 5) {
        iVar4 = *(int *)(param_1 + 0x708);
        cVar2 = *(char *)(param_1 + 0x710);
        iVar12 = *(int *)(param_1 + 0x70c);
        FUN_14018fcb0();
        if (iVar4 == 0) goto LAB_1401935b5;
        if ((cVar2 != '\0') && (iVar12 = iVar12 + -2, 0 < iVar12)) {
          lVar9 = (longlong)iVar12;
          psVar10 = (short *)(*(longlong *)(param_1 + 0x700) + lVar9 * 2);
          do {
            if (*psVar10 == -1) {
              puVar5 = *(undefined8 **)(param_1 + 0x6f8);
              puVar1 = puVar5 + ((longlong)iVar12 + 1) * 8;
              uVar15 = puVar1[1];
              uVar6 = puVar1[2];
              uVar7 = puVar1[3];
              *puVar5 = *puVar1;
              puVar5[1] = uVar15;
              puVar5[2] = uVar6;
              puVar5[3] = uVar7;
              puVar1 = puVar5 + ((longlong)iVar12 + 1) * 8 + 4;
              uVar15 = puVar1[1];
              uVar6 = puVar1[2];
              uVar7 = puVar1[3];
              puVar5[4] = *puVar1;
              puVar5[5] = uVar15;
              puVar5[6] = uVar6;
              puVar5[7] = uVar7;
              break;
            }
            iVar12 = iVar12 + -1;
            lVar9 = lVar9 + -1;
            psVar10 = psVar10 + -1;
          } while (0 < lVar9);
        }
      }
      else {
        if (uVar8 != 4) {
          return;
        }
        iVar12 = *(int *)(param_1 + 0x708);
        if (iVar12 != 0) {
          FUN_140194840();
        }
        *(undefined8 *)(param_1 + 0x708) = 0;
        *(undefined1 *)(param_1 + 0x710) = 0;
        if (iVar12 < 1) goto LAB_1401935b5;
        puVar5 = *(undefined8 **)(param_1 + 0x6f8);
        puVar1 = puVar5 + (longlong)iVar12 * 8 + -8;
        uVar15 = puVar1[1];
        uVar6 = puVar1[2];
        uVar7 = puVar1[3];
        *puVar5 = *puVar1;
        puVar5[1] = uVar15;
        puVar5[2] = uVar6;
        puVar5[3] = uVar7;
        puVar1 = puVar5 + (longlong)iVar12 * 8 + -4;
        uVar15 = puVar1[1];
        uVar6 = puVar1[2];
        uVar7 = puVar1[3];
        puVar5[4] = *puVar1;
        puVar5[5] = uVar15;
        puVar5[6] = uVar6;
        puVar5[7] = uVar7;
      }
      **(undefined2 **)(param_1 + 0x700) = 0;
      *(undefined4 *)(param_1 + 0x708) = 1;
      *(undefined4 *)(param_1 + 0x70c) = 1;
    }
LAB_1401935b5:
    FUN_140192920(param_1);
    return;
  }
  if ((param_2 < 0x1b) && ((0x400040eU >> (param_2 & 0x1f) & 1) != 0)) {
    *(ulonglong *)(param_1 + 200 + uVar11 * 8) = param_3;
    return;
  }
  if (param_2 == 0x1b) {
    return;
  }
  if (param_2 == 0) {
    uVar11 = *(ulonglong *)(param_1 + 200);
    uVar8 = (uint)uVar11 & 7;
    if ((((uVar8 != 1) || (uVar11 != param_3)) && (((uVar11 & 7) != 0 || (uVar11 != param_3)))) &&
       ((uVar8 != 6 || (uVar11 != param_3)))) {
      if (uVar8 == 4) {
        if (uVar11 == param_3) {
          if (*(int *)(param_1 + 0x708) < 3) {
LAB_140193340:
            *(undefined8 *)(param_1 + 0x708) = 0;
            *(undefined1 *)(param_1 + 0x710) = 0;
            *(ulonglong *)(param_1 + 200) = param_3;
            return;
          }
          iVar12 = *(int *)(param_1 + 0x70c);
LAB_140193319:
          *(undefined2 *)(*(longlong *)(param_1 + 0x700) + (longlong)iVar12 * 2) = 0xffff;
          *(int *)(param_1 + 0x70c) = *(int *)(param_1 + 0x70c) + 1;
          *(undefined1 *)(param_1 + 0x710) = 1;
          *(ulonglong *)(param_1 + 200) = param_3;
          return;
        }
      }
      else if ((uVar8 == 5) && (uVar11 == param_3)) {
        iVar12 = *(int *)(param_1 + 0x70c);
        if (iVar12 < 3) goto LAB_140193340;
        goto LAB_140193319;
      }
      if (*(int *)(param_1 + 0x708) != 0) {
        FUN_140194840(param_1);
      }
      *(undefined8 *)(param_1 + 0x708) = 0;
      *(undefined1 *)(param_1 + 0x710) = 0;
    }
    *(ulonglong *)(param_1 + 200) = param_3;
    return;
  }
  if (param_2 < 0x50) {
    if (*(ulonglong *)(param_1 + 200 + uVar11 * 8) == param_3) goto LAB_1401933b9;
  }
  else if (param_2 != 0x50) goto LAB_1401933b9;
  if (*(int *)(param_1 + 0x708) != 0) {
    FUN_140194840();
  }
  *(undefined1 *)(param_1 + 0x710) = 0;
  *(undefined8 *)(param_1 + 0x708) = 0;
LAB_1401933b9:
  *(ulonglong *)(param_1 + 200 + uVar11 * 8) = param_3;
  return;
}

