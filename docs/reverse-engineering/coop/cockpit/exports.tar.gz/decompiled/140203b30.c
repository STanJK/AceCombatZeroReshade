/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140203b30; RVA 0x203b30
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_140203b30(longlong param_1,undefined8 *param_2)

{
  ushort uVar1;
  int iVar2;
  undefined8 uVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    return param_2;
  }
  *param_2 = 0x10000006;
  *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000006;
  *(undefined4 *)(param_2 + 2) = 4;
  *(undefined4 *)((longlong)param_2 + 0x14) = 0x10000000;
  param_2[3] = 0xe;
  *(undefined4 *)(param_2 + 1) = 0;
  uVar4 = **(undefined4 **)(param_1 + 0x10);
  *(undefined4 *)(param_2 + 4) = 0;
  *(undefined4 *)(param_2 + 5) = 0x50;
  *(undefined4 *)((longlong)param_2 + 0x24) = uVar4;
  uVar4 = *(undefined4 *)(*(longlong *)(param_1 + 0x10) + 8);
  *(undefined4 *)(param_2 + 6) = 0;
  *(undefined4 *)(param_2 + 7) = 0x51;
  *(undefined4 *)((longlong)param_2 + 0x34) = uVar4;
  uVar1 = *(ushort *)(*(longlong *)(param_1 + 0x10) + 0xe);
  *(uint *)(param_2 + 8) = (uint)*(ushort *)(*(longlong *)(param_1 + 0x10) + 0xc);
  *(uint *)((longlong)param_2 + 0x44) = (uint)uVar1;
  *(undefined4 *)(param_2 + 9) = 0x52;
  *(undefined4 *)((longlong)param_2 + 0x54) = *(undefined4 *)(param_1 + 0x40);
  *(undefined4 *)(param_2 + 10) = 0;
  *(undefined4 *)(param_2 + 0xb) = 0x53;
  iVar2 = *(int *)(param_1 + 0x30);
  *(undefined8 *)((longlong)param_2 + 100) = 0x8000000;
  *(undefined4 *)((longlong)param_2 + 0x6c) = 0;
  *(int *)(param_2 + 0xc) = (int)(iVar2 + (iVar2 >> 0x1f & 0xfU)) >> 4;
  uVar3 = *(undefined8 *)(param_1 + 0x20);
  iVar2 = *(int *)(param_1 + 0x30);
  *(undefined4 *)((longlong)param_2 + 0x74) = 0;
  *(uint *)(param_2 + 0xe) = (int)(iVar2 + (iVar2 >> 0x1f & 0xfU)) >> 4 | 0x30000000;
  FUN_140197b30(param_2 + 0xe,uVar3);
  puVar5 = param_2 + 0xf;
  *(undefined4 *)puVar5 = 0;
  *(uint *)((longlong)param_2 + 0x7c) =
       (int)(*(int *)(param_1 + 0x30) + (*(int *)(param_1 + 0x30) >> 0x1f & 0xfU)) >> 4 | 0x50000000
  ;
  if (*(longlong *)(param_1 + 0x28) != 0) {
    param_2[0x10] = 0x10000006;
    *(undefined4 *)(param_2 + 0x11) = 0;
    *(undefined4 *)((longlong)param_2 + 0x8c) = 0x50000006;
    *(undefined4 *)(param_2 + 0x12) = 4;
    *(undefined4 *)((longlong)param_2 + 0x94) = 0x10000000;
    param_2[0x13] = 0xe;
    uVar4 = **(undefined4 **)(param_1 + 0x18);
    *(undefined4 *)(param_2 + 0x14) = 0;
    *(undefined4 *)(param_2 + 0x15) = 0x50;
    *(undefined4 *)((longlong)param_2 + 0xa4) = uVar4;
    uVar4 = *(undefined4 *)(*(longlong *)(param_1 + 0x10) + 8);
    *(undefined4 *)(param_2 + 0x16) = 0;
    *(undefined4 *)((longlong)param_2 + 0xb4) = uVar4;
    *(undefined4 *)(param_2 + 0x17) = 0x51;
    uVar1 = *(ushort *)(*(longlong *)(param_1 + 0x18) + 0xe);
    *(uint *)(param_2 + 0x18) = (uint)*(ushort *)(*(longlong *)(param_1 + 0x18) + 0xc);
    *(uint *)((longlong)param_2 + 0xc4) = (uint)uVar1;
    *(undefined4 *)(param_2 + 0x19) = 0x52;
    param_2[0x1a] = 0;
    *(undefined4 *)(param_2 + 0x1b) = 0x53;
    iVar2 = *(int *)(param_1 + 0x34);
    *(undefined8 *)((longlong)param_2 + 0xe4) = 0x8000000;
    *(undefined4 *)((longlong)param_2 + 0xec) = 0;
    *(int *)(param_2 + 0x1c) = (int)(iVar2 + (iVar2 >> 0x1f & 0xfU)) >> 4;
    uVar3 = *(undefined8 *)(param_1 + 0x28);
    iVar2 = *(int *)(param_1 + 0x34);
    *(undefined4 *)((longlong)param_2 + 0xf4) = 0;
    *(uint *)(param_2 + 0x1e) = (int)(iVar2 + (iVar2 >> 0x1f & 0xfU)) >> 4 | 0x30000000;
    FUN_140197b30(param_2 + 0x1e,uVar3);
    puVar5 = param_2 + 0x1f;
    *(undefined4 *)puVar5 = 0;
    *(uint *)((longlong)param_2 + 0xfc) =
         (int)(*(int *)(param_1 + 0x34) + (*(int *)(param_1 + 0x34) >> 0x1f & 0xfU)) >> 4 |
         0x50000000;
  }
  puVar5[1] = 0x10000002;
  *(undefined4 *)(puVar5 + 2) = 0;
  *(undefined4 *)((longlong)puVar5 + 0x14) = 0x50000002;
  *(undefined4 *)(puVar5 + 3) = 0x8001;
  *(undefined4 *)((longlong)puVar5 + 0x1c) = 0x10000000;
  puVar5[4] = 0xe;
  *(undefined4 *)(puVar5 + 6) = 0x3f;
  return puVar5 + 7;
}

