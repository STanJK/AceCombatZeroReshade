/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b9a60; RVA 0xb9a60
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_1400b9a60(longlong param_1,undefined8 param_2,undefined8 param_3,longlong *param_4)

{
  uint uVar1;
  byte bVar2;
  undefined1 uVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  char cVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  uint uVar12;
  longlong lVar13;
  undefined1 auVar14 [64];
  undefined1 auVar15 [64];
  float fVar16;
  float fVar17;
  undefined1 auVar18 [64];
  undefined1 auVar19 [64];
  undefined1 auVar20 [64];
  undefined8 local_res10;
  
  uVar12 = 0;
  *(undefined8 *)(param_1 + 0x330) = 0;
  *(undefined8 *)(param_1 + 0x338) = 0;
  uVar4 = *(undefined8 *)
           (*(longlong *)(*param_4 + (ulonglong)*(byte *)(param_1 + 0x3ca) * 8) + 0x110);
  bVar2 = *(byte *)((longlong)param_4 + 0x34);
  if ((ulonglong)bVar2 != 0) {
    lVar13 = 0;
    auVar15 = ZEXT464(DAT_1402d20b0);
    auVar18 = ZEXT464(DAT_1402d2a78);
    auVar19 = ZEXT464(DAT_1402d2168);
    auVar20 = ZEXT464(DAT_1402d22d0);
    fVar16 = DAT_1402d2b60;
    fVar17 = DAT_1402d2ac0;
    local_res10 = param_2;
    do {
      lVar11 = 0;
      lVar5 = *param_4;
      lVar10 = *(longlong *)(lVar5 + lVar13 * 8);
      if (((*(byte *)(lVar10 + 0x120) & 2) != 0) &&
         (lVar10 = (longlong)*(int *)(lVar10 + 0x118), 0 < lVar10)) {
        do {
          lVar9 = *(longlong *)(lVar5 + lVar13 * 8);
          uVar3 = *(undefined1 *)(lVar9 + 0x15d);
          lVar9 = *(longlong *)(lVar9 + 0x110) + lVar11;
          cVar8 = *(char *)(**(longlong **)(lVar9 + 0x388) + 0x15d);
          if (((cVar8 != '\0') && (cVar8 != '\x02')) ||
             ((*(char *)(lVar9 + 0x235) != '\0' || (uVar12 != *(byte *)(param_1 + 0x3ca))))) {
            if (*(short *)(**(longlong **)(lVar9 + 0x1a0) + 0x6c) == 0x55c) {
              *(longlong *)(param_1 + 0x330) = lVar9;
            }
            if (*(short *)(**(longlong **)(lVar9 + 0x1a0) + 0x6c) == 0x202) {
              *(longlong *)(param_1 + 0x338) = lVar9;
            }
            uVar1 = *(uint *)(lVar9 + 0x20c + (ulonglong)*(byte *)(param_1 + 0x3ca) * 4);
            auVar14 = ZEXT464(uVar1);
            cVar8 = FUN_1400bf770(lVar9,*(undefined8 *)(param_1 + 0x2f8),uVar1);
            param_2 = local_res10;
            if ((cVar8 != '\0') &&
               (((*(byte *)(lVar9 + 500) & 2) != 0 || (auVar14._0_4_ <= fVar16)))) {
              auVar6 = auVar15._0_16_;
              if (auVar14._0_4_ <= fVar17) {
                auVar6 = vcmpss_avx(auVar18._0_16_,auVar14._0_16_,1);
                auVar6 = vblendvps_avx(auVar20._0_16_,auVar19._0_16_,auVar6);
              }
              auVar7 = vpcmpeqd_avx(ZEXT116(*(byte *)(*(longlong *)(lVar5 + lVar13 * 8) + 0x120) & 4
                                           ),SUB6416(ZEXT464(0),0));
              auVar6 = vblendvps_avx(auVar6,auVar15._0_16_,auVar7);
              local_res10 = FUN_1400b9d80(param_1,local_res10,param_4,param_3,lVar9,uVar4,
                                          auVar6._0_4_,uVar3);
              param_2 = local_res10;
            }
          }
          lVar11 = lVar11 + 0x520;
          lVar10 = lVar10 + -1;
        } while (lVar10 != 0);
      }
      uVar12 = uVar12 + 1;
      lVar13 = lVar13 + 1;
    } while (lVar13 < (longlong)(ulonglong)bVar2);
  }
  return param_2;
}

