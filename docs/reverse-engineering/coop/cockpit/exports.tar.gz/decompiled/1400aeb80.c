/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400aeb80; RVA 0xaeb80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 * FUN_1400aeb80(longlong param_1,undefined8 *param_2,longlong param_3,longlong *param_4)

{
  int iVar1;
  float fVar2;
  undefined1 uVar3;
  char cVar4;
  int iVar5;
  bool bVar6;
  float fVar7;
  int iVar8;
  undefined8 uVar9;
  undefined8 *puVar10;
  ushort uVar11;
  uint uVar12;
  longlong lVar13;
  longlong lVar14;
  int iVar15;
  uint uVar16;
  longlong lVar17;
  longlong lVar18;
  char *pcVar19;
  int iVar20;
  char *pcVar21;
  longlong lVar22;
  int iVar23;
  int iVar24;
  int iVar25;
  float fVar26;
  undefined1 auVar27 [16];
  undefined1 auVar28 [16];
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  undefined1 auVar33 [16];
  undefined1 auVar34 [64];
  undefined1 auVar35 [64];
  float fVar36;
  float fVar37;
  float fVar38;
  undefined1 auStack_268 [32];
  undefined8 local_248;
  undefined4 local_240;
  undefined8 local_238;
  int *local_230;
  char *local_228;
  undefined1 local_218;
  undefined1 local_217;
  undefined1 local_216;
  undefined1 local_215;
  int local_214;
  int local_210;
  int local_20c;
  int local_208;
  int local_204;
  int local_200;
  int local_1fc;
  float local_1f8;
  float local_1f4;
  undefined4 local_1f0;
  undefined4 local_1ec;
  float local_1e8;
  float local_1e4;
  undefined4 local_1e0;
  undefined4 local_1dc;
  float local_1d8;
  float local_1d4;
  float local_1d0;
  undefined4 local_1cc;
  float local_1c8;
  float local_1c4;
  undefined4 local_1c0;
  float local_1bc;
  longlong local_1b8;
  longlong local_1b0;
  undefined1 local_1a8;
  undefined1 local_1a7;
  undefined1 local_1a6;
  undefined1 local_1a5;
  float local_19c;
  int local_194;
  int local_190;
  undefined8 local_18c;
  undefined1 local_184;
  undefined1 local_183;
  undefined1 local_182;
  undefined1 local_181;
  float local_178;
  uint local_170;
  int local_16c;
  undefined8 local_168;
  undefined1 local_160;
  undefined1 local_15f;
  undefined1 local_15e;
  undefined1 local_15d;
  float local_154;
  int local_14c;
  int local_148;
  undefined8 local_144;
  undefined1 local_13c;
  undefined1 local_13b;
  undefined1 local_13a;
  undefined1 local_139;
  float local_130;
  uint local_128;
  int local_124;
  undefined8 local_120;
  undefined1 local_118;
  undefined1 local_117;
  undefined1 local_116;
  undefined1 local_115;
  float local_10c;
  int local_104;
  int local_100;
  undefined8 local_fc;
  char local_e8;
  char local_e7 [15];
  ulonglong local_d8;
  
  local_d8 = DAT_140309040 ^ (ulonglong)auStack_268;
  if ((*(char *)(param_1 + 0x1a4) == -1) || (*(char *)(param_1 + 0x1a5) == -1)) {
    return param_2;
  }
  local_216 = *(undefined1 *)(param_1 + 0x1b1);
  local_218 = *(undefined1 *)(param_1 + 0x1b3);
  auVar33 = *(undefined1 (*) [16])(param_1 + 400);
  uVar3 = *(undefined1 *)(param_1 + 0x1b0);
  local_217 = *(undefined1 *)(param_1 + 0x1b2);
  auVar35 = ZEXT864(0);
  fVar31 = auVar33._0_4_ - *(float *)(param_1 + 0x180);
  auVar27 = vshufps_avx(auVar33,auVar33,0x55);
  fVar30 = auVar27._0_4_ - *(float *)(param_1 + 0x184);
  auVar27 = vshufps_avx(auVar33,auVar33,0xaa);
  fVar32 = auVar27._0_4_ - *(float *)(param_1 + 0x188);
  auVar33 = vshufps_avx(auVar33,auVar33,0xff);
  fVar29 = auVar33._0_4_ - *(float *)(param_1 + 0x18c);
  local_1b0 = *(longlong *)
               (*(longlong *)(*param_4 + (ulonglong)*(byte *)(param_1 + 0x3ca) * 8) + 0x110);
  local_19c = DAT_1402d22d0;
  local_178 = DAT_1402d22d0;
  local_154 = DAT_1402d22d0;
  local_130 = DAT_1402d22d0;
  local_10c = DAT_1402d22d0;
  local_1f8 = DAT_1402d22d0;
  local_1e8 = 0.0;
  local_1d8 = 0.0;
  local_1c8 = 0.0;
  local_1f4 = 0.0;
  local_1e4 = DAT_1402d22d0;
  local_1d4 = 0.0;
  local_1c4 = 0.0;
  local_1f0 = 0;
  local_1e0 = 0;
  local_1d0 = DAT_1402d22d0;
  local_1c0 = 0;
  local_1ec = 0;
  local_1dc = 0;
  local_1cc = 0;
  local_1bc = DAT_1402d22d0;
  local_18c = 0xfffffff;
  local_168 = 0xfffffff;
  local_144 = 0xfffffff;
  local_120 = 0xfffffff;
  local_fc = 0xfffffff;
  fVar36 = DAT_1402d22d0;
  local_215 = uVar3;
  local_1b8 = param_1;
  local_1a8 = uVar3;
  local_1a7 = local_216;
  local_1a6 = local_217;
  local_1a5 = local_218;
  local_184 = uVar3;
  local_183 = local_216;
  local_182 = local_217;
  local_181 = local_218;
  local_160 = uVar3;
  local_15f = local_216;
  local_15e = local_217;
  local_15d = local_218;
  local_13c = uVar3;
  local_13b = local_216;
  local_13a = local_217;
  local_139 = local_218;
  local_118 = uVar3;
  local_117 = local_216;
  local_116 = local_217;
  local_115 = local_218;
  FUN_140202230(&local_1f8,&local_1f8,local_1b0 + 0x268);
  FUN_14003a2e0(&local_1f8);
  fVar7 = DAT_1402d253c;
  iVar5 = *(int *)(param_1 + 0x394);
  fVar38 = fVar29 * local_1c4 + fVar32 * local_1d4 + fVar30 * local_1e4 + fVar31 * local_1f4;
  fVar37 = fVar29 * local_1c8 + fVar32 * local_1d8 + fVar30 * local_1e8 + fVar31 * local_1f8;
  fVar2 = *(float *)(param_3 + 0x19c);
  fVar26 = *(float *)(param_3 + 0x198);
  iVar24 = *(int *)(param_1 + 0x390);
  iVar23 = iVar5 + 0xdf;
  auVar33 = vmaxss_avx(ZEXT416((uint)(-(SQRT(fVar29 * fVar29 +
                                             fVar32 * fVar32 + fVar30 * fVar30 + fVar31 * fVar31) *
                                       DAT_1402d1df0) + fVar36)),auVar35._0_16_);
  local_210 = (int)(fVar26 * DAT_1402d2690);
  iVar25 = (int)(fVar2 * DAT_1402d2690);
  iVar15 = iVar24 + 0x100;
  local_1fc = (int)(-(fVar37 * DAT_1402d2080) + DAT_1402d287c);
  local_200 = (int)(fVar2 * DAT_1402d264c);
  local_204 = (int)(fVar26 * DAT_1402d264c);
  fVar32 = fVar2 * DAT_1402d264c * auVar33._0_4_;
  fVar31 = -(fVar37 * DAT_1402d2080) + (float)iVar15;
  fVar29 = fVar26 * DAT_1402d264c * auVar33._0_4_;
  fVar30 = -(fVar38 * DAT_1402d2cf4) + (float)iVar23;
  if (fVar29 + fVar31 <= (float)(local_204 + iVar15)) {
    if (fVar31 - fVar29 < (float)(iVar15 - local_204)) {
      fVar31 = (float)(iVar15 - local_204) + fVar29;
    }
  }
  else {
    fVar31 = (float)(local_204 + iVar15) - fVar29;
  }
  if (fVar30 + fVar32 <= (float)(local_200 + iVar23)) {
    if (fVar30 - fVar32 < (float)(iVar23 - local_200)) {
      fVar30 = (float)(iVar23 - local_200) + fVar32;
    }
  }
  else {
    fVar30 = (float)(local_200 + iVar23) - fVar32;
  }
  auVar33._0_4_ = (float)local_210;
  auVar33._4_12_ = SUB1612(ZEXT816(0),4);
  if (fVar29 <= auVar33._0_4_) {
    auVar33 = vmaxss_avx(ZEXT416((uint)(float)(int)(fVar26 * DAT_1402d253c)),ZEXT416((uint)fVar29));
  }
  else {
    *(uint *)(param_1 + 0x34c) = *(uint *)(param_1 + 0x34c) | 2;
  }
  auVar35 = ZEXT1664(auVar33);
  auVar33 = ZEXT416((uint)(float)iVar25);
  if (fVar32 <= (float)iVar25) {
    auVar33 = vmaxss_avx(ZEXT416((uint)(float)(int)(fVar2 * fVar7)),ZEXT416((uint)fVar32));
  }
  else {
    *(uint *)(param_1 + 0x34c) = *(uint *)(param_1 + 0x34c) | 2;
  }
  auVar34 = ZEXT1664(auVar33);
  bVar6 = true;
  if ((fVar37 < DAT_1402d2478) && (DAT_1402d2dd0 < fVar37)) {
    bVar6 = false;
  }
  iVar20 = (iVar5 + 0x7ff) * 0x10;
  lVar22 = 8;
  local_214 = iVar15;
  local_20c = iVar23;
  local_208 = iVar25;
  if (DAT_1402d2478 <= fVar38 || fVar38 <= DAT_1402d2dd0) {
    lVar18 = 8;
    iVar8 = (int)(local_210 * 2 + (local_210 * 2 >> 0x1f & 0xfU)) >> 4;
    uVar16 = ((iVar15 - local_210) + 0x700) * 0x10;
    do {
      *param_2 = 0x10000004;
      *(undefined4 *)(param_2 + 1) = 0;
      uVar12 = (iVar5 + 0x7ff) * 0x100000;
      *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000004;
      *(uint *)(param_2 + 4) = uVar16 | uVar12;
      *(undefined4 *)(param_2 + 2) = 0x8001;
      *(uint *)(param_2 + 8) = uVar16 + iVar8 * 0x10 | uVar12;
      uVar16 = uVar16 + iVar8 * 0x20;
      *(undefined4 *)((longlong)param_2 + 0x14) = 0x3020c000;
      param_2[3] = 0xeee;
      *(undefined4 *)((longlong)param_2 + 0x24) = 0xfffffff;
      *(undefined4 *)(param_2 + 5) = 5;
      *(uint *)(param_2 + 6) = CONCAT31(CONCAT21(CONCAT11(local_218,local_217),local_216),uVar3);
      *(undefined4 *)((longlong)param_2 + 0x34) = 0x3f800000;
      *(undefined4 *)(param_2 + 7) = 1;
      *(undefined4 *)((longlong)param_2 + 0x44) = 0xfffffff;
      *(undefined4 *)(param_2 + 9) = 5;
      param_2 = param_2 + 10;
      lVar18 = lVar18 + -1;
    } while (lVar18 != 0);
    param_1 = local_1b8;
  }
  else {
    local_194 = ((iVar15 - local_210) + 0x700) * 0x10;
    local_170 = (iVar24 + 0x800 + local_210) * 0x10;
    local_190 = iVar20;
    local_16c = iVar20;
    param_2 = (undefined8 *)FUN_1400b99c0(local_210,param_2,&local_1a8,&local_184);
  }
  iVar8 = local_204;
  local_170 = (iVar24 + 0x800) * 0x10;
  iVar24 = iVar23 - iVar25;
  if (bVar6) {
    iVar15 = (int)(iVar25 * 2 + (iVar25 * 2 >> 0x1f & 0xfU)) >> 4;
    iVar25 = (iVar24 + 0x720) * 0x10;
    do {
      *param_2 = 0x10000004;
      *(undefined4 *)(param_2 + 1) = 0;
      *(uint *)(param_2 + 4) = iVar25 << 0x10 | local_170;
      iVar1 = iVar25 + iVar15 * 0x10;
      iVar25 = iVar25 + iVar15 * 0x20;
      *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000004;
      *(uint *)(param_2 + 8) = iVar1 * 0x10000 | local_170;
      *(undefined4 *)(param_2 + 2) = 0x8001;
      *(undefined4 *)((longlong)param_2 + 0x14) = 0x3020c000;
      param_2[3] = 0xeee;
      *(undefined4 *)((longlong)param_2 + 0x24) = 0xfffffff;
      *(undefined4 *)(param_2 + 5) = 5;
      *(uint *)(param_2 + 6) = CONCAT31(CONCAT21(CONCAT11(local_218,local_217),local_216),local_215)
      ;
      *(undefined4 *)((longlong)param_2 + 0x34) = 0x3f800000;
      *(undefined4 *)(param_2 + 7) = 1;
      *(undefined4 *)((longlong)param_2 + 0x44) = 0xfffffff;
      *(undefined4 *)(param_2 + 9) = 5;
      param_2 = param_2 + 10;
      lVar22 = lVar22 + -1;
    } while (lVar22 != 0);
    iVar15 = local_214;
  }
  else {
    *param_2 = 0x10000004;
    *(uint *)(param_2 + 4) = (iVar24 + 0x720) * 0x100000 | local_170;
    *(undefined4 *)(param_2 + 1) = 0;
    *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000004;
    *(undefined4 *)(param_2 + 2) = 0x8001;
    *(undefined4 *)((longlong)param_2 + 0x14) = 0x3020c000;
    param_2[3] = 0xeee;
    *(uint *)(param_2 + 8) = (iVar5 + 0x7ff + iVar25) * 0x100000 | local_170;
    *(undefined4 *)((longlong)param_2 + 0x24) = 0xfffffff;
    *(undefined4 *)(param_2 + 5) = 5;
    *(uint *)(param_2 + 6) = CONCAT31(CONCAT21(CONCAT11(local_218,local_217),local_216),local_215);
    *(undefined4 *)((longlong)param_2 + 0x34) = 0x3f800000;
    *(undefined4 *)(param_2 + 7) = 1;
    *(undefined4 *)((longlong)param_2 + 0x44) = 0xfffffff;
    *(undefined4 *)(param_2 + 9) = 5;
    param_2 = param_2 + 10;
  }
  local_16c = ((iVar23 - local_200) + 0x720) * 0x10;
  local_194 = ((iVar15 - local_204) + 0x700) * 0x10;
  local_14c = (local_204 + 0x700 + iVar15) * 0x10;
  local_124 = (local_200 + 0x720 + iVar23) * 0x10;
  local_248 = 0;
  local_190 = iVar20;
  local_148 = iVar20;
  local_128 = local_170;
  local_104 = local_194;
  local_100 = iVar20;
  uVar9 = FUN_1401fe080(param_2,0x142,5,&local_1a8);
  if ((local_1b0 != 0) && (lVar22 = *(longlong *)(local_1b0 + 0x1b8), lVar22 != 0)) {
    uVar11 = *(ushort *)(lVar22 + 0x2090) & 0xff3f;
    fVar2 = (float)iVar8 * DAT_1402d21f8;
    fVar26 = (float)((uint)fVar2 ^ DAT_1402d3770);
    *(ushort *)(lVar22 + 0x2090) = uVar11;
    if (fVar26 <= (float)(local_1fc + -0x100)) {
      if ((float)(local_1fc + -0x100) <= fVar2) goto LAB_1400af37c;
      uVar11 = uVar11 | 0x80;
    }
    else {
      uVar11 = uVar11 | 0x40;
    }
    *(ushort *)(lVar22 + 0x2090) = uVar11;
  }
LAB_1400af37c:
  local_194 = (int)((fVar31 - auVar35._0_4_) * DAT_1402d2544 + DAT_1402d2b1c);
  local_190 = (int)(fVar30 * DAT_1402d2544 + DAT_1402d2b2c);
  local_170 = (uint)(fVar31 * DAT_1402d2544 + DAT_1402d2b1c);
  local_16c = (int)((fVar30 - auVar34._0_4_) * DAT_1402d2544 + DAT_1402d2b2c);
  local_14c = (int)(fVar31 * DAT_1402d2544 + auVar35._0_4_ * DAT_1402d2544 + DAT_1402d2b1c);
  local_124 = (int)(fVar30 * DAT_1402d2544 + auVar34._0_4_ * DAT_1402d2544 + DAT_1402d2b2c);
  local_248 = 0;
  local_148 = local_190;
  local_128 = local_170;
  local_104 = local_194;
  local_100 = local_190;
  uVar9 = FUN_1401fe080(uVar9,0x142,5,&local_1a8);
  lVar18 = *(longlong *)(param_1 + 0x300);
  iVar23 = (int)fVar37;
  local_210 = iVar15 + 10 + local_210;
  local_214 = *(int *)(param_1 + 0x1b0);
  lVar22 = lVar18 + 0x338;
  pcVar19 = &local_e8;
  if (iVar23 < 0) {
    pcVar19 = local_e7;
    local_e8 = '-';
  }
  iVar25 = -iVar23;
  if (-iVar23 < 0) {
    iVar25 = iVar23;
  }
  pcVar21 = pcVar19;
  if (iVar25 == 0) {
LAB_1400af536:
    *pcVar21 = '0';
    pcVar21 = pcVar21 + 1;
  }
  else {
    do {
      iVar23 = iVar25 / 10;
      *pcVar21 = (char)iVar25 + (char)iVar23 * -10 + '0';
      pcVar21 = pcVar21 + 1;
      iVar25 = iVar23;
    } while (iVar23 != 0);
    if (pcVar19 == pcVar21) goto LAB_1400af536;
  }
  lVar14 = -1;
  *pcVar21 = '\0';
  lVar13 = -1;
  do {
    lVar13 = lVar13 + 1;
  } while (pcVar19[lVar13] != '\0');
  iVar23 = (int)lVar13 / 2;
  lVar17 = (longlong)iVar23;
  if (0 < iVar23) {
    pcVar21 = pcVar19 + (longlong)(int)lVar13 + -1;
    do {
      cVar4 = *pcVar19;
      *pcVar19 = *pcVar21;
      pcVar19 = pcVar19 + 1;
      *pcVar21 = cVar4;
      lVar17 = lVar17 + -1;
      pcVar21 = pcVar21 + -1;
    } while (lVar17 != 0);
  }
  local_228 = &local_e8;
  local_230 = &local_214;
  local_238 = *(undefined8 *)(lVar18 + 0x398);
  local_240 = 2;
  auVar27._0_4_ = (float)(iVar15 + 10);
  auVar27._4_12_ = SUB1612(ZEXT816(0),4);
  local_248._0_4_ = (float)(iVar24 + -4);
  uVar9 = FUN_1400bb3e0(lVar22,uVar9,0,auVar27._0_8_);
  iVar24 = (int)fVar38;
  pcVar19 = &local_e8;
  if (iVar24 < 0) {
    pcVar19 = local_e7;
    local_e8 = '-';
  }
  iVar15 = -iVar24;
  if (-iVar24 < 0) {
    iVar15 = iVar24;
  }
  pcVar21 = pcVar19;
  if (iVar15 != 0) {
    do {
      iVar24 = iVar15 / 10;
      *pcVar21 = (char)iVar15 + (char)iVar24 * -10 + '0';
      pcVar21 = pcVar21 + 1;
      iVar15 = iVar24;
    } while (iVar24 != 0);
    if (pcVar19 != pcVar21) goto LAB_1400af68c;
  }
  *pcVar21 = '0';
  pcVar21 = pcVar21 + 1;
LAB_1400af68c:
  *pcVar21 = '\0';
  do {
    lVar14 = lVar14 + 1;
  } while (pcVar19[lVar14] != '\0');
  iVar24 = (int)lVar14 / 2;
  lVar18 = (longlong)iVar24;
  if (0 < iVar24) {
    pcVar21 = pcVar19 + (longlong)(int)lVar14 + -1;
    do {
      cVar4 = *pcVar19;
      *pcVar19 = *pcVar21;
      pcVar19 = pcVar19 + 1;
      *pcVar21 = cVar4;
      lVar18 = lVar18 + -1;
      pcVar21 = pcVar21 + -1;
    } while (lVar18 != 0);
  }
  local_228 = &local_e8;
  local_230 = &local_214;
  local_238 = *(undefined8 *)(*(longlong *)(param_1 + 0x300) + 0x398);
  auVar28._0_4_ = (float)local_210;
  auVar28._4_12_ = SUB1612(ZEXT816(0),4);
  local_240 = 2;
  local_248 = CONCAT44(local_248._4_4_,(float)(iVar5 + 0xdb));
  puVar10 = (undefined8 *)FUN_1400bb3e0(lVar22,uVar9,0,auVar28._0_8_);
  return puVar10;
}

