/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400bbe30; RVA 0xbbe30
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_1400bbe30(undefined4 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined1 uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined1 uVar10;
  longlong lVar11;
  undefined1 uVar12;
  ulonglong uVar13;
  int *piVar14;
  int iVar15;
  int *piVar16;
  int iVar17;
  undefined1 uVar18;
  int *piVar19;
  int *piVar20;
  byte bVar21;
  int *piVar22;
  int iVar23;
  int iVar24;
  int *piVar25;
  int iVar26;
  int iVar27;
  undefined1 auVar28 [16];
  undefined1 auVar29 [16];
  undefined1 auVar30 [16];
  undefined1 auVar31 [16];
  undefined1 auVar32 [16];
  undefined1 auVar33 [16];
  float fVar34;
  float fVar35;
  undefined1 auVar36 [64];
  float fVar37;
  float fVar38;
  float fVar39;
  float fVar40;
  undefined1 auStack_358 [32];
  undefined8 local_338;
  undefined4 *local_330;
  float local_328;
  float local_320;
  float local_318;
  float local_310;
  int local_308;
  int *local_300;
  int *local_2f8;
  int local_2f0 [12];
  int local_2c0;
  int local_2bc;
  int local_2b8;
  int local_2b4;
  int local_2b0;
  int local_2ac;
  int local_2a8 [12];
  int local_278 [12];
  int local_248 [12];
  undefined8 local_218;
  undefined8 uStack_210;
  undefined8 uStack_208;
  undefined8 uStack_200;
  undefined8 local_1f8;
  undefined8 uStack_1f0;
  undefined8 uStack_1e8;
  undefined8 uStack_1e0;
  undefined8 local_1d8;
  undefined8 uStack_1d0;
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  undefined4 local_1b8;
  undefined4 local_1b4;
  undefined4 local_1b0;
  undefined8 local_1a8;
  undefined8 uStack_1a0;
  undefined8 uStack_198;
  int iStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 local_184;
  undefined4 local_180;
  float local_178;
  undefined4 local_174;
  int local_170;
  int local_16c;
  undefined8 local_168;
  undefined1 local_158;
  undefined1 local_157;
  undefined1 local_156;
  undefined1 local_155;
  float local_14c;
  short local_148;
  short local_146;
  int local_144;
  int local_140;
  undefined8 local_13c;
  undefined1 local_134;
  undefined1 local_133;
  undefined1 local_132;
  undefined1 local_131;
  float local_128;
  short local_124;
  short local_122;
  int local_120;
  int local_11c;
  undefined8 local_118;
  undefined1 local_110;
  undefined1 local_10f;
  undefined1 local_10e;
  undefined1 local_10d;
  float local_104;
  int local_fc;
  undefined4 local_f8;
  undefined8 local_f4;
  undefined1 local_ec;
  undefined1 local_eb;
  undefined1 local_ea;
  undefined1 local_e9;
  float local_e0;
  int local_d8;
  undefined4 local_d4;
  undefined8 local_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  ulonglong local_a8;
  
  fVar40 = DAT_1402d22d0;
  fVar39 = DAT_1402d21f8;
  local_a8 = DAT_140309040 ^ (ulonglong)auStack_358;
  bVar21 = *(byte *)((longlong)param_1 + 0x22);
  if ((bVar21 & 2) != 0) {
    return param_2;
  }
  uStack_188 = 0x40;
  local_184 = 0x40;
  local_180 = 0x40;
  local_1b8 = 0x17;
  local_1b4 = 0x17;
  local_1b0 = 0x17;
  local_1a8 = _DAT_1402d3c60;
  uStack_1a0 = _UNK_1402d3c68;
  uStack_198 = _UNK_1402d3c70;
  iStack_190 = (int)_UNK_1402d3c78;
  uStack_18c = (undefined4)((ulonglong)_UNK_1402d3c78 >> 0x20);
  local_1d8 = _DAT_1402d3b20;
  uStack_1d0 = _UNK_1402d3b28;
  uStack_1c8 = _UNK_1402d3b30;
  uStack_1c0 = _UNK_1402d3b38;
  fVar37 = *(float *)(param_3 + 0x19c) / *(float *)(param_3 + 0x198);
  fVar34 = DAT_1402d22d0;
  if ((bVar21 & 4) != 0) {
    fVar37 = fVar37 * DAT_1402d21f8;
    *param_2 = 0x10000002;
    auVar36 = ZEXT464((uint)fVar37);
    fVar34 = fVar39;
    FUN_140197b30(param_2,0);
    fVar37 = auVar36._0_4_;
    *(undefined4 *)(param_2 + 1) = 0;
    *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000002;
    *(undefined4 *)(param_2 + 2) = 0x8001;
    *(undefined4 *)((longlong)param_2 + 0x14) = 0x10000000;
    param_2[3] = 0xe;
    param_2[4] = 0x60;
    *(undefined4 *)(param_2 + 5) = 0x14;
    param_2 = param_2 + 6;
    bVar21 = *(byte *)((longlong)param_1 + 0x22);
  }
  iVar15 = (int)(fVar34 * DAT_1402d257c);
  local_2a8[0] = (int)(fVar37 * DAT_1402d257c);
  local_248[2] = (int)(fVar34 * DAT_1402d256c);
  local_2f0[1] = 0xff - iVar15;
  local_2f0[2] = 0x100 - local_248[2] / 2;
  local_2a8[2] = (int)(fVar37 * DAT_1402d2594);
  local_248[4] = (int)(fVar34 * DAT_1402d2698);
  local_2a8[4] = (int)(fVar37 * DAT_1402d258c);
  local_2f0[4] = iVar15 + 0x101;
  local_2f0[6] = 0x100 - local_248[4] / 2;
  local_2f0[5] = (local_2f0[1] - local_248[4]) + 0x10;
  local_2f0[0] = 0x102;
  if ((bVar21 & 4) == 0) {
    iVar26 = (local_2f0[5] - local_248[4]) + 0x18;
  }
  else {
    local_2f0[5] = (local_2f0[1] - local_248[4]) + 0xd;
    local_2f0[4] = iVar15 + 0xfe;
    iVar26 = (local_2f0[5] - local_248[4]) + 0x14;
  }
  local_158 = *(undefined1 *)param_1;
  local_308 = 0x17c - local_2a8[0] / 2;
  local_278[2] = 0x17c - local_2a8[2];
  local_278[6] = (local_278[2] - local_2a8[4]) + 4;
  local_278[3] = 0x17d;
  local_278[7] = local_2a8[2] + 0x179;
  local_278[10] = -(local_2a8[4] / 2);
  local_c8 = _DAT_1402d3d00;
  uStack_c0 = _UNK_1402d3d08;
  uStack_b8 = _UNK_1402d3d10;
  uStack_b0 = _UNK_1402d3d18;
  local_278[4] = local_278[10] + 0x17c;
  local_13c = 0xfffffff;
  local_278[8] = local_278[10] + 0x166;
  local_278[10] = local_278[10] + 0x192;
  uVar13 = 0;
  local_156 = *(undefined1 *)((longlong)param_1 + 2);
  local_157 = *(undefined1 *)((longlong)param_1 + 1);
  local_155 = *(undefined1 *)((longlong)param_1 + 3);
  local_218 = _DAT_1402d3800;
  uStack_210 = _UNK_1402d3808;
  uStack_208 = _UNK_1402d3810;
  uStack_200 = _UNK_1402d3818;
  local_118 = 0xfffffff;
  fVar38 = DAT_1402d257c;
  local_2f0[3] = local_2f0[2];
  local_2f0[7] = local_2f0[6];
  local_2f0[8] = iVar26;
  local_2f0[9] = iVar26;
  local_2f0[10] = iVar26;
  local_2a8[1] = local_2a8[0];
  local_2a8[3] = local_2a8[2];
  local_2a8[5] = local_2a8[4];
  local_2a8[6] = local_2a8[4];
  local_2a8[7] = local_2a8[4];
  local_2a8[8] = local_2a8[4];
  local_2a8[9] = local_2a8[4];
  local_2a8[10] = local_2a8[4];
  local_278[0] = local_308;
  local_278[1] = local_308;
  local_278[5] = local_278[4];
  local_278[9] = local_278[4];
  local_248[0] = iVar15;
  local_248[1] = iVar15;
  local_248[3] = local_248[2];
  local_248[5] = local_248[4];
  local_248[6] = local_248[4];
  local_248[7] = local_248[4];
  local_248[8] = local_248[4];
  local_248[9] = local_248[4];
  local_248[10] = local_248[4];
  local_14c = fVar40;
  local_134 = local_158;
  local_133 = local_157;
  local_132 = local_156;
  local_131 = local_155;
  local_128 = fVar40;
  puVar6 = (undefined8 *)FUN_1400bf810(param_2,2);
  auVar36 = ZEXT464(DAT_1402d2e08);
  uVar13 = uVar13 & 0xffffffff;
  fVar39 = DAT_1402d2544;
  fVar37 = DAT_1402d2b1c;
  fVar34 = DAT_1402d2b2c;
  do {
    lVar11 = 0x398;
    if (3 < uVar13) {
      lVar11 = 0x3a0;
    }
    local_338 = *(undefined8 *)(lVar11 + *(longlong *)(param_1 + 6));
    local_144 = (int)((float)local_2f0[uVar13] * fVar39 + fVar37);
    local_140 = (int)((float)local_278[uVar13] * fVar39 + fVar34);
    local_120 = (int)((float)local_248[uVar13] * fVar39 + (float)local_2f0[uVar13] * fVar39 + fVar37
                     );
    local_148 = (short)(int)((float)*(int *)((longlong)&local_c8 + uVar13 * 4) * fVar39);
    local_146 = (short)(int)((float)local_248[uVar13 + 0xc] * fVar39);
    local_11c = (int)((float)local_2a8[uVar13] * fVar39 + (float)local_278[uVar13] * fVar39 + fVar34
                     );
    local_124 = local_148 -
                (short)(int)((float)*(int *)((longlong)&local_1a8 + uVar13 * 4) * auVar36._0_4_);
    local_122 = local_146 -
                (short)(int)((float)*(int *)((longlong)&local_1d8 + uVar13 * 4) * auVar36._0_4_);
    puVar6 = (undefined8 *)FUN_1401fe080(puVar6,0x156,2,&local_158);
    uVar13 = uVar13 + 1;
  } while ((longlong)uVar13 < 8);
  bVar21 = *(byte *)((longlong)param_1 + 0x25);
  local_218 = _DAT_1402d3d00;
  uStack_210 = _UNK_1402d3d08;
  uStack_208 = _UNK_1402d3d10;
  uStack_200 = _UNK_1402d3d18;
  uStack_b8._0_4_ = param_1[1];
  local_c8._0_4_ = (undefined4)uStack_b8;
  local_c8._4_4_ = (undefined4)uStack_b8;
  uStack_c0 = CONCAT44((undefined4)uStack_b8,(undefined4)uStack_b8);
  uStack_b8._4_4_ = (undefined4)uStack_b8;
  uStack_b0 = CONCAT44((undefined4)uStack_b8,(undefined4)uStack_b8);
  local_1f8 = _DAT_1402d3b60;
  uStack_1f0 = _UNK_1402d3b68;
  uStack_1e8 = _UNK_1402d3b70;
  uStack_1e0 = _UNK_1402d3b78;
  if ((bVar21 & 1) == 0) {
    if ((bVar21 & 2) == 0) {
      if ((((bVar21 & 4) != 0) || ((bVar21 & 8) != 0)) || ((bVar21 & 0x10) != 0)) {
        local_c8._4_4_ = param_1[2];
        uStack_b8._4_4_ = param_1[2];
      }
    }
    else {
      uStack_c0 = CONCAT44(param_1[2],(undefined4)uStack_b8);
      uStack_b0 = CONCAT44(param_1[2],(undefined4)uStack_b8);
    }
  }
  else {
    uStack_c0 = CONCAT44((undefined4)uStack_b8,param_1[2]);
    uStack_b0 = CONCAT44((undefined4)uStack_b8,param_1[2]);
  }
  if ((bVar21 & 0x20) != 0) {
    local_c8._0_4_ = param_1[2];
    local_c8._4_4_ = uStack_b8._4_4_;
    uStack_b8._0_4_ = param_1[2];
  }
  uVar13 = 0;
  local_c8._0_4_ = (undefined4)uStack_b8;
  local_c8._4_4_ = uStack_b8._4_4_;
  do {
    local_157 = *(undefined1 *)((longlong)&local_c8 + uVar13 * 4 + 1);
    lVar11 = 0x398;
    local_158 = *(undefined1 *)((longlong)&local_c8 + uVar13 * 4);
    if (3 < uVar13) {
      lVar11 = 0x3a0;
    }
    local_338 = *(undefined8 *)(lVar11 + *(longlong *)(param_1 + 6));
    local_156 = *(undefined1 *)((longlong)&local_c8 + uVar13 * 4 + 2);
    local_155 = *(undefined1 *)((longlong)&local_c8 + uVar13 * 4 + 3);
    local_131 = local_155;
    local_144 = (int)((float)local_2f0[uVar13] * fVar39 + fVar37);
    local_132 = local_156;
    local_133 = local_157;
    local_140 = (int)((float)local_278[uVar13] * fVar39 + fVar34);
    local_120 = (int)((float)local_248[uVar13] * fVar39 + (float)local_2f0[uVar13] * fVar39 + fVar37
                     );
    local_11c = (int)((float)local_2a8[uVar13] * fVar39 + (float)local_278[uVar13] * fVar39 + fVar34
                     );
    local_148 = (short)(int)((float)local_248[uVar13 + 0xc] * fVar39);
    local_124 = local_148 -
                (short)(int)((float)*(int *)((longlong)&local_1a8 + uVar13 * 4) * auVar36._0_4_);
    local_146 = (short)(int)((float)*(int *)((longlong)&local_1f8 + uVar13 * 4) * fVar39);
    local_122 = local_146 -
                (short)(int)((float)*(int *)((longlong)&local_1d8 + uVar13 * 4) * auVar36._0_4_);
    local_13c = 0xfffffff;
    local_118 = 0xfffffff;
    auVar36 = ZEXT1664(auVar36._0_16_);
    local_14c = fVar40;
    local_134 = local_158;
    local_128 = fVar40;
    puVar6 = (undefined8 *)FUN_1401fe080(puVar6,0x156,2);
    iVar17 = local_248[4];
    iVar23 = local_2a8[4];
    iVar24 = local_2f0[5];
    uVar4 = _UNK_1402d3478;
    uVar3 = _DAT_1402d3470;
    uVar8 = _UNK_1402d33f8;
    uVar9 = _DAT_1402d33f0;
    uVar13 = uVar13 + 1;
  } while ((longlong)uVar13 < 8);
  puVar7 = puVar6 + 0x10;
  *puVar6 = 0x10000007;
  *(undefined4 *)(puVar6 + 1) = 0;
  *(undefined4 *)((longlong)puVar6 + 0xc) = 0x50000007;
  *(undefined4 *)(puVar6 + 2) = 0x8006;
  *(undefined4 *)((longlong)puVar6 + 0x14) = 0x10000000;
  puVar6[3] = 0xe;
  *(undefined4 *)(puVar6 + 4) = 5;
  *(undefined4 *)((longlong)puVar6 + 0x24) = 0x40000000;
  *(undefined4 *)(puVar6 + 5) = 8;
  *(undefined4 *)(puVar6 + 6) = 0x80000;
  *(undefined4 *)((longlong)puVar6 + 0x34) = 0xff000000;
  *(undefined4 *)(puVar6 + 7) = 0x4c;
  *(undefined4 *)(puVar6 + 8) = 0x1000000;
  *(undefined4 *)((longlong)puVar6 + 0x44) = 1;
  *(undefined4 *)(puVar6 + 9) = 0x4e;
  *(undefined4 *)(puVar6 + 10) = 0x7000;
  *(undefined4 *)((longlong)puVar6 + 0x54) = 0x7200;
  *(undefined4 *)(puVar6 + 0xb) = 0x18;
  *(undefined4 *)(puVar6 + 0xc) = 0x30000;
  *(undefined4 *)(puVar6 + 0xd) = 0x47;
  puVar6[0xe] = 0x48;
  *(undefined4 *)(puVar6 + 0xf) = 0x42;
  local_158 = *(undefined1 *)(param_1 + 3);
  local_157 = *(undefined1 *)((longlong)param_1 + 0xd);
  local_156 = *(undefined1 *)((longlong)param_1 + 0xe);
  local_155 = *(undefined1 *)((longlong)param_1 + 0xf);
  local_134 = *(undefined1 *)(param_1 + 3);
  local_133 = *(undefined1 *)((longlong)param_1 + 0xd);
  local_132 = *(undefined1 *)((longlong)param_1 + 0xe);
  local_131 = *(undefined1 *)((longlong)param_1 + 0xf);
  local_14c = fVar40;
  local_128 = fVar40;
  local_218 = uVar3;
  uStack_210 = uVar4;
  local_1f8 = uVar9;
  uStack_1f0 = uVar8;
  local_13c = 0xfffffff;
  local_118 = 0xfffffff;
  if ((*(byte *)((longlong)param_1 + 0x25) & 0x20) != 0) {
    local_318 = DAT_1402d2e0c;
    local_320 = (float)local_2a8[0];
    local_328 = (float)iVar15;
    auVar31._0_4_ = (float)local_308;
    auVar31._4_12_ = SUB1612(ZEXT816(0),4);
    local_330 = (undefined4 *)CONCAT44(local_330._4_4_,DAT_1402d2774);
    local_338 = CONCAT44(local_338._4_4_,DAT_1402d2848);
    local_310 = fVar38;
    FUN_1400ad600(&local_158,&local_134,DAT_1402d2880,auVar31._0_8_);
    local_338 = *(undefined8 *)(*(longlong *)(param_1 + 6) + 0x398);
    puVar7 = (undefined8 *)FUN_1401fe080(puVar7,0x156,2);
  }
  bVar21 = *(byte *)((longlong)param_1 + 0x25);
  if ((bVar21 & 1) == 0) {
    if ((bVar21 & 2) == 0) {
      if ((((bVar21 & 4) == 0) && ((bVar21 & 8) == 0)) && ((bVar21 & 0x10) == 0))
      goto LAB_1400bca8e;
      local_2f8 = local_278 + 1;
      local_300 = local_2f0 + 1;
      piVar19 = (int *)((longlong)&local_1d8 + 4);
      piVar20 = (int *)((longlong)&local_1a8 + 4);
      piVar22 = local_2a8 + 1;
      piVar14 = local_248 + 1;
      piVar16 = (int *)((longlong)&local_1f8 + 4);
      piVar25 = (int *)((longlong)&local_218 + 4);
    }
    else {
      local_2f8 = local_278 + 3;
      piVar19 = (int *)((longlong)&uStack_1d0 + 4);
      local_300 = local_2f0 + 3;
      piVar20 = (int *)((longlong)&uStack_1a0 + 4);
      piVar22 = local_2a8 + 3;
      piVar14 = local_248 + 3;
      piVar16 = (int *)((longlong)&uStack_1f0 + 4);
      piVar25 = (int *)((longlong)&uStack_210 + 4);
    }
  }
  else {
    local_2f8 = local_278 + 2;
    piVar19 = (int *)&uStack_1d0;
    local_300 = local_2f0 + 2;
    piVar20 = (int *)&uStack_1a0;
    piVar22 = local_2a8 + 2;
    piVar14 = local_248 + 2;
    piVar16 = (int *)&uStack_1f0;
    piVar25 = (int *)&uStack_210;
  }
  if (((*(byte *)((longlong)param_1 + 0x23) & 6) == 2) &&
     (((longlong)(int)*(short *)(param_1 + 8) / (longlong)(int)(*(byte *)(param_1 + 9) / 5) & 1U) ==
      0)) {
    iVar24 = local_2f0[5];
  }
  else {
    local_310 = (float)*piVar19;
    auVar32._0_4_ = (float)*local_2f8;
    auVar32._4_12_ = SUB1612(ZEXT816(0),4);
    local_318 = (float)*piVar20;
    local_320 = (float)*piVar22;
    local_328 = (float)*piVar14;
    auVar29._0_4_ = (float)*local_300;
    auVar29._4_12_ = SUB1612(ZEXT816(0),4);
    local_330 = (undefined4 *)CONCAT44(local_330._4_4_,(float)*piVar16);
    local_338 = CONCAT44(local_338._4_4_,(float)*piVar25);
    FUN_1400ad600(&local_158,&local_134,auVar29._0_8_,auVar32._0_8_);
    local_338 = *(undefined8 *)(*(longlong *)(param_1 + 6) + 0x398);
    puVar7 = (undefined8 *)FUN_1401fe080(puVar7,0x156,2);
    iVar24 = local_2f0[5];
  }
LAB_1400bca8e:
  bVar21 = *(byte *)((longlong)param_1 + 0x25);
  if (((bVar21 & 4) != 0) || ((bVar21 & 0x18) != 0)) {
    if ((bVar21 & 4) == 0) {
      if ((bVar21 & 8) == 0) {
        iVar15 = -1;
        if ((bVar21 & 0x10) != 0) {
          iVar15 = 2;
        }
      }
      else {
        iVar15 = 0;
      }
    }
    else {
      iVar15 = 1;
    }
    uVar18 = *(undefined1 *)((longlong)param_1 + 3);
    uVar12 = *(undefined1 *)((longlong)param_1 + 2);
    local_184 = *param_1;
    uVar1 = *(undefined2 *)param_1;
    fVar38 = (float)iVar17 * fVar39;
    uVar9 = *(undefined8 *)(*(longlong *)(param_1 + 6) + 0x3a0);
    *puVar7 = 0x10000007;
    local_308 = (int)((float)iVar26 * fVar39 + fVar37);
    *(undefined4 *)(puVar7 + 1) = 0;
    *(undefined4 *)((longlong)puVar7 + 0xc) = 0x50000007;
    *(undefined4 *)(puVar7 + 2) = 0x8006;
    *(undefined4 *)((longlong)puVar7 + 0x14) = 0x10000000;
    puVar7[3] = 0xe;
    *(undefined4 *)(puVar7 + 4) = 5;
    *(undefined4 *)((longlong)puVar7 + 0x24) = 0x40000000;
    *(undefined4 *)(puVar7 + 5) = 8;
    *(undefined4 *)(puVar7 + 6) = 0x80000;
    *(undefined4 *)((longlong)puVar7 + 0x34) = 0xff000000;
    *(undefined4 *)(puVar7 + 7) = 0x4c;
    *(undefined4 *)(puVar7 + 8) = 0x1000000;
    *(undefined4 *)((longlong)puVar7 + 0x44) = 1;
    *(undefined4 *)(puVar7 + 9) = 0x4e;
    *(undefined4 *)(puVar7 + 10) = 0x7000;
    *(undefined4 *)((longlong)puVar7 + 0x54) = 0x7200;
    *(undefined4 *)(puVar7 + 0xb) = 0x18;
    *(undefined4 *)(puVar7 + 0xc) = 0x30000;
    *(undefined4 *)(puVar7 + 0xd) = 0x47;
    local_2c0 = (int)((float)local_278[8] * fVar39 + fVar34);
    iVar17 = (int)((float)iVar26 * fVar39 + fVar38 + fVar37);
    fVar35 = (float)iVar23 * fVar39;
    iVar23 = (int)((float)local_278[8] * fVar39 + fVar35 + fVar34);
    local_1a8 = CONCAT62(CONCAT51(CONCAT41(local_1a8._4_4_,uVar18),uVar12),uVar1);
    uStack_1a0 = CONCAT44(fVar40,(int)uStack_1a0);
    uStack_18c = 0xfffffff;
    uStack_188 = 0;
    local_168 = 0xfffffff;
    puVar7[0xe] = 0x44;
    *(undefined4 *)(puVar7 + 0xf) = 0x42;
    uStack_198 = CONCAT44(local_308,0xd000000);
    local_174 = 0xe700400;
    local_338 = uVar9;
    iStack_190 = local_2c0;
    local_178 = fVar40;
    local_170 = iVar17;
    local_16c = iVar23;
    uVar8 = FUN_1401fe080(puVar7 + 0x10,0x156,2,&local_1a8);
    local_2bc = (int)((float)iVar26 * fVar39 + fVar37);
    local_2b8 = (int)((float)local_278[4] * fVar39 + fVar34);
    local_2b4 = (int)((float)iVar26 * fVar39 + fVar38 + fVar37);
    local_2b0 = (int)((float)local_278[4] * fVar39 + fVar35 + fVar34);
    uStack_198 = CONCAT44(local_2bc,0xd000400);
    local_174 = 0xe700800;
    local_338 = uVar9;
    iStack_190 = local_2b8;
    local_170 = local_2b4;
    local_16c = local_2b0;
    uVar8 = FUN_1401fe080(uVar8,0x156,2,&local_1a8);
    iVar27 = (int)((float)iVar26 * fVar39 + fVar37);
    local_2ac = (int)((float)local_278[10] * fVar39 + fVar34);
    local_170 = (int)(fVar38 + (float)iVar26 * fVar39 + fVar37);
    local_300 = (int *)CONCAT44(local_300._4_4_,local_170);
    local_16c = (int)(fVar35 + (float)local_278[10] * fVar39 + fVar34);
    local_2f8 = (int *)CONCAT44(local_2f8._4_4_,local_16c);
    uStack_198 = CONCAT44(iVar27,0xd000800);
    local_174 = 0xe700c00;
    local_338 = uVar9;
    iStack_190 = local_2ac;
    uVar8 = FUN_1401fe080(uVar8,0x156,2,&local_1a8);
    uStack_18c = 0xfffffff;
    uStack_188 = 0;
    local_168 = 0xfffffff;
    uStack_1a0 = CONCAT44(fVar40,(int)uStack_1a0);
    uVar9 = *(undefined8 *)(*(longlong *)(param_1 + 6) + 0x3a0);
    if (iVar15 == 0) {
      uVar18 = *(undefined1 *)(param_1 + 2);
      uVar12 = *(undefined1 *)((longlong)param_1 + 9);
      uVar10 = *(undefined1 *)((longlong)param_1 + 10);
      uVar5 = *(undefined1 *)((longlong)param_1 + 0xb);
    }
    else {
      uVar18 = *(undefined1 *)(param_1 + 1);
      uVar12 = *(undefined1 *)((longlong)param_1 + 5);
      uVar10 = *(undefined1 *)((longlong)param_1 + 6);
      uVar5 = *(undefined1 *)((longlong)param_1 + 7);
    }
    local_184 = CONCAT31(CONCAT21(CONCAT11(uVar5,uVar10),uVar12),uVar18);
    local_1a8._2_6_ = CONCAT51(CONCAT41(local_1a8._4_4_,uVar5),uVar10);
    iStack_190 = local_2c0;
    uStack_198 = CONCAT44(local_308,0xe800000);
    local_174 = 0xff00400;
    local_338 = uVar9;
    local_178 = fVar40;
    local_170 = iVar17;
    local_16c = iVar23;
    local_1a8._0_1_ = uVar18;
    local_1a8._1_1_ = uVar12;
    uVar8 = FUN_1401fe080(uVar8,0x156,2,&local_1a8);
    uStack_18c = 0xfffffff;
    uStack_188 = 0;
    local_168 = 0xfffffff;
    uStack_1a0 = CONCAT44(fVar40,(int)uStack_1a0);
    if (iVar15 == 1) {
      local_184 = param_1[2];
      local_1a8._0_4_ = param_1[2];
    }
    else {
      local_184 = param_1[1];
      local_1a8._0_4_ = param_1[1];
    }
    iStack_190 = local_2b8;
    local_170 = local_2b4;
    local_16c = local_2b0;
    uStack_198 = CONCAT44(local_2bc,0xe800400);
    local_174 = 0xff00800;
    local_338 = uVar9;
    local_178 = fVar40;
    uVar8 = FUN_1401fe080(uVar8,0x156,2,&local_1a8);
    uStack_18c = 0xfffffff;
    uStack_188 = 0;
    local_168 = 0xfffffff;
    uStack_1a0 = CONCAT44(fVar40,(int)uStack_1a0);
    if (iVar15 == 2) {
      local_184 = param_1[2];
      uVar2 = param_1[2];
    }
    else {
      local_184 = param_1[1];
      uVar2 = param_1[1];
    }
    local_1a8 = CONCAT44(local_1a8._4_4_,uVar2);
    iStack_190 = local_2ac;
    local_170 = local_300._0_4_;
    local_16c = local_2f8._0_4_;
    uStack_198 = CONCAT44(iVar27,0xe800800);
    local_174 = 0xff00c00;
    local_338 = uVar9;
    local_178 = fVar40;
    uVar9 = FUN_1401fe080(uVar8,0x156,2,&local_1a8);
    local_330 = param_1 + 4;
    iVar26 = -0xc;
    if ((*(byte *)((longlong)param_1 + 0x22) & 4) == 0) {
      iVar26 = -0x10;
    }
    iVar23 = local_278[(longlong)iVar15 + 8];
    iVar17 = local_2a8[(longlong)iVar15 + 8];
    iVar27 = local_248[(longlong)iVar15 + 8] + iVar26 + local_2f0[(longlong)iVar15 + 8];
    iVar26 = 0xb;
    if ((*(byte *)((longlong)param_1 + 0x22) & 4) == 0) {
      iVar26 = 0xf;
    }
    auVar28._0_4_ = (float)(iVar26 + local_2f0[(longlong)iVar15 + 8]);
    auVar28._4_12_ = SUB1612(ZEXT816(0),4);
    auVar33._0_4_ = (float)iVar27;
    auVar33._4_12_ = SUB1612(ZEXT816(0),4);
    auVar30._0_4_ = (float)iVar23;
    auVar30._4_12_ = SUB1612(ZEXT816(0),4);
    local_338 = CONCAT44(local_338._4_4_,(float)(iVar23 + -2 + iVar17));
    uVar9 = FUN_1400bff50(uVar9,auVar28._0_8_,auVar30._0_8_,auVar33._0_8_);
    local_156 = *(undefined1 *)((longlong)param_1 + 10);
    local_155 = *(undefined1 *)((longlong)param_1 + 0xb);
    local_158 = *(undefined1 *)(param_1 + 2);
    local_157 = *(undefined1 *)((longlong)param_1 + 9);
    iVar27 = iVar27 * 0x10;
    local_144 = iVar27 + 0x7000;
    local_13c = 0xfffffff;
    local_118 = 0xfffffff;
    local_f4 = 0xfffffff;
    local_d0 = 0xfffffff;
    local_d8 = (iVar24 + 0x712) * 0x10;
    local_f8 = 0x89c0;
    local_d4 = 0x89c0;
    local_140 = (iVar17 / 2 + 0x720 + iVar23) * 0x10;
    local_fc = iVar27 + 0x7050;
    if ((*(byte *)((longlong)param_1 + 0x22) & 4) != 0) {
      local_fc = iVar27 + 0x7040;
      local_d8 = local_d8 + -0x40;
    }
    local_338 = 0;
    local_14c = fVar40;
    local_134 = local_158;
    local_133 = local_157;
    local_132 = local_156;
    local_131 = local_155;
    local_128 = fVar40;
    local_120 = local_fc;
    local_11c = local_140;
    local_110 = local_158;
    local_10f = local_157;
    local_10e = local_156;
    local_10d = local_155;
    local_104 = fVar40;
    local_ec = local_158;
    local_eb = local_157;
    local_ea = local_156;
    local_e9 = local_155;
    local_e0 = fVar40;
    puVar6 = (undefined8 *)FUN_1401fe080(uVar9,0x42,4,&local_158);
    *puVar6 = 0x10000007;
    puVar7 = puVar6 + 0x10;
    *(undefined4 *)(puVar6 + 1) = 0;
    *(undefined4 *)((longlong)puVar6 + 0xc) = 0x50000007;
    *(undefined4 *)(puVar6 + 2) = 0x8006;
    *(undefined4 *)((longlong)puVar6 + 0x14) = 0x10000000;
    puVar6[3] = 0xe;
    *(undefined4 *)(puVar6 + 4) = 5;
    *(undefined4 *)((longlong)puVar6 + 0x24) = 0x40000000;
    *(undefined4 *)(puVar6 + 5) = 8;
    *(undefined4 *)(puVar6 + 6) = 0x80000;
    *(undefined4 *)((longlong)puVar6 + 0x34) = 0xff000000;
    *(undefined4 *)(puVar6 + 7) = 0x4c;
    *(undefined4 *)(puVar6 + 8) = 0x1000000;
    *(undefined4 *)((longlong)puVar6 + 0x44) = 1;
    *(undefined4 *)(puVar6 + 9) = 0x4e;
    *(undefined4 *)(puVar6 + 10) = 0x7000;
    *(undefined4 *)((longlong)puVar6 + 0x54) = 0x7200;
    *(undefined4 *)(puVar6 + 0xb) = 0x18;
    *(undefined4 *)(puVar6 + 0xc) = 0x30000;
    *(undefined4 *)(puVar6 + 0xd) = 0x47;
    puVar6[0xe] = 0x48;
    *(undefined4 *)(puVar6 + 0xf) = 0x42;
  }
  return puVar7;
}

