/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401580c0; RVA 0x1580c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 *
FUN_1401580c0(longlong param_1,undefined8 *param_2,longlong param_3,longlong param_4,float param_5)

{
  longlong lVar1;
  uint *puVar2;
  float fVar3;
  undefined8 *puVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  
  fVar3 = DAT_140328448;
  if (DAT_140328448 - *(float *)(param_1 + 0xc7c) <= param_5) {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x31) || (*(ushort *)(param_1 + 0x2aa) < 0x31)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 0xc0);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x180);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x31) || (*(ushort *)(param_1 + 0x3aa) < 0x31)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 0xc0);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 0x180);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
  }
  else {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x31) || (*(ushort *)(param_1 + 0x2aa) < 0x31)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 0xc0);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x180);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x31) || (*(ushort *)(param_1 + 0x3aa) < 0x31)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 0xc0);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 0x180);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
  }
  if (param_5 <= *(float *)(param_1 + 0xc78) - fVar3) {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x30) || (*(ushort *)(param_1 + 0x2aa) < 0x30)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 0xbc);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x178);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x30) || (*(ushort *)(param_1 + 0x3aa) < 0x30)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 0xbc);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 0x178);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
  }
  else {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x30) || (*(ushort *)(param_1 + 0x2aa) < 0x30)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 0xbc);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x178);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x30) || (*(ushort *)(param_1 + 0x3aa) < 0x30)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 0xbc);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 0x178);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
  }
  if (fVar3 - *(float *)(param_1 + 0xc84) <= param_5) {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x33) || (*(ushort *)(param_1 + 0x2aa) < 0x33)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 200);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 400);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x33) || (*(ushort *)(param_1 + 0x3aa) < 0x33)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 200);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 400);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
  }
  else {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x33) || (*(ushort *)(param_1 + 0x2aa) < 0x33)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 200);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 400);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x33) || (*(ushort *)(param_1 + 0x3aa) < 0x33)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 200);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 400);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
  }
  if (param_5 <= *(float *)(param_1 + 0xc80) - fVar3) {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x32) || (*(ushort *)(param_1 + 0x2aa) < 0x32)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 0xc4);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x188);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x32) || (*(ushort *)(param_1 + 0x3aa) < 0x32)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 0xc4);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 0x188);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
  }
  else {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x32) || (*(ushort *)(param_1 + 0x2aa) < 0x32)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 0xc4);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x188);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x32) || (*(ushort *)(param_1 + 0x3aa) < 0x32)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 0xc4);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 0x188);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
  }
  if ((param_5 <= (float)(*(uint *)(param_1 + 0xc74) ^ DAT_1402d3770) - fVar3) ||
     (fVar3 + *(float *)(param_1 + 0xc70) <= param_5)) {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x2f) || (*(ushort *)(param_1 + 0x2aa) < 0x2f)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 0xb8);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x170);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x2f) || (*(ushort *)(param_1 + 0x3aa) < 0x2f)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 0xb8);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 0x170);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 | 2;
      } while (lVar6 < iVar5);
    }
  }
  else {
    if ((*(ushort *)(param_1 + 0x2a8) < 0x2f) || (*(ushort *)(param_1 + 0x2aa) < 0x2f)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x2b0) + 0xb8);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x170);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x2a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
    if ((*(ushort *)(param_1 + 0x3a8) < 0x2f) || (*(ushort *)(param_1 + 0x3aa) < 0x2f)) {
      iVar5 = 0;
      lVar7 = 0;
    }
    else {
      iVar5 = *(int *)(*(longlong *)(param_1 + 0x3b0) + 0xb8);
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 0x3b8) + 0x170);
    }
    if (0 < iVar5) {
      lVar6 = 0;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
        puVar2 = (uint *)((ulonglong)*(ushort *)(lVar7 + lVar1) * 800 + 0x31c +
                         *(longlong *)(param_1 + 0x3a0));
        *puVar2 = *puVar2 & 0xfffffffd;
      } while (lVar6 < iVar5);
    }
  }
  *param_2 = 0x50000000;
  FUN_140197b30(param_2,&DAT_140294b50);
  *(undefined4 *)(param_2 + 1) = 0;
  *(undefined4 *)((longlong)param_2 + 0xc) = 0x11000000;
  param_2[2] = 0x50000000;
  FUN_140197b30(param_2 + 2,&DAT_140294b40);
  auVar8 = SUB3216(*(undefined1 (*) [32])(param_3 + 0x20),0);
  vshufps_avx(auVar8,auVar8,0xaa);
  auVar9 = SUB3216(*(undefined1 (*) [32])(param_3 + 0x20),0x10);
  vshufps_avx(auVar9,auVar9,0xff);
  vshufps_avx(auVar8,auVar8,0xff);
  vshufps_avx(auVar9,auVar9,0xaa);
  auVar8 = SUB3216(*(undefined1 (*) [32])(param_4 + 0x20),0);
  vshufps_avx(auVar8,auVar8,0xaa);
  auVar9 = SUB3216(*(undefined1 (*) [32])(param_4 + 0x20),0x10);
  vshufps_avx(auVar9,auVar9,0xff);
  vshufps_avx(auVar8,auVar8,0xff);
  vshufps_avx(auVar9,auVar9,0xaa);
  *(undefined4 *)(param_2 + 3) = 0x3000040;
  *(undefined4 *)((longlong)param_2 + 0x1c) = 0x2000198;
  DAT_14030cab0 = 0x40;
  puVar4 = (undefined8 *)FUN_140157f40();
  *puVar4 = 0x10000003;
  *(undefined4 *)(puVar4 + 1) = 0;
  *(undefined4 *)((longlong)puVar4 + 0xc) = 0x50000003;
  *(undefined4 *)(puVar4 + 2) = 0x8002;
  *(undefined4 *)((longlong)puVar4 + 0x14) = 0x10000000;
  puVar4[3] = 0xe;
  *(undefined4 *)(puVar4 + 4) = 0;
  *(undefined4 *)(puVar4 + 5) = 0x4a;
  *(undefined4 *)(puVar4 + 6) = 0;
  *(undefined4 *)(puVar4 + 7) = 0x4b;
  return puVar4 + 8;
}

