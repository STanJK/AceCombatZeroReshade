/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14003a2e0; RVA 0x3a2e0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14003a2e0(float *param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  undefined1 auVar18 [16];
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  float fVar33;
  float fVar34;
  
  fVar1 = param_1[3];
  fVar2 = param_1[2];
  fVar3 = param_1[6];
  fVar4 = param_1[9];
  fVar5 = param_1[7];
  fVar6 = param_1[0xc];
  fVar7 = param_1[8];
  fVar8 = param_1[0xd];
  fVar9 = param_1[10];
  fVar10 = param_1[0xb];
  fVar11 = param_1[5];
  fVar12 = param_1[4];
  fVar13 = param_1[0xe];
  fVar22 = fVar5 * fVar2 - fVar3 * fVar1;
  fVar23 = fVar8 * fVar7 - fVar6 * fVar4;
  fVar24 = fVar10 * fVar2 - fVar9 * fVar1;
  fVar25 = fVar12 * fVar8 - fVar11 * fVar6;
  fVar26 = fVar12 * fVar4 - fVar11 * fVar7;
  fVar14 = param_1[0xf];
  fVar27 = fVar14 * fVar2 - fVar13 * fVar1;
  fVar15 = param_1[1];
  fVar16 = *param_1;
  fVar28 = fVar16 * fVar8 - fVar15 * fVar6;
  fVar29 = fVar16 * fVar4 - fVar15 * fVar7;
  fVar30 = fVar14 * fVar3 - fVar13 * fVar5;
  fVar31 = fVar16 * fVar11 - fVar15 * fVar12;
  fVar32 = fVar14 * fVar9 - fVar13 * fVar10;
  fVar33 = fVar10 * fVar3 - fVar9 * fVar5;
  fVar34 = fVar23 * fVar22 +
           -(fVar25 * fVar24) +
           fVar26 * fVar27 + fVar33 * fVar28 + (fVar31 * fVar32 - fVar30 * fVar29);
  if (fVar34 != 0.0) {
    fVar19 = fVar2 * fVar8;
    fVar20 = fVar11 * param_1[0xe];
    fVar17 = param_1[0xf];
    fVar21 = param_1[0xe] * fVar4;
    *param_1 = fVar33 * fVar8 + (fVar13 * fVar5 - fVar14 * fVar3) * fVar4 + fVar11 * fVar32;
    fVar32 = param_1[0xb];
    param_1[4] = (fVar32 * fVar12 - fVar5 * fVar7) * param_1[0xe] +
                 (fVar17 * fVar7 - fVar32 * fVar6) * fVar3 +
                 (fVar5 * fVar6 - fVar17 * fVar12) * fVar9;
    param_1[8] = param_1[0xf] * fVar26 + fVar32 * (fVar11 * fVar6 - fVar12 * fVar8) + fVar5 * fVar23
    ;
    param_1[0xc] = (fVar3 * fVar4 - fVar9 * fVar11) * fVar6 +
                   (fVar8 * fVar9 - fVar21) * fVar12 + (fVar20 - fVar3 * fVar8) * fVar7;
    param_1[1] = (fVar13 * fVar10 - fVar14 * fVar9) * fVar15 +
                 (fVar9 * fVar1 - fVar10 * fVar2) * fVar8 + fVar4 * fVar27;
    param_1[5] = (fVar32 * fVar6 - fVar17 * fVar7) * fVar2 +
                 (fVar1 * fVar7 - param_1[0xb] * fVar16) * param_1[0xe] +
                 (fVar17 * fVar16 - fVar1 * fVar6) * fVar9;
    param_1[9] = (fVar6 * fVar4 - fVar8 * fVar7) * fVar1 +
                 (fVar15 * fVar7 - fVar16 * fVar4) * param_1[0xf] + param_1[0xb] * fVar28;
    auVar18 = vinsertps_avx(ZEXT416((uint)fVar19),ZEXT416((uint)fVar19),0xe);
    param_1[2] = (fVar13 * fVar1 - fVar14 * fVar2) * fVar11 + fVar30 * fVar15 + fVar8 * fVar22;
    param_1[0xd] = fVar16 * (fVar21 - fVar8 * fVar9) +
                   (fVar9 * fVar15 - fVar2 * fVar4) * fVar6 +
                   (auVar18._0_4_ - fVar13 * fVar15) * fVar7;
    param_1[6] = fVar3 * (fVar1 * fVar6 - fVar17 * fVar16) +
                 (fVar16 * fVar5 - fVar1 * fVar12) * param_1[0xe] +
                 (fVar17 * fVar12 - fVar5 * fVar6) * fVar2;
    param_1[10] = fVar5 * (fVar15 * fVar6 - fVar16 * fVar8) + fVar1 * fVar25 + param_1[0xf] * fVar31
    ;
    fVar14 = param_1[0xb];
    param_1[0xe] = fVar12 * (fVar13 * fVar15 - fVar19) +
                   (fVar2 * fVar11 - fVar3 * fVar15) * fVar6 + (fVar3 * fVar8 - fVar20) * fVar16;
    param_1[3] = fVar4 * (fVar3 * fVar1 - fVar5 * fVar2) +
                 (fVar9 * fVar5 - fVar10 * fVar3) * fVar15 + fVar11 * fVar24;
    param_1[7] = fVar9 * (fVar1 * fVar12 - fVar16 * fVar5) +
                 fVar3 * (fVar14 * fVar16 - fVar1 * fVar7) +
                 (fVar5 * fVar7 - fVar14 * fVar12) * fVar2;
    param_1[0xb] = fVar14 * (fVar15 * fVar12 - fVar16 * fVar11) +
                   fVar1 * (fVar11 * fVar7 - fVar12 * fVar4) + fVar5 * fVar29;
    fVar1 = DAT_1402d22d0;
    fVar34 = DAT_1402d22d0 / fVar34;
    param_1[0xf] = fVar7 * (fVar3 * fVar15 - fVar2 * fVar11) +
                   fVar12 * (fVar4 * fVar2 - fVar9 * fVar15) +
                   (fVar9 * fVar11 - fVar3 * fVar4) * fVar16;
    FUN_14003b3e0(fVar1,fVar34);
  }
  return;
}

