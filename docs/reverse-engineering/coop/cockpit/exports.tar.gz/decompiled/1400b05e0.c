/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b05e0; RVA 0xb05e0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_1400b05e0(longlong param_1,undefined8 param_2,longlong param_3,longlong param_4,
             longlong *param_5,int *param_6)

{
  undefined1 auVar1 [32];
  undefined1 auVar2 [32];
  byte bVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [12];
  char cVar8;
  int iVar9;
  uint uVar10;
  undefined8 uVar11;
  longlong lVar12;
  longlong lVar13;
  longlong lVar14;
  uint uVar15;
  float fVar16;
  undefined1 auVar17 [16];
  float fVar18;
  undefined1 auVar19 [16];
  float fVar20;
  float fVar21;
  float fVar22;
  undefined1 auVar23 [16];
  float fVar24;
  float fVar25;
  undefined1 auVar26 [64];
  float fVar27;
  float fVar28;
  float fVar29;
  undefined1 auVar30 [64];
  undefined1 auVar31 [64];
  float fVar32;
  float fVar33;
  undefined1 auStack_2b8 [32];
  undefined8 local_298;
  undefined4 local_290;
  float local_288;
  float local_280;
  float local_278;
  float local_270;
  float local_268;
  float local_264;
  float local_260;
  float local_25c;
  float local_258;
  float local_254;
  undefined1 local_248 [8];
  float fStack_240;
  float fStack_23c;
  float local_238;
  float local_234;
  float local_230;
  float local_22c;
  undefined1 local_228 [8];
  undefined8 uStack_220;
  float local_218;
  float local_214;
  float local_210;
  float local_20c;
  float local_208;
  float local_204;
  float local_200;
  float local_1fc;
  undefined1 local_1f8 [8];
  float fStack_1f0;
  float fStack_1ec;
  float local_1e8 [4];
  undefined1 local_1d8 [16];
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  undefined1 local_1b8 [16];
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined1 local_198 [16];
  undefined1 local_188 [16];
  undefined1 local_178 [16];
  undefined1 local_168 [16];
  float local_158;
  float local_154;
  float local_150;
  float local_14c;
  float local_148;
  float local_144;
  float local_140;
  undefined8 local_13c;
  float local_134;
  float local_130;
  float local_12c;
  float local_128;
  float local_124;
  float local_120;
  float local_11c;
  undefined8 local_118;
  undefined1 local_110;
  undefined1 local_10f;
  undefined1 local_10e;
  undefined1 local_10d;
  float local_104;
  undefined2 local_100;
  undefined2 local_fe;
  int local_fc;
  int local_f8;
  undefined8 local_f4;
  ulonglong local_e8;
  
  local_e8 = DAT_140309040 ^ (ulonglong)auStack_2b8;
  lVar13 = *(longlong *)(param_1 + 0x328);
  if (lVar13 == 0) {
    return param_2;
  }
  cVar8 = FUN_1400b7400(param_1,param_5);
  if (cVar8 == '\0') {
    return param_2;
  }
  _local_1f8 = *(undefined1 (*) [16])(lVar13 + 600);
  iVar9 = FUN_140202ed0(param_3 + 0x150,local_1f8);
  if (iVar9 != 0) {
    return param_2;
  }
  bVar3 = *(byte *)(param_1 + 0x3ca);
  lVar14 = *(longlong *)(param_1 + 0x2f0);
  local_1fc = *(float *)(lVar13 + 0x20c + (ulonglong)bVar3 * 4);
  if (lVar14 == 0) {
    return param_2;
  }
  local_264 = *(float *)(lVar14 + 0x14) * DAT_1402d2478;
  if (local_264 <= local_1fc) {
    return param_2;
  }
  auVar4 = vcvtdq2ps_avx(ZEXT416(*(uint *)(lVar14 + 0x44)));
  lVar14 = *(longlong *)(lVar13 + 0x1b8);
  local_204 = auVar4._0_4_;
  auVar4 = vcvtdq2ps_avx(ZEXT116(*(byte *)(param_4 + 0xcc8)));
  fVar32 = local_1fc /
           (((*(float *)(param_1 + 0x98) * DAT_1402d2934) / auVar4._0_4_) * DAT_1402d1e74 +
           (local_204 * DAT_1402d2360) / auVar4._0_4_);
  local_208 = fVar32;
  if (lVar14 == 0) {
    lVar14 = *(longlong *)(lVar13 + 0x360);
    if (lVar14 == 0) {
      local_154 = 0.0;
      uVar15 = 0;
      if (*(longlong *)(lVar13 + 0x368) == 0) {
        if (*(longlong *)(lVar13 + 0x370) != 0) {
          uVar15 = *(uint *)(*(longlong *)(lVar13 + 0x370) + 0x288);
        }
      }
      else {
        uVar15 = *(uint *)(*(longlong *)(lVar13 + 0x368) + 0x2c8);
      }
      fVar24 = (float)(uVar15 ^ DAT_1402d3770);
      local_158 = DAT_1402d22d0;
      local_144 = DAT_1402d22d0;
      local_130 = DAT_1402d22d0;
      local_11c = DAT_1402d22d0;
      local_13c = 0;
      local_150 = local_154;
      local_14c = local_154;
      local_148 = local_154;
      local_140 = local_154;
      local_134 = local_154;
      local_12c = local_154;
      local_128 = local_154;
      local_124 = local_154;
      local_120 = local_154;
      FUN_140202230(&local_158,&local_158,lVar13 + 0x268);
      fVar21 = fVar24 * local_13c._4_4_;
      fVar20 = fVar24 * local_134;
      fVar22 = fVar24 * local_130;
      fVar24 = fVar24 * local_12c;
    }
    else {
      fVar21 = *(float *)(lVar14 + 0x3f8);
      fVar20 = *(float *)(lVar14 + 0x3fc);
      fVar22 = *(float *)(lVar14 + 0x400);
      fVar24 = *(float *)(lVar14 + 0x404);
    }
  }
  else {
    fVar21 = *(float *)(lVar14 + 0x15d0);
    fVar20 = *(float *)(lVar14 + 0x15d4);
    fVar22 = *(float *)(lVar14 + 0x15d8);
    fVar24 = *(float *)(lVar14 + 0x15dc);
  }
  auVar1 = *(undefined1 (*) [32])(param_3 + 0x110);
  auVar2 = *(undefined1 (*) [32])(param_3 + 0x130);
  fVar25 = *(float *)(lVar13 + 0x260);
  fVar33 = *(float *)(lVar13 + 600);
  fVar18 = *(float *)(lVar13 + 0x25c);
  fVar16 = *(float *)(lVar13 + 0x264);
  fVar29 = fVar32 * fVar22 + fVar25;
  auVar23 = auVar1._0_16_;
  auVar4 = vshufps_avx(auVar23,auVar23,0xff);
  fVar27 = fVar32 * fVar21 + fVar33;
  fVar28 = fVar32 * fVar20 + fVar18;
  auVar17 = auVar2._0_16_;
  local_1b8 = auVar2._16_16_;
  auVar19 = vshufps_avx(local_1b8,local_1b8,0xff);
  fVar24 = fVar32 * fVar24 + fVar16;
  local_1d8 = auVar1._16_16_;
  auVar5 = vshufps_avx(local_1d8,local_1d8,0xff);
  auVar6 = vshufps_avx(auVar17,auVar17,0xff);
  fVar22 = DAT_1402d2544 /
           (fVar28 * auVar5._0_4_ + auVar4._0_4_ * fVar27 +
           fVar29 * auVar6._0_4_ + auVar19._0_4_ * fVar24);
  local_168 = vshufps_avx(auVar17,auVar17,0xff);
  local_178 = vshufps_avx(local_1b8,local_1b8,0xff);
  local_198 = vshufps_avx(auVar23,auVar23,0xff);
  local_188 = vshufps_avx(local_1d8,local_1d8,0xff);
  fVar20 = DAT_1402d2544 /
           (fVar16 * local_178._0_4_ + local_168._0_4_ * fVar25 +
           fVar18 * local_188._0_4_ + local_198._0_4_ * fVar33);
  local_268 = fVar20 * (fVar16 * auVar2._16_4_ + auVar2._0_4_ * fVar25 +
                       fVar18 * auVar1._16_4_ + auVar1._0_4_ * fVar33) -
              (fVar28 * auVar1._16_4_ + auVar1._0_4_ * fVar27 +
              fVar29 * auVar2._0_4_ + auVar2._16_4_ * fVar24) * fVar22;
  auVar4 = vshufps_avx(auVar23,auVar23,0x55);
  auVar19 = vshufps_avx(local_1b8,local_1b8,0x55);
  auVar5 = vshufps_avx(local_1d8,local_1d8,0x55);
  auVar6 = vshufps_avx(auVar17,auVar17,0x55);
  auVar17 = SUB3216(*(undefined1 (*) [32])(param_3 + 0x130),0);
  _local_228 = vshufps_avx(auVar17,auVar17,0x55);
  auVar17 = SUB3216(*(undefined1 (*) [32])(param_3 + 0x130),0x10);
  _local_248 = vshufps_avx(auVar17,auVar17,0x55);
  fVar32 = *(float *)(param_1 + 0x74);
  auVar17 = vshufps_avx(auVar23,auVar23,0x55);
  lVar13 = *(longlong *)
            (*(longlong *)(*(longlong *)(*param_5 + (ulonglong)bVar3 * 8) + 0x110) + 0x1b8);
  auVar23 = vshufps_avx(local_1d8,local_1d8,0x55);
  fVar21 = *(float *)(param_1 + 0x78);
  local_200 = fVar20 * (fVar16 * local_248._0_4_ + local_228._0_4_ * fVar25 +
                       fVar18 * auVar23._0_4_ + auVar17._0_4_ * fVar33) -
              (fVar28 * auVar5._0_4_ + auVar4._0_4_ * fVar27 +
              fVar29 * auVar6._0_4_ + auVar19._0_4_ * fVar24) * fVar22;
  local_260 = *(float *)(param_1 + 0x8c);
  _local_1f8 = ZEXT416(0);
  local_258 = *(float *)(param_1 + 0x94);
  local_25c = *(float *)(param_1 + 0x90);
  local_254 = DAT_1402d22d0;
  if (((*(ushort *)(lVar13 + 0x1b8) < 0x41) || (*(ushort *)(lVar13 + 0x1bc) < 0x41)) ||
     (**(int **)(lVar13 + 0x1d0) == 0)) {
    fVar20 = 0.0;
    fVar22 = 0.0;
    fVar24 = 0.0;
  }
  else {
    lVar12 = (ulonglong)*(ushort *)**(undefined8 **)(lVar13 + 0x1d8) * 800;
    lVar14 = *(longlong *)(lVar13 + 0x1b0);
    fVar20 = *(float *)(lVar12 + 0xc4 + lVar14);
    fVar22 = *(float *)(lVar12 + 200 + lVar14);
    fVar24 = *(float *)(lVar12 + 0xcc + lVar14);
  }
  local_1e8[1] = 0.0;
  local_1e8[2] = 0.0;
  local_1e8[0] = **(float **)(lVar13 + 0xfe0) * DAT_1402d1f38;
  local_1e8[3] = 0.0;
  auVar26 = ZEXT464(0);
  auVar30 = ZEXT1664(auVar17);
  auVar31 = ZEXT1664(auVar23);
  fVar25 = DAT_1402d22d0;
  fVar33 = DAT_1402d2544;
  FUN_140203050(local_1e8,&local_260,local_1e8);
  local_154 = auVar26._0_4_;
  local_158 = fVar25;
  local_150 = local_154;
  local_14c = local_154;
  local_148 = local_154;
  local_144 = fVar25;
  local_140 = local_154;
  local_134 = local_154;
  local_130 = fVar25;
  local_12c = local_154;
  local_128 = local_154;
  local_124 = local_154;
  local_120 = local_154;
  local_11c = fVar25;
  local_13c._0_4_ = local_154;
  local_13c._4_4_ = local_154;
  FUN_140202230(&local_158,&local_158,&local_260);
  local_298._0_4_ = (int)local_208;
  local_260 = fVar24 * local_13c._4_4_ + fVar22 * local_148 + fVar20 * local_158 +
              fVar32 + local_128;
  local_25c = fVar24 * local_134 + fVar22 * local_144 + fVar20 * local_154 + fVar21 + local_124;
  local_258 = fVar24 * local_130 + fVar22 * local_140 + fVar20 * local_150 +
              *(float *)(param_1 + 0x7c) + local_120;
  local_288 = local_204;
  local_290 = *(undefined4 *)(param_1 + 0x98);
  local_254 = fVar22 * (float)local_13c + fVar20 * local_14c + fVar24 * local_12c + local_11c;
  FUN_14013c8f0(param_4 + 0xca0,local_1f8,&local_260,local_1e8);
  fVar24 = DAT_1402d1fbc;
  fVar20 = *(float *)(param_3 + 0x110);
  fVar22 = *(float *)(param_3 + 0x130);
  fVar32 = DAT_1402d1fbc * local_200;
  fVar18 = fVar33 / ((float)local_1f8._4_4_ * (float)local_188._0_4_ +
                     (float)local_198._0_4_ * (float)local_1f8._0_4_ +
                    (float)local_168._0_4_ * fStack_1f0 + (float)local_178._0_4_ * fStack_1ec);
  fVar21 = ((float)local_1f8._4_4_ * auVar31._0_4_ + auVar30._0_4_ * (float)local_1f8._0_4_ +
           (float)local_228._0_4_ * fStack_1f0 + (float)local_248._0_4_ * fStack_1ec) * fVar18 *
           DAT_1402d1fbc;
  if (*(ushort *)(param_1 + 0x39c) == 0xffff) {
    if ((*(uint *)(param_1 + 0x34c) & 0x10001) == 0) goto LAB_1400b0efc;
    local_158 = *(float *)(param_1 + 0x1f8);
  }
  else {
    if ((*(uint *)(param_1 + 0x348) >> 0x1a & 1) == 0) {
      *(uint *)(param_1 + 0x348) = *(uint *)(param_1 + 0x348) | 0x4000000;
    }
    if ((*(ushort *)(param_1 + 0x39c) & 4) == 0) {
      local_158 = *(float *)(param_1 + 0x1f8);
    }
    else {
LAB_1400b0efc:
      local_158 = *(float *)(param_1 + 0x21c);
    }
  }
  local_270 = DAT_1402d25e8;
  local_278 = DAT_1402d25e8;
  local_110 = SUB41(local_158,0);
  lVar13 = 0;
  local_10e = (undefined1)((uint)local_158 >> 0x10);
  local_10d = (undefined1)((uint)local_158 >> 0x18);
  fVar20 = ((fVar18 * ((float)local_1f8._4_4_ * (float)local_1d8._0_4_ +
                       fVar20 * (float)local_1f8._0_4_ +
                      fVar22 * fStack_1f0 + (float)local_1b8._0_4_ * fStack_1ec) + local_268) *
            fVar24 + (float)*param_6) - DAT_1402d29e8;
  fVar32 = (float)param_6[1] + fVar21 + fVar32;
  local_280 = (*(float *)(param_3 + 0x19c) / *(float *)(param_3 + 0x198)) * DAT_1402d25e8;
  local_288 = DAT_1402d25e8;
  local_290 = DAT_1402d26e8;
  local_298 = CONCAT44(local_298._4_4_,DAT_1402d23c0);
  local_13c = 0xfffffff;
  local_10f = (undefined1)((uint)local_158 >> 8);
  local_118 = 0xfffffff;
  local_f4 = 0xfffffff;
  auVar26 = ZEXT1664(auVar26._0_16_);
  local_14c = fVar25;
  local_134 = local_158;
  local_128 = fVar25;
  local_104 = fVar25;
  FUN_1400ad600(&local_158,&local_134);
  local_298 = *(undefined8 *)(*(longlong *)(param_1 + 0x300) + 0x398);
  uVar11 = FUN_1401fe080(param_2,0x156,2,&local_158);
  auVar19 = ZEXT416((uint)((local_1fc / local_264) * DAT_1402d249c));
  auVar4 = vcmpss_avx(ZEXT416((uint)DAT_1402d249c),auVar19,2);
  auVar4 = vblendvps_avx(auVar19,auVar26._0_16_,auVar4);
  auVar30 = ZEXT1664(auVar4);
  fVar21 = auVar4._0_4_;
  local_264 = (float)(int)(fVar21 * DAT_1402d233c);
  if (fVar21 == auVar26._0_4_) {
    return uVar11;
  }
  fVar32 = fVar32 - DAT_1402d29f4;
  lVar14 = (longlong)(int)local_264;
  fVar22 = fVar20 + DAT_1402d2534;
  fVar24 = (*(float *)(param_3 + 0x19c) / *(float *)(param_3 + 0x198)) * DAT_1402d2534;
  local_214 = fVar20 - DAT_1402d2534;
  local_248._4_4_ = fVar32 - fVar24;
  auVar7._4_8_ = uStack_220;
  auVar7._0_4_ = fVar22;
  local_228 = (undefined1  [8])(auVar7._0_8_ << 0x20);
  uStack_220._0_4_ = fVar22;
  uStack_220._4_4_ = fVar22;
  local_238 = fVar32 + fVar24;
  local_234 = local_238;
  local_210 = local_214;
  local_20c = local_214;
  local_1b8._8_8_ = _UNK_1402d4228;
  local_1b8._0_8_ = _DAT_1402d4220;
  uStack_1a8 = _UNK_1402d4230;
  uStack_1a0 = _UNK_1402d4238;
  local_228._0_4_ = fVar20;
  local_218 = fVar20;
  local_248._0_4_ = local_248._4_4_;
  fStack_240 = fVar32;
  fStack_23c = local_238;
  local_230 = fVar32;
  local_22c = (float)local_248._4_4_;
  local_1d8._8_8_ = _UNK_1402d4248;
  local_1d8._0_8_ = _DAT_1402d4240;
  uStack_1c8 = _UNK_1402d4250;
  uStack_1c0 = _UNK_1402d4258;
  fVar22 = DAT_1402d2b1c;
  fVar25 = DAT_1402d2b2c;
  fVar18 = DAT_1402d233c;
  if (0 < (int)local_264) {
    fVar16 = fVar20 * fVar33 + DAT_1402d2b1c;
    fVar27 = fVar32 * fVar33 + DAT_1402d2b2c;
    uVar15 = 1;
    do {
      local_120 = (float)(int)(fVar33 * *(float *)(local_228 + lVar13 * 4) + fVar22);
      local_11c = (float)(int)(fVar33 * *(float *)(local_248 + lVar13 * 4) + fVar25);
      local_124 = (float)CONCAT22((short)(int)(fVar33 * *(float *)(local_1d8 + lVar13 * 4)),
                                  (short)(int)(fVar33 * *(float *)(local_1b8 + lVar13 * 4)));
      local_144 = (float)(int)fVar16;
      local_140 = (float)(int)fVar27;
      local_148 = 3.9122977e-35;
      uVar10 = uVar15 & 0x80000007;
      if ((int)uVar10 < 0) {
        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
      }
      lVar12 = (longlong)(int)uVar10;
      local_fc = (int)(fVar33 * *(float *)(local_228 + lVar12 * 4) + fVar22);
      local_f8 = (int)(fVar33 * *(float *)(local_248 + lVar12 * 4) + fVar25);
      local_100 = (undefined2)(int)(fVar33 * *(float *)(local_1b8 + lVar12 * 4));
      local_fe = (undefined2)(int)(fVar33 * *(float *)(local_1d8 + lVar12 * 4));
      local_298 = *(undefined8 *)(*(longlong *)(param_1 + 0x300) + 0x398);
      auVar30 = ZEXT1664(auVar30._0_16_);
      uVar11 = FUN_1401fe080(uVar11,0x153,3,&local_158);
      fVar21 = auVar30._0_4_;
      uVar15 = uVar15 + 1;
      lVar13 = lVar13 + 1;
    } while (lVar13 < lVar14);
  }
  uVar15 = (int)local_264 + 1U & 0x80000007;
  if ((int)uVar15 < 0) {
    uVar15 = (uVar15 - 1 | 0xfffffff8) + 1;
  }
  fVar21 = -((float)(int)local_264 * DAT_1402d220c) + fVar21;
  switch(uVar15) {
  case 0:
  case 1:
    local_fc = (int)(fVar33 * *(float *)(local_228 + lVar14 * 4) + fVar21 * DAT_1402d2898 + fVar22);
    local_f8 = (int)(fVar33 * *(float *)(local_248 + (longlong)(int)uVar15 * 4) + fVar25);
    local_100 = (short)(int)(fVar33 * *(float *)(local_1b8 + lVar14 * 4) + fVar21 * DAT_1402d2898);
    local_fe = (undefined2)(int)(fVar33 * *(float *)(local_1d8 + (longlong)(int)uVar15 * 4));
    break;
  case 2:
  case 3:
    local_fc = (int)(fVar33 * *(float *)(local_228 + (longlong)(int)uVar15 * 4) + fVar22);
    local_f8 = (int)((fVar24 * fVar21 * fVar18 + *(float *)(local_248 + lVar14 * 4)) * fVar33 +
                    fVar25);
    local_100 = (short)(int)(fVar33 * *(float *)(local_1b8 + (longlong)(int)uVar15 * 4));
    local_fe = (undefined2)
               (int)(fVar33 * *(float *)(local_1d8 + lVar14 * 4) + fVar21 * DAT_1402d2898);
    break;
  case 4:
  case 5:
    local_fc = (int)((-(fVar21 * DAT_1402d2558) + *(float *)(local_228 + lVar14 * 4)) * fVar33 +
                    fVar22);
    local_f8 = (int)(fVar33 * *(float *)(local_248 + (longlong)(int)uVar15 * 4) + fVar25);
    local_100 = (undefined2)
                (int)((-(fVar21 * DAT_1402d2558) + *(float *)(local_1b8 + lVar14 * 4)) * fVar33);
    fVar16 = *(float *)(local_1d8 + (longlong)(int)uVar15 * 4);
    goto LAB_1400b1504;
  case 6:
  case 7:
    local_fc = (int)(fVar33 * *(float *)(local_228 + (longlong)(int)uVar15 * 4) + fVar22);
    fVar16 = -(fVar21 * DAT_1402d2558) + *(float *)(local_1d8 + lVar14 * 4);
    local_f8 = (int)((-(fVar24 * fVar21 * fVar18) + *(float *)(local_248 + lVar14 * 4)) * fVar33 +
                    fVar25);
    local_100 = (undefined2)(int)(fVar33 * *(float *)(local_1b8 + (longlong)(int)uVar15 * 4));
LAB_1400b1504:
    local_fe = (undefined2)(int)(fVar16 * fVar33);
    break;
  default:
    goto switchD_1400b1362_default;
  }
switchD_1400b1362_default:
  lVar13 = (longlong)(int)local_264;
  local_144 = (float)(int)(fVar20 * fVar33 + fVar22);
  local_140 = (float)(int)(fVar32 * fVar33 + fVar25);
  local_120 = (float)(int)(fVar33 * *(float *)(local_228 + lVar13 * 4) + fVar22);
  local_11c = (float)(int)(fVar33 * *(float *)(local_248 + lVar13 * 4) + fVar25);
  local_124 = (float)CONCAT22((short)(int)(fVar33 * *(float *)(local_1d8 + lVar13 * 4)),
                              (short)(int)(fVar33 * *(float *)(local_1b8 + lVar13 * 4)));
  local_148 = 3.9122977e-35;
  local_298 = *(undefined8 *)(*(longlong *)(param_1 + 0x300) + 0x398);
  uVar11 = FUN_1401fe080(uVar11,0x153,3,&local_158);
  return uVar11;
}

