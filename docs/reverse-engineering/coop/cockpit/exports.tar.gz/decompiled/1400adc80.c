/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400adc80; RVA 0xadc80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_1400adc80(undefined8 *param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  longlong lVar3;
  
  puVar2 = param_1 + 0x36;
  *(undefined8 *)((longlong)param_1 + 0x44) = 0;
  *(undefined8 *)((longlong)param_1 + 0x4c) = 0;
  *(undefined8 *)((longlong)param_1 + 0x54) = 0;
  *(undefined8 *)((longlong)param_1 + 0x5c) = 0;
  *(undefined8 *)((longlong)param_1 + 0x74) = 0;
  *(undefined8 *)((longlong)param_1 + 0x7c) = 0;
  *(undefined8 *)((longlong)param_1 + 0x84) = 0;
  *(undefined8 *)((longlong)param_1 + 0x8c) = 0;
  *(undefined8 *)((longlong)param_1 + 0x94) = 0;
  *(undefined8 *)((longlong)param_1 + 0x9c) = 0;
  *(undefined8 *)((longlong)param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0x1f) = 0;
  *(undefined2 *)((longlong)param_1 + 0xfc) = 0;
  *(undefined1 *)((longlong)param_1 + 0xfe) = 0;
  *(undefined1 *)((longlong)param_1 + 0xec) = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  lVar3 = 0x2b;
  do {
    *(undefined4 *)puVar2 = 0;
    puVar2 = (undefined8 *)((longlong)puVar2 + 4);
    lVar3 = lVar3 + -1;
  } while (lVar3 != 0);
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  *(undefined4 *)(param_1 + 0x4e) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)((longlong)param_1 + 0x284) = 0x3c;
  param_1[0x71] = 0;
  param_1[0x72] = 0;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[0x5c] = 0;
  *(undefined2 *)((longlong)param_1 + 0x3b2) = 0;
  *(undefined1 *)((longlong)param_1 + 0x3b4) = 0;
  *(undefined2 *)((longlong)param_1 + 0x3b6) = 0;
  *(undefined1 *)(param_1 + 8) = 1;
  param_1[0x5e] = 0;
  *(undefined4 *)((longlong)param_1 + 0x3ba) = 0x7040909;
  *(undefined4 *)((longlong)param_1 + 0x39e) = 0x80008;
  *(undefined8 *)((longlong)param_1 + 0x314) = 0;
  *(undefined4 *)(param_1 + 0x62) = 0;
  *(undefined8 *)((longlong)param_1 + 0x31c) = 0;
  *(undefined1 *)((longlong)param_1 + 0x3be) = 0xff;
  *(undefined4 *)(param_1 + 0x6e) = 0x15;
  param_1[0x5d] = 0;
  param_1[0x5f] = 0;
  lVar3 = FUN_140189320();
  uVar1 = *(undefined1 *)(lVar3 + 0xc);
  *(undefined1 *)((longlong)param_1 + 0x175) = 0;
  *(undefined4 *)(param_1 + 0x26) = 0xc8800000;
  *(undefined4 *)((longlong)param_1 + 0x134) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x27) = 0x48800000;
  *(undefined4 *)((longlong)param_1 + 0x13c) = 0x48800000;
  *(undefined4 *)(param_1 + 0x2e) = 0;
  *(undefined8 *)((longlong)param_1 + 0x394) = 0;
  *(undefined4 *)(param_1 + 0x72) = 0;
  *(undefined1 *)(param_1 + 0x78) = uVar1;
  *(undefined2 *)(param_1 + 0x77) = 0;
  *(undefined2 *)((longlong)param_1 + 0x3ca) = 0;
  *(undefined4 *)((longlong)param_1 + 0x37c) = 0;
  *(undefined4 *)(param_1 + 0x69) = 0xfffffff;
  *(undefined2 *)((longlong)param_1 + 0x39c) = 0xffff;
  *(undefined1 *)((longlong)param_1 + 0x3c3) = 1;
  param_1[0x61] = 0;
  return param_1;
}

