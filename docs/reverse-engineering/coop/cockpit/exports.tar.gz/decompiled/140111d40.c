/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140111d40; RVA 0x111d40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140111d40(float *param_1,byte param_2,char param_3)

{
  ushort uVar1;
  char *pcVar2;
  byte bVar3;
  ushort uVar4;
  longlong lVar5;
  undefined1 auVar6 [16];
  bool bVar7;
  bool bVar8;
  uchar uVar9;
  uint uVar10;
  int iVar11;
  byte bVar12;
  char cVar13;
  ulonglong uVar14;
  float fVar15;
  float fVar16;
  undefined1 auVar17 [16];
  undefined1 extraout_var [56];
  undefined1 extraout_var_00 [56];
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  undefined1 auVar24 [64];
  undefined1 auVar25 [64];
  undefined1 auVar26 [16];
  undefined1 auVar27 [64];
  float fVar28;
  undefined1 auVar29 [64];
  undefined4 uVar30;
  undefined4 uVar31;
  undefined4 uVar32;
  undefined1 auVar33 [64];
  float fVar34;
  undefined1 auVar35 [16];
  undefined1 auVar36 [64];
  float local_res8 [2];
  undefined4 local_150;
  undefined4 local_14c;
  undefined4 local_148;
  undefined4 local_144;
  undefined4 local_140;
  float local_13c;
  undefined4 local_138;
  undefined4 local_134;
  undefined1 local_130 [8];
  float fStack_128;
  undefined4 uStack_124;
  undefined8 local_118;
  undefined8 uStack_110;
  undefined1 local_108 [8];
  float fStack_100;
  float fStack_fc;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined1 local_e8 [8];
  float fStack_e0;
  float fStack_dc;
  
  fVar23 = DAT_1402d1ff8;
  auVar33 = ZEXT464(DAT_1402d237c);
  bVar3 = *(byte *)((longlong)param_1 + 0x157);
  uVar14 = (ulonglong)bVar3;
  bVar7 = false;
  auVar27 = ZEXT864(0);
  auVar25 = ZEXT864(0);
  auVar24 = ZEXT864(0);
  if ((bVar3 & 1) == 0) {
    if ((*(char *)((longlong)param_1 + 0x156) == '\x01') && ((bVar3 & 2) == 0)) {
      uVar14 = *(ulonglong *)(param_1 + 0x42);
      auVar17 = ZEXT816(0);
      if (uVar14 != 0) {
        auVar26 = *(undefined1 (*) [16])(param_1 + 0x24);
        auVar6 = vshufps_avx(auVar26,auVar26,0xaa);
        auVar35 = vshufps_avx(auVar26,auVar26,0xff);
        local_150 = auVar26._0_4_;
        auVar26 = vshufps_avx(auVar26,auVar26,0x55);
        local_148 = auVar6._0_4_;
        local_144 = auVar35._0_4_;
        local_13c = auVar26._0_4_ + DAT_1402d2698;
        local_14c = DAT_1402d2e2c;
        local_140 = local_150;
        local_138 = local_148;
        local_134 = local_144;
        _local_130 = auVar17;
        uVar10 = FUN_1400782c0(uVar14,local_130,local_res8,&local_140,&local_150);
        auVar17 = vpcmpeqd_avx(ZEXT416(uVar10),SUB6416(ZEXT464(0),0));
        auVar17 = vblendvps_avx(ZEXT416((uint)local_130._4_4_),auVar27._0_16_,auVar17);
      }
      if (param_1[0x25] < auVar17._0_4_ + DAT_1402d277c) {
        bVar7 = true;
        if ((param_1[0x2a] < DAT_1402d2d98) || (auVar33._0_4_ < param_1[0x2a])) {
          auVar25 = ZEXT464((uint)fVar23);
        }
      }
    }
  }
  else {
    auVar25 = ZEXT464((uint)param_1[0x4a]);
    auVar24 = ZEXT464((uint)param_1[0x4b]);
    bVar7 = true;
  }
  cVar13 = *(char *)((longlong)param_1 + 0x156);
  bVar8 = false;
  if (cVar13 == '\x01') {
    fVar22 = param_1[0x46];
  }
  else if (cVar13 == '\x02') {
    fVar22 = param_1[0x47];
  }
  else {
    fVar22 = param_1[0x45];
  }
  uVar30 = 0;
  uVar31 = 0;
  uVar32 = 0;
  local_res8[0] = DAT_1402d22d0;
  uVar10 = DAT_1402d3770;
  if (bVar7) {
    fVar19 = DAT_1402d22d0;
    if (cVar13 == '\x02') {
      fVar15 = FUN_140187ec0(uVar14,param_2,'\x19');
      fVar16 = FUN_140187ec0(uVar14,param_2,'\x1b');
      auVar24 = ZEXT464((uint)(fVar16 - fVar15));
      fVar15 = FUN_140187ec0(uVar14,param_2,'\x1f');
      fVar16 = FUN_140187ec0(uVar14,param_2,'\x1d');
      auVar25 = ZEXT464((uint)(fVar16 - fVar15));
    }
    param_1[0x48] = (fVar22 - param_1[0x48]) * DAT_1402d2168 + param_1[0x48];
    param_1[0x49] = fVar22;
    *(undefined1 *)((longlong)param_1 + 0x155) = 0;
    *(undefined2 *)((longlong)param_1 + 0x15b) = 0xff;
    *(undefined1 *)((longlong)param_1 + 0x15a) = 0xff;
    goto LAB_140112130;
  }
  fVar19 = DAT_1402d2168;
  if (param_3 == '\0') {
    if ((cVar13 != '\0') || (fVar15 = FUN_140187ec0(uVar14,param_2,'\x0e'), fVar15 < fVar19))
    goto LAB_140112024;
    fVar15 = ((fVar15 - fVar19) + fVar15) - fVar19;
  }
  else {
    fVar22 = param_1[0x45];
LAB_140112024:
    fVar15 = 0.0;
  }
  uVar14 = DAT_14032c8f0;
  uVar9 = FUN_140187a40(DAT_14032c8f0,param_2,'\x0e');
  if (uVar9 == '\0') {
    *(undefined1 *)((longlong)param_1 + 0x155) = 0;
    *(undefined2 *)((longlong)param_1 + 0x15b) = 0xff;
    *(undefined1 *)((longlong)param_1 + 0x15a) = 0xff;
LAB_1401120aa:
    param_1[0x49] = fVar22;
  }
  else {
    bVar3 = *(byte *)((longlong)param_1 + 0x155);
    uVar14 = (ulonglong)bVar3;
    if (param_1[0x44] <= (float)bVar3 / (float)*(byte *)(param_1 + 0x55)) {
      fVar22 = fVar15 * (DAT_1402d2a54 - fVar22) + fVar22;
      bVar8 = true;
      goto LAB_1401120aa;
    }
    fVar22 = param_1[0x49];
    uVar14 = (ulonglong)(byte)(bVar3 + 1);
    *(byte *)((longlong)param_1 + 0x155) = bVar3 + 1;
  }
  param_1[0x48] = (fVar22 - param_1[0x48]) * fVar19 + param_1[0x48];
  if (((*(byte *)((longlong)param_1 + 0x157) & 2) == 0) || (cVar13 != '\x01')) {
    if (!bVar8) goto LAB_1401120e8;
    bVar3 = *(byte *)(param_1 + 0x56);
    pcVar2 = (char *)((longlong)param_1 + 0x159);
    if ((bVar3 == 0xff) && (*pcVar2 == -1)) {
      uVar14 = (ulonglong)*(byte *)((longlong)param_1 + 0x15a);
      if ((*(byte *)((longlong)param_1 + 0x15a) != 0xff) &&
         (*(byte *)((longlong)param_1 + 0x15b) != 0xff)) {
        if (((*(byte *)(*(longlong *)
                         (*(longlong *)(**(longlong **)(param_1 + 0x40) + uVar14 * 8) + 0x110) +
                        0x1f0 + (ulonglong)*(byte *)((longlong)param_1 + 0x15b) * 0x520) & 2) == 0)
           && (*(char *)(param_1 + 0x57) != '\0')) {
          *(char *)(param_1 + 0x57) = *(char *)(param_1 + 0x57) + -1;
        }
        else {
          uVar14 = 0xff;
          *(undefined2 *)((longlong)param_1 + 0x15a) = 0xffff;
          *(char *)(param_1 + 0x57) = *(char *)(param_1 + 0x55) * '\x03';
        }
      }
    }
    else {
      bVar12 = *(byte *)((longlong)param_1 + 0x15a);
      if ((bVar12 == 0xff) && (*(char *)((longlong)param_1 + 0x15b) == -1)) {
        uVar14 = (ulonglong)bVar3;
        *(char *)((longlong)param_1 + 0x15b) = *pcVar2;
        *(byte *)((longlong)param_1 + 0x15a) = bVar3;
        *(char *)(param_1 + 0x57) = *(char *)(param_1 + 0x55) * '\x03';
        bVar12 = bVar3;
LAB_1401123b2:
        if (*pcVar2 == *(char *)((longlong)param_1 + 0x15b)) goto LAB_14011242f;
      }
      else {
        uVar14 = (ulonglong)bVar12;
        if (bVar3 == bVar12) goto LAB_1401123b2;
      }
      if (((*(byte *)(*(longlong *)
                       (*(longlong *)(**(longlong **)(param_1 + 0x40) + (ulonglong)bVar12 * 8) +
                       0x110) + 0x1f0 + (ulonglong)*(byte *)((longlong)param_1 + 0x15b) * 0x520) & 2
           ) == 0) && (*(char *)(param_1 + 0x57) != '\0')) {
        cVar13 = *(char *)(param_1 + 0x57) + -1;
      }
      else {
        uVar14 = (ulonglong)bVar3;
        *(byte *)((longlong)param_1 + 0x15b) = *(byte *)((longlong)param_1 + 0x159);
        *(byte *)((longlong)param_1 + 0x15a) = bVar3;
        cVar13 = *(char *)(param_1 + 0x55) * '\x03';
      }
      *(char *)(param_1 + 0x57) = cVar13;
    }
LAB_14011242f:
    if (((char)uVar14 != -1) || (*(byte *)((longlong)param_1 + 0x15b) != 0xff)) {
      bVar3 = *(byte *)((longlong)param_1 + 0x15b);
      local_118 = 0;
      uStack_110 = 0;
      _local_108 = ZEXT816(0);
      lVar5 = *(longlong *)(*(longlong *)(**(longlong **)(param_1 + 0x40) + uVar14 * 8) + 0x110);
      local_f8 = 0;
      uStack_f0 = 0;
      _local_e8 = ZEXT816(0);
      FUN_140202920(&local_118,param_1 + 0x28);
      auVar17 = *(undefined1 (*) [16])(lVar5 + 600 + (ulonglong)bVar3 * 0x520);
      fVar15 = auVar17._0_4_ - param_1[0x24];
      auVar26 = vshufps_avx(auVar17,auVar17,0x55);
      fVar16 = auVar26._0_4_ - param_1[0x25];
      auVar26 = vshufps_avx(auVar17,auVar17,0xaa);
      fVar20 = auVar26._0_4_ - param_1[0x26];
      auVar17 = vshufps_avx(auVar17,auVar17,0xff);
      fVar28 = auVar17._0_4_ - param_1[0x27];
      fVar22 = fVar28 * uStack_f0._4_4_ + fVar20 * (float)uStack_f0 +
               fVar16 * local_f8._4_4_ + fVar15 * (float)local_f8;
      fVar19 = fVar28 * fStack_fc + fVar20 * fStack_100 +
               fVar16 * (float)local_108._4_4_ + fVar15 * (float)local_108._0_4_;
      fVar15 = fVar28 * uStack_110._4_4_ + fVar20 * (float)uStack_110 +
               fVar16 * local_118._4_4_ + fVar15 * (float)local_118;
      fVar16 = local_res8[0] / SQRT(fVar22 * fVar22 + fVar19 * fVar19 + fVar15 * fVar15);
      auVar17 = vmaxss_avx(ZEXT416((uint)(fVar19 * fVar16)),ZEXT416(DAT_1402d2d64));
      auVar17 = vminss_avx(auVar17,ZEXT416((uint)local_res8[0]));
      fVar19 = local_res8[0];
      auVar25._0_8_ = FUN_140272150(auVar17._0_8_);
      auVar25._8_56_ = extraout_var;
      auVar25 = ZEXT1664(auVar25._0_16_);
      auVar24._0_8_ =
           FUN_140272370(CONCAT44(uVar30,(uint)(fVar15 * fVar16) ^ uVar10),
                         CONCAT44(uVar30,(uint)(fVar22 * fVar16) ^ uVar10));
      auVar24._8_56_ = extraout_var_00;
      auVar24 = ZEXT1664(auVar24._0_16_);
      goto LAB_140112130;
    }
    auVar25 = ZEXT864(0);
    auVar24 = ZEXT864(0);
  }
  else {
    bVar8 = false;
LAB_1401120e8:
    fVar22 = FUN_140187ec0(uVar14,param_2,'\x19');
    fVar19 = FUN_140187ec0(uVar14,param_2,'\x1b');
    auVar24 = ZEXT464((uint)(fVar19 - fVar22));
    fVar22 = FUN_140187ec0(uVar14,param_2,'\x1f');
    fVar19 = FUN_140187ec0(uVar14,param_2,'\x1d');
    auVar25 = ZEXT464((uint)(fVar19 - fVar22));
  }
  fVar19 = local_res8[0];
LAB_140112130:
  _local_130 = ZEXT816(0);
  if (*(char *)((longlong)param_1 + 0x156) == '\x01') {
    local_130._4_4_ = param_1[0x4e] * DAT_1402d2c9c;
    local_130._0_4_ = param_1[0x4c] * DAT_1402d2cc0;
    fStack_128 = param_1[0x4d] * DAT_1402d2038;
    uStack_124 = 0;
  }
  bVar3 = *(byte *)((longlong)param_1 + 0x15e);
  auVar36 = ZEXT464(DAT_1402d2db4);
  auVar29 = ZEXT464(DAT_1402d2420);
  if (bVar3 != 0) {
    fVar15 = (float)*(byte *)(param_1 + 0x55);
    iVar11 = FUN_140242630();
    fVar15 = (((float)iVar11 * DAT_1402d1d98 - local_res8[0]) * (float)bVar3) / fVar15;
    fVar16 = (float)*(byte *)(param_1 + 0x55);
    fVar19 = (float)*(byte *)((longlong)param_1 + 0x15e);
    iVar11 = FUN_140242630();
    fVar22 = DAT_1402d1d98;
    *(char *)((longlong)param_1 + 0x15e) = *(char *)((longlong)param_1 + 0x15e) + -1;
    fVar16 = (((float)iVar11 * fVar22 - local_res8[0]) * fVar19) / fVar16;
    fVar19 = local_res8[0];
    if (*(char *)((longlong)param_1 + 0x156) == '\x01') {
      auVar17 = *(undefined1 (*) [16])(param_1 + 0x38);
      auVar26 = vshufps_avx(auVar17,auVar17,0x55);
      fVar23 = (fVar16 - param_1[0x39]) * DAT_1402d2034;
      auVar6 = vshufps_avx(auVar17,auVar17,0xaa);
      fVar22 = DAT_1402d2cdc * param_1[0x3a];
      auVar35 = vshufps_avx(auVar17,auVar17,0xff);
      fVar16 = DAT_1402d2cdc * param_1[0x3b];
      param_1[0x38] = (fVar15 - param_1[0x38]) * DAT_1402d2034 + auVar17._0_4_;
      param_1[0x39] = fVar23 + auVar26._0_4_;
      param_1[0x3a] = fVar22 + auVar6._0_4_;
      param_1[0x3b] = fVar16 + auVar35._0_4_;
    }
    else {
      param_1[0x38] = fVar15;
      auVar26._4_12_ = auVar25._4_12_;
      auVar26._0_4_ = fVar15 * fVar23 + auVar25._0_4_;
      auVar6._4_12_ = auVar24._4_12_;
      auVar6._0_4_ = fVar16 * fVar23 + auVar24._0_4_;
      auVar35 = auVar36._0_16_;
      auVar17 = vcmpss_avx(auVar26,auVar35,1);
      auVar17 = vblendvps_avx(auVar26,auVar35,auVar17);
      auVar17 = vminss_avx(auVar17,auVar29._0_16_);
      auVar25 = ZEXT1664(auVar17);
      auVar17 = vcmpss_avx(auVar6,auVar35,1);
      auVar17 = vblendvps_avx(auVar6,auVar35,auVar17);
      auVar17 = vminss_avx(auVar17,auVar29._0_16_);
      auVar24 = ZEXT1664(auVar17);
      param_1[0x39] = fVar16;
      param_1[0x3a] = 0.0;
      param_1[0x3b] = 0.0;
    }
  }
  fVar15 = DAT_1402d249c;
  fVar22 = auVar25._0_4_;
  fVar23 = auVar24._0_4_;
  auVar17 = auVar33._0_16_;
  if (*(ushort *)(param_1 + 0x50) != 0) {
    uVar4 = *(ushort *)((longlong)param_1 + 0x142);
    uVar1 = uVar4 + 1;
    *(ushort *)((longlong)param_1 + 0x142) = uVar1;
    if (uVar4 < *(ushort *)(param_1 + 0x50)) {
      fVar16 = param_1[0x52];
      fVar20 = (float)FUN_140275650(((float)((ulonglong)uVar1 %
                                            (ulonglong)*(ushort *)(param_1 + 0x51)) /
                                    (float)*(ushort *)(param_1 + 0x51)) * fVar15);
      fVar22 = auVar25._0_4_;
      fVar23 = auVar24._0_4_;
      auVar17 = auVar33._0_16_;
      param_1[0x52] = fVar16 * param_1[0x53];
      param_1[0x54] = fVar20 * fVar16;
      if ((*(char *)((longlong)param_1 + 0x156) == '\x02') ||
         (*(char *)((longlong)param_1 + 0x156) == '\0')) {
        param_1[0x28] = fVar20 * fVar16 + param_1[0x28];
      }
    }
    else {
      *(undefined2 *)(param_1 + 0x50) = 0;
      param_1[0x54] = 0.0;
    }
  }
  fVar28 = auVar29._0_4_;
  fVar34 = auVar36._0_4_;
  cVar13 = *(char *)((longlong)param_1 + 0x156);
  fVar20 = auVar27._0_4_;
  auVar26 = auVar27._0_16_;
  fVar16 = auVar17._0_4_;
  if (cVar13 == '\x02') {
    if (bVar8) {
      fVar23 = fVar23 * DAT_1402d268c;
      if (fVar20 <= fVar23) {
        auVar17 = vminss_avx(ZEXT416((uint)fVar23),ZEXT416((uint)param_1[0xf]));
        fVar23 = auVar17._0_4_ / param_1[0xf];
      }
      else {
        auVar17._0_4_ = (uint)param_1[0x19] ^ uVar10;
        auVar17._4_4_ = uVar30;
        auVar17._8_4_ = uVar31;
        auVar17._12_4_ = uVar32;
        auVar17 = vmaxss_avx(auVar17,ZEXT416((uint)fVar23));
        fVar23 = auVar17._0_4_ / param_1[0x19];
      }
      fVar22 = fVar22 * DAT_1402d21a8;
    }
    if (fVar20 <= fVar23) {
      fVar18 = param_1[10] / param_1[0xf];
      fVar21 = param_1[0xb];
      if (fVar23 <= fVar18) {
        fVar19 = fVar21 * (fVar23 / fVar18) + -((fVar23 / fVar18) * param_1[9]) + param_1[9];
      }
      else {
        fVar19 = (fVar23 - fVar18) / (fVar19 - fVar18);
        fVar19 = fVar19 * param_1[0x10] + -(fVar21 * fVar19) + fVar21;
      }
    }
    else {
      fVar18 = param_1[0x14] / param_1[0x19];
      fVar21 = param_1[0x15];
      if ((float)((uint)fVar18 ^ uVar10) <= fVar23) {
        fVar19 = (float)((uint)(fVar23 / fVar18) ^ uVar10);
        fVar19 = fVar19 * fVar21 + -(fVar19 * param_1[9]) + param_1[9];
      }
      else {
        fVar19 = ((float)((uint)fVar23 ^ uVar10) - fVar18) / (fVar19 - fVar18);
        fVar19 = fVar19 * param_1[0x1a] + -(fVar21 * fVar19) + fVar21;
      }
    }
    if (fVar20 <= fVar22) {
      fVar22 = fVar22 * fVar16;
    }
    else {
      fVar22 = fVar19 * fVar22 * DAT_1402d1f38;
    }
    auVar17 = vpcmpeqd_avx(ZEXT116(*(byte *)((longlong)param_1 + 0x157) & 4),SUB6416(ZEXT464(0),0));
    auVar17 = vblendvps_avx(ZEXT416(DAT_1402d1f90),auVar26,auVar17);
    if (fVar20 <= fVar23) {
      fVar23 = fVar23 * (DAT_1402d1f38 * param_1[0xf] - auVar17._0_4_);
    }
    else {
      fVar23 = fVar23 * (DAT_1402d1f38 * param_1[0x19] - auVar17._0_4_);
    }
  }
  else if (!bVar8) {
    fVar22 = fVar22 * fVar16;
    auVar25 = ZEXT464((uint)fVar22);
    if (*(char *)((ulonglong)param_2 + 0x82 + DAT_14032c8c0) == '\x03') {
      fVar16 = fVar23 * fVar16;
      auVar24 = ZEXT464((uint)fVar16);
      fVar23 = fVar16;
      if (!bVar7) {
        if ((cVar13 == '\x01') && (*(char *)((longlong)param_1 + 0x15d) == '\x01')) {
          auVar17 = vcmpss_avx(ZEXT416((uint)fVar22),auVar26,1);
          auVar17 = vblendvps_avx(ZEXT416((uint)fVar22),auVar26,auVar17);
          auVar25 = ZEXT1664(auVar17);
        }
        uVar9 = FUN_140187a40(DAT_14032c8f0,param_2,'!');
        fVar23 = auVar24._0_4_;
        fVar22 = auVar25._0_4_;
        fVar28 = auVar29._0_4_;
        fVar34 = auVar36._0_4_;
        if ((uVar9 != '\0') &&
           (((*(char *)((longlong)param_1 + 0x15d) != '\x02' || (cVar13 != '\x01')) &&
            (fVar23 = fVar23 + fVar28, auVar27._0_4_ < fVar16)))) {
          fVar23 = fVar16 - fVar28;
        }
      }
    }
    else {
      fVar23 = fVar23 * fVar28;
      if ((!bVar7) && (cVar13 == '\x01')) {
        if (*(char *)((longlong)param_1 + 0x15d) == '\x01') {
          if (fVar20 < fVar22) {
            fVar22 = 0.0;
          }
        }
        else if (*(char *)((longlong)param_1 + 0x15d) == '\x02') {
          auVar26 = vcmpss_avx(auVar17,ZEXT416((uint)fVar23),1);
          auVar17 = vblendvps_avx(ZEXT416((uint)fVar23),auVar17,auVar26);
          auVar17 = vmaxss_avx(auVar17,ZEXT416((uint)DAT_1402d2d98));
          fVar23 = auVar17._0_4_;
        }
      }
    }
  }
  fVar23 = fVar23 - param_1[0x3d];
  if (*(char *)((longlong)param_1 + 0x156) != '\x02') {
    if (fVar34 <= fVar23) {
      if (fVar28 < fVar23) {
        fVar23 = fVar23 - fVar15;
      }
    }
    else {
      fVar23 = fVar23 + fVar15;
    }
  }
  auVar17 = *(undefined1 (*) [16])(param_1 + 0x3c);
  param_1[0x3c] = (fVar22 - param_1[0x3c]) * DAT_1402d2034 + auVar17._0_4_;
  auVar26 = vshufps_avx(auVar17,auVar17,0x55);
  param_1[0x3d] = fVar23 * DAT_1402d2034 + auVar26._0_4_;
  auVar26 = vshufps_avx(auVar17,auVar17,0xaa);
  fVar23 = param_1[0x3e] * DAT_1402d2cdc;
  auVar17 = vshufps_avx(auVar17,auVar17,0xff);
  param_1[0x3f] = param_1[0x3f] * DAT_1402d2cdc + auVar17._0_4_;
  param_1[0x3e] = fVar23 + auVar26._0_4_;
  cVar13 = *(char *)((longlong)param_1 + 0x156);
  if (cVar13 == '\0') {
    FUN_140203050(param_1 + 0x34,param_1 + 0x28,param_1 + 0x3c);
    fVar22 = param_1[6];
    fVar19 = param_1[7];
    fVar15 = param_1[8];
    _local_108 = ZEXT816(0);
    local_118 = 0;
    uStack_110 = 0;
    local_f8 = 0;
    uStack_f0 = 0;
    _local_e8 = _local_108;
    FUN_140202920(&local_118,param_1 + 0x28);
    fVar16 = fVar15 * (float)uStack_f0 + fVar19 * fStack_100 + fVar22 * (float)uStack_110 +
             fStack_e0;
    fVar23 = fVar15 * local_f8._4_4_ + fVar19 * (float)local_108._4_4_ + fVar22 * local_118._4_4_ +
             (float)local_e8._4_4_;
    auVar17 = *(undefined1 (*) [16])(param_1 + 0x24);
    fVar15 = fVar15 * (float)local_f8 + fVar19 * (float)local_108._0_4_ + fVar22 * (float)local_118
             + (float)local_e8._0_4_;
    auVar26 = vshufps_avx(auVar17,auVar17,0x55);
    param_1[0x30] = fVar15 + auVar17._0_4_;
    auVar17 = vshufps_avx(auVar17,auVar17,0xaa);
    param_1[0x31] = fVar23 + auVar26._0_4_;
    param_1[0x32] = fVar16 + auVar17._0_4_;
    param_1[0x2e] = fVar16;
    param_1[0x33] = 1.0;
    param_1[0x2f] = 1.0;
  }
  else {
    if (cVar13 == '\x01') {
      FUN_140203050(param_1 + 0x34,param_1 + 0x28,local_130);
      FUN_140203050(param_1 + 0x34,param_1 + 0x34,param_1 + 0x3c);
      fVar23 = *param_1;
      fVar22 = param_1[2];
      fVar20 = -((float)((uint)(param_1[0x3c] * DAT_1402d21a8) & _DAT_1402d3760) * param_1[1]) +
               param_1[1];
      _local_108 = ZEXT816(0);
      local_118 = 0;
      uStack_110 = 0;
      local_f8 = 0;
      uStack_f0 = 0;
      _local_e8 = _local_108;
      FUN_140202920(&local_118,param_1 + 0x34);
      fVar19 = fVar22 * uStack_f0._4_4_ + fVar20 * fStack_fc + fVar23 * uStack_110._4_4_ + fStack_dc
      ;
      fVar15 = fVar22 * (float)uStack_f0 + fVar20 * fStack_100 + fVar23 * (float)uStack_110 +
               fStack_e0;
      fVar16 = fVar22 * (float)local_f8 +
               fVar20 * (float)local_108._0_4_ + fVar23 * (float)local_118 + (float)local_e8._0_4_;
      fVar20 = fVar22 * local_f8._4_4_ + fVar20 * (float)local_108._4_4_ + fVar23 * local_118._4_4_
               + (float)local_e8._4_4_;
      _local_108 = ZEXT816(0);
      local_118 = 0;
      uStack_110 = 0;
      local_f8 = 0;
      uStack_f0 = 0;
      _local_e8 = _local_108;
      FUN_140202920(&local_118,param_1 + 0x28);
      fVar23 = param_1[3];
      fVar22 = param_1[4];
      fVar21 = param_1[0x4f] * DAT_1402d24d0 + param_1[5];
      fVar28 = fVar21 * (float)uStack_f0 + fVar22 * fStack_100 + fVar23 * (float)uStack_110 +
               fStack_e0;
      fVar34 = fVar21 * (float)local_f8 +
               fVar22 * (float)local_108._0_4_ + fVar23 * (float)local_118 + (float)local_e8._0_4_;
      fVar23 = fVar21 * local_f8._4_4_ + fVar22 * (float)local_108._4_4_ + fVar23 * local_118._4_4_
               + (float)local_e8._4_4_;
      if (*(char *)((longlong)param_1 + 0x15e) != '\0') {
        auVar17 = *(undefined1 (*) [16])(param_1 + 0x34);
        auVar26 = vshufps_avx(auVar17,auVar17,0x55);
        fVar22 = DAT_1402d205c * param_1[0x39];
        auVar6 = vshufps_avx(auVar17,auVar17,0xaa);
        fVar21 = DAT_1402d205c * param_1[0x3a];
        auVar35 = vshufps_avx(auVar17,auVar17,0xff);
        fVar18 = DAT_1402d205c * param_1[0x3b];
        param_1[0x34] = DAT_1402d205c * param_1[0x38] + auVar17._0_4_;
        param_1[0x35] = fVar22 + auVar26._0_4_;
        param_1[0x36] = fVar21 + auVar6._0_4_;
        param_1[0x37] = fVar18 + auVar35._0_4_;
      }
      auVar17 = *(undefined1 (*) [16])(param_1 + 0x24);
      param_1[0x30] = auVar17._0_4_ + fVar16 + fVar34;
      auVar26 = vshufps_avx(auVar17,auVar17,0x55);
      param_1[0x31] = auVar26._0_4_ + fVar20 + fVar23;
      auVar26 = vshufps_avx(auVar17,auVar17,0xaa);
      param_1[0x32] = auVar26._0_4_ + fVar15 + fVar28;
      auVar17 = vshufps_avx(auVar17,auVar17,0xff);
      param_1[0x33] = auVar17._0_4_ + fVar19;
      param_1[0x2c] = fVar34 + fVar16;
      param_1[0x2e] = fVar28 + fVar15;
      param_1[0x2d] = fVar23 + fVar20;
      param_1[0x2f] = fVar19;
      return;
    }
    if (cVar13 != '\x02') {
      return;
    }
    FUN_140203050(param_1 + 0x34,param_1 + 0x28,param_1 + 0x3c);
    fVar23 = param_1[6];
    fVar22 = param_1[7];
    fVar19 = param_1[8];
    _local_108 = ZEXT816(0);
    local_118 = 0;
    uStack_110 = 0;
    local_f8 = 0;
    uStack_f0 = 0;
    fVar15 = param_1[0x3d] * DAT_1402d268c;
    if (auVar27._0_4_ <= param_1[0x3d]) {
      fVar16 = param_1[10];
      if (fVar15 <= fVar16) {
        fVar15 = fVar15 / fVar16;
        fVar23 = -(param_1[0xc] * fVar15) + fVar23;
        fVar22 = fVar15 * param_1[0xd] + fVar22;
        fVar19 = param_1[0xe] * fVar15 + fVar19;
      }
      else {
        fVar16 = (fVar15 - fVar16) / (param_1[0xf] - fVar16);
        fVar15 = local_res8[0] - fVar16;
        fVar22 = fVar16 * param_1[0x12] + param_1[0xd] * fVar15 + fVar22;
        fVar19 = fVar16 * param_1[0x13] + param_1[0xe] * fVar15 + fVar19;
        fVar23 = fVar23 - (fVar16 * param_1[0x11] + fVar15 * param_1[0xc]);
      }
    }
    else {
      fVar16 = param_1[0x14];
      if ((float)((uint)fVar16 ^ uVar10) <= fVar15) {
        fVar15 = (float)((uint)(fVar15 / fVar16) ^ uVar10);
        fVar23 = param_1[0x16] * fVar15 + fVar23;
        fVar22 = fVar15 * param_1[0x17] + fVar22;
        fVar19 = fVar15 * param_1[0x18] + fVar19;
      }
      else {
        fVar16 = ((float)((uint)fVar15 ^ uVar10) - fVar16) / (param_1[0x19] - fVar16);
        fVar15 = local_res8[0] - fVar16;
        fVar22 = fVar16 * param_1[0x1c] + param_1[0x17] * fVar15 + fVar22;
        fVar19 = fVar16 * param_1[0x1d] + fVar15 * param_1[0x18] + fVar19;
        fVar23 = fVar16 * param_1[0x1b] + fVar15 * param_1[0x16] + fVar23;
      }
    }
    _local_e8 = _local_108;
    FUN_140202920(&local_118,param_1 + 0x28);
    auVar17 = *(undefined1 (*) [16])(param_1 + 0x24);
    fVar16 = fVar19 * (float)uStack_f0 + fVar23 * (float)uStack_110 + fVar22 * fStack_100 +
             fStack_e0;
    fVar20 = fVar19 * uStack_f0._4_4_ + fVar23 * uStack_110._4_4_ + fVar22 * fStack_fc + fStack_dc;
    fVar15 = fVar19 * (float)local_f8 + fVar23 * (float)local_118 + fVar22 * (float)local_108._0_4_
             + (float)local_e8._0_4_;
    fVar23 = fVar19 * local_f8._4_4_ + fVar23 * local_118._4_4_ + fVar22 * (float)local_108._4_4_ +
             (float)local_e8._4_4_;
    param_1[0x30] = auVar17._0_4_ + fVar15;
    auVar26 = vshufps_avx(auVar17,auVar17,0x55);
    auVar6 = vshufps_avx(auVar17,auVar17,0xaa);
    param_1[0x31] = auVar26._0_4_ + fVar23;
    auVar17 = vshufps_avx(auVar17,auVar17,0xff);
    param_1[0x32] = auVar6._0_4_ + fVar16;
    param_1[0x33] = auVar17._0_4_ + fVar20;
    param_1[0x2e] = fVar16;
    param_1[0x2f] = fVar20;
  }
  param_1[0x2d] = fVar23;
  param_1[0x2c] = fVar15;
  return;
}

