/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400bf810; RVA 0xbf810
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_1400bf810(undefined8 *param_1,int param_2)

{
  *param_1 = 0x10000007;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0x50000007;
  *(undefined4 *)(param_1 + 2) = 0x8006;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0x10000000;
  param_1[3] = 0xe;
  *(undefined4 *)(param_1 + 4) = 5;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0x40000000;
  *(undefined4 *)(param_1 + 5) = 8;
  *(undefined4 *)(param_1 + 6) = 0x80000;
  *(undefined4 *)((longlong)param_1 + 0x34) = 0xff000000;
  *(undefined4 *)(param_1 + 7) = 0x4c;
  *(undefined4 *)(param_1 + 8) = 0x1000000;
  *(undefined4 *)((longlong)param_1 + 0x44) = 1;
  *(undefined4 *)(param_1 + 9) = 0x4e;
  *(undefined4 *)(param_1 + 10) = 0x7000;
  *(undefined4 *)((longlong)param_1 + 0x54) = 0x7200;
  *(undefined4 *)(param_1 + 0xb) = 0x18;
  *(undefined4 *)(param_1 + 0xc) = 0x30000;
  *(undefined4 *)(param_1 + 0xd) = 0x47;
  *(undefined4 *)(param_1 + 0xf) = 0x42;
  if (param_2 == 0) {
LAB_1400bf8f2:
    param_1[0xe] = 0x48;
    return param_1 + 0x10;
  }
  if (param_2 == 1) {
    param_1[0xe] = 0x46;
    return param_1 + 0x10;
  }
  if (param_2 != 2) {
    if (param_2 == 3) {
      *(undefined4 *)(param_1 + 0xe) = 0x40;
      *(undefined4 *)((longlong)param_1 + 0x74) = 0x80;
      return param_1 + 0x10;
    }
    if (param_2 == 4) goto LAB_1400bf8f2;
  }
  param_1[0xe] = 0x44;
  return param_1 + 0x10;
}

