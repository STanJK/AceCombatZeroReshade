/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020ea20; RVA 0x20ea20
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14020ea20(int param_1,byte param_2)

{
  int iVar1;
  bool bVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined4 uVar8;
  int local_res8 [2];
  int local_res18 [2];
  longlong local_res20;
  ulonglong uVar9;
  undefined1 local_58 [16];
  undefined1 local_48 [32];
  
  bVar2 = false;
  local_res8[0] = param_1;
  if (param_1 == -1) {
    DAT_140356740 = param_2 ^ 1;
    bVar2 = true;
    lVar7 = *(longlong *)(DAT_140356700 + 8 + (DAT_140356718 & 0xad2aca7747985764) * 0x10);
    if (lVar7 == DAT_1403566f0) {
LAB_14020ea99:
      lVar7 = 0;
    }
    else {
      iVar1 = *(int *)(lVar7 + 0x10);
      while (iVar1 != 1) {
        if (lVar7 == *(longlong *)(DAT_140356700 + (DAT_140356718 & 0xad2aca7747985764) * 0x10))
        goto LAB_14020ea99;
        lVar7 = *(longlong *)(lVar7 + 8);
        iVar1 = *(int *)(lVar7 + 0x10);
      }
    }
    lVar4 = DAT_1403566f0;
    if (lVar7 != 0) {
      lVar4 = lVar7;
    }
    if (lVar4 == DAT_1403566f0) {
      return;
    }
    local_res8[0] = 1;
  }
  if ((DAT_140356740 == 0) || (bVar2)) {
    plVar6 = *(longlong **)(DAT_14033da48 + 0x10);
    plVar5 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_58,local_res8);
    lVar7 = *plVar5;
    if (param_2 == 0) {
      if ((*(char *)(lVar7 + 0x7a) == '\0') && (*(int *)(lVar7 + 0xa0) != 1)) {
        local_res18[0] = *(int *)(lVar7 + 0x80);
        *(undefined1 *)(lVar7 + 0x7a) = 1;
        plVar6 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_48,local_res18);
        lVar4 = *plVar6;
        if (!bVar2) {
          FUN_14020e550(local_res8[0],0,0);
          FUN_14020abe0(local_res8[0],local_res18[0],0);
        }
        *(undefined4 *)(lVar7 + 0x38) = *(undefined4 *)(lVar7 + 0x40);
        *(undefined4 *)(lVar7 + 0x3c) = *(undefined4 *)(lVar7 + 0x44);
        FUN_140211420(lVar7 + 0x18,lVar4 + 0x18);
        FUN_140211420(lVar7 + 0x20,lVar4 + 0x20);
        *(undefined4 *)(lVar7 + 0x8c) = *(undefined4 *)(lVar4 + 0x8c);
        *(undefined4 *)(lVar7 + 0x90) = *(undefined4 *)(lVar4 + 0x90);
        *(undefined4 *)(lVar7 + 0x40) = *(undefined4 *)(lVar4 + 0x40);
        *(undefined4 *)(lVar7 + 0x44) = *(undefined4 *)(lVar4 + 0x44);
        *(undefined4 *)(lVar7 + 0xa0) = 1;
        if ((!bVar2) && (*(int *)(DAT_140356730 + -4) == local_res8[0])) {
          FUN_14020e490();
          FUN_14020e000(local_res8[0]);
        }
      }
    }
    else if (*(char *)(lVar7 + 0x7a) != '\0') {
      *(undefined1 *)(lVar7 + 0x7a) = 0;
      if (!bVar2) {
        FUN_14020e550(local_res8[0],0,0);
      }
      plVar5 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_48,lVar7 + 0x80);
      lVar4 = *plVar5;
      *(undefined1 *)(lVar4 + 0x60) = 1;
      *(undefined1 *)(lVar4 + 0x78) = *(undefined1 *)(lVar7 + 0x78);
      *(undefined4 *)(lVar4 + 0x40) = *(undefined4 *)(lVar7 + 0x40);
      *(undefined4 *)(lVar4 + 0x44) = *(undefined4 *)(lVar7 + 0x44);
      FUN_140211420(lVar7 + 0x18,lVar7 + 0x28);
      FUN_140211420(lVar7 + 0x20,lVar7 + 0x30);
      *(undefined4 *)(lVar7 + 0x8c) = *(undefined4 *)(lVar7 + 0x84);
      *(undefined4 *)(lVar7 + 0x90) = *(undefined4 *)(lVar7 + 0x88);
      *(undefined4 *)(lVar7 + 0x40) = *(undefined4 *)(lVar7 + 0x38);
      *(undefined4 *)(lVar7 + 0x44) = *(undefined4 *)(lVar7 + 0x3c);
      *(undefined1 *)(lVar7 + 0x60) = 1;
      *(undefined1 *)(lVar7 + 0x78) = 0;
      local_res18[0] = *(int *)(DAT_140356730 + -4);
      if (bVar2) {
        *(int *)(lVar7 + 0xa0) = DAT_14030f26c;
      }
      else {
        *(int *)(lVar7 + 0xa0) = -DAT_14030f26c;
        FUN_14020e490();
        FUN_14020e000(local_res8[0]);
        puVar3 = DAT_14033da68;
        iVar1 = *(int *)(lVar7 + 0x8c);
        (**(code **)(*(longlong *)*DAT_14033da68 + 0x48))((longlong *)*DAT_14033da68,&local_res20);
        uVar9 = 0;
        (**(code **)(*plVar6 + 0x180))
                  (plVar6,iVar1 * *(int *)(puVar3 + 1) + local_res20,&DAT_1402ce2c0,0,0);
        DAT_14031e3a8 = 0;
        if (((DAT_14031e0e8 != 3) || (DAT_14031e3ac != '\0')) || (DAT_14031e3b0 != 0)) {
          DAT_14031e110 = 1;
          DAT_14031e0e8 = 3;
          DAT_14031e3ac = '\0';
          DAT_14031e3b0 = 0;
          _DAT_14031e308 = 0;
          DAT_14031e314 = 0;
        }
        uVar8 = 0;
        FUN_14020ef50(0x14,0,1,0,uVar9 & 0xffffffffffffff00);
        FUN_14020f8e0(lVar4 + 0x48,3,&DAT_1402ce200,3,1,DAT_1402d2d64,0,DAT_1402d23c0,DAT_1402d2d9c,
                      uVar8,uVar8,0,&DAT_14031e088,0,0);
        *(int *)(lVar7 + 0xa0) = DAT_14030f26c;
        if (local_res18[0] != local_res8[0]) {
          FUN_14020e490();
          FUN_140211b80(&DAT_1403566e8,local_48,local_res18);
          FUN_14020e000(local_res18[0]);
        }
      }
    }
  }
  return;
}

