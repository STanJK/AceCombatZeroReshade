/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140194840; RVA 0x194840
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Removing unreachable block (ram,0x000140194df9) */
/* WARNING: Removing unreachable block (ram,0x000140195025) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140194840(longlong param_1)

{
  undefined4 uVar1;
  ulonglong uVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  double dVar7;
  float fVar8;
  float fVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  char cVar16;
  longlong lVar17;
  ulonglong uVar18;
  uint *puVar19;
  __uint64 _Var20;
  void *pvVar21;
  longlong lVar22;
  undefined8 *puVar23;
  longlong *plVar24;
  int iVar25;
  ulonglong *puVar26;
  longlong lVar27;
  int iVar28;
  undefined8 uVar29;
  float *pfVar30;
  uint uVar31;
  ulonglong *puVar32;
  int iVar33;
  undefined8 *puVar34;
  byte bVar35;
  int iVar36;
  uint uVar37;
  ulonglong uVar38;
  undefined8 uVar39;
  undefined8 uVar40;
  uint uVar41;
  longlong unaff_GS_OFFSET;
  float fVar42;
  double dVar43;
  float fVar44;
  float fVar45;
  float fVar46;
  float fVar47;
  float fVar48;
  undefined1 auVar49 [64];
  undefined1 auVar50 [64];
  undefined1 auVar51 [64];
  undefined1 auVar52 [64];
  float fVar53;
  undefined1 auVar54 [64];
  undefined1 auVar55 [64];
  undefined1 auVar56 [64];
  float fVar57;
  ulonglong *in_stack_fffffffffffffe88;
  uint7 uVar58;
  undefined4 local_118;
  undefined1 local_114;
  int local_110;
  undefined1 local_10c;
  float local_108 [2];
  ulonglong local_100;
  undefined8 *local_f8;
  undefined1 local_f0 [4];
  undefined1 auStack_ec [12];
  
  local_110 = 0;
  cVar16 = FUN_1401936b0(param_1,&local_118);
  if (cVar16 == '\0') {
    return;
  }
  iVar25 = *(int *)(param_1 + 0x708);
  lVar17 = 0x1a0;
  if ((*(byte *)(param_1 + 0x198) & 1) != 0) {
    lVar17 = 200;
  }
  uVar18 = (ulonglong)(*(uint *)(param_1 + 200) & 7);
  bVar35 = (byte)*(ulonglong *)(lVar17 + param_1);
  uVar38 = *(ulonglong *)(lVar17 + param_1) >> 9;
  local_100 = (ulonglong)((uint)uVar38 & 1);
  if (iVar25 < *(int *)(&DAT_1402c4294 + uVar18 * 8)) {
    return;
  }
  iVar28 = *(int *)(&DAT_1402c4290 + uVar18 * 8);
  if ((bVar35 >> 3 & 1) == 0) {
    if (iVar28 != 3) {
      if (((iVar28 != 5) && (*(int *)(&DAT_1402c4294 + uVar18 * 8) != 4)) &&
         (iVar36 = 0, 0 < iVar25 + -1)) {
        lVar17 = 0;
        do {
          iVar36 = iVar36 + 1;
          *(undefined4 *)(lVar17 + 0x10 + *(longlong *)(param_1 + 0x6f8)) =
               *(undefined4 *)((longlong)iVar25 * 0x40 + -0x30 + *(longlong *)(param_1 + 0x6f8));
          *(undefined4 *)(lVar17 + 0x14 + *(longlong *)(param_1 + 0x6f8)) =
               *(undefined4 *)
                ((longlong)*(int *)(param_1 + 0x708) * 0x40 + -0x2c + *(longlong *)(param_1 + 0x6f8)
                );
          *(undefined4 *)(lVar17 + 0x18 + *(longlong *)(param_1 + 0x6f8)) =
               *(undefined4 *)
                ((longlong)*(int *)(param_1 + 0x708) * 0x40 + -0x28 + *(longlong *)(param_1 + 0x6f8)
                );
          *(undefined4 *)(lVar17 + 0x1c + *(longlong *)(param_1 + 0x6f8)) =
               *(undefined4 *)
                ((longlong)*(int *)(param_1 + 0x708) * 0x40 + -0x24 + *(longlong *)(param_1 + 0x6f8)
                );
          iVar25 = *(int *)(param_1 + 0x708);
          lVar17 = lVar17 + 0x40;
        } while (iVar36 < iVar25 + -1);
      }
      goto LAB_140194a3e;
    }
    iVar36 = 0;
    if (iVar25 + -1 < 1) goto LAB_140194a36;
    lVar17 = 0;
    do {
      iVar36 = iVar36 + 2;
      *(undefined4 *)(lVar17 + 0x10 + *(longlong *)(param_1 + 0x6f8)) =
           *(undefined4 *)(lVar17 + 0x50 + *(longlong *)(param_1 + 0x6f8));
      *(undefined4 *)(lVar17 + 0x14 + *(longlong *)(param_1 + 0x6f8)) =
           *(undefined4 *)(lVar17 + 0x54 + *(longlong *)(param_1 + 0x6f8));
      *(undefined4 *)(lVar17 + 0x18 + *(longlong *)(param_1 + 0x6f8)) =
           *(undefined4 *)(lVar17 + 0x58 + *(longlong *)(param_1 + 0x6f8));
      *(undefined4 *)(lVar17 + 0x1c + *(longlong *)(param_1 + 0x6f8)) =
           *(undefined4 *)(lVar17 + 0x5c + *(longlong *)(param_1 + 0x6f8));
      iVar25 = *(int *)(param_1 + 0x708);
      lVar17 = lVar17 + 0x80;
    } while (iVar36 < iVar25 + -1);
LAB_140194a4a:
    fVar57 = DAT_1402d2168;
    iVar36 = 0;
    DAT_14031e0e0 = (float)DAT_1403566cc * DAT_1402d1e80;
    if (0 < iVar25) {
      lVar17 = 0;
      do {
        lVar27 = *(longlong *)(param_1 + 0x6f8);
        fVar42 = *(float *)(param_1 + 0x73c);
        fVar44 = *(float *)(param_1 + 0x740);
        iVar36 = iVar36 + 1;
        fVar47 = *(float *)(param_1 + 0x748);
        fVar45 = fVar42 * fVar57 + (*(float *)(lVar17 + lVar27) - *(float *)(param_1 + 0x744));
        *(float *)(lVar17 + lVar27) = fVar45;
        fVar47 = fVar44 * fVar57 + (*(float *)(lVar17 + 4 + lVar27) - fVar47);
        *(float *)(lVar17 + 4 + lVar27) = fVar47;
        fVar45 = ((float)DAT_1403566c8 / fVar42) * fVar45;
        *(float *)(lVar17 + lVar27) = fVar45;
        fVar42 = (float)DAT_1403566cc;
        *(float *)(lVar17 + lVar27) = (float)(int)(fVar45 + fVar57);
        *(float *)(lVar17 + 4 + lVar27) = (float)(int)((fVar42 / fVar44) * fVar47 + fVar57);
        iVar25 = *(int *)(param_1 + 0x708);
        lVar17 = lVar17 + 0x40;
      } while (iVar36 < iVar25);
    }
    if (iVar28 == 4) {
      iVar28 = 0;
      if (0 < iVar25) {
        do {
          iVar36 = iVar28 + 1;
          *(short *)(*(longlong *)(param_1 + 0x700) + (longlong)iVar36 * 2) = (short)iVar28;
          iVar25 = *(int *)(param_1 + 0x708);
          iVar28 = iVar36;
        } while (iVar36 < iVar25);
      }
      if (3 < iVar25) {
        pfVar30 = *(float **)(param_1 + 0x6f8);
        if ((pfVar30[(longlong)iVar25 * 0x10 + -0x10] == *pfVar30) &&
           (pfVar30[(longlong)iVar25 * 0x10 + -0xf] == pfVar30[1])) {
          iVar28 = 7;
          **(short **)(param_1 + 0x700) = (short)iVar25 + -2;
          *(undefined2 *)
           (*(longlong *)(param_1 + 0x700) + 2 + (longlong)*(int *)(param_1 + 0x708) * 2) = 1;
          iVar25 = *(int *)(param_1 + 0x708) + 2;
          goto LAB_140194c3a;
        }
      }
      iVar28 = 7;
      **(undefined2 **)(param_1 + 0x700) = 0;
      *(short *)(*(longlong *)(param_1 + 0x700) + 2 + (longlong)*(int *)(param_1 + 0x708) * 2) =
           *(short *)(param_1 + 0x708) + -1;
      iVar25 = *(int *)(param_1 + 0x708) + 2;
    }
    else {
      iVar28 = 0;
      if (0 < iVar25) {
        iVar36 = 0;
        do {
          *(short *)(*(longlong *)(param_1 + 0x700) + (longlong)iVar36 * 2) = (short)iVar28;
          lVar17 = (longlong)iVar36;
          iVar36 = iVar36 + 2;
          *(short *)(*(longlong *)(param_1 + 0x700) + 2 + lVar17 * 2) = (short)iVar28;
          iVar28 = iVar28 + 1;
          iVar25 = *(int *)(param_1 + 0x708);
        } while (iVar28 < iVar25);
      }
      iVar28 = 6;
      iVar25 = iVar25 * 2;
    }
LAB_140194c3a:
    *(int *)(param_1 + 0x70c) = iVar25;
    *(undefined1 *)(param_1 + 0x710) = 1;
    fVar42 = (float)DAT_1403566c8;
    *(float *)(param_1 + 0x73c) = fVar42;
    fVar44 = (float)DAT_1403566cc;
    *(float *)(param_1 + 0x740) = fVar44;
    *(float *)(param_1 + 0x748) = fVar44 * fVar57;
    *(float *)(param_1 + 0x744) = fVar42 * fVar57;
  }
  else {
LAB_140194a36:
    if (iVar28 == 3) goto LAB_140194a4a;
LAB_140194a3e:
    if (iVar28 == 4) goto LAB_140194a4a;
  }
  uVar40 = 0;
  uVar31 = 0;
  puVar34 = &DAT_14031e088;
  uVar29 = 0;
  auVar54 = ZEXT864(0);
  if ((bVar35 >> 4 & 1) != 0) {
    puVar32 = (ulonglong *)(param_1 + 0xf8);
    if ((uVar38 & 1) != 0) {
      puVar32 = (ulonglong *)(param_1 + 0x100);
    }
    uVar18 = *puVar32;
    if (((uVar18 & 0x1800000000) != 0) ||
       (((uVar31 = (uint)uVar18, (uVar31 & 0x3f00000) != 0x1000000 &&
         ((uVar31 & 0x3f00000) != 0x1300000)) &&
        (((uVar31 & 0x3f00000) != 0x1400000 &&
         ((((uVar31 & 0x3f00000) != 0x1b00000 && ((uVar18 & 0x3f00000) != 0)) &&
          ((uVar31 & 0x3f00000) != 0x3100000)))))))) {
LAB_140195095:
      *(undefined4 *)(param_1 + 0x708) = 0;
      return;
    }
    puVar26 = (ulonglong *)(param_1 + 0x168);
    if ((uVar38 & 1) != 0) {
      puVar26 = (ulonglong *)(param_1 + 0x170);
    }
    uVar2 = *puVar26;
    if ((((uVar2 & 0x1c) == 0) ||
        (uVar37 = (uint)(uVar2 >> 0x24) & 0xff, (char)(uVar2 >> 0x24) == '\0')) ||
       ((uVar2 & 1) == 0)) {
      local_f8 = (undefined8 *)FUN_140191040(param_1,uVar18,0);
      if (local_f8 == (undefined8 *)0x0) goto LAB_140195095;
      uVar31 = *(uint *)(local_f8 + 7);
      puVar34 = local_f8;
      if ((uVar31 != 0) &&
         (puVar34 = *(undefined8 **)
                     ((&DAT_14033ac70)[((ulonglong)uVar31 & 0xffff) * 3] +
                     (longlong)((int)uVar31 >> 0x10) * 8), puVar34 == (undefined8 *)0x0)) {
        puVar34 = local_f8;
      }
    }
    else {
      puVar26 = (ulonglong *)(param_1 + 0x268);
      if ((uVar38 & 1) != 0) {
        puVar26 = (ulonglong *)(param_1 + 0x270);
      }
      if ((uVar2 >> 9 & 1) != 0) {
        uVar41 = (uint)(uVar18 >> 0xe) & 0x3f;
        dVar43 = (double)FUN_140273c10(DAT_1402d23c8,(double)((uint)(uVar18 >> 0x1e) & 0xf));
        iVar25 = uVar41 * (int)dVar43;
        iVar33 = ((int)((iVar25 >> 0x1f & 3U) + iVar25) >> 2) + uVar31;
        iVar25 = (int)dVar43 / 2;
        iVar36 = (uVar41 >> 1) * iVar25;
        iVar36 = ((int)((iVar36 >> 0x1f & 3U) + iVar36) >> 2) + iVar33;
        iVar25 = (iVar25 / 2) * (uVar41 >> 2);
        puVar34 = (undefined8 *)(((longlong)iVar36 & 0x3fffU) << 0x14);
        *puVar26 = ((longlong)iVar33 ^ *puVar26) & 0xffc000fc000fc000 ^ (ulonglong)puVar34 ^
                   ((longlong)(((int)(iVar25 + (iVar25 >> 0x1f & 3U)) >> 2) + iVar36) & 0x3fffU) <<
                   0x28 ^ (longlong)iVar33 & 0xffc000fc000fffffU;
      }
      uVar18 = *puVar32;
      if (uVar37 == 1) {
        puVar34 = (undefined8 *)0xfffffffc3fffffff;
        uVar38 = (uVar18 ^ *puVar26) & 0xffffffffffffc000 ^ *puVar26;
        uVar18 = ((uVar38 >> 0x1a) - 1) * 0x4000000;
        uVar18 = (uVar38 ^ uVar18) & 0xffffffffc3ffffff ^ uVar18;
        uVar38 = ((uVar18 >> 0x1e) - 1) * 0x40000000;
        uVar38 = (uVar18 ^ uVar38) & 0xfffffffc3fffffff ^ uVar38;
        uVar18 = (ulonglong)((uint)(uVar38 >> 1) & 0x7c000) | uVar38 & 0xfffffffffff03fff;
      }
      else if (uVar37 == 2) {
        puVar34 = (undefined8 *)0xfffffffc3fffffff;
        uVar38 = (uVar18 ^ *puVar26 >> 0x14) & 0xffffffffffffc000 ^ *puVar26 >> 0x14;
        uVar18 = ((uVar38 >> 0x1a) - 2) * 0x4000000;
        uVar18 = (uVar18 ^ uVar38) & 0xffffffffc3ffffff ^ uVar18;
        uVar38 = ((uVar18 >> 0x1e) - 2) * 0x40000000;
        uVar38 = (uVar18 ^ uVar38) & 0xfffffffc3fffffff ^ uVar38;
        uVar18 = (ulonglong)((uint)(uVar38 >> 2) & 0x3c000) | uVar38 & 0xfffffffffff03fff;
      }
      else if (uVar37 == 3) {
        puVar34 = (undefined8 *)0xfffffffc3fffffff;
        uVar38 = ((uVar18 >> 0x1a) - 3) * 0x4000000;
        uVar38 = ((uVar18 ^ *puVar26 >> 0x28) & 0xffffffffffffc000 ^ *puVar26 >> 0x28 ^ uVar38) &
                 0xffffffffc3ffffff ^ uVar38;
        uVar18 = ((uVar38 >> 0x1e) - 3) * 0x40000000;
        uVar18 = (uVar38 ^ uVar18) & 0xfffffffc3fffffff ^ uVar18;
        dVar43 = (double)((uint)(uVar18 >> 0xe) & 0x3f) * DAT_1402d2370;
        if (DAT_1402d2900 <= dVar43) {
          dVar43 = dVar43 - DAT_1402d2900;
        }
        uVar18 = (uVar18 ^ (longlong)dVar43 * 0x4000) & 0xfffffffffff03fff ^
                 (longlong)dVar43 * 0x4000;
      }
      puVar34 = (undefined8 *)
                FUN_140191040(param_1,uVar18,CONCAT71((int7)((ulonglong)puVar34 >> 8),1));
      if (puVar34 == (undefined8 *)0x0) goto LAB_140195095;
    }
    iVar25 = *(int *)(puVar34 + 5);
    uVar40 = *puVar34;
    if ((iVar25 == DAT_14030cab8) && (*(int *)(puVar34 + 4) == 0x1500)) {
      uVar29 = 1;
LAB_14019549f:
      uVar39 = 0;
LAB_1401954a2:
      FUN_14020e550(iVar25,uVar29,uVar39);
    }
    else {
      if ((iVar25 == DAT_14030cabc) && (*(int *)(puVar34 + 4) == 0x1520)) {
        uVar39 = 1;
        uVar29 = 0;
        goto LAB_1401954a2;
      }
      if ((DAT_14030cac4 == -1) || (iVar25 != DAT_14030cac4)) {
        if (iVar25 != -1) {
          uVar29 = 0;
          goto LAB_14019549f;
        }
      }
      else {
        if (*(int *)((longlong)puVar34 + 0x2c) == -1) {
          auStack_ec._0_2_ = DAT_1402c4240;
          local_f0 = (undefined1  [4])DAT_1402c423c;
          auStack_ec._3_9_ = SUB169((undefined1  [16])0x0,7);
          auStack_ec[2] = 0;
          in_stack_fffffffffffffe88 =
               (ulonglong *)((ulonglong)in_stack_fffffffffffffe88 & 0xffffffffffffff00);
          local_108[0] = (float)FUN_14020cde0(*(undefined4 *)((longlong)puVar34 + 0x14),
                                              *(undefined4 *)(puVar34 + 3));
          *(float *)((longlong)puVar34 + 0x2c) = local_108[0];
          plVar24 = (longlong *)FUN_140211de0(&DAT_1403566e8,local_f0,local_108);
          puVar34[6] = *plVar24 + 0x48;
        }
        auVar55 = ZEXT464(DAT_1402d23c0);
        auVar56 = ZEXT464(DAT_1402d2d64);
        uVar18 = (ulonglong)*(uint *)(param_1 + 0x708);
        auVar52 = ZEXT1664(ZEXT416(DAT_1402d23c0));
        auVar49 = ZEXT1664(ZEXT416(DAT_1402d2d64));
        auVar50 = ZEXT1664(ZEXT416(DAT_1402d23c0));
        auVar51 = ZEXT1664(ZEXT416(DAT_1402d2d64));
        if ((int)*(uint *)(param_1 + 0x708) < 1) goto LAB_140195b50;
        puVar19 = (uint *)(*(longlong *)(param_1 + 0x6f8) + 0x24);
        do {
          uVar31 = puVar19[-1];
          uVar37 = *puVar19;
          puVar19 = puVar19 + 0x10;
          auVar3 = vcmpss_avx(ZEXT416(uVar31),auVar52._0_16_,1);
          auVar3 = vblendvps_avx(auVar52._0_16_,ZEXT416(uVar31),auVar3);
          auVar52 = ZEXT1664(auVar3);
          auVar4 = vcmpss_avx(auVar49._0_16_,ZEXT416(uVar31),1);
          auVar4 = vblendvps_avx(auVar49._0_16_,ZEXT416(uVar31),auVar4);
          auVar49 = ZEXT1664(auVar4);
          auVar5 = vcmpss_avx(ZEXT416(uVar37),auVar50._0_16_,1);
          auVar5 = vblendvps_avx(auVar50._0_16_,ZEXT416(uVar37),auVar5);
          auVar50 = ZEXT1664(auVar5);
          auVar6 = vcmpss_avx(auVar51._0_16_,ZEXT416(uVar37),1);
          auVar6 = vblendvps_avx(auVar51._0_16_,ZEXT416(uVar37),auVar6);
          auVar51 = ZEXT1664(auVar6);
          uVar18 = uVar18 - 1;
        } while (uVar18 != 0);
        if ((DAT_1402d22d0 <= auVar3._0_4_) || (DAT_1402d22d0 <= auVar5._0_4_)) goto LAB_140195b50;
        if ((auVar4._0_4_ <= auVar54._0_4_) ||
           (((auVar6._0_4_ <= auVar54._0_4_ || (auVar3._0_4_ == auVar4._0_4_)) ||
            (auVar5._0_4_ == auVar6._0_4_)))) goto LAB_140195b50;
        auVar3 = ZEXT816(0x40) * ZEXT416(*(uint *)(param_1 + 0x708));
        _Var20 = auVar3._0_8_;
        if (auVar3._8_8_ != 0) {
          _Var20 = 0xffffffffffffffff;
        }
        fVar57 = DAT_1402d22d0;
        pvVar21 = operator_new(_Var20);
        dVar43 = DAT_1402d22e0;
        uVar15 = _UNK_1402c4308;
        uVar14 = _UNK_1402c4300;
        uVar13 = _UNK_1402c42f8;
        uVar12 = _DAT_1402c42f0;
        uVar11 = _UNK_1402c42e8;
        uVar10 = _UNK_1402c42e0;
        uVar39 = _UNK_1402c42d8;
        uVar29 = _DAT_1402c42d0;
        iVar25 = 0;
        if (0 < *(int *)(param_1 + 0x708)) {
          pfVar30 = (float *)((longlong)pvVar21 + 0x20);
          do {
            *(undefined8 *)(pfVar30 + -8) = uVar29;
            *(undefined8 *)(pfVar30 + -6) = uVar39;
            *(undefined8 *)(pfVar30 + -4) = uVar10;
            *(undefined8 *)(pfVar30 + -2) = uVar11;
            *(undefined8 *)pfVar30 = uVar12;
            *(undefined8 *)(pfVar30 + 2) = uVar13;
            *(undefined8 *)(pfVar30 + 4) = uVar14;
            *(undefined8 *)(pfVar30 + 6) = uVar15;
            fVar42 = *(float *)((longlong)pfVar30 +
                               *(longlong *)(param_1 + 0x6f8) + -(longlong)pvVar21);
            fVar44 = *(float *)((longlong)pfVar30 +
                               *(longlong *)(param_1 + 0x6f8) + -(longlong)pvVar21 + 4);
            if (fVar42 == auVar52._0_4_) {
              dVar7 = (double)fVar42 - dVar43;
LAB_140195322:
              fVar42 = (float)dVar7;
            }
            else if (fVar42 == auVar49._0_4_) {
              dVar7 = (double)fVar42 + dVar43;
              goto LAB_140195322;
            }
            if (fVar44 == auVar50._0_4_) {
              dVar7 = (double)fVar44 - dVar43;
LAB_140195345:
              fVar44 = (float)dVar7;
            }
            else if (fVar44 == auVar51._0_4_) {
              dVar7 = (double)fVar44 + dVar43;
              goto LAB_140195345;
            }
            pfVar30[-8] = (fVar42 + fVar42) - fVar57;
            *pfVar30 = fVar42;
            pfVar30[1] = fVar44;
            pfVar30[-7] = (fVar44 + fVar44) - fVar57;
            pfVar30 = pfVar30 + 0x10;
            iVar25 = iVar25 + 1;
          } while (iVar25 < *(int *)(param_1 + 0x708));
        }
        auVar54 = ZEXT1664(auVar54._0_16_);
        auVar49 = ZEXT1664(auVar55._0_16_);
        auVar50 = ZEXT1664(auVar56._0_16_);
        FUN_14020e000(*(undefined4 *)((longlong)puVar34 + 0x2c));
        FUN_14020e550(DAT_14030cac4,0,0);
        DAT_14031e3a8 = 0;
        if (((DAT_14031e0e8 != 3) || (DAT_14031e3ac != '\0')) || (DAT_14031e3b0 != 0)) {
          DAT_14031e110 = 1;
          DAT_14031e0e8 = 3;
          DAT_14031e3ac = '\0';
          DAT_14031e3b0 = 0;
          _DAT_14031e308 = 0;
          DAT_14031e314 = 0;
        }
        uVar18 = (ulonglong)in_stack_fffffffffffffe88 & 0xffffffffffffff00;
        FUN_14020ef50(0x14,auVar54._0_8_,1,0,uVar18);
        in_stack_fffffffffffffe88 = (ulonglong *)CONCAT44((int)(uVar18 >> 0x20),iVar28);
        FUN_14020f8e0(uVar40,0,pvVar21,*(undefined4 *)(param_1 + 0x708),in_stack_fffffffffffffe88,
                      auVar50._0_4_,0,auVar49._0_4_,DAT_1402d2d9c,auVar54._0_4_,auVar54._0_4_,0,
                      &DAT_14031e088,0,0);
        FUN_14020e490(*(undefined4 *)((longlong)puVar34 + 0x2c));
        FUN_14020e550(*(undefined4 *)((longlong)puVar34 + 0x2c),0,0);
        thunk_FUN_1402500f0(pvVar21);
        FUN_1401936b0(param_1,&local_118);
        uVar40 = puVar34[6];
      }
    }
    uVar29 = auVar54._0_8_;
    if (DAT_14030cab8 == DAT_14030cac4) {
      iVar25 = *(int *)(puVar34 + 4);
      if (iVar25 == 0x2000) {
        lVar17 = 0;
      }
      else if (iVar25 == 0x2040) {
        lVar17 = 1;
      }
      else if (iVar25 == 0x2080) {
        lVar17 = 2;
      }
      else {
        if (iVar25 != 0x20c0) goto LAB_140195748;
        lVar17 = 3;
      }
      iVar25 = 0;
      if (0 < *(int *)(param_1 + 0x708)) {
        lVar27 = 0;
        local_108[0] = (float)(&DAT_14033bc64)[lVar17 * 4];
        fVar57 = (float)(&DAT_14033bc60)[lVar17 * 4];
        fVar42 = (float)(&DAT_14033bc68)[lVar17 * 4];
        do {
          lVar22 = *(longlong *)(param_1 + 0x6f8);
          fVar44 = *(float *)(lVar27 + 0x60 + lVar22);
          fVar8 = *(float *)(lVar27 + 0x84 + lVar22) - *(float *)(lVar27 + 4 + lVar22);
          fVar47 = *(float *)(lVar27 + 0xa4 + lVar22);
          fVar9 = *(float *)(lVar27 + 0x40 + lVar22) - *(float *)(lVar27 + lVar22);
          fVar48 = DAT_1402d22d0 / (fVar44 - *(float *)(lVar27 + 0x20 + lVar22));
          fVar46 = DAT_1402d22d0 / (fVar47 - *(float *)(lVar27 + 0x24 + lVar22));
          fVar45 = (fVar57 - *(float *)(lVar27 + 0x20 + lVar22)) * fVar48 * fVar9;
          fVar53 = auVar54._0_4_;
          fVar9 = (fVar42 - fVar44) * fVar48 * fVar9;
          fVar44 = (local_108[0] - *(float *)(lVar27 + 0x24 + lVar22)) * fVar46 * fVar8;
          fVar8 = ((float)(&DAT_14033bc6c)[lVar17 * 4] - fVar47) * fVar46 * fVar8;
          if (fVar53 < fVar45) {
            *(float *)(lVar27 + lVar22) = fVar45 + *(float *)(lVar27 + lVar22);
            *(float *)(lVar27 + 0x80 + *(longlong *)(param_1 + 0x6f8)) =
                 fVar45 + *(float *)(lVar27 + 0x80 + *(longlong *)(param_1 + 0x6f8));
            *(float *)(lVar27 + 0x20 + *(longlong *)(param_1 + 0x6f8)) = fVar57;
            *(float *)(lVar27 + 0xa0 + *(longlong *)(param_1 + 0x6f8)) = fVar57;
            lVar22 = *(longlong *)(param_1 + 0x6f8);
          }
          if (fVar53 < fVar44) {
            uVar1 = (&DAT_14033bc64)[lVar17 * 4];
            *(float *)(lVar27 + 4 + lVar22) = fVar44 + *(float *)(lVar27 + 4 + lVar22);
            *(float *)(lVar27 + 0x44 + *(longlong *)(param_1 + 0x6f8)) =
                 fVar44 + *(float *)(lVar27 + 0x44 + *(longlong *)(param_1 + 0x6f8));
            *(undefined4 *)(lVar27 + 0x24 + *(longlong *)(param_1 + 0x6f8)) = uVar1;
            *(undefined4 *)(lVar27 + 100 + *(longlong *)(param_1 + 0x6f8)) = uVar1;
            lVar22 = *(longlong *)(param_1 + 0x6f8);
          }
          if (fVar9 < fVar53) {
            *(float *)(lVar27 + 0x40 + lVar22) = fVar9 + *(float *)(lVar27 + 0x40 + lVar22);
            *(float *)(*(longlong *)(param_1 + 0x6f8) + lVar27 + 0xc0) =
                 fVar9 + *(float *)(*(longlong *)(param_1 + 0x6f8) + lVar27 + 0xc0);
            *(float *)(lVar27 + 0x60 + *(longlong *)(param_1 + 0x6f8)) = fVar42;
            *(float *)(lVar27 + 0xe0 + *(longlong *)(param_1 + 0x6f8)) = fVar42;
          }
          if (fVar8 < fVar53) {
            uVar1 = (&DAT_14033bc6c)[lVar17 * 4];
            *(float *)(lVar27 + 0x84 + *(longlong *)(param_1 + 0x6f8)) =
                 fVar8 + *(float *)(lVar27 + 0x84 + *(longlong *)(param_1 + 0x6f8));
            *(float *)(lVar27 + 0xc4 + *(longlong *)(param_1 + 0x6f8)) =
                 fVar8 + *(float *)(lVar27 + 0xc4 + *(longlong *)(param_1 + 0x6f8));
            *(undefined4 *)(lVar27 + 0xa4 + *(longlong *)(param_1 + 0x6f8)) = uVar1;
            *(undefined4 *)(lVar27 + 0xe4 + *(longlong *)(param_1 + 0x6f8)) = uVar1;
          }
          iVar25 = iVar25 + 4;
          lVar27 = lVar27 + 0x100;
        } while (iVar25 < *(int *)(param_1 + 0x708));
      }
    }
LAB_140195748:
    puVar32 = (ulonglong *)(param_1 + 0x108);
    if ((int)local_100 != 0) {
      puVar32 = (ulonglong *)(param_1 + 0x110);
    }
    uVar18 = *puVar32;
    uVar37 = (uint)(uVar18 >> 0xe) & 0x3ff;
    iVar25 = uVar37 + 1;
    uVar41 = (uint)*puVar32 & 3;
    uVar31 = (uint)(uVar18 >> 2) & 3;
    iVar36 = ((uint)(uVar18 >> 0x22) & 0x3ff) + 1;
    if (*(int *)(puVar34 + 4) == 0) {
      if ((uVar37 - 0x1ff & 0xffffff7f) == 0) {
        iVar25 = *(int *)((longlong)puVar34 + 0x14);
      }
      if (iVar36 == 0x1c0) {
        iVar36 = *(int *)(puVar34 + 3);
      }
    }
    if (((uVar41 == 2) && ((uVar18 >> 4 & 0x3ff) == 0)) &&
       (*(int *)((longlong)puVar34 + 0x14) <= iVar25)) {
      uVar41 = 1;
    }
    if (((uVar31 == 2) && ((uVar18 & 0x3ff000000) == 0)) && (*(int *)(puVar34 + 3) <= iVar36)) {
      uVar31 = 1;
    }
    if ((1 < uVar41) || (1 < uVar31)) {
      in_stack_fffffffffffffe88 = puVar32;
      puVar23 = (undefined8 *)FUN_1401924e0(param_1,local_f8,uVar41,uVar31,puVar32);
      uVar29 = auVar54._0_8_;
      uVar40 = *puVar23;
      if (1 < uVar41) {
        uVar41 = 1 - (uVar41 & 1);
      }
      if (1 < uVar31) {
        uVar31 = 1 - (uVar31 & 1);
      }
    }
    fVar57 = DAT_1402d2d2c;
    uVar31 = uVar41 * 2 | uVar31;
    if (*puVar32 >> 0x3e != 0) {
      iVar25 = 0;
      uVar31 = (*puVar32 >> 0x3e != 1) + 4;
      if (0 < *(int *)(param_1 + 0x708)) {
        lVar17 = 0;
        do {
          if ((float)uVar29 == *(float *)(*(longlong *)(param_1 + 0x6f8) + 0x20 + lVar17)) {
            *(float *)(*(longlong *)(param_1 + 0x6f8) + 0x20 + lVar17) =
                 fVar57 / (float)*(int *)((longlong)puVar34 + 0x14);
          }
          if ((float)uVar29 == *(float *)(*(longlong *)(param_1 + 0x6f8) + 0x24 + lVar17)) {
            *(float *)(*(longlong *)(param_1 + 0x6f8) + 0x24 + lVar17) =
                 fVar57 / (float)*(int *)(puVar34 + 3);
          }
          iVar25 = iVar25 + 1;
          lVar17 = lVar17 + 0x40;
        } while (iVar25 < *(int *)(param_1 + 0x708));
      }
    }
  }
  uVar39 = 1;
  lVar17 = 0;
  iVar25 = 0;
  if (*(char *)(param_1 + 0x710) != '\0') {
    lVar17 = *(longlong *)(param_1 + 0x700);
    iVar36 = *(int *)(param_1 + 0x70c) + -1;
    iVar25 = *(int *)(param_1 + 0x70c);
    if (*(short *)(lVar17 + (longlong)iVar36 * 2) == -1) {
      *(int *)(param_1 + 0x70c) = iVar36;
      iVar25 = iVar36;
    }
  }
  if (local_110 == 0) {
    puVar34 = &DAT_14031e088;
  }
  else if (local_110 == 1) {
    if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dab98) &&
       (FUN_14022d540(&DAT_1437dab98), DAT_1437dab98 == -1)) {
      DAT_14031efa0._0_4_ = DAT_1402c4100;
      DAT_14031efa0._4_2_ = DAT_1402c4104;
      atexit(FUN_140279660);
      _Init_thread_footer(&DAT_1437dab98);
      puVar34 = &DAT_14031efa0;
    }
    else {
      puVar34 = &DAT_14031efa0;
    }
  }
  else {
    if (local_110 == 2) {
      FUN_140195dc0(param_1);
      goto LAB_140195b50;
    }
    uVar58 = (uint7)((ulonglong)in_stack_fffffffffffffe88 >> 8);
    if (local_110 != 3) {
      if (local_110 != 4) {
        if (local_110 == 5) {
          FUN_14020ef50(0x10,DAT_1402d22d0,0,0,(ulonglong)uVar58 << 8);
          if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dabac) &&
             (FUN_14022d540(&DAT_1437dabac), DAT_1437dabac == -1)) {
            DAT_14031ef20._0_4_ = DAT_1402c412c;
            DAT_14031ef20._4_2_ = DAT_1402c4130;
            atexit(FUN_140279560);
            _Init_thread_footer(&DAT_1437dabac);
            puVar34 = &DAT_14031ef20;
          }
          else {
            puVar34 = &DAT_14031ef20;
          }
        }
        else if (local_110 == 6) {
          if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437daba4) &&
             (FUN_14022d540(&DAT_1437daba4), DAT_1437daba4 == -1)) {
            DAT_14031ef40._0_4_ = DAT_1402c4124;
            DAT_14031ef40._4_2_ = DAT_1402c4128;
            atexit(FUN_1402794e0);
            _Init_thread_footer(&DAT_1437daba4);
            puVar34 = &DAT_14031ef40;
          }
          else {
            puVar34 = &DAT_14031ef40;
          }
        }
        else {
          if (local_110 != 7) goto LAB_140195b50;
          if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437daba0) &&
             (FUN_14022d540(&DAT_1437daba0), DAT_1437daba0 == -1)) {
            DAT_14031efe0._0_4_ = DAT_1402c411c;
            DAT_14031efe0._4_2_ = DAT_1402c4120;
            atexit(FUN_140279460);
            _Init_thread_footer(&DAT_1437daba0);
            puVar34 = &DAT_14031efe0;
          }
          else {
            puVar34 = &DAT_14031efe0;
          }
        }
        goto LAB_140195ad7;
      }
      uVar39 = 9;
    }
    FUN_14020ef50(uVar39,uVar29,0,0,(ulonglong)uVar58 << 8);
    if (DAT_140326f84 == '\0') {
      puVar34 = &DAT_14031e088;
    }
    else {
      FUN_14020e550(DAT_14030cac0,0,0);
      local_108[0] = DAT_14030cac0;
      plVar24 = (longlong *)FUN_140211de0(&DAT_1403566e8,local_f0,local_108);
      DAT_14032c908 = 0;
      DAT_14032c900 = *plVar24 + 0x48;
      if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437daba8) &&
         (FUN_14022d540(&DAT_1437daba8), DAT_1437daba8 == -1)) {
        DAT_14031ef60._0_4_ = (undefined4)DAT_1402c40f0;
        DAT_14031ef60._4_2_ = DAT_1402c40f0._4_2_;
        DAT_14031ef60._6_1_ = DAT_1402c40f0._6_1_;
        atexit(FUN_1402795e0);
        _Init_thread_footer(&DAT_1437daba8);
        puVar34 = &DAT_14031ef60;
      }
      else {
        puVar34 = &DAT_14031ef60;
      }
    }
  }
LAB_140195ad7:
  FUN_14020f8e0(uVar40,uVar31,*(undefined8 *)(param_1 + 0x6f8),*(undefined4 *)(param_1 + 0x708),
                iVar28,local_118,local_114,*(undefined4 *)(param_1 + 0x73c),
                *(uint *)(param_1 + 0x740) ^ DAT_1402d3770,*(undefined4 *)(param_1 + 0x744),
                *(undefined4 *)(param_1 + 0x748),local_10c,puVar34,lVar17,iVar25);
LAB_140195b50:
  *(undefined1 *)(param_1 + 0x738) = 1;
  return;
}

