/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020f590; RVA 0x20f590
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14020f590(int param_1)

{
  int local_18 [6];
  
  local_18[0] = 1;
  local_18[1] = 2;
  local_18[2] = 3;
  if ((DAT_14031e110 == '\0') && (DAT_14031e2e0 == local_18[param_1])) {
    DAT_14031e110 = 0;
    DAT_14031e2e0 = local_18[param_1];
    return;
  }
  DAT_14031e2e0 = local_18[param_1];
  DAT_14031e110 = 1;
  return;
}

