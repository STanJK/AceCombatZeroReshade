/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400af750; RVA 0xaf750
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_1400af750(longlong param_1,undefined8 param_2,longlong param_3,longlong *param_4)

{
  uint *puVar1;
  longlong lVar2;
  longlong lVar3;
  float fVar4;
  float fVar5;
  undefined4 uVar6;
  ushort uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong lVar10;
  ulonglong uVar11;
  undefined8 uVar12;
  longlong lVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  float fVar17;
  undefined8 extraout_XMM0_Qa;
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  float fVar20;
  float fVar21;
  undefined1 auVar22 [16];
  undefined1 auVar23 [64];
  undefined1 auVar24 [16];
  undefined1 auVar25 [64];
  float fVar26;
  float fVar27;
  undefined1 auVar28 [64];
  float fVar29;
  undefined1 auVar30 [64];
  float fVar31;
  float fVar32;
  float fVar33;
  undefined1 uStackX_9;
  undefined1 uStackX_a;
  undefined1 uStackX_b;
  float fVar34;
  undefined8 local_120;
  undefined8 uStack_118;
  undefined1 local_108 [12];
  undefined4 uStack_fc;
  undefined8 local_f8;
  int iStack_f0;
  undefined4 uStack_ec;
  float fStack_e8;
  undefined1 uStack_e4;
  undefined1 uStack_e3;
  undefined1 uStack_e2;
  undefined1 uStack_e1;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  
  fVar27 = *(float *)(param_3 + 0x198);
  fVar4 = fVar27 * DAT_1402d2504;
  fVar34 = *(float *)(param_3 + 0x19c) * DAT_1402d2504;
  auVar28 = ZEXT464((uint)(fVar27 * DAT_1402d26ac));
  lVar13 = 0;
  fVar5 = *(float *)(param_3 + 0x19c) * DAT_1402d26ac;
  auVar30 = ZEXT464((uint)fVar5);
  lVar2 = *(longlong *)(*(longlong *)(*param_4 + (ulonglong)*(byte *)(param_1 + 0x3ca) * 8) + 0x110)
  ;
  if (lVar2 != 0) {
    lVar13 = *(longlong *)(lVar2 + 0x1b8);
  }
  lVar3 = *(longlong *)(param_1 + 0x118);
  lVar10 = 0;
  if (lVar3 != 0) {
    lVar10 = lVar3;
  }
  if ((lVar2 == 0) || (lVar10 == 0)) {
    return param_2;
  }
  local_120 = *(undefined8 *)(lVar2 + 0x268);
  uStack_118 = *(undefined8 *)(lVar2 + 0x270);
  auVar18 = *(undefined1 (*) [16])(lVar3 + 600);
  auVar23 = ZEXT1664(auVar18);
  auVar25 = ZEXT1664(*(undefined1 (*) [16])(lVar2 + 600));
  auVar18 = vshufps_avx(auVar18,auVar18,0x55);
  fVar17 = auVar18._0_4_ + *(float *)(param_1 + 0x120);
  _local_108 = ZEXT816(0);
  fStack_e8 = 0.0;
  uStack_e4 = 0;
  uStack_e3 = 0;
  uStack_e2 = 0;
  uStack_e1 = 0;
  uStack_e0 = local_108._4_8_;
  local_f8 = 0;
  iStack_f0 = 0;
  uStack_ec = 0;
  local_d8 = 0;
  uStack_d0 = 0;
  FUN_140202920(local_108,&local_120,fVar27,fVar4,fVar34);
  FUN_14003a2e0(local_108);
  fVar26 = auVar25._0_4_ - auVar23._0_4_;
  auVar24 = auVar25._0_16_;
  auVar18 = vshufps_avx(auVar24,auVar24,0x55);
  fVar17 = auVar18._0_4_ - fVar17;
  auVar22 = auVar23._0_16_;
  auVar18 = vshufps_avx(auVar22,auVar22,0xaa);
  auVar19 = vshufps_avx(auVar24,auVar24,0xaa);
  fVar21 = auVar19._0_4_ - auVar18._0_4_;
  auVar18 = vshufps_avx(auVar24,auVar24,0xff);
  auVar19 = vshufps_avx(auVar22,auVar22,0xff);
  fVar29 = auVar18._0_4_ - auVar19._0_4_;
  fVar27 = (fVar26 * (float)local_108._4_4_ + fVar17 * local_f8._4_4_ +
           fVar29 * local_d8._4_4_ +
           fVar21 * (float)CONCAT13(uStack_e1,CONCAT12(uStack_e2,CONCAT11(uStack_e3,uStack_e4)))) *
           DAT_1402d1fa8;
  fVar17 = (fVar26 * (float)local_108._0_4_ + fVar17 * (float)local_f8 +
           fVar29 * (float)local_d8 + fVar21 * fStack_e8) * DAT_1402d2cb8;
  fVar26 = auVar28._0_4_;
  if (fVar17 <= fVar26) {
    auVar18._0_4_ = (uint)fVar26 ^ DAT_1402d3770;
    auVar18._4_4_ = auVar28._4_4_;
    auVar18._8_4_ = auVar28._8_4_;
    auVar18._12_4_ = auVar28._12_4_;
    auVar18 = vmaxss_avx(auVar18,ZEXT416((uint)fVar17));
  }
  else {
    auVar18 = auVar28._0_16_;
  }
  auVar28 = ZEXT1664(auVar18);
  if (fVar27 <= auVar30._0_4_) {
    auVar19._0_4_ = (uint)auVar30._0_4_ ^ DAT_1402d3770;
    auVar19._4_4_ = auVar30._4_4_;
    auVar19._8_4_ = auVar30._8_4_;
    auVar19._12_4_ = auVar30._12_4_;
    auVar19 = vmaxss_avx(auVar19,ZEXT416((uint)fVar27));
    auVar30 = ZEXT1664(auVar19);
  }
  if (lVar13 != 0) {
    fVar27 = fVar26 * DAT_1402d21f8;
    uVar7 = *(ushort *)(lVar13 + 0x2090) & 0xff3f;
    fVar17 = (float)((uint)fVar27 ^ DAT_1402d3770);
    *(ushort *)(lVar13 + 0x2090) = uVar7;
    if (fVar17 <= auVar18._0_4_) {
      if (auVar18._0_4_ <= fVar27) goto LAB_1400af993;
      uVar7 = uVar7 | 0x80;
    }
    else {
      uVar7 = uVar7 | 0x40;
    }
    *(ushort *)(lVar13 + 0x2090) = uVar7;
  }
LAB_1400af993:
  uVar7 = *(ushort *)(param_1 + 0x39c);
  puVar1 = (uint *)(param_1 + 0x348);
  if (uVar7 == 0xffff) {
    uVar11 = 4;
    if ((*(uint *)(param_1 + 0x34c) & 0x10001) != 0) goto LAB_1400af9c8;
LAB_1400afa3e:
    uVar8 = *(undefined4 *)(param_1 + 0x1b0);
  }
  else {
    if ((*puVar1 >> 0x1a & 1) == 0) {
      *puVar1 = *puVar1 | 0x4000000;
    }
    uVar11 = (ulonglong)(uVar7 & 4);
    if ((uVar7 & 4) != 0) goto LAB_1400afa3e;
LAB_1400af9c8:
    uVar8 = *(undefined4 *)(param_1 + 0x1f8);
  }
  uVar6 = DAT_1402d22d0;
  local_108._0_4_ = uVar8;
  uStack_ec = 0xfffffff;
  fStack_e8 = 0.0;
  uStack_fc = DAT_1402d22d0;
  if (uVar7 == 0xffff) {
    if ((*(uint *)(param_1 + 0x34c) & 0x10001) != 0) goto LAB_1400afa1e;
  }
  else {
    if ((*puVar1 >> 0x1a & 1) == 0) {
      *puVar1 = *puVar1 | 0x4000000;
    }
    if ((short)uVar11 == 0) {
LAB_1400afa1e:
      uVar8 = *(undefined4 *)(param_1 + 0x1f8);
      goto LAB_1400afa55;
    }
  }
  uVar8 = *(undefined4 *)(param_1 + 0x1b0);
LAB_1400afa55:
  auVar23 = ZEXT464((uint)DAT_1402d2544);
  uStack_e4 = (undefined1)uVar8;
  uStackX_9 = (undefined1)((uint)uVar8 >> 8);
  uStack_e3 = uStackX_9;
  uStackX_a = (undefined1)((uint)uVar8 >> 0x10);
  uStack_e2 = uStackX_a;
  uStackX_b = (undefined1)((uint)uVar8 >> 0x18);
  local_d8 = CONCAT44(local_d8._4_4_,uVar6);
  uStack_e1 = uStackX_b;
  local_c8 = 0xfffffff;
  fVar17 = auVar30._0_4_ * DAT_1402d2544;
  fVar31 = (float)(*(int *)(param_1 + 0x390) + 0x100);
  fVar20 = (float)(*(int *)(param_1 + 0x394) + 0xdf);
  fVar21 = fVar20 * DAT_1402d2544;
  iStack_f0 = (int)(fVar21 + fVar17 + DAT_1402d2b2c);
  fVar29 = fVar31 * DAT_1402d2544;
  fVar27 = fVar26 * DAT_1402d2544 + fVar29 + DAT_1402d2b1c;
  iVar14 = (int)fVar27;
  iVar15 = (int)((fVar31 - fVar26) * DAT_1402d2544 + DAT_1402d2b1c);
  local_f8 = CONCAT44(iVar15,(float)local_f8);
  uStack_d0 = CONCAT44(iStack_f0,iVar14);
  fVar26 = DAT_1402d2b2c;
  fVar33 = DAT_1402d2b1c;
  uVar9 = FUN_1400b99c0(fVar27,param_2,local_108,&uStack_e4);
  fVar27 = auVar23._0_4_ * fVar4;
  iStack_f0 = (int)((fVar20 - fVar4) * auVar23._0_4_ + fVar17 + fVar26);
  uStack_d0._4_4_ = (int)(fVar21 + fVar27 + fVar17 + fVar26);
  uVar12 = CONCAT44((int)(uVar11 >> 0x20),uStack_d0._4_4_);
  uStack_d0._0_4_ = iVar15;
  uVar9 = FUN_1400b99c0(uVar12,uVar9,local_108,&uStack_e4);
  uVar8 = (undefined4)((ulonglong)uVar12 >> 0x20);
  local_f8 = CONCAT44(iVar14,(float)local_f8);
  uStack_d0 = CONCAT44(uStack_d0._4_4_,iVar14);
  uVar9 = FUN_1400b99c0(extraout_XMM0_Qa,uVar9,local_108,&uStack_e4);
  fVar32 = auVar23._0_4_;
  fVar17 = auVar28._0_4_ * fVar32;
  iVar14 = (int)(fVar29 + fVar17 + fVar33);
  iVar15 = (int)((fVar20 - fVar5) * fVar32 + fVar26);
  iVar16 = (int)(fVar32 * fVar5 + fVar21 + fVar26);
  local_f8 = CONCAT44(iVar14,(float)local_f8);
  uStack_d0 = CONCAT44(iVar16,iVar14);
  iStack_f0 = iVar15;
  uVar9 = FUN_1400b99c0(CONCAT44(uVar8,iVar14),uVar9,local_108,&uStack_e4);
  local_f8 = CONCAT44((int)((fVar31 - fVar34) * auVar23._0_4_ + fVar17 + fVar33),(float)local_f8);
  iVar14 = (int)(auVar23._0_4_ * fVar34 + fVar29 + fVar17 + fVar33);
  uStack_d0 = CONCAT44(iVar15,iVar14);
  uVar9 = FUN_1400b99c0(iVar14,uVar9,local_108,&uStack_e4);
  local_f8 = CONCAT44((int)((fVar31 - fVar4) * auVar23._0_4_ + fVar17 + fVar33),(float)local_f8);
  iVar14 = (int)(fVar29 + fVar27 + fVar17 + fVar33);
  uStack_d0 = CONCAT44(iVar16,iVar14);
  iStack_f0 = iVar16;
  uVar9 = FUN_1400b99c0(iVar14,uVar9,local_108,&uStack_e4);
  return uVar9;
}

