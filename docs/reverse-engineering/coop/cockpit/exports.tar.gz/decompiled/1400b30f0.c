/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b30f0; RVA 0xb30f0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400b30f0(longlong param_1,undefined8 param_2,longlong param_3,longlong *param_4)

{
  undefined1 auVar1 [32];
  undefined1 auVar2 [32];
  byte bVar3;
  byte bVar4;
  byte bVar5;
  undefined4 uVar6;
  longlong lVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  int iVar11;
  longlong lVar12;
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 in_ZMM6 [64];
  undefined1 auVar17 [64];
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined1 auVar22 [64];
  undefined1 auVar23 [64];
  undefined1 auVar24 [64];
  undefined1 auVar25 [64];
  undefined1 auVar26 [64];
  undefined1 auStack_1b8 [32];
  undefined8 local_198;
  float local_190;
  float local_188;
  float local_180;
  float local_178;
  float local_170;
  int local_168 [4];
  int local_158 [4];
  longlong local_148;
  undefined8 local_138;
  undefined8 uStack_130;
  undefined1 local_128;
  undefined1 local_127;
  undefined1 local_126;
  undefined1 local_125;
  undefined4 local_11c;
  int local_114;
  int local_110;
  undefined8 local_10c;
  undefined1 local_104;
  undefined1 local_103;
  undefined1 local_102;
  undefined1 local_101;
  undefined4 local_f8;
  int local_f0;
  int local_ec;
  undefined8 local_e8;
  ulonglong local_d8;
  undefined1 local_38 [16];
  
  local_d8 = DAT_140309040 ^ (ulonglong)auStack_1b8;
  bVar3 = *(byte *)(param_1 + 0x3ca);
  iVar11 = 1;
  local_158[0] = 0x79;
  local_158[1] = 0x79;
  lVar7 = *param_4;
  local_158[2] = 0x79;
  local_168[0] = 0x74;
  local_168[1] = 0x74;
  lVar12 = *(longlong *)(lVar7 + (ulonglong)bVar3 * 8);
  local_168[2] = 0x74;
  if (1 < *(int *)(lVar12 + 0x118)) {
    lVar9 = 0x520;
    auVar22 = ZEXT464(DAT_1402d2b60);
    auVar23 = ZEXT464(DAT_1402d2544);
    auVar24 = ZEXT464(DAT_1402d22d0);
    auVar25 = ZEXT464(DAT_1402d28e0);
    auVar26 = ZEXT464(DAT_1402d277c);
    local_38 = in_ZMM6._0_16_;
    lVar10 = 0;
    local_148 = param_3;
    do {
      if ((*(char *)(lVar12 + 0x15d) == '\0') &&
         (lVar12 = *(longlong *)(lVar12 + 0x110), (*(byte *)(lVar12 + 0x1f0 + lVar9) & 2) != 0)) {
        bVar4 = *(byte *)(lVar12 + 0x236 + lVar9);
        bVar5 = *(byte *)(lVar12 + 0x237 + lVar9);
        if ((bVar4 != 0xff) &&
           ((bVar5 != 0xff &&
            (lVar12 = *(longlong *)(*(longlong *)(*param_4 + (ulonglong)bVar4 * 8) + 0x110) +
                      (ulonglong)bVar5 * 0x520, (*(uint *)(lVar12 + 0x1f0) & 0x2002) == 2)))) {
          local_138 = *(undefined8 *)(lVar12 + 600);
          uStack_130 = *(undefined8 *)(lVar12 + 0x260);
          iVar8 = FUN_140202ed0(param_3 + 0x150,&local_138);
          if ((iVar8 == 0) &&
             (*(float *)(lVar12 + 0x20c + (ulonglong)*(byte *)(param_1 + 0x3ca) * 4) <=
              auVar22._0_4_)) {
            uVar6 = *(undefined4 *)(param_1 + 0x254);
            fVar18 = *(float *)(lVar12 + 600);
            fVar19 = *(float *)(lVar12 + 0x25c);
            fVar21 = *(float *)(lVar12 + 0x264);
            fVar20 = *(float *)(lVar12 + 0x260);
            auVar13 = SUB3216(*(undefined1 (*) [32])(param_3 + 0x110),0);
            auVar13 = vshufps_avx(auVar13,auVar13,0xff);
            auVar14 = SUB3216(*(undefined1 (*) [32])(param_3 + 0x110),0x10);
            auVar14 = vshufps_avx(auVar14,auVar14,0xff);
            local_188 = auVar23._0_4_;
            auVar15 = SUB3216(*(undefined1 (*) [32])(param_3 + 0x130),0);
            auVar15 = vshufps_avx(auVar15,auVar15,0xff);
            auVar16 = SUB3216(*(undefined1 (*) [32])(param_3 + 0x130),0x10);
            auVar16 = vshufps_avx(auVar16,auVar16,0xff);
            local_190 = (float)*(int *)((longlong)local_168 + lVar10);
            local_126 = (undefined1)((uint)uVar6 >> 0x10);
            local_125 = (undefined1)((uint)uVar6 >> 0x18);
            local_198 = CONCAT44(local_198._4_4_,(float)*(int *)((longlong)local_158 + lVar10));
            local_11c = auVar24._0_4_;
            local_10c = 0xfffffff;
            local_128 = (undefined1)uVar6;
            local_127 = (undefined1)((uint)uVar6 >> 8);
            local_e8 = 0xfffffff;
            auVar17 = ZEXT1664(CONCAT124(auVar23._4_12_,
                                         local_188 /
                                         (fVar18 * auVar13._0_4_ + fVar19 * auVar14._0_4_ +
                                         fVar20 * auVar15._0_4_ + fVar21 * auVar16._0_4_)));
            auVar22 = ZEXT1664(auVar22._0_16_);
            auVar23 = ZEXT1664(auVar23._0_16_);
            auVar24 = ZEXT1664(auVar24._0_16_);
            auVar25 = ZEXT1664(auVar25._0_16_);
            auVar26 = ZEXT1664(auVar26._0_16_);
            local_180 = local_188;
            local_178 = local_188;
            local_170 = local_188;
            local_104 = local_128;
            local_103 = local_127;
            local_102 = local_126;
            local_101 = local_125;
            local_f8 = local_11c;
            FUN_1400ad600(&local_128,&local_104);
            auVar1 = *(undefined1 (*) [32])(param_3 + 0x110);
            auVar2 = *(undefined1 (*) [32])(param_3 + 0x130);
            auVar13 = vshufps_avx(auVar1._0_16_,auVar1._0_16_,0x55);
            local_114 = (int)(auVar17._0_4_ *
                              (fVar18 * auVar1._0_4_ + fVar19 * auVar1._16_4_ +
                              fVar20 * auVar2._0_4_ + fVar21 * auVar2._16_4_) - auVar25._0_4_);
            auVar14 = vshufps_avx(auVar1._16_16_,auVar1._16_16_,0x55);
            auVar15 = vshufps_avx(auVar2._0_16_,auVar2._0_16_,0x55);
            auVar16 = vshufps_avx(auVar2._16_16_,auVar2._16_16_,0x55);
            local_f0 = local_114 + 0x100;
            local_110 = (int)(auVar17._0_4_ *
                              (fVar18 * auVar13._0_4_ + fVar19 * auVar14._0_4_ +
                              fVar20 * auVar15._0_4_ + fVar21 * auVar16._0_4_) + auVar26._0_4_);
            local_ec = local_110 + 0x100;
            local_198 = *(undefined8 *)(*(longlong *)(param_1 + 0x300) + 0x398);
            auVar22 = ZEXT1664(auVar22._0_16_);
            auVar23 = ZEXT1664(auVar23._0_16_);
            auVar24 = ZEXT1664(auVar24._0_16_);
            auVar25 = ZEXT1664(auVar25._0_16_);
            auVar26 = ZEXT1664(auVar26._0_16_);
            param_2 = FUN_1401fe080(param_2,0x156,2,&local_128);
            param_3 = local_148;
          }
        }
      }
      lVar12 = *(longlong *)(lVar7 + (ulonglong)bVar3 * 8);
      iVar11 = iVar11 + 1;
      lVar10 = lVar10 + 4;
      lVar9 = lVar9 + 0x520;
    } while (iVar11 < *(int *)(lVar12 + 0x118));
  }
  return param_2;
}

