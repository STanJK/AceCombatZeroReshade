/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401936b0; RVA 0x1936b0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Removing unreachable block (ram,0x000140193ad6) */
/* WARNING: Removing unreachable block (ram,0x000140193a8f) */
/* WARNING: Removing unreachable block (ram,0x000140193b6a) */
/* WARNING: Removing unreachable block (ram,0x000140193b2f) */

undefined8 FUN_1401936b0(longlong param_1,float *param_2)

{
  ulonglong uVar1;
  uint uVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  byte bVar6;
  uint uVar8;
  uint uVar7;
  char cVar9;
  ulonglong uVar10;
  bool bVar11;
  float fVar12;
  undefined1 auVar13 [64];
  undefined1 local_res8 [16];
  char local_res18 [8];
  undefined4 local_res20 [2];
  undefined4 local_48 [8];
  
  local_res20[0] = 0x14;
  lVar3 = 0x1a0;
  if ((*(byte *)(param_1 + 0x198) & 1) != 0) {
    lVar3 = 200;
  }
  auVar13 = ZEXT864(0);
  uVar10 = (ulonglong)((uint)(*(ulonglong *)(lVar3 + param_1) >> 9) & 1);
  if ((*(ulonglong *)(lVar3 + param_1) >> 6 & 1) == 0) {
LAB_140193a24:
    *param_2 = -1.0;
    cVar9 = '\0';
    *(undefined1 *)(param_2 + 1) = 0;
    uVar1 = *(ulonglong *)(param_1 + 0x300 + uVar10 * 8);
    local_res18[0] = '\x01';
    local_res8[0] = 1;
    if ((uVar1 & 1) != 0) {
      uVar4 = uVar1 >> 0xc;
      uVar8 = (uint)uVar1;
      uVar7 = uVar8 & 0xe;
      uVar2 = (uint)uVar4 & 3;
      if (uVar7 == 0xc) {
        if ((uVar4 & 3) == 0) {
          *param_2 = (float)(uVar1 >> 4 & 0xff) * DAT_1402d1ed8;
        }
        else {
          if (uVar2 != 3) goto LAB_140193b9b;
          fVar12 = (float)(uVar1 >> 4 & 0xff);
LAB_140193aeb:
          *param_2 = fVar12 * DAT_1402d1ed8;
          *(undefined1 *)(param_2 + 1) = 1;
        }
      }
      else if (uVar7 == 10) {
        if (uVar2 == 3) {
          fVar12 = (float)(uVar1 >> 4 & 0xff) - DAT_1402d1ff8;
          goto LAB_140193aeb;
        }
        if ((uVar4 & 3) != 0) goto LAB_140193b9b;
        *param_2 = ((float)(uVar1 >> 4 & 0xff) - DAT_1402d1ff8) * DAT_1402d1ed8;
      }
      else if (uVar7 != 2) {
LAB_140193b9b:
        if ((uVar8 & 0x3ffe) == 0xe) {
          *param_2 = 0.0;
        }
        else {
          if (((uVar1 & 0xe) != 0) || ((uVar1 & 0x3000) == 0)) goto LAB_140193c25;
          if ((uVar8 & 0x3000) != 0x1000) {
            if ((uVar8 & 0x3000) != 0x3000) goto LAB_140193bd5;
            local_res18[0] = '\0';
          }
          local_res8[0] = 0;
        }
      }
    }
LAB_140193bd5:
    uVar1 = *(ulonglong *)(param_1 + 0x300 + uVar10 * 8);
    if ((uVar1 >> 0xe & 1) != 0) {
      cVar9 = ((uVar1 >> 0xf & 1) != 0) + '\x01';
    }
    if (((uVar1 >> 0x10 & 1) == 0) || (uVar2 = (uint)uVar1 & 0x60000, uVar2 == 0x20000)) {
      local_48[0] = 0;
    }
    else if (uVar2 == 0x40000) {
      local_48[0] = 1;
    }
    else {
      if (uVar2 != 0x60000) goto LAB_140193c25;
      local_48[0] = 2;
    }
    FUN_140193cc0(param_1,local_res20,local_res18,local_48,local_res8);
    *(byte *)(param_2 + 3) = *(byte *)(param_1 + 0x318 + uVar10 * 8) & 1;
    FUN_14020f410(local_48[0],local_res8[0],cVar9);
    if (local_res18[0] == '\0') {
      *(undefined1 *)(param_2 + 3) = 0;
      *(undefined1 *)(param_2 + 1) = 0;
    }
    FUN_14020ef50(local_res20[0],auVar13._0_8_,local_res18[0],*(undefined1 *)(param_2 + 3),
                  *(undefined1 *)(param_2 + 1));
    uVar5 = 1;
  }
  else {
    uVar1 = *(ulonglong *)(param_1 + 0x2d8 + uVar10 * 8);
    uVar2 = (uint)uVar1 & 3;
    bVar6 = (byte)uVar1;
    if ((uVar1 & 3) == 0) {
      uVar2 = (uint)uVar1 & 0xc;
      if (uVar2 == 4) {
        if (((uVar1 & 0x30) != 0) || ((bVar6 & 0xc0) != 0x40)) goto LAB_14019379c;
        local_res20[0] = 0;
      }
      else if (uVar2 == 8) {
        if ((uVar1 & 0x30) == 0) {
          if ((bVar6 & 0xc0) == 0x40) {
            local_res20[0] = 1;
          }
          else {
LAB_14019379c:
            if (((uVar1 & 0x3c) == 0) && ((bVar6 & 0xc0) == 0x40)) goto LAB_14019396f;
            if ((bVar6 & 0xc) == 8) {
              if ((bVar6 & 0x30) == 0x10) {
                if ((bVar6 & 0xc0) != 0x40) goto LAB_140193843;
                local_res20[0] = 9;
              }
              else {
                if (((uVar1 & 0x30) != 0) || ((bVar6 & 0xc0) != 0x80)) goto LAB_140193843;
                local_res20[0] = 0x11;
              }
            }
            else {
              if ((bVar6 & 0xc) == 4) {
                if ((bVar6 & 0x30) == 0x10) {
                  if ((bVar6 & 0xc0) == 0x40) {
                    local_res20[0] = 10;
                    goto LAB_140193a0b;
                  }
                }
                else if ((bVar6 & 0x30) == 0x20) {
                  if ((bVar6 & 0xc0) == 0x40) {
                    local_res20[0] = 0xb;
                  }
                  else {
                    if ((bVar6 & 0xc0) != 0x80) goto LAB_140193843;
                    local_res20[0] = 0xd;
                  }
                  goto LAB_140193a0b;
                }
              }
LAB_140193843:
              if ((uVar1 & 0xfc) != 0) goto LAB_140193c25;
              if (*(char *)(param_1 + 0x2dc + uVar10 * 8) == -1) {
                local_res20[0] = 0xf;
              }
              else {
                param_2[2] = (float)(uint)*(byte *)(param_1 + 0x2dc + uVar10 * 8);
                local_res20[0] = 0x14;
              }
            }
          }
        }
        else {
          if (((bVar6 & 0x30) != 0x20) || ((bVar6 & 0xc0) != 0x40)) goto LAB_14019379c;
          local_res20[0] = 6;
        }
      }
      else {
        if ((((uVar1 & 0xc) != 0) || ((bVar6 & 0x30) != 0x20)) || ((uVar1 & 0xc0) != 0))
        goto LAB_14019379c;
LAB_140193955:
        local_res20[0] = 0x14;
      }
LAB_140193a0b:
      auVar13 = ZEXT464((uint)((float)*(byte *)(param_1 + 0x2dc + uVar10 * 8) * DAT_1402d1ed4));
      goto LAB_140193a24;
    }
    if (uVar2 == 1) {
      if ((uVar1 & 0xc) == 0) {
        if ((((bVar6 & 0x30) == 0x20) && ((bVar6 & 0xc0) == 0x80)) &&
           ((char)(uVar1 >> 0x20) == -0x80)) {
          local_res20[0] = 3;
          goto LAB_140193a0b;
        }
      }
      else if ((bVar6 & 0xc) == 8) {
        if ((uVar1 & 0x30) == 0) {
          if ((bVar6 & 0xc0) == 0x80) {
            local_res20[0] = 5;
          }
          else {
            if ((bVar6 & 0xc0) != 0x40) goto LAB_140193c25;
            bVar11 = *(char *)(param_1 + 0x2dc + uVar10 * 8) == -0x7f;
            local_res20[0] = 0x13;
            if (!bVar11) {
              local_res20[0] = 5;
            }
            param_2[2] = (float)(bVar11 + 6);
          }
        }
        else {
          if (((bVar6 & 0x30) != 0x20) || ((bVar6 & 0xc0) != 0x80)) goto LAB_140193c25;
          local_res20[0] = 7;
        }
        goto LAB_140193a0b;
      }
    }
    else if (uVar2 == 2) {
      if ((bVar6 & 0xc) == 8) {
        if ((bVar6 & 0x30) == 0x20) {
          if ((uVar1 & 0xc0) == 0) goto LAB_140193955;
        }
        else if (((uVar1 & 0x30) == 0) && ((bVar6 & 0xc0) == 0x40)) {
LAB_14019396f:
          local_res20[0] = 8;
          goto LAB_140193a0b;
        }
      }
      if (((uVar1 & 0x3c) == 0) && ((bVar6 & 0xc0) == 0x40)) {
        local_res20[0] = 4;
      }
      else if ((uVar1 & 0xc) == 0) {
        if ((bVar6 & 0x30) == 0x10) {
          if ((uVar1 & 0xc0) == 0) {
            local_res20[0] = 0xc;
          }
          else {
            if ((bVar6 & 0xc0) != 0x40) goto LAB_140193c25;
            local_res20[0] = 0xe;
          }
        }
        else {
          if (((bVar6 & 0x30) != 0x20) || ((bVar6 & 0xc0) != 0x40)) goto LAB_140193c25;
          local_res20[0] = 0x10;
        }
      }
      else {
        if ((((bVar6 & 0xc) != 4) || ((uVar1 & 0x30) != 0)) || ((bVar6 & 0xc0) != 0x40))
        goto LAB_140193c25;
        local_res20[0] = 0x12;
      }
      goto LAB_140193a0b;
    }
LAB_140193c25:
    uVar5 = 0;
  }
  return uVar5;
}

