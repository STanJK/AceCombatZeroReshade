/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b7b40; RVA 0xb7b40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400b7b40(longlong *param_1,longlong *param_2,undefined8 param_3,float param_4,
                  undefined8 param_5,undefined8 param_6)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  float fVar4;
  byte bVar5;
  float fVar6;
  float fVar7;
  byte bVar8;
  undefined1 uVar9;
  int iVar10;
  uint uVar11;
  longlong lVar12;
  ulonglong uVar13;
  short sVar14;
  longlong lVar15;
  longlong lVar16;
  char *pcVar17;
  char cVar18;
  undefined7 uVar21;
  longlong lVar19;
  char *pcVar20;
  short sVar22;
  short sVar23;
  longlong lVar24;
  bool bVar25;
  short sVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  undefined8 in_stack_ffffffffffffff88;
  undefined4 uVar30;
  
  fVar29 = DAT_1402d2420;
  uVar30 = (undefined4)((ulonglong)in_stack_ffffffffffffff88 >> 0x20);
  sVar23 = 0;
  iVar10 = *(int *)((longlong)param_1 + 0x354) + 1;
  if (9999 < *(int *)((longlong)param_1 + 0x354)) {
    iVar10 = 0;
  }
  *(int *)((longlong)param_1 + 0x354) = iVar10;
  fVar27 = *(float *)((longlong)param_1 + 0x54);
  if (fVar29 <= fVar27) {
    do {
      fVar27 = fVar27 - fVar29;
    } while (fVar29 <= fVar27);
    *(float *)((longlong)param_1 + 0x54) = fVar27;
  }
  fVar4 = DAT_1402d2db4;
  if (fVar27 <= DAT_1402d2db4) {
    do {
      fVar27 = fVar27 + fVar29;
    } while (fVar27 <= DAT_1402d2db4);
    *(float *)((longlong)param_1 + 0x54) = fVar27;
  }
  fVar6 = DAT_1402d249c;
  fVar27 = *(float *)(param_1 + 0xb);
  if (fVar29 <= fVar27) {
    do {
      fVar27 = fVar27 - DAT_1402d249c;
    } while (fVar29 <= fVar27);
    *(float *)(param_1 + 0xb) = fVar27;
  }
  if (fVar27 <= fVar4) {
    do {
      fVar27 = fVar27 + fVar6;
    } while (fVar27 <= fVar4);
    *(float *)(param_1 + 0xb) = fVar27;
  }
  FUN_1400d5810();
  param_1[0x65] = 0;
  if ((*(byte *)((longlong)param_1 + 0xed) != 0xff) && (*(byte *)((longlong)param_1 + 0xee) != 0xff)
     ) {
    param_1[0x65] =
         (ulonglong)*(byte *)((longlong)param_1 + 0xee) * 0x520 +
         *(longlong *)
          (*(longlong *)(*param_2 + (ulonglong)*(byte *)((longlong)param_1 + 0xed) * 8) + 0x110);
  }
  fVar29 = 0.0;
  if (0.0 < param_4) {
    *(byte *)((longlong)param_1 + 0x3c9) = *(char *)((longlong)param_1 + 0x3c9) + 1U & 3;
  }
  fVar4 = DAT_1402d20b0;
  fVar27 = DAT_1402d1ff8;
  cVar18 = *(char *)((longlong)param_1 + 0x3c9);
  if (cVar18 == '\0') {
LAB_1400b7cf2:
    *(undefined4 *)((longlong)param_1 + 0x364) = 0;
    *(undefined4 *)((longlong)param_1 + 0x35c) = 0x3d4ccccd;
    *(undefined2 *)((longlong)param_1 + 0x3c4) = 0;
    *(undefined4 *)(param_1 + 0x6b) = 0;
  }
  else {
    if (cVar18 == '\x01') {
      param_4 = DAT_1402d2080;
    }
    else if (cVar18 == '\x02') {
      param_4 = DAT_1402d2134;
    }
    else if (cVar18 == '\x03') {
      param_4 = DAT_1402d22d0;
    }
    else if (param_4 <= DAT_1402d1ff8) goto LAB_1400b7cf2;
    if ((*(float *)(param_1 + 0x6b) + DAT_1402d1ff8 <= param_4) ||
       (param_4 <= *(float *)(param_1 + 0x6b) - DAT_1402d1ff8)) {
      *(float *)(param_1 + 0x6b) = param_4;
      fVar7 = DAT_1402d2168;
      fVar28 = DAT_1402d2018;
      fVar6 = DAT_1402d1fa8;
      if (*(char *)((longlong)param_1 + 0x3cb) == '\0') {
        if (param_4 <= DAT_1402d2198) {
          if (DAT_1402d20f0 < param_4) goto LAB_1400b7d47;
          if (param_4 <= fVar27) {
LAB_1400b7e77:
            *(undefined4 *)(param_1 + 0x6c) = 0x3d4ccccd;
            fVar28 = fVar6;
          }
          else {
            *(undefined4 *)((longlong)param_1 + 0x364) = *(undefined4 *)((longlong)param_1 + 0x35c);
            *(char *)((longlong)param_1 + 0x3c4) =
                 (char)(int)((float)*(byte *)(param_1 + 0x78) * fVar4);
            *(undefined4 *)(param_1 + 0x6c) = 0x3e000000;
          }
          goto LAB_1400b7e89;
        }
      }
      else if (param_4 <= DAT_1402d2198) {
        if (DAT_1402d2154 < param_4) {
LAB_1400b7d47:
          *(undefined4 *)(param_1 + 0x6c) = 0x3e800000;
          *(undefined4 *)((longlong)param_1 + 0x364) = *(undefined4 *)((longlong)param_1 + 0x35c);
          *(char *)((longlong)param_1 + 0x3c4) =
               (char)(int)((float)*(byte *)(param_1 + 0x78) * fVar4);
          fVar28 = fVar4;
          goto LAB_1400b7e89;
        }
        if (param_4 <= DAT_1402d20f0) {
          if (param_4 <= fVar27) goto LAB_1400b7e77;
          *(undefined4 *)((longlong)param_1 + 0x364) = *(undefined4 *)((longlong)param_1 + 0x35c);
          *(char *)((longlong)param_1 + 0x3c4) =
               (char)(int)((float)*(byte *)(param_1 + 0x78) * fVar4);
          *(undefined4 *)(param_1 + 0x6c) = 0x3dcccccd;
          fVar28 = fVar27;
          goto LAB_1400b7e89;
        }
      }
      *(undefined4 *)(param_1 + 0x6c) = 0x3f000000;
      *(undefined4 *)((longlong)param_1 + 0x364) = *(undefined4 *)((longlong)param_1 + 0x35c);
      *(char *)((longlong)param_1 + 0x3c4) = (char)(int)((float)*(byte *)(param_1 + 0x78) * fVar4);
      fVar28 = fVar7;
    }
    else {
      *(float *)((longlong)param_1 + 0x35c) = *(float *)(param_1 + 0x6c);
      fVar28 = *(float *)(param_1 + 0x6c);
    }
LAB_1400b7e89:
    if (*(char *)((longlong)param_1 + 0x3c4) != '\0') {
      bVar8 = *(char *)((longlong)param_1 + 0x3c4) - 1;
      *(undefined1 *)((longlong)param_1 + 0x3c5) = 0;
      *(byte *)((longlong)param_1 + 0x3c4) = bVar8;
      *(float *)((longlong)param_1 + 0x35c) =
           (float)(int)((int)((float)*(byte *)(param_1 + 0x78) * fVar4) - (uint)bVar8) *
           ((fVar28 - *(float *)((longlong)param_1 + 0x364)) /
           (float)(int)((float)*(byte *)(param_1 + 0x78) * fVar4)) +
           *(float *)((longlong)param_1 + 0x364);
    }
  }
  if ((*(char *)((longlong)param_1 + 0x3cb) == '\0') || (cVar18 != '\x03')) {
    uVar21 = (undefined7)((ulonglong)((longlong)param_1 + 0x35c) >> 8);
    if (cVar18 == '\0') {
      if ((*(char *)((longlong)param_1 + 0x176) == '\v') ||
         ((byte)(*(char *)((longlong)param_1 + 0x176) - 0xcU) < 2)) {
        lVar15 = *(longlong *)(*param_1 + 0x1468);
        if (lVar15 != 0) {
          *(undefined4 *)(lVar15 + 0x5c) = 0x80;
          lVar12 = lVar15 + 0x84;
          goto LAB_1400b7f65;
        }
      }
      else {
        lVar15 = *(longlong *)(*param_1 + 0x1468);
        if (lVar15 != 0) {
          *(undefined4 *)(lVar15 + 0x5c) = 0x10;
          lVar12 = lVar15 + 0x60;
LAB_1400b7f65:
          *(longlong *)(lVar15 + 0x50) = lVar12;
        }
      }
      if ((((*(byte *)((longlong)param_1 + 0x174) < 3) &&
           (*(char *)((longlong)param_1 + 0x177) == '\0')) &&
          (5 < (byte)((char)param_1[0x2f] - 0xcU))) &&
         ((6 < (byte)((char)param_1[0x2f] - 0x14U) &&
          (*(char *)((longlong)param_1 + 0x176) == '\x1c')))) {
        FUN_1400dfbc0(*param_1,CONCAT71(uVar21,1));
      }
      else {
        *(undefined1 *)(*param_1 + 0x10ca) = 0;
      }
      cVar18 = *(char *)((longlong)param_1 + 0x179);
      lVar15 = *param_1;
      uVar2 = *(undefined4 *)((longlong)param_1 + 0x14c);
      lVar12 = param_1[0x29];
      uVar3 = *(undefined4 *)((longlong)param_1 + 0x144);
      lVar19 = param_1[0x28];
      *(char *)(lVar15 + 0x10c8) = cVar18;
      if (cVar18 != '\0') {
        *(int *)(lVar15 + 0x1404) = (int)lVar19;
        *(undefined4 *)(lVar15 + 0x1408) = uVar3;
        *(int *)(lVar15 + 0x140c) = (int)lVar12;
        *(undefined4 *)(lVar15 + 0x1410) = uVar2;
      }
      cVar18 = *(char *)((longlong)param_1 + 0x177);
      if (cVar18 == '\0') {
        if ((byte)((char)param_1[0x2f] - 0xcU) < 6) {
          cVar18 = '\x04';
        }
        else if ((byte)((char)param_1[0x2f] - 0x14U) < 7) {
          cVar18 = '\x05';
        }
      }
      FUN_1400ad6f0(*param_1,cVar18 == '\x04',(int)param_1[0x2a],
                    *(undefined4 *)((longlong)param_1 + 0x154),CONCAT44(uVar30,(int)param_1[0x2b]),
                    *(undefined4 *)((longlong)param_1 + 0x15c));
      (**(code **)(*(longlong *)*param_1 + 0x70))
                ((longlong *)*param_1,param_2,(longlong)param_1 + 0x44,param_1[0x5f],param_3,
                 (int)param_1[0x26],*(undefined4 *)((longlong)param_1 + 0x134),(int)param_1[0x27],
                 *(undefined4 *)((longlong)param_1 + 0x13c),(char)param_1[0x78]);
    }
    else if ((byte)(cVar18 - 1U) < 3) {
      if ((((*(byte *)((longlong)param_1 + 0x174) < 3) &&
           (*(char *)((longlong)param_1 + 0x177) == '\0')) &&
          (5 < (byte)((char)param_1[0x2f] - 0xcU))) &&
         ((6 < (byte)((char)param_1[0x2f] - 0x14U) &&
          (*(char *)((longlong)param_1 + 0x176) == '\x1c')))) {
        FUN_1400dfbc0(param_1[1],CONCAT71(uVar21,1));
      }
      else {
        *(undefined1 *)(param_1[1] + 0x10ca) = 0;
      }
      cVar18 = *(char *)((longlong)param_1 + 0x179);
      lVar15 = param_1[1];
      uVar2 = *(undefined4 *)((longlong)param_1 + 0x14c);
      lVar12 = param_1[0x29];
      uVar3 = *(undefined4 *)((longlong)param_1 + 0x144);
      lVar19 = param_1[0x28];
      *(char *)(lVar15 + 0x10c8) = cVar18;
      if (cVar18 != '\0') {
        *(int *)(lVar15 + 0x1404) = (int)lVar19;
        *(undefined4 *)(lVar15 + 0x1408) = uVar3;
        *(int *)(lVar15 + 0x140c) = (int)lVar12;
        *(undefined4 *)(lVar15 + 0x1410) = uVar2;
      }
      cVar18 = *(char *)((longlong)param_1 + 0x177);
      if (cVar18 == '\0') {
        if ((byte)((char)param_1[0x2f] - 0xcU) < 6) {
          cVar18 = '\x04';
        }
        else if ((byte)((char)param_1[0x2f] - 0x14U) < 7) {
          cVar18 = '\x05';
        }
      }
      FUN_1400ad6f0(param_1[1],cVar18 == '\x04',(int)param_1[0x2a],
                    *(undefined4 *)((longlong)param_1 + 0x154),CONCAT44(uVar30,(int)param_1[0x2b]),
                    *(undefined4 *)((longlong)param_1 + 0x15c));
      (**(code **)(*(longlong *)param_1[1] + 0x70))
                ((longlong *)param_1[1],param_2,param_1[0x5f],
                 *(undefined4 *)((longlong)param_1 + 0x35c),(int)param_1[0x26],
                 *(undefined4 *)((longlong)param_1 + 0x134),(int)param_1[0x27],
                 *(undefined4 *)((longlong)param_1 + 0x13c));
    }
  }
  else {
    *(undefined4 *)((longlong)param_1 + 0x35c) = 0;
  }
  *(bool *)(param_1[3] + 8) = *(char *)((longlong)param_1 + 0x17a) == '\0';
  FUN_1400d8af0(param_1[2],(longlong)param_1 + 0x44,param_2,param_6);
  lVar15 = param_1[3];
  lVar12 = param_1[0x2c];
  if ((*(char *)(lVar15 + 8) != '\0') &&
     (plVar1 = (longlong *)(*param_2 + (ulonglong)*(byte *)(lVar15 + 0x1d) * 8),
     plVar1 != (longlong *)0x0)) {
    iVar10 = *(int *)(*plVar1 + 0x118);
    lVar19 = (longlong)iVar10;
    *(undefined4 *)(lVar15 + 0x28) = 0;
    if (0 < iVar10) {
      lVar24 = 0;
      do {
        lVar16 = *(longlong *)(*plVar1 + 0x110) + lVar24;
        if (lVar16 != 0) {
          *(int *)(lVar15 + 0x28) = *(int *)(lVar15 + 0x28) + *(int *)(lVar16 + 0x420);
        }
        lVar24 = lVar24 + 0x520;
        lVar19 = lVar19 + -1;
      } while (lVar19 != 0);
    }
    *(int *)(lVar15 + 0x2c) = (int)lVar12;
  }
  fVar27 = DAT_1402d271c;
  if (*(char *)((longlong)param_1 + 0x3cb) == '\0') {
    fVar4 = *(float *)(param_1 + 0x2e);
    lVar15 = param_1[4];
    fVar6 = (fVar4 - (float)(int)fVar4) * DAT_1402d271c;
    *(int *)(lVar15 + 0x28) = (int)fVar4;
    *(int *)(lVar15 + 0x2c) = (int)fVar6;
    if ((((fVar4 != *(float *)(lVar15 + 0x30)) && (*(char *)((longlong)param_1 + 0x177) == '\0')) &&
        (5 < (byte)((char)param_1[0x2f] - 0xcU))) && (6 < (byte)((char)param_1[0x2f] - 0x14U))) {
      *(int *)(lVar15 + 0x34) = *(int *)(lVar15 + 0x34) + 1;
    }
    *(float *)(lVar15 + 0x30) = fVar4;
  }
  lVar15 = param_1[5];
  uVar9 = *(undefined1 *)((longlong)param_1 + 0x3b6);
  lVar12 = param_1[0x6e];
  if (*(char *)(lVar15 + 8) != '\0') {
    *(int *)(lVar15 + 0x13c) = *(int *)(lVar15 + 0x13c) + 1;
    *(int *)(lVar15 + 0x118) = (int)lVar12;
    *(int *)(lVar15 + 0x11c) = (int)(short)param_1[0x1f];
    *(uint *)(lVar15 + 0x120) = (uint)*(byte *)((longlong)param_1 + 0xfa);
    *(uint *)(lVar15 + 0x124) = (uint)*(byte *)((longlong)param_1 + 0xfb);
    *(undefined4 *)(lVar15 + 300) = *(undefined4 *)((longlong)param_1 + 100);
    *(int *)(lVar15 + 0x130) = (int)param_1[0xd];
    *(undefined4 *)(lVar15 + 0x134) = *(undefined4 *)((longlong)param_1 + 0x6c);
    *(int *)(lVar15 + 0x138) = (int)param_1[0xe];
    *(undefined1 *)(lVar15 + 0x141) = uVar9;
    *(undefined1 *)(lVar15 + 0x142) = *(undefined1 *)((longlong)param_1 + 0x103);
    *(bool *)(lVar15 + 0x140) = *(char *)((longlong)param_1 + 0xfc) == '\0';
    lVar12 = *(longlong *)
              (*(longlong *)(*param_2 + (ulonglong)*(byte *)(lVar15 + 0x1d) * 8) + 0x110);
    fVar4 = (fVar27 / (float)*(byte *)(**(longlong **)(lVar12 + 0x1a0) + 0x6e)) *
            (float)(int)*(short *)(lVar12 + 0x428);
    *(float *)(lVar15 + 0x128) = fVar4;
    if (fVar4 < fVar29) {
      *(undefined4 *)(lVar15 + 0x128) = 0;
    }
  }
  lVar15 = param_1[6];
  if (*(char *)(lVar15 + 8) != '\0') {
    bVar8 = *(byte *)((longlong)param_1 + 0x285);
    if ((bVar8 & 1) == 0) {
      if ((bVar8 & 2) == 0) {
        if ((bVar8 & 4) == 0) {
          if ((bVar8 & 8) == 0) {
            uVar9 = 0xff;
            if ((bVar8 & 0x10) != 0) {
              uVar9 = 4;
            }
          }
          else {
            uVar9 = 3;
          }
        }
        else {
          uVar9 = 2;
        }
      }
      else {
        uVar9 = 1;
      }
    }
    else {
      uVar9 = 0;
    }
    *(undefined1 *)(lVar15 + 0x31) = uVar9;
    *(bool *)(lVar15 + 0x30) = (*(byte *)((longlong)param_1 + 0x285) & 0x20) != 0;
  }
  lVar15 = param_1[7];
  if (*(char *)(lVar15 + 8) != '\0') {
    if (*(char *)(lVar15 + 0x1c) == '\0') {
      FUN_1400dc8c0(lVar15,(longlong)param_1 + 0x44,param_2,(char)param_1[0x78]);
    }
    else {
      bVar8 = *(byte *)((longlong)param_1 + 0xed);
      if (bVar8 != 0xff) {
        bVar5 = *(byte *)((longlong)param_1 + 0xee);
        if (bVar5 != 0xff) {
          lVar19 = (ulonglong)bVar5 * 0x520;
          lVar12 = *(longlong *)(*(longlong *)(*param_2 + (ulonglong)bVar8 * 8) + 0x110);
          sVar14 = *(short *)(**(longlong **)(lVar12 + 0x1a0 + lVar19) + 0x82);
          if (sVar14 != -1) {
            pcVar17 = (char *)(((ulonglong)*(byte *)(DAT_140328418 + 0x401) + (longlong)sVar14 * 6)
                               * 0x20 + 0x10 + *(longlong *)(DAT_140328418 + 0x3f0));
            pcVar20 = (char *)(lVar15 + 0x2c);
            do {
              cVar18 = *pcVar17;
              pcVar17 = pcVar17 + 1;
              *pcVar20 = cVar18;
              pcVar20 = pcVar20 + 1;
            } while (cVar18 != '\0');
          }
          *(undefined1 *)(lVar15 + 0x4c) =
               *(undefined1 *)(**(longlong **)(lVar12 + 0x1a0 + lVar19) + 0x81);
          *(undefined2 *)(lVar15 + 0x28) =
               *(undefined2 *)(**(longlong **)(lVar12 + 0x1a0 + lVar19) + 0x5c);
          *(byte *)(lVar15 + 0x4d) = bVar8;
          *(byte *)(lVar15 + 0x4e) = bVar5;
          *(undefined2 *)(lVar15 + 0x2a) = 0;
          *(undefined4 *)(lVar15 + 0x24) = 1;
          *(undefined1 *)(lVar15 + 0xfc) = 1;
          goto LAB_1400b85bb;
        }
      }
      *(undefined1 *)(lVar15 + 0xfc) = 0;
    }
  }
LAB_1400b85bb:
  sVar14 = (short)param_1[0x50];
  if (sVar14 < 1) {
    sVar14 = 0;
    *(byte *)((longlong)param_1 + 0x283) = *(byte *)((longlong)param_1 + 0x283) & 0xf8;
  }
  else if ((*(byte *)((longlong)param_1 + 0x283) & 2) == 0) {
    sVar14 = sVar14 - (ushort)*(byte *)((longlong)param_1 + 0x286);
  }
  else {
    sVar14 = sVar14 + -1;
  }
  *(short *)(param_1 + 0x50) = sVar14;
  *(undefined1 *)(param_1[4] + 8) = 1;
  if (*(int *)((longlong)param_1 + 0x36c) == -1) {
    lVar15 = param_1[0x67];
    if ((lVar15 == 0) || ((*(byte *)(lVar15 + 0x1f0) & 1) == 0)) goto LAB_1400b86b4;
    *(int *)((longlong)param_1 + 0x36c) =
         (int)((float)*(byte *)(param_1 + 0x78) * *(float *)(**(longlong **)(lVar15 + 0x1a0) + 0x48)
              );
    *(undefined1 *)((longlong)param_1 + 0x3c7) = *(undefined1 *)(lVar15 + 0x234);
    *(undefined1 *)(param_1 + 0x79) = *(undefined1 *)(lVar15 + 0x235);
  }
  else if (((*(byte *)(*(longlong *)
                        (*(longlong *)
                          (*param_2 + (ulonglong)*(byte *)((longlong)param_1 + 0x3c7) * 8) + 0x110)
                       + 0x1f0 + (ulonglong)*(byte *)(param_1 + 0x79) * 0x520) & 1) != 0) &&
          (iVar10 = *(int *)((longlong)param_1 + 0x36c) + -1,
          *(int *)((longlong)param_1 + 0x36c) = iVar10, iVar10 < 0)) {
    *(undefined4 *)((longlong)param_1 + 0x36c) = 0;
  }
  *(undefined1 *)(param_1[4] + 8) = 0;
LAB_1400b86b4:
  sVar14 = *(short *)((longlong)param_1 + 0x39c);
  if (sVar14 == -1) {
    bVar25 = (*(uint *)((longlong)param_1 + 0x34c) & 0x10001) != 0;
    sVar26 = 0;
  }
  else {
    fVar29 = ((float)(int)sVar14 / (float)*(byte *)(param_1 + 0x78)) *
             ((float)(int)sVar14 / (float)*(byte *)(param_1 + 0x78));
    iVar10 = FUN_140242630();
    fVar4 = (fVar29 * DAT_1402d2498 + (float)(iVar10 % 6)) - DAT_1402d241c;
    iVar10 = FUN_140242630();
    fVar29 = (fVar29 * fVar27 + (float)(iVar10 % 6)) - DAT_1402d241c;
    uVar11 = FUN_140242630();
    uVar13 = FUN_140242630();
    sVar22 = (short)(int)fVar29;
    sVar26 = (short)(int)fVar4;
    sVar23 = -sVar22;
    if ((uVar13 & 1) != 0) {
      sVar23 = sVar22;
    }
    *(short *)((longlong)param_1 + 0x39c) = *(short *)((longlong)param_1 + 0x39c) + -1;
    if ((uVar11 & 1) != 0) {
      sVar26 = -sVar26;
    }
    bVar25 = (bool)(~((byte)sVar14 >> 2) & 1);
  }
  *(short *)(param_1 + 0x73) = sVar26;
  *(short *)((longlong)param_1 + 0x39a) = sVar23;
  if ((char)param_1[8] == '\0') {
    if (bVar25 == true) {
      (**(code **)(*(longlong *)*param_1 + 0x38))((longlong *)*param_1,param_1 + 0x3f);
      (**(code **)(*(longlong *)param_1[1] + 0x38))((longlong *)param_1[1],param_1 + 0x3f);
      (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],param_1 + 0x3f);
      (**(code **)(*(longlong *)param_1[3] + 0x38))((longlong *)param_1[3],param_1 + 0x3f);
      if (*(char *)((longlong)param_1 + 0x3cb) == '\0') {
        (**(code **)(*(longlong *)param_1[4] + 0x38))((longlong *)param_1[4],param_1 + 0x3f);
      }
      (**(code **)(*(longlong *)param_1[5] + 0x38))((longlong *)param_1[5],param_1 + 0x3f);
      (**(code **)(*(longlong *)param_1[6] + 0x38))((longlong *)param_1[6],param_1 + 0x3f);
      (**(code **)(*(longlong *)param_1[7] + 0x38))((longlong *)param_1[7],param_1 + 0x3f);
      *(undefined1 *)(param_1 + 8) = 1;
      return;
    }
  }
  else if (((char)param_1[8] == '\x01') && (bVar25 == false)) {
    (**(code **)(*(longlong *)*param_1 + 0x38))((longlong *)*param_1,0);
    (**(code **)(*(longlong *)param_1[1] + 0x38))((longlong *)param_1[1],0);
    (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
    (**(code **)(*(longlong *)param_1[3] + 0x38))((longlong *)param_1[3],0);
    (**(code **)(*(longlong *)param_1[4] + 0x38))((longlong *)param_1[4],0);
    (**(code **)(*(longlong *)param_1[5] + 0x38))((longlong *)param_1[5],0);
    (**(code **)(*(longlong *)param_1[6] + 0x38))((longlong *)param_1[6],0);
    (**(code **)(*(longlong *)param_1[7] + 0x38))((longlong *)param_1[7],0);
    *(undefined1 *)(param_1 + 8) = 0;
  }
  return;
}

