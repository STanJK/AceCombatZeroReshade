/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140107320; RVA 0x107320
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140107320(longlong param_1,undefined1 param_2)

{
  float *pfVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined4 uVar4;
  float fVar5;
  float fVar6;
  
  fVar6 = DAT_1402d1ff8;
  auVar2 = *(undefined1 (*) [16])(param_1 + 0x70);
  auVar3 = *(undefined1 (*) [16])(param_1 + 0x80);
  if ((*(byte *)(*(longlong *)
                  (*(longlong *)
                    (**(longlong **)(param_1 + 0x2040) + (ulonglong)*(byte *)(param_1 + 0x20a1) * 8)
                  + 0x110) + 0x1f0 + (ulonglong)*(byte *)(param_1 + 0x20a2) * 0x520) & 1) != 0) {
    fVar5 = (*(float *)(param_1 + 0x1650) - *(float *)(param_1 + 0x1d80)) * DAT_1402d1ff8;
    *(float *)(param_1 + 0x1d84) =
         (*(float *)(param_1 + 0x1654) - *(float *)(param_1 + 0x1d84)) * DAT_1402d1ff8 +
         *(float *)(param_1 + 0x1d84);
    *(float *)(param_1 + 0x1d80) = fVar5 + *(float *)(param_1 + 0x1d80);
    *(float *)(param_1 + 0x1d88) =
         (*(float *)(param_1 + 0x1658) - *(float *)(param_1 + 0x1d88)) * fVar6 +
         *(float *)(param_1 + 0x1d88);
    *(float *)(param_1 + 0x1d8c) =
         (*(float *)(param_1 + 0x165c) - *(float *)(param_1 + 0x1d8c)) * DAT_1402d1fa8 +
         *(float *)(param_1 + 0x1d8c);
    *(int *)(param_1 + 0x1ce0) = auVar2._0_4_;
    uVar4 = vextractps_avx(auVar2,1);
    *(undefined4 *)(param_1 + 0x1ce4) = uVar4;
    uVar4 = vextractps_avx(auVar2,2);
    *(undefined4 *)(param_1 + 0x1ce8) = uVar4;
    uVar4 = vextractps_avx(auVar2,3);
    *(undefined4 *)(param_1 + 0x1cec) = uVar4;
    *(int *)(param_1 + 0x1cf0) = auVar3._0_4_;
    uVar4 = vextractps_avx(auVar3,1);
    *(undefined4 *)(param_1 + 0x1cf4) = uVar4;
    uVar4 = vextractps_avx(auVar3,2);
    *(undefined4 *)(param_1 + 0x1cf8) = uVar4;
    uVar4 = vextractps_avx(auVar3,3);
    *(undefined4 *)(param_1 + 0x1cfc) = uVar4;
    FUN_140111d40(param_1 + 0x1c50,param_2,*(undefined1 *)(param_1 + 0x2097));
  }
  pfVar1 = (float *)(param_1 + 0x1d70);
  if (*(char *)(param_1 + 0x2094) == '\x02') {
    fVar6 = DAT_1402d22d0;
  }
  else {
    fVar6 = *pfVar1 * DAT_1402d1ef4;
  }
  auVar2 = *(undefined1 (*) [16])(param_1 + 0x1d10);
  *(int *)(param_1 + 0x10e0) = auVar2._0_4_;
  uVar4 = vextractps_avx(auVar2,1);
  *(undefined4 *)(param_1 + 0x10e4) = uVar4;
  uVar4 = vextractps_avx(auVar2,2);
  *(undefined4 *)(param_1 + 0x10e8) = uVar4;
  uVar4 = vextractps_avx(auVar2,3);
  *(undefined4 *)(param_1 + 0x10ec) = uVar4;
  auVar2 = *(undefined1 (*) [16])(param_1 + 0x1d20);
  *(int *)(param_1 + 0x10f0) = auVar2._0_4_;
  uVar4 = vextractps_avx(auVar2,1);
  *(undefined4 *)(param_1 + 0x10f4) = uVar4;
  uVar4 = vextractps_avx(auVar2,2);
  *(undefined4 *)(param_1 + 0x10f8) = uVar4;
  uVar4 = vextractps_avx(auVar2,3);
  *(undefined4 *)(param_1 + 0x10fc) = uVar4;
  *(float *)(param_1 + 0x10bc) = fVar6;
  *(float *)(param_1 + 0x10b8) = *pfVar1;
  FUN_1401fbec0();
  auVar2 = *(undefined1 (*) [16])(param_1 + 0x1d00);
  *(int *)(param_1 + 0x12a0) = auVar2._0_4_;
  uVar4 = vextractps_avx(auVar2,1);
  *(undefined4 *)(param_1 + 0x12a4) = uVar4;
  uVar4 = vextractps_avx(auVar2,2);
  *(undefined4 *)(param_1 + 0x12a8) = uVar4;
  uVar4 = vextractps_avx(auVar2,3);
  *(undefined4 *)(param_1 + 0x12ac) = uVar4;
  auVar2 = *(undefined1 (*) [16])(param_1 + 0x1d20);
  *(int *)(param_1 + 0x12b0) = auVar2._0_4_;
  uVar4 = vextractps_avx(auVar2,1);
  *(undefined4 *)(param_1 + 0x12b4) = uVar4;
  uVar4 = vextractps_avx(auVar2,2);
  *(undefined4 *)(param_1 + 0x12b8) = uVar4;
  uVar4 = vextractps_avx(auVar2,3);
  *(undefined4 *)(param_1 + 0x12bc) = uVar4;
  *(float *)(param_1 + 0x127c) = fVar6;
  *(float *)(param_1 + 0x1278) = *pfVar1;
  FUN_1401fbec0();
  return;
}

