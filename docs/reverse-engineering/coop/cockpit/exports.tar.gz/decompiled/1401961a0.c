/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401961a0; RVA 0x1961a0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401961a0(longlong param_1,longlong param_2,int param_3)

{
  uint uVar1;
  longlong lVar2;
  uint uVar3;
  ulonglong uVar4;
  ushort *puVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  int iVar8;
  ulonglong uVar9;
  uint uVar10;
  longlong lVar11;
  ulonglong uVar12;
  uint uVar13;
  int local_res20;
  undefined4 local_58;
  ulonglong local_48;
  
  local_58 = 0x3f800000;
  iVar8 = 0;
  if (0 < param_3) {
    do {
      lVar2 = (longlong)iVar8;
      local_res20 = iVar8 + 1;
      uVar1 = *(uint *)(param_2 + lVar2 * 0x10);
      uVar13 = uVar1 & 0x7fff;
      local_48 = (ulonglong)uVar13;
      uVar3 = *(uint *)(param_2 + 4 + lVar2 * 0x10);
      uVar9 = CONCAT44(*(undefined4 *)(param_2 + 0xc + lVar2 * 0x10),
                       *(undefined4 *)(param_2 + 8 + lVar2 * 0x10));
      uVar10 = uVar3 >> 0x1c;
      if (uVar10 == 0) {
        uVar10 = 0x10;
      }
      iVar8 = local_res20;
      if ((uVar3 & 0xc000000) == 0) {
        if ((uVar3 >> 0xe & 1) != 0) {
          FUN_140193240(param_1,0,uVar3 >> 0xf & 0x7ff);
        }
        if (uVar13 != 0) {
          lVar2 = (longlong)local_res20;
          do {
            lVar11 = lVar2;
            if (uVar10 != 0) {
              uVar6 = (ulonglong)uVar10;
              local_res20 = iVar8 + uVar10;
              uVar12 = 0;
              lVar11 = lVar2 + uVar6;
              puVar5 = (ushort *)(param_2 + 4 + lVar2 * 0x10);
              do {
                uVar4 = uVar9 >> (uVar12 & 0x3f);
                uVar3 = (uint)uVar4 & 0xf;
                if ((uVar4 & 0xf) == 0) {
                  uVar4 = (ulonglong)(*(uint *)(puVar5 + -2) & 0x7ff);
                  uVar13 = 0;
LAB_1401963c6:
                  FUN_140193240(param_1,uVar13,uVar4);
                }
                else {
                  if (uVar3 == 0xe) {
                    uVar4 = CONCAT44(*(undefined4 *)puVar5,*(undefined4 *)(puVar5 + -2));
                    uVar13 = (uint)(byte)puVar5[2];
                    goto LAB_1401963c6;
                  }
                  uVar13 = uVar3;
                  if (uVar3 == 1) {
                    uVar4 = CONCAT71(CONCAT61(CONCAT51(CONCAT41(local_58,(char)puVar5[4]),
                                                       (char)puVar5[2]),(char)*puVar5),
                                     (char)puVar5[-2]);
                    goto LAB_1401963c6;
                  }
                  if (uVar3 == 2) {
                    local_58 = *(undefined4 *)(puVar5 + 2);
                    uVar4 = CONCAT44(*(undefined4 *)puVar5,*(undefined4 *)(puVar5 + -2));
                    goto LAB_1401963c6;
                  }
                  if (uVar3 == 3) {
                    uVar4 = (ulonglong)CONCAT22(*puVar5,puVar5[-2]);
                    goto LAB_1401963c6;
                  }
                  if (uVar3 == 4) {
                    uVar4 = (((ulonglong)(*(uint *)(puVar5 + 4) & 0xff0) * 0x1000000 +
                             (ulonglong)(*(uint *)(puVar5 + 2) & 0xffffff0)) * 0x1000 +
                            (ulonglong)*puVar5) * 0x10000 + (ulonglong)puVar5[-2];
                    uVar13 = (*(uint *)(puVar5 + 4) & 0x8000 | 0x4000) >> 0xc;
                    goto LAB_1401963c6;
                  }
                  if (uVar3 == 5) {
                    uVar4 = CONCAT62(CONCAT42(*(undefined4 *)(puVar5 + 2),*puVar5),puVar5[-2]);
                    uVar13 = 0xd;
                    if ((*(uint *)(puVar5 + 4) & 0x8000) == 0) {
                      uVar13 = uVar3;
                    }
                    goto LAB_1401963c6;
                  }
                }
                puVar5 = puVar5 + 8;
                uVar12 = (ulonglong)((int)uVar12 + 4);
                uVar6 = uVar6 - 1;
              } while (uVar6 != 0);
              iVar8 = local_res20;
            }
            local_48 = local_48 - 1;
            lVar2 = lVar11;
          } while (local_48 != 0);
        }
      }
      else if ((uVar3 & 0xc000000) == 0x4000000) {
        puVar7 = (undefined8 *)((longlong)local_res20 * 0x10 + param_2);
        if (uVar13 != 0) {
          uVar12 = (ulonglong)uVar13;
          do {
            if (uVar10 != 0) {
              uVar6 = 0;
              uVar4 = (ulonglong)uVar10;
              do {
                uVar3 = (uint)(uVar9 >> (uVar6 & 0x3f)) & 0xf;
                if ((uVar3 != 0xe) && (uVar3 != 0xf)) {
                  FUN_140193240(param_1,uVar3,*puVar7);
                }
                puVar7 = puVar7 + 1;
                uVar6 = (ulonglong)((int)uVar6 + 4);
                uVar4 = uVar4 - 1;
              } while (uVar4 != 0);
            }
            uVar12 = uVar12 - 1;
          } while (uVar12 != 0);
        }
        local_res20 = local_res20 + (uVar10 * uVar13 + 1 >> 1);
        iVar8 = local_res20;
      }
      else if ((uVar3 & 0xc000000) == 0x8000000) {
        *(undefined4 *)(param_1 + 0x750) = 2;
      }
      if ((uVar1 & 0x8000) != 0) {
        if (*(int *)(param_1 + 0x708) != 0) {
          FUN_140194840(param_1);
        }
        *(undefined8 *)(param_1 + 0x708) = 0;
        *(undefined1 *)(param_1 + 0x710) = 0;
        if (param_3 == 0x7fffffff) {
          return;
        }
        iVar8 = local_res20;
      }
    } while (iVar8 < param_3);
  }
  return;
}

