/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140202c00; RVA 0x202c00
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140202c00(undefined8 *param_1,undefined8 param_2,float *param_3)

{
  *param_1 = 0x3f800000;
  *(undefined4 *)(param_1 + 2) = 0;
  param_1[4] = 0;
  param_1[6] = 0;
  *(undefined8 *)((longlong)param_1 + 0x14) = 0x3f800000;
  param_1[1] = 0;
  param_1[5] = 0x3f800000;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0x3f800000;
  FUN_140202230(param_1,param_1,param_2);
  *(float *)(param_1 + 6) = *(float *)(param_1 + 6) + *param_3;
  *(float *)((longlong)param_1 + 0x34) = param_3[1] + *(float *)((longlong)param_1 + 0x34);
  *(float *)(param_1 + 7) = param_3[2] + *(float *)(param_1 + 7);
  FUN_14003a2e0(param_1);
  return;
}

