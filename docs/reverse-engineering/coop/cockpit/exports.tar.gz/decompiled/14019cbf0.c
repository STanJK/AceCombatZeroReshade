/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14019cbf0; RVA 0x19cbf0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14019cbf0(int *param_1)

{
  byte *pbVar1;
  longlong lVar2;
  short sVar3;
  int iVar4;
  longlong lVar5;
  
  lVar2 = *(longlong *)(param_1 + 0x20);
  if (*(int *)(lVar2 + 0x720) != 0) {
    FUN_140194840(lVar2 + 0x18);
  }
  *(undefined8 *)(lVar2 + 0x720) = 0;
  *(undefined1 *)(lVar2 + 0x728) = 0;
  lVar2 = *(longlong *)(param_1 + 0x20);
  param_1[0x1e] = 1;
  pbVar1 = (byte *)(lVar2 + 0x12);
  *pbVar1 = *pbVar1 ^ 1;
  *(undefined2 *)(lVar2 + 10) = *(undefined2 *)(lVar2 + 0xc);
  iVar4 = DAT_14033bbf0;
  if (*pbVar1 == 0) {
    sVar3 = 0;
  }
  else {
    sVar3 = *(short *)(lVar2 + 0x10);
  }
  lVar5 = (longlong)DAT_14033bbf0;
  *(short *)(lVar2 + 0xc) = sVar3 + *(short *)(lVar2 + 0xe);
  if (iVar4 != -1) {
    if (*param_1 == 0) {
      *param_1 = 1;
      param_1[0x1e] = 0;
    }
    else {
      if (*(char *)(*(longlong *)(param_1 + 0x20) + 0x750) != '\0') {
        *(undefined1 *)(*(longlong *)(param_1 + 0x20) + 0x750) = 0;
        if (*(longlong *)(param_1 + 0x22) == 0) {
          return;
        }
        if ((((*(longlong *)(param_1 + 0x24) != 0) && (*(longlong *)(param_1 + 0x26) != 0)) &&
            (*(longlong *)(param_1 + 0x28) != 0)) &&
           ((code *)(&PTR__guard_check_icall_14031d7b0)[lVar5 * 9] != (code *)0x0)) {
          (*(code *)(&PTR__guard_check_icall_14031d7b0)[lVar5 * 9])(param_1);
          iVar4 = DAT_14033bbf0;
        }
      }
      if (((*(longlong *)(param_1 + 0x22) != 0) && (*(longlong *)(param_1 + 0x24) != 0)) &&
         ((*(longlong *)(param_1 + 0x26) != 0 &&
          ((*(longlong *)(param_1 + 0x28) != 0 &&
           ((code *)(&PTR_FUN_14031d7b8)[(longlong)iVar4 * 9] != (code *)0x0)))))) {
        (*(code *)(&PTR_FUN_14031d7b8)[(longlong)iVar4 * 9])(param_1);
        param_1[0x1e] = 0;
        return;
      }
    }
  }
  return;
}

