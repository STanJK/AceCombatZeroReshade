0x1400adc80  MOV qword ptr [RSP + 0x8],RBX
0x1400adc85  PUSH RDI
0x1400adc86  SUB RSP,0x20
0x1400adc8a  XOR EDI,EDI
0x1400adc8c  LEA RAX,[RCX + 0x1b0]
0x1400adc93  MOV qword ptr [RCX + 0x44],RDI
0x1400adc97  MOV RBX,RCX
0x1400adc9a  MOV qword ptr [RCX + 0x4c],RDI
0x1400adc9e  MOV qword ptr [RCX + 0x54],RDI
0x1400adca2  MOV qword ptr [RCX + 0x5c],RDI
0x1400adca6  MOV qword ptr [RCX + 0x74],RDI
0x1400adcaa  MOV qword ptr [RCX + 0x7c],RDI
0x1400adcae  MOV qword ptr [RCX + 0x84],RDI
0x1400adcb5  MOV qword ptr [RCX + 0x8c],RDI
0x1400adcbc  MOV qword ptr [RCX + 0x94],RDI
0x1400adcc3  MOV qword ptr [RCX + 0x9c],RDI
0x1400adcca  MOV qword ptr [RCX + 0xa4],RDI
0x1400adcd1  MOV dword ptr [RCX + 0xf8],EDI
0x1400adcd7  MOV word ptr [RCX + 0xfc],DI
0x1400adcde  MOV byte ptr [RCX + 0xfe],DIL
0x1400adce5  MOV byte ptr [RCX + 0xec],DIL
0x1400adcec  MOV qword ptr [RCX + 0x180],RDI
0x1400adcf3  MOV qword ptr [RCX + 0x188],RDI
0x1400adcfa  MOV qword ptr [RCX + 0x190],RDI
0x1400add01  MOV qword ptr [RCX + 0x198],RDI
0x1400add08  MOV ECX,0x2b
0x1400add0d  MOV dword ptr [RAX],EDI
0x1400add0f  LEA RAX,[RAX + 0x4]
0x1400add13  SUB RCX,0x1
0x1400add17  JNZ 0x1400add0d
0x1400add19  MOV qword ptr [RBX + 0x260],RDI
0x1400add20  MOV qword ptr [RBX + 0x268],RDI
0x1400add27  MOV dword ptr [RBX + 0x270],EDI
0x1400add2d  MOV dword ptr [RBX + 0x280],EDI
0x1400add33  MOV dword ptr [RBX + 0x284],0x3c
0x1400add3d  MOV qword ptr [RBX + 0x388],RDI
0x1400add44  MOV qword ptr [RBX + 0x390],RDI
0x1400add4b  MOV qword ptr [RBX],RDI
0x1400add4e  MOV qword ptr [RBX + 0x8],RDI
0x1400add52  MOV qword ptr [RBX + 0x10],RDI
0x1400add56  MOV qword ptr [RBX + 0x18],RDI
0x1400add5a  MOV qword ptr [RBX + 0x20],RDI
0x1400add5e  MOV qword ptr [RBX + 0x28],RDI
0x1400add62  MOV qword ptr [RBX + 0x30],RDI
0x1400add66  MOV qword ptr [RBX + 0x38],RDI
0x1400add6a  MOV qword ptr [RBX + 0x2e0],RDI
0x1400add71  MOV word ptr [RBX + 0x3b2],DI
0x1400add78  MOV byte ptr [RBX + 0x3b4],DIL
0x1400add7f  MOV word ptr [RBX + 0x3b6],DI
0x1400add86  MOV byte ptr [RBX + 0x40],0x1
0x1400add8a  MOV qword ptr [RBX + 0x2f0],RDI
0x1400add91  MOV dword ptr [RBX + 0x3ba],0x7040909
0x1400add9b  MOV dword ptr [RBX + 0x39e],0x80008
0x1400adda5  MOV qword ptr [RBX + 0x314],RDI
0x1400addac  MOV dword ptr [RBX + 0x310],EDI
0x1400addb2  MOV qword ptr [RBX + 0x31c],RDI
0x1400addb9  MOV byte ptr [RBX + 0x3be],0xff
0x1400addc0  MOV dword ptr [RBX + 0x370],0x15
0x1400addca  MOV qword ptr [RBX + 0x2e8],RDI
0x1400addd1  MOV qword ptr [RBX + 0x2f8],RDI
0x1400addd8  CALL 0x140189320
0x1400adddd  MOVZX ECX,byte ptr [RAX + 0xc]
0x1400adde1  MOV RAX,RBX
0x1400adde4  MOV byte ptr [RBX + 0x175],DIL
0x1400addeb  MOV dword ptr [RBX + 0x130],0xc8800000
0x1400addf5  MOV dword ptr [RBX + 0x134],0xc8800000
0x1400addff  MOV dword ptr [RBX + 0x138],0x48800000
0x1400ade09  MOV dword ptr [RBX + 0x13c],0x48800000
0x1400ade13  MOV dword ptr [RBX + 0x170],EDI
0x1400ade19  MOV qword ptr [RBX + 0x394],RDI
0x1400ade20  MOV dword ptr [RBX + 0x390],EDI
0x1400ade26  MOV byte ptr [RBX + 0x3c0],CL
0x1400ade2c  MOV word ptr [RBX + 0x3b8],DI
0x1400ade33  MOV word ptr [RBX + 0x3ca],DI
0x1400ade3a  MOV dword ptr [RBX + 0x37c],EDI
0x1400ade40  MOV dword ptr [RBX + 0x348],0xfffffff
0x1400ade4a  MOV word ptr [RBX + 0x39c],0xffff
0x1400ade53  MOV byte ptr [RBX + 0x3c3],0x1
0x1400ade5a  MOV qword ptr [RBX + 0x308],RDI
0x1400ade61  MOV RBX,qword ptr [RSP + 0x30]
0x1400ade66  ADD RSP,0x20
0x1400ade6a  POP RDI
0x1400ade6b  RET
