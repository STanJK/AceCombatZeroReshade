/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400ad600; RVA 0xad600
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400ad600(longlong param_1,longlong param_2,float param_3,float param_4,float param_5,
                  float param_6,float param_7,float param_8,float param_9,float param_10)

{
  float fVar1;
  float fVar2;
  
  fVar2 = DAT_1402d2544;
  *(int *)(param_1 + 0x14) = (int)(param_3 * DAT_1402d2544 + DAT_1402d2b1c);
  *(int *)(param_1 + 0x18) = (int)(param_4 * fVar2 + DAT_1402d2b2c);
  *(short *)(param_1 + 0x10) = (short)(int)(fVar2 * param_5);
  *(short *)(param_1 + 0x12) = (short)(int)(fVar2 * param_6);
  fVar1 = param_4 * fVar2 + fVar2 * param_8 + DAT_1402d2b2c;
  *(int *)(param_2 + 0x14) = (int)(param_3 * fVar2 + fVar2 * param_7 + DAT_1402d2b1c);
  *(int *)(param_2 + 0x18) = (int)fVar1;
  *(short *)(param_2 + 0x10) = (short)(int)(fVar2 * param_9);
  param_9 = param_9 * DAT_1402d2e08;
  *(short *)(param_2 + 0x12) = (short)(int)(fVar2 * param_10);
  param_10 = param_10 * DAT_1402d2e08;
  *(short *)(param_2 + 0x10) = *(short *)(param_1 + 0x10) - (short)(int)param_9;
  *(short *)(param_2 + 0x12) = *(short *)(param_1 + 0x12) - (short)(int)param_10;
  return;
}

