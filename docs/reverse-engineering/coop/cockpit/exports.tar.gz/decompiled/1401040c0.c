/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401040c0; RVA 0x1040c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1401040c0(ulonglong param_1,uchar param_2,longlong param_3)

{
  byte *pbVar1;
  char *pcVar2;
  undefined1 *puVar3;
  char cVar4;
  byte bVar5;
  ushort uVar6;
  short *psVar7;
  longlong *plVar8;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  bool bVar11;
  bool bVar12;
  bool bVar13;
  uchar uVar14;
  uchar uVar15;
  uchar uVar16;
  uchar uVar17;
  undefined1 uVar18;
  char cVar19;
  byte bVar20;
  char cVar21;
  short sVar22;
  undefined2 uVar23;
  ushort uVar24;
  uint uVar25;
  undefined4 uVar26;
  undefined8 uVar27;
  byte bVar28;
  byte bVar29;
  undefined4 uVar30;
  longlong lVar31;
  ulonglong uVar32;
  ulonglong uVar33;
  int iVar34;
  char cVar35;
  undefined2 uVar36;
  ushort *puVar37;
  undefined2 uVar38;
  undefined7 uVar39;
  longlong lVar40;
  longlong lVar41;
  float fVar42;
  float fVar43;
  float fVar44;
  undefined8 extraout_XMM0_Qa;
  undefined8 uVar45;
  undefined8 extraout_XMM0_Qa_00;
  float fVar46;
  undefined1 auVar47 [16];
  float fVar48;
  undefined1 auVar49 [64];
  float fVar50;
  undefined8 uVar51;
  float fVar52;
  float fVar53;
  undefined1 auVar54 [64];
  undefined1 auVar55 [16];
  undefined1 auVar56 [64];
  undefined1 *local_res8;
  uchar local_res10;
  longlong local_res18;
  char local_res20 [8];
  undefined8 *in_stack_fffffffffffffe08;
  ulonglong in_stack_fffffffffffffe10;
  undefined8 *puVar57;
  undefined1 **ppuVar58;
  ulonglong in_stack_fffffffffffffe18;
  undefined7 uVar59;
  undefined8 local_1c8;
  undefined8 uStack_1c0;
  float local_1b8 [4];
  undefined8 local_1a8;
  undefined8 uStack_1a0;
  undefined4 local_198;
  undefined2 local_188 [2];
  float local_184;
  undefined1 local_178 [8];
  float fStack_170;
  float fStack_16c;
  undefined1 auStack_168 [8];
  float fStack_160;
  float fStack_15c;
  undefined1 local_158 [8];
  float fStack_150;
  float fStack_14c;
  undefined1 local_148 [8];
  float fStack_140;
  float fStack_13c;
  float local_138;
  undefined4 local_134;
  undefined4 local_130;
  undefined8 local_128;
  undefined8 uStack_120;
  float local_118;
  undefined4 local_114;
  undefined1 local_110 [16];
  uint local_100;
  float local_fc;
  undefined1 local_f8 [11] [16];
  
  local_110 = ZEXT816(0);
  local_f8[0] = ZEXT816(0);
  local_res10 = param_2;
  local_res18 = param_3;
  FUN_1401c56d0();
  lVar41 = *(longlong *)
            (*(longlong *)
              (**(longlong **)(param_1 + 0x2040) + (ulonglong)*(byte *)(param_1 + 0x20a1) * 8) +
            0x110) + (ulonglong)*(byte *)(param_1 + 0x20a2) * 0x520;
  *(undefined1 *)(param_1 + 0x1c2b) = 1;
  if ((*(byte *)(lVar41 + 0x1f0) & 2) == 0) {
    FUN_14010e220(param_1,0);
    *(undefined1 *)(param_1 + 0x1c2b) = 0;
  }
  uVar51 = _UNK_1402d35f8;
  uVar27 = _DAT_1402d35f0;
  fVar52 = DAT_1402d1ff8;
  uVar25 = *(uint *)(lVar41 + 0x1f0);
  uVar32 = (ulonglong)uVar25;
  auVar54 = ZEXT464(DAT_1402d22d0);
  local_100 = DAT_1402d22d0;
  auVar56 = ZEXT864(0);
  if ((uVar25 & 1) == 0) {
    fVar52 = DAT_1402d2168;
    if (((*(char *)(param_1 + 0x20a3) == '\"') &&
        (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\x14')) && ((uVar25 & 2) == 0)) {
      FUN_1400a94d0(*(longlong *)(param_1 + 0x1fc8) + 0x1d628,*(undefined1 *)(param_1 + 0x20a1),
                    *(undefined1 *)(param_1 + 0x20a2));
    }
LAB_140105f59:
    uVar26 = (undefined4)(in_stack_fffffffffffffe10 >> 0x20);
  }
  else {
    local_fc = DAT_1402d1ff8;
    if ((*(uint *)(param_1 + 0x2058) & 2) == 0) {
      cVar21 = *(char *)(param_1 + 0x2094);
      *(char *)(param_1 + 0x20a5) = cVar21;
      cVar35 = cVar21;
      if ((((*(uint *)(param_1 + 0x2058) >> 0xd & 1) == 0) &&
          (uVar14 = FUN_140187c80(uVar32,param_2,'\"'), uVar14 != '\0')) &&
         (*(char *)(*(longlong *)(param_1 + 0x2040) + 0x37) == '\x01')) {
        if (cVar21 == '\0') {
          *(undefined1 *)(param_1 + 0x2094) = 2;
          cVar35 = '\x02';
        }
        else if (cVar21 == '\x02') {
          *(undefined1 *)(param_1 + 0x2094) = 1;
          cVar35 = '\x01';
        }
        else if (cVar21 == '\x01') {
          *(undefined1 *)(param_1 + 0x2094) = 0;
          cVar35 = '\0';
        }
      }
      cVar4 = *(char *)(param_1 + 0x2096);
      if (cVar4 != -1) {
        *(char *)(param_1 + 0x2094) = cVar4;
        *(undefined1 *)(param_1 + 0x2096) = 0xff;
        cVar35 = cVar4;
      }
      if (cVar35 != cVar21) {
        *(char *)(param_1 + 0x1da6) = cVar35;
        if (cVar35 == '\x01') {
          uVar26 = *(undefined4 *)(param_1 + 0x1d68);
        }
        else if (cVar35 == '\x02') {
          uVar26 = *(undefined4 *)(param_1 + 0x1d6c);
        }
        else {
          uVar26 = *(undefined4 *)(param_1 + 0x1d64);
        }
        *(undefined4 *)(param_1 + 0x1d70) = uVar26;
        *(undefined4 *)(param_1 + 0x1d74) = uVar26;
        *(undefined8 *)(param_1 + 0x1d40) = 0;
        *(undefined8 *)(param_1 + 0x1d48) = 0;
        FUN_1401c6590();
      }
      uVar14 = local_res10;
      *(undefined1 *)(param_1 + 0x20bb) = 0;
      if ((*(uint *)(param_1 + 0x2058) & 0x1000) == 0) {
        uVar18 = *(undefined1 *)(*(longlong *)(param_1 + 0x2040) + 0x69);
        uVar15 = FUN_140187c80(uVar32,local_res10,'\x04');
        uVar16 = FUN_140187c80(uVar32,uVar14,'\x06');
        uVar14 = FUN_140187c80(uVar32,uVar14,'\n');
        uVar17 = FUN_140187c80(uVar32,local_res10,'\b');
        in_stack_fffffffffffffe10 =
             CONCAT71((int7)(in_stack_fffffffffffffe10 >> 8),uVar18) & 0xffffffffffffff01;
        in_stack_fffffffffffffe08 =
             (undefined8 *)CONCAT71((int7)((ulonglong)in_stack_fffffffffffffe08 >> 8),uVar15);
        uVar32 = param_1 + 0x1ac8;
        cVar21 = FUN_1400bbc50(uVar32,uVar17,uVar14,uVar16,in_stack_fffffffffffffe08,
                               in_stack_fffffffffffffe10);
        *(char *)(param_1 + 0x20bb) = cVar21;
        if (cVar21 != '\0') {
          lVar31 = *(longlong *)(param_1 + 0x2040);
          uVar32 = param_1 + 0x1ac8;
          uVar18 = FUN_1400bbe00();
          *(byte *)(lVar31 + 0x69) = *(byte *)(lVar31 + 0x69) | 8;
          *(undefined1 *)(lVar31 + 0x68) = uVar18;
          if ((*(byte *)(param_1 + 0x1aed) & 0x20) == 0) {
            pbVar1 = (byte *)(*(longlong *)(param_1 + 0x2040) + 0x69);
            *pbVar1 = *pbVar1 & 0xfe;
          }
          else {
            pbVar1 = (byte *)(*(longlong *)(param_1 + 0x2040) + 0x69);
            *pbVar1 = *pbVar1 | 1;
          }
        }
        param_2 = local_res10;
        fVar44 = FUN_140187ec0(uVar32,local_res10,'\x16');
        fVar42 = FUN_140187ec0(uVar32,param_2,'\x13');
        fVar43 = FUN_140187ec0(uVar32,param_2,'\x14');
        fVar43 = (float)((uint)(fVar43 - fVar42) & _DAT_1402d3760);
        fVar42 = FUN_140187ec0(uVar32,param_2,'\x15');
        *(char *)(param_1 + 0x1aee) =
             (char)(int)((fVar43 + (float)((uint)(fVar42 - fVar44) & _DAT_1402d3760)) *
                         (float)*(byte *)(param_1 + 0x1aec) * fVar52 + auVar54._0_4_);
      }
      else {
        *(byte *)(param_1 + 0x1aeb) = *(byte *)(param_1 + 0x1aeb) & 0xf8;
        *(undefined2 *)(param_1 + 0x1ae8) = 0;
      }
      FUN_14010f600(param_1 + 0x1430,param_2,*(undefined1 *)(param_1 + 0x20a1),
                    *(undefined1 *)(param_1 + 0x20a2));
      local_114 = *(undefined4 *)(param_1 + 0x1804);
      local_138 = *(float *)(param_1 + 0x180c);
      local_134 = *(undefined4 *)(param_1 + 0x1810);
      local_130 = *(undefined4 *)(param_1 + 0x1814);
      fVar42 = *(float *)*(undefined1 (*) [16])(param_1 + 0x17f8);
      fVar43 = *(float *)(param_1 + 0x17fc);
      fVar53 = *(float *)(param_1 + 0x1800);
      local_110 = *(undefined1 (*) [16])(param_1 + 0x17f8);
      fVar44 = *(float *)*(undefined1 (*) [16])(param_1 + 0x1808);
      local_f8[0] = *(undefined1 (*) [16])(param_1 + 0x1808);
      *(undefined4 *)(param_1 + 0x7c) = local_114;
      *(float *)(param_1 + 0x84) = local_138;
      *(undefined4 *)(param_1 + 0x88) = local_134;
      *(undefined4 *)(param_1 + 0x8c) = local_130;
      *(float *)(param_1 + 0x70) = fVar42;
      *(float *)(param_1 + 0x74) = fVar43;
      *(float *)(param_1 + 0x78) = fVar53;
      *(float *)(param_1 + 0x80) = fVar44;
      local_res8 = (undefined1 *)CONCAT44(local_res8._4_4_,fVar44);
      *(undefined1 *)(param_1 + 0x20bc) = 0;
      local_1b8[0] = fVar43;
      local_184 = fVar53;
      local_118 = fVar42;
      if (*(char *)(param_1 + 0x2097) == '\0') {
        fVar52 = DAT_1402d2478;
        if ((*(byte *)(param_1 + 0x2058) & 0x20) == 0) {
          pcVar2 = (char *)(param_1 + 0xc3b);
          uVar25 = *(uint *)(param_1 + 0xd48) & 0x10000;
          if (uVar25 == 0) {
            cVar21 = '\x02';
          }
          else {
            cVar21 = *pcVar2;
          }
          uVar32 = DAT_14032c8f0;
          uVar14 = FUN_140187a40(DAT_14032c8f0,param_2,'\r');
          if (uVar14 == '\0') {
            if (((byte)(cVar21 - 1U) < 2) && (uVar25 != 0)) {
              *pcVar2 = '\x03';
            }
LAB_140104a86:
            FUN_1401c6490();
          }
          else if (*(short *)(param_1 + 0x208e) == 0) {
            if (((byte)(cVar21 - 1U) < 2) && (uVar25 != 0)) {
              *pcVar2 = '\x03';
            }
            *(undefined1 *)(param_1 + 0x20bc) = 5;
            FUN_1401c6490();
            uVar14 = FUN_140187c80(uVar32,param_2,'\r');
            if (uVar14 != '\0') {
              local_res20[0] = '\x01';
              local_res20[1] = '\0';
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,5);
              FUN_1401c6150();
            }
          }
          else {
            if (((cVar21 == '\x03') || (cVar21 == '\0')) && (uVar25 != 0)) {
              *pcVar2 = '\x01';
            }
            if (cVar21 == '\x02') {
              *(ushort *)(param_1 + 0xae4) = *(ushort *)(param_1 + 0xae4) | 2;
              if (*(short *)(param_1 + 0x1ef8) == 0) {
                _local_178 = ZEXT816(0);
                auVar54 = ZEXT464((uint)(((*(float *)(param_1 + 0x1848) * DAT_1402d20dc) /
                                         (float)*(byte *)(param_1 + 0x20a0)) * fVar52));
                _auStack_168 = ZEXT816(0);
                _local_158 = _local_178;
                _local_148 = _auStack_168;
                FUN_140202920(local_178,local_f8);
                uVar25 = DAT_1437d9a50;
                fVar42 = fVar42 + (float)local_148._0_4_;
                fVar44 = (float)local_148._4_4_ + local_1b8[0];
                fVar43 = local_184 + fStack_140;
                fVar53 = 0.0;
                fVar50 = 0.0;
                fVar48 = 0.0;
                fVar46 = 0.0;
                if (0x40 < *(ushort *)(param_1 + 0x1b8)) {
                  if (0x40 < *(ushort *)(param_1 + 0x1bc)) {
                    if (**(int **)(param_1 + 0x1d0) == 1) {
                      FUN_14015e650(param_1 + 0x120,&local_1c8,0x40,0);
                    }
                    else {
                      if (**(int **)(param_1 + 0x1d0) != 2) goto LAB_14010478c;
                      FUN_14015e650(param_1 + 0x120,&local_1c8,0x40,DAT_1437d9a50 & 1);
                      DAT_1437d9a50 = uVar25 + 1;
                    }
                    fVar53 = (float)local_1c8;
                    fVar50 = local_1c8._4_4_;
                    fVar48 = (float)uStack_1c0;
                    fVar46 = uStack_1c0._4_4_;
                  }
                }
LAB_14010478c:
                uVar26 = auVar56._0_4_;
                local_1c8 = CONCAT44(uVar26,**(float **)(param_1 + 0xfe0) * DAT_1402d1f38);
                uStack_1c0 = CONCAT44(uVar26,uVar26);
                FUN_140203050(&local_1c8,local_f8,&local_1c8);
                local_1a8 = local_1c8;
                in_stack_fffffffffffffe18 = *(ulonglong *)(param_1 + 0x1fb0);
                auVar47 = vshufps_avx(_local_178,_local_178,0x55);
                auVar55 = vshufps_avx(_local_158,_local_158,0x55);
                local_1c8 = CONCAT44(fVar44 * fVar46 +
                                     auVar55._0_4_ * fVar48 +
                                     auVar47._0_4_ * fVar53 + fVar50 * (float)auStack_168._4_4_,
                                     fVar42 * fVar46 +
                                     local_158._0_4_ * fVar48 +
                                     local_178._0_4_ * fVar53 + fVar50 * (float)auStack_168._0_4_);
                auVar47 = vshufps_avx(_local_158,_local_158,0xaa);
                auVar55 = vshufps_avx(_local_158,_local_158,0xff);
                uStack_1a0 = uStack_1c0;
                auVar9 = vshufps_avx(_local_178,_local_178,0xaa);
                auVar10 = vshufps_avx(_local_178,_local_178,0xff);
                uStack_1c0 = CONCAT44(fVar46 * fStack_13c + fVar48 * auVar55._0_4_ +
                                      fVar50 * fStack_15c + auVar10._0_4_ * fVar53,
                                      fVar43 * fVar46 +
                                      auVar47._0_4_ * fVar48 +
                                      fVar53 * auVar9._0_4_ + fVar50 * fStack_160);
                in_stack_fffffffffffffe08 =
                     (undefined8 *)
                     CONCAT71((int7)((ulonglong)in_stack_fffffffffffffe08 >> 8),
                              *(undefined1 *)(param_1 + 0x20a1));
                FUN_14013ace0(local_res18 + 0xca0,&local_1c8,&local_1a8,auVar54._0_8_,
                              in_stack_fffffffffffffe08,*(undefined1 *)(param_1 + 0x20a2),
                              in_stack_fffffffffffffe18,
                              *(byte *)(*(longlong *)(param_1 + 0xff8) + 0xc) >> 7);
                FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),0xd,0);
                *(byte *)(param_1 + 0x1f00) = *(byte *)(param_1 + 0x1f00) | 1;
                sVar22 = *(short *)(param_1 + 0x208e);
                if (sVar22 != 10000) {
                  sVar22 = sVar22 + -1;
                  *(short *)(param_1 + 0x208e) = sVar22;
                }
                uVar51 = _UNK_1402d35f8;
                uVar27 = _DAT_1402d35f0;
                fVar44 = local_res8._0_4_;
                fVar53 = local_184;
                fVar43 = local_1b8[0];
                if (sVar22 == 0) {
                  *(undefined1 *)(param_1 + 0x20bc) = 5;
                }
              }
              uVar32 = param_1 + 0x205c;
              cVar21 = FUN_1401c5910();
              if (cVar21 == '\0') {
                local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,3);
                if (*(longlong *)(param_1 + 0x1fa8) != 0) {
                  local_res8 = (undefined1 *)
                               CONCAT62(local_res8._2_6_,
                                        (ushort)*(byte *)(*(longlong *)(param_1 + 0x1fa8) + 0x40));
                }
                local_1a8 = uVar27;
                uStack_1a0 = uVar51;
                local_128 = uVar27;
                uStack_120 = uVar51;
                if (*(char *)(param_1 + 0x2094) == '\x01') {
                  local_res20[0] = '\x02';
                  local_res20[1] = '\0';
                  in_stack_fffffffffffffe08 = &local_128;
                  FUN_1401c5c30(extraout_XMM0_Qa,&local_res8,local_res20,local_110,
                                in_stack_fffffffffffffe08,&local_1a8,uVar32);
                  in_stack_fffffffffffffe18 = uVar32;
                }
                else {
                  in_stack_fffffffffffffe08 = &local_128;
                  if (*(char *)(param_1 + 0x2094) == '\0') {
                    local_res20[0] = '\0';
                    local_res20[1] = '\0';
                    FUN_1401c5c30(0,&local_res8,local_res20,local_110,in_stack_fffffffffffffe08,
                                  &local_1a8,uVar32);
                    in_stack_fffffffffffffe18 = uVar32;
                  }
                  else {
                    local_res20[0] = '\x01';
                    local_res20[1] = '\0';
                    FUN_1401c5c30(extraout_XMM0_Qa,&local_res8,local_res20,local_110,
                                  in_stack_fffffffffffffe08,&local_1a8,uVar32);
                    in_stack_fffffffffffffe18 = uVar32;
                  }
                }
              }
              else {
                if (*(char *)(param_1 + 0x2094) != *(char *)(param_1 + 0x20a5)) goto LAB_140104a86;
                FUN_1401c6260(extraout_XMM0_Qa,uVar32,local_110);
              }
            }
          }
        }
        uVar32 = param_1 + 0x1ef0;
        FUN_140102540();
        if (((*(byte *)(param_1 + 0x2058) & 0x20) == 0) &&
           (uVar14 = FUN_140187c80(uVar32,param_2,'\x02'), uVar14 != '\0')) {
          *(byte *)(param_1 + 0x1eee) = *(byte *)(param_1 + 0x1eee) & 0xbf;
          if (*(char *)(param_1 + 0x2098) == '\0') {
            if (*(char *)(param_1 + 0x209a) == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,5);
              local_res20[0] = '\x01';
              local_res20[1] = '\0';
              FUN_1401c6150();
              *(undefined1 *)(param_1 + 0x20bc) = 4;
            }
            else {
              *(undefined1 *)(param_1 + 0x2098) = 1;
              uVar27 = FUN_1400c1030(param_1 + 0x1e38);
              *(undefined2 *)(param_1 + 0x1eec) = 0xffff;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,6);
              local_res20[0] = '\x01';
              local_res20[1] = '\0';
              FUN_1401c6150(uVar27,local_res20,&local_res8);
              *(undefined1 *)(param_1 + 0x20bc) = 2;
              bVar20 = *(byte *)(*(longlong *)(param_1 + 0xfd8) + 0xf);
              fVar52 = fVar52 * *(float *)(*(longlong *)(param_1 + 0x1fb8) + 0x10) *
                       *(float *)(*(longlong *)(param_1 + 0xfd8) + 8);
              bVar29 = *(byte *)(param_1 + 0x209a);
              if (bVar20 <= *(byte *)(param_1 + 0x209a)) {
                bVar29 = bVar20;
              }
              FUN_1400c04e0(param_1 + 0x1e38,bVar29);
              *(float *)(param_1 + 0x1ec4) = fVar52;
              *(float *)(param_1 + 0x1e44) = fVar52;
              *(float *)(param_1 + 0x1e64) = fVar52;
              *(float *)(param_1 + 0x1e84) = fVar52;
              *(float *)(param_1 + 0x1ea4) = fVar52;
              FUN_1400c2630(param_1 + 0x1e38,*(byte *)(*(longlong *)(param_1 + 0xfd8) + 0xc) & 1);
              FUN_1400c2680(param_1 + 0x1e38,
                            *(byte *)(*(longlong *)(param_1 + 0xfd8) + 0xc) >> 1 & 1);
            }
          }
          else {
            if ((*(char *)(param_1 + 0x20a3) == '\"') &&
               (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\x14')) {
              FUN_1400a94d0(*(longlong *)(param_1 + 0x1fc8) + 0x1d628,
                            *(undefined1 *)(param_1 + 0x20a1),*(undefined1 *)(param_1 + 0x20a2));
            }
            *(undefined1 *)(param_1 + 0x2098) = 0;
            local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,7);
            local_res20[0] = '\x01';
            local_res20[1] = '\0';
            FUN_1401c6150();
            cVar21 = *(char *)(param_1 + 0x2099);
            *(undefined1 *)(param_1 + 0x20bc) = 1;
            FUN_1400c1030(param_1 + 0x1e38);
            *(undefined2 *)(param_1 + 0x1eec) = 0xffff;
            uVar27 = FUN_1400c04e0(param_1 + 0x1e38,cVar21 != '\0');
            fVar52 = fVar52 * *(float *)(*(longlong *)(param_1 + 0x1fb8) + 0x10);
            *(float *)(param_1 + 0x1ec4) = fVar52;
            *(float *)(param_1 + 0x1e44) = fVar52;
            *(float *)(param_1 + 0x1e64) = fVar52;
            *(float *)(param_1 + 0x1e84) = fVar52;
            *(float *)(param_1 + 0x1ea4) = fVar52;
            *(byte *)(param_1 + 0x1eee) = *(byte *)(param_1 + 0x1eee) & 0xf3;
            *(byte *)(param_1 + 0x1ecd) = *(byte *)(param_1 + 0x1ecd) & 0xfc;
            if (*(char *)(param_1 + 0x2099) == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,5);
              local_res20[0] = '\x01';
              local_res20[1] = '\0';
              FUN_1401c6150(uVar27,local_res20,&local_res8);
              *(undefined1 *)(param_1 + 0x20bc) = 3;
            }
          }
        }
        lVar31 = *(longlong *)(param_1 + 0x1fd0);
        if (lVar31 != 0) {
          bVar20 = *(byte *)(lVar31 + 0x2a6);
          uVar14 = FUN_140187a40(DAT_14032c8f0,param_2,'\f');
          if (uVar14 == '\0') {
            if (bVar20 != 0) {
              bVar20 = bVar20 | 0x40;
              *(int *)(lVar31 + 0x2b0) =
                   (int)(longlong)((float)*(byte *)(lVar31 + 0x2ae) * DAT_1402d2168);
LAB_140104d9b:
              *(byte *)(lVar31 + 0x2a6) = bVar20;
            }
          }
          else if ((bVar20 & 0x40) != 0) {
            iVar34 = *(int *)(lVar31 + 0x2b0);
            if (iVar34 != 0) {
              iVar34 = iVar34 + -1;
              *(int *)(lVar31 + 0x2b0) = iVar34;
            }
            if ((bVar20 != 0) && (iVar34 == 0)) {
              bVar20 = bVar20 & 0xbf;
              goto LAB_140104d9b;
            }
          }
        }
        cVar21 = *(char *)(param_1 + 0x2098);
        FUN_1401031b0(param_1);
        lVar31 = param_1 + 0x1f38;
        lVar40 = 4;
        do {
          FUN_140102540(lVar31);
          lVar31 = lVar31 + 0x18;
          lVar40 = lVar40 + -1;
        } while (lVar40 != 0);
        FUN_1401024c0(param_1 + 0x1f98);
        uVar25 = *(uint *)(param_1 + 0xd48) & 0x40000;
        if (uVar25 == 0) {
          cVar35 = '\x02';
        }
        else {
          cVar35 = *(char *)(param_1 + 0xc3d);
        }
        cVar4 = *(char *)(param_1 + 0x20a3);
        uVar32 = (ulonglong)((byte)(*(uint *)(param_1 + 0x2058) >> 5) & 1);
        if (*(char *)(param_1 + 0x2098) != '\x01') {
          uVar32 = 1;
        }
        uVar33 = uVar32;
        if (*(char *)(param_1 + 0x209a) == '\0') {
          uVar33 = 1;
        }
        if (cVar4 == '\"') {
          if (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\x14') {
            uVar32 = *(longlong *)(param_1 + 0x1fc8) + 0x1d628;
            cVar19 = FUN_1400a9700();
            if (cVar19 == '\0') goto LAB_1401052d3;
            goto LAB_140104e74;
          }
          cVar35 = '\x02';
LAB_1401052e7:
          if (uVar25 != 0) {
            *(undefined1 *)(param_1 + 0xc3d) = 3;
          }
LAB_140104e8a:
          if ((cVar4 == '\"') && (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\x14')) {
            uVar32 = param_1;
            FUN_14010bc20();
          }
        }
        else {
LAB_1401052d3:
          if ((char)uVar33 == '\0') {
LAB_140104e74:
            if ((cVar35 == '\x03') || (cVar35 == '\0')) {
              if (uVar25 != 0) {
                *(undefined1 *)(param_1 + 0xc3d) = 1;
              }
              goto LAB_140104e8a;
            }
          }
          else if ((byte)(cVar35 - 1U) < 2) goto LAB_1401052e7;
        }
        bVar12 = false;
        local_res8 = (undefined1 *)((ulonglong)local_res8 & 0xffffffffffffff00);
        if ((((cVar21 == '\x01') && ((*(byte *)(param_1 + 0x2058) & 0x20) == 0)) &&
            (uVar14 = FUN_140187c80(uVar32,local_res10,'\f'), uVar14 != '\0')) &&
           (bVar12 = true, *(char *)(param_1 + 0x209a) == '\0')) {
          *(undefined1 *)(param_1 + 0x20bc) = 4;
          local_res20[0] = '\x05';
          local_res20[1] = '\0';
          local_188[0] = 1;
          FUN_1401c6150();
        }
        bVar11 = false;
        if (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\b') {
          bVar13 = false;
          if (*(char *)(param_1 + 0x1fa1) == '\0') {
            bVar13 = bVar12;
          }
          bVar12 = bVar13;
          if ((*(short *)(param_1 + 0x1f9c) == 0) && (*(char *)(param_1 + 0x1fa1) != '\0')) {
            bVar11 = true;
            local_res8 = (undefined1 *)CONCAT71(local_res8._1_7_,1);
          }
        }
        if (((bVar12) || (bVar11)) &&
           ((*(char *)(param_1 + 0x209a) != '\0' &&
            ((cVar35 == '\x02' && (bVar20 = *(byte *)(param_1 + 0x20b4), bVar20 != 0)))))) {
          bVar29 = *(byte *)(param_1 + 0x1ec8);
          uVar25 = 0;
          if (bVar29 == 0) {
LAB_140104ff1:
            local_res20[0] = 0xff;
            bVar28 = 1;
            local_188[0] = CONCAT11(local_188[0]._1_1_,0xff);
          }
          else {
            bVar5 = *(byte *)(param_1 + 0x1ec8);
            uVar32 = 0;
            do {
              uVar33 = uVar32;
              if (((byte)uVar25 < bVar5) &&
                 (lVar31 = (ulonglong)(uVar25 & 0xff) * 0x20,
                 (*(byte *)(lVar31 + 0x1e55 + param_1) & 2) != 0)) {
                cVar21 = *(char *)(lVar31 + 0x1e53 + param_1);
                cVar35 = *(char *)(lVar31 + 0x1e54 + param_1);
                if ((cVar21 != -1) && (cVar35 != -1)) {
                  uVar33 = (ulonglong)(byte)((char)uVar32 + 1);
                  local_res20[uVar32] = cVar21;
                  *(char *)((longlong)local_188 + uVar32) = cVar35;
                }
              }
              bVar28 = (byte)uVar33;
              uVar25 = uVar25 + 1;
              uVar32 = uVar33;
            } while ((int)uVar25 < (int)(uint)bVar29);
            if (bVar28 == 0) goto LAB_140104ff1;
          }
          auVar47 = local_110;
          if (bVar20 < bVar28) {
            bVar28 = bVar20;
          }
          bVar11 = false;
          local_110._1_7_ = 0;
          local_110[0] = bVar28;
          local_110._8_8_ = auVar47._8_8_;
          if (bVar28 == 0) goto LAB_14010598e;
          lVar31 = 0;
          fVar52 = DAT_1402d1d18;
          do {
            cVar21 = local_res20[lVar31];
            uVar18 = *(undefined1 *)((longlong)local_188 + lVar31);
            if (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\x13') {
              *(undefined1 *)(param_1 + 0x209d) = 0;
            }
            uVar32 = (ulonglong)*(byte *)(param_1 + 0x209d);
            if (*(byte *)(param_1 + 0x20b4) <= *(byte *)(param_1 + 0x209d)) {
              *(undefined1 *)(param_1 + 0x209d) = 0;
              uVar32 = 0;
            }
            sVar22 = *(short *)(uVar32 * 0x18 + 8000 + param_1);
            if (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\x15') {
              sVar22 = *(short *)(param_1 + uVar32 * -0x18 + 0x1f58);
            }
            if (((sVar22 == 0) && (bVar12)) || ((char)local_res8 != '\0')) {
              _local_178 = ZEXT816(0);
              _auStack_168 = ZEXT816(0);
              fVar48 = fVar44;
              _local_158 = _local_178;
              _local_148 = _auStack_168;
              FUN_14015e650(param_1 + 0x120,&local_1c8,
                            (int)uVar32 + 0x43 + (uint)*(byte *)(param_1 + 0x279a) * 4,0);
              FUN_140202920(local_178,local_f8);
              auVar49 = ZEXT464((uint)local_138);
              fVar42 = uStack_1c0._4_4_ * fStack_13c + (float)uStack_1c0 * fStack_14c +
                       (float)local_1c8 * fStack_16c + local_1c8._4_4_ * fStack_15c;
              fVar53 = (fVar53 + fStack_140) * uStack_1c0._4_4_ + (float)uStack_1c0 * fStack_150 +
                       local_1c8._4_4_ * fStack_160 + (float)local_1c8 * fStack_170;
              fVar43 = (fVar43 + (float)local_148._4_4_) * uStack_1c0._4_4_ +
                       (float)uStack_1c0 * (float)local_158._4_4_ +
                       local_1c8._4_4_ * (float)auStack_168._4_4_ +
                       (float)local_1c8 * (float)local_178._4_4_;
              auVar54 = ZEXT464(*(uint *)(param_1 + 0x1848));
              uVar32 = (ulonglong)*(uint *)(param_1 + 0x1848);
              fVar50 = (local_118 + (float)local_148._0_4_) * uStack_1c0._4_4_ +
                       (float)uStack_1c0 * (float)local_158._0_4_ +
                       local_1c8._4_4_ * (float)auStack_168._0_4_ +
                       (float)local_1c8 * (float)local_178._0_4_;
              fVar44 = fVar48;
              fVar46 = local_138;
              if (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\b') {
                iVar34 = FUN_140242630();
                fVar48 = (float)(iVar34 + -0x3fff) * fVar52 + fVar48;
                iVar34 = FUN_140242630();
                uVar32 = auVar54._0_8_;
                fVar46 = (float)(iVar34 + -0x3fff) * fVar52 + auVar49._0_4_;
              }
              cVar35 = *(char *)(*(longlong *)(param_1 + 0xff8) + 4 +
                                (ulonglong)*(byte *)(param_1 + 0x279a));
              if (*(char *)(param_1 + 0x20a3) == '#') {
                if (cVar35 == '\x14') {
                  cVar35 = '\x16';
                }
              }
              in_stack_fffffffffffffe18 = CONCAT71((int7)(in_stack_fffffffffffffe18 >> 8),cVar21);
              in_stack_fffffffffffffe08 =
                   (undefined8 *)
                   CONCAT71((int7)((ulonglong)in_stack_fffffffffffffe08 >> 8),
                            *(undefined1 *)(param_1 + 0x20a1));
              local_128 = CONCAT44(fVar46,fVar48);
              uStack_120 = CONCAT44(local_130,local_134);
              local_1a8 = CONCAT44(fVar43,fVar50);
              uStack_1a0 = CONCAT44(fVar42,fVar53);
              iVar34 = FUN_140141200(local_res18 + 0x1b10,&local_1a8,&local_128,uVar32,
                                     in_stack_fffffffffffffe08,*(undefined1 *)(param_1 + 0x20a2),
                                     in_stack_fffffffffffffe18,uVar18,
                                     *(undefined8 *)(param_1 + 0x1fb8),cVar35);
              if (iVar34 < 0) {
                if (iVar34 == -1) goto LAB_1401054f7;
              }
              else {
                *(undefined1 *)(local_res18 + 0x1fd90) = 1;
              }
              lVar40 = *(longlong *)(param_1 + 0xfd8);
              uVar59 = (undefined7)(in_stack_fffffffffffffe18 >> 8);
              uVar39 = (undefined7)((ulonglong)in_stack_fffffffffffffe08 >> 8);
              if (*(char *)(lVar40 + 0xd) == '\b') {
                if ((*(short *)(param_1 + 8000 + (ulonglong)*(byte *)(param_1 + 0x209d) * 0x18) == 0
                    ) && (bVar12)) {
                  *(undefined1 *)(param_1 + 0x1fa1) = *(undefined1 *)(param_1 + 0x1fa0);
                  *(undefined2 *)(param_1 + 0x1f9c) = 0;
                  *(undefined1 *)(param_1 + 0x1f9e) = 0;
                }
                if (*(char *)(param_1 + 0x1fa1) == *(char *)(param_1 + 0x1fa0)) {
                  *(int *)(param_1 + 0x20c4) = iVar34;
                }
                *(byte *)(param_1 + 0x1f9e) = *(byte *)(param_1 + 0x1f9e) | 1;
                if (*(char *)(param_1 + 0x1fa1) == '\x01') {
                  *(char *)(param_1 + 0x209a) = *(char *)(param_1 + 0x209a) + -1;
                  *(byte *)(param_1 + 0x1f48) = *(byte *)(param_1 + 0x1f48) | 1;
                  *(byte *)(param_1 + 0x1f60) = *(byte *)(param_1 + 0x1f60) | 1;
                  *(byte *)(param_1 + 0x1f78) = *(byte *)(param_1 + 0x1f78) | 1;
                  *(byte *)(param_1 + 0x1f90) = *(byte *)(param_1 + 0x1f90) | 1;
                  if (*(longlong *)(param_1 + 0x1fd0) != 0) {
                    in_stack_fffffffffffffe18 = CONCAT71(uVar59,cVar21);
                    in_stack_fffffffffffffe08 =
                         (undefined8 *)CONCAT71(uVar39,*(undefined1 *)(param_1 + 0x20a1));
                    FUN_1401417e0(*(longlong *)(param_1 + 0x1fd0),iVar34,1,
                                  *(undefined1 *)(lVar40 + 0xd),in_stack_fffffffffffffe08,
                                  *(undefined1 *)(param_1 + 0x20a2),in_stack_fffffffffffffe18,uVar18
                                 );
                  }
                }
              }
              else {
                *(char *)(param_1 + 0x209a) = *(char *)(param_1 + 0x209a) + -1;
                if ((*(longlong *)(param_1 + 0x1fd0) != 0) && (lVar31 == 0)) {
                  if ((*(char *)(param_1 + 0x20a3) == '#') && (*(char *)(lVar40 + 0xd) == '\x14')) {
                    uVar32 = CONCAT71((int7)((ulonglong)lVar40 >> 8),0x16);
                  }
                  else {
                    uVar32 = (ulonglong)*(byte *)(lVar40 + 0xd);
                  }
                  in_stack_fffffffffffffe18 = CONCAT71(uVar59,cVar21);
                  in_stack_fffffffffffffe08 =
                       (undefined8 *)CONCAT71(uVar39,*(undefined1 *)(param_1 + 0x20a1));
                  FUN_1401417e0(*(longlong *)(param_1 + 0x1fd0),iVar34,1,uVar32,
                                in_stack_fffffffffffffe08,*(undefined1 *)(param_1 + 0x20a2),
                                in_stack_fffffffffffffe18,uVar18);
                }
                if ((*(short *)(param_1 + 8000 + (ulonglong)*(byte *)(param_1 + 0x209d) * 0x18) == 0
                    ) && (bVar12)) {
                  pbVar1 = (byte *)(param_1 + 0x1f48 + (ulonglong)*(byte *)(param_1 + 0x209d) * 0x18
                                   );
                  *pbVar1 = *pbVar1 | 1;
                }
              }
              *(char *)(param_1 + 0x209d) = *(char *)(param_1 + 0x209d) + '\x01';
              if (*(byte *)(param_1 + 0x20b4) <= *(byte *)(param_1 + 0x209d)) {
                *(undefined1 *)(param_1 + 0x209d) = 0;
              }
              bVar11 = true;
              if ((*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xd) == '\x13') &&
                 (*(char *)(param_1 + 0x209a) == '\0')) {
                psVar7 = (short *)(*(undefined8 **)(local_res18 + 0x15fd8))[3];
                if ((psVar7 != (short *)0x0) &&
                   (((puVar57 = (undefined8 *)**(undefined8 **)(local_res18 + 0x15fd8),
                     puVar57 != (undefined8 *)0x0 && (*(short *)*puVar57 != 0)) && (*psVar7 == 0))))
                {
                  *psVar7 = 99;
                }
              }
              if (*(char *)(param_1 + 0x209a) == '\0') goto LAB_140105518;
            }
LAB_1401054f7:
            lVar31 = lVar31 + 1;
            fVar53 = local_184;
            fVar43 = local_1b8[0];
          } while (lVar31 < (longlong)local_110._0_8_);
          if (!bVar11) goto LAB_14010598e;
LAB_140105518:
          switch(*(undefined1 *)
                  ((ulonglong)*(byte *)(param_1 + 0x279a) + 4 + *(longlong *)(param_1 + 0xff8))) {
          case 1:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x67);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x68);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x69);
            }
            break;
          case 2:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x6a);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x6b);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x6c);
            }
            break;
          case 3:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x6d);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x6e);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x6f);
            }
            break;
          case 4:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x70);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x71);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x72);
            }
            break;
          case 5:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x73);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x74);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x75);
            }
            break;
          case 6:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x76);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x77);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x78);
            }
            break;
          case 7:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x79);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x7a);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x7b);
            }
            break;
          case 8:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x7c);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x7d);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x7e);
            }
            break;
          case 9:
          case 10:
          case 0xd:
          case 0xe:
          case 0xf:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,100);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x65);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x66);
            }
            break;
          case 0xb:
          case 0xc:
          case 0x10:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x61);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x62);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,99);
            }
            break;
          default:
            goto switchD_14010554b_caseD_11;
          case 0x12:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x82);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x83);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x84);
            }
            break;
          case 0x14:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x8e);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x8f);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x90);
            }
            break;
          case 0x15:
            cVar21 = *(char *)(param_1 + 0x2094);
            if (cVar21 == '\0') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x92);
            }
            else if (cVar21 == '\x02') {
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x93);
            }
            else {
              if (cVar21 != '\x01') goto switchD_14010554b_caseD_11;
              local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,0x94);
            }
          }
          in_stack_fffffffffffffe18 = in_stack_fffffffffffffe18 & 0xffffffffffffff00;
          local_res20[0] = '\x01';
          local_res20[1] = '\0';
          in_stack_fffffffffffffe08 = (undefined8 *)(param_1 + 0x15d0);
          local_1a8 = _DAT_1402d35f0;
          uStack_1a0 = _UNK_1402d35f8;
          FUN_1401c5d20(&local_1a8,local_res20,&local_res8,param_1 + 0x70,in_stack_fffffffffffffe08,
                        &local_1a8,in_stack_fffffffffffffe18);
switchD_14010554b_caseD_11:
          if (*(char *)(param_1 + 0x2098) == '\0') {
            bVar20 = *(char *)(param_1 + 0x2099) != '\0';
          }
          else {
            bVar20 = *(byte *)(*(longlong *)(param_1 + 0xfd8) + 0xf);
            if (*(byte *)(param_1 + 0x209a) < bVar20) {
              bVar20 = *(byte *)(param_1 + 0x209a);
            }
          }
          FUN_1400c04e0(param_1 + 0x1e38,bVar20);
          *(uint *)(lVar41 + 0x1fc) = *(uint *)(lVar41 + 0x1fc) | 2;
        }
LAB_14010598e:
        if ((*(byte *)(param_1 + 0x1676) & 8) != 0) {
          cVar21 = *(char *)(param_1 + 0x2094);
          if (cVar21 == '\0') {
            uVar23 = 0xe1;
          }
          else if (cVar21 == '\x02') {
            uVar23 = 0xe2;
          }
          else {
            if (cVar21 != '\x01') goto LAB_1401059ee;
            uVar23 = 0xe3;
          }
          local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,uVar23);
          local_res20[0] = '\x01';
          local_res20[1] = '\0';
          FUN_1401c6150();
        }
LAB_1401059ee:
        param_2 = local_res10;
        uVar32 = DAT_14032c8f0;
        bVar20 = *(byte *)(param_1 + 0x20a6);
        iVar34 = (int)((float)*(byte *)(param_1 + 0x20a0) * DAT_1402d2168);
        uVar33 = DAT_14032c8f0;
        uVar14 = FUN_140187a40(DAT_14032c8f0,local_res10,'\x0e');
        if (uVar14 == '\0') {
          if ((bVar20 != 0) && ((int)(uint)bVar20 < iVar34)) {
            *(byte *)(param_1 + 0x1eee) = *(byte *)(param_1 + 0x1eee) & 0x3e | 1;
          }
          *(undefined1 *)(param_1 + 0x20a6) = 0;
        }
        else if ((int)(uint)bVar20 < iVar34) {
          *(byte *)(param_1 + 0x20a6) = bVar20 + 1;
        }
        uVar14 = FUN_140187c80(uVar33,param_2,'\x0f');
        pbVar1 = (byte *)(param_1 + 0x1eee);
        if (uVar14 != '\0') {
          *pbVar1 = *pbVar1 & 0x3d | 2;
        }
        *(undefined1 *)(param_1 + 0x20a7) = 0;
        uVar14 = FUN_140187a40(uVar32,param_2,'&');
        if (uVar14 == '\0') {
          if ((*(char *)(param_1 + 0x20a8) != '\0') &&
             (lVar31 = FUN_140189320(),
             (int)(uint)*(byte *)(param_1 + 0x20a8) < *(int *)(lVar31 + 0xc) / 2)) {
            bVar20 = *pbVar1;
            if ((char)bVar20 < '\0') {
              bVar20 = bVar20 & 0x7f;
            }
            else if ((bVar20 & 0x40) == 0) {
              if ((*(char *)(param_1 + 0x2098) != '\0') &&
                 ((*(char *)(param_1 + 0x2098) != '\x01' ||
                  (*(char *)(*(longlong *)(param_1 + 0xfd8) + 0xf) != '\x01')))) goto LAB_140105b34;
              bVar20 = bVar20 | 0x40;
              *(undefined1 *)(param_1 + 0x20a7) = 1;
            }
            else {
              bVar20 = bVar20 & 0xbf;
            }
            *(byte *)(param_1 + 0x1eee) = bVar20;
          }
LAB_140105b34:
          *(undefined1 *)(param_1 + 0x20a8) = 0;
        }
        else {
          lVar31 = FUN_140189320();
          if ((int)(uint)*(byte *)(param_1 + 0x20a8) < *(int *)(lVar31 + 0xc) / 2) {
            *(byte *)(param_1 + 0x20a8) = *(byte *)(param_1 + 0x20a8) + 1;
          }
          FUN_140189320();
        }
        FUN_1400c11c0(param_1 + 0x1e38);
        uVar32 = param_1;
        FUN_14010b000();
        in_stack_fffffffffffffe10 = param_1 + 0x10b0;
        bVar20 = FUN_140187c80(uVar32,param_2,'\x10');
        auVar47._0_4_ = (float)bVar20;
        auVar47._4_12_ = SUB1612(ZEXT816(0),4);
        FUN_1400b7b40(param_1 + 0x1868,*(undefined8 *)(param_1 + 0x2040),
                      *(undefined8 *)(param_1 + 0x1fc8),auVar47._0_8_,
                      (ulonglong)in_stack_fffffffffffffe08 & 0xffffffffffffff00,
                      in_stack_fffffffffffffe10);
        auVar54 = ZEXT464(local_100);
        fVar52 = local_fc;
        uVar27 = _DAT_1402d35f0;
        uVar51 = _UNK_1402d35f8;
      }
      uVar26 = local_114;
      fVar42 = local_138;
      fVar43 = local_1b8[0];
      fVar53 = local_184;
      fVar50 = local_118;
    }
    else {
      local_134 = *(undefined4 *)(param_1 + 0x1810);
      fVar44 = *(float *)(param_1 + 0x1808);
      local_130 = *(undefined4 *)(param_1 + 0x1814);
      uVar26 = *(undefined4 *)(param_1 + 0x1804);
      fVar42 = *(float *)(param_1 + 0x180c);
      fVar43 = *(float *)(param_1 + 0x17fc);
      fVar53 = *(float *)(param_1 + 0x1800);
      fVar50 = *(float *)(param_1 + 0x17f8);
    }
    *(float *)(param_1 + 0x1d80) =
         (*(float *)(param_1 + 0x1650) - *(float *)(param_1 + 0x1d80)) * fVar52 +
         *(float *)(param_1 + 0x1d80);
    *(float *)(param_1 + 0x1d84) =
         (*(float *)(param_1 + 0x1654) - *(float *)(param_1 + 0x1d84)) * fVar52 +
         *(float *)(param_1 + 0x1d84);
    *(float *)(param_1 + 0x1d88) =
         (*(float *)(param_1 + 0x1658) - *(float *)(param_1 + 0x1d88)) * fVar52 +
         *(float *)(param_1 + 0x1d88);
    *(float *)(param_1 + 0x1d8c) =
         (*(float *)(param_1 + 0x165c) - *(float *)(param_1 + 0x1d8c)) * DAT_1402d1fa8 +
         *(float *)(param_1 + 0x1d8c);
    *(float *)(param_1 + 0x1ce4) = fVar43;
    *(float *)(param_1 + 0x1ce0) = fVar50;
    *(float *)(param_1 + 0x1ce8) = fVar53;
    *(undefined4 *)(param_1 + 0x1cec) = uVar26;
    *(undefined4 *)(param_1 + 0x1cf8) = local_134;
    *(float *)(param_1 + 0x1cf0) = fVar44;
    *(undefined4 *)(param_1 + 0x1cfc) = local_130;
    *(float *)(param_1 + 0x1cf4) = fVar42;
    *(undefined1 *)(param_1 + 0x1da9) = *(undefined1 *)(param_1 + 0x1eed);
    *(undefined1 *)(param_1 + 0x1da8) = *(undefined1 *)(param_1 + 0x1eec);
    if ((*(byte *)(param_1 + 0x1676) & 1) == 0) {
      bVar20 = *(byte *)(param_1 + 0x1da7) & 0xfd;
    }
    else {
      bVar20 = *(byte *)(param_1 + 0x1da7) | 2;
    }
    *(byte *)(param_1 + 0x1da7) = bVar20;
    FUN_140111d40(param_1 + 0x1c50,param_2,*(undefined1 *)(param_1 + 0x2097));
    if ((*(byte *)(param_1 + 0x2058) & 2) == 0) {
      fVar52 = *(float *)(param_1 + 0x1850);
      if ((*(byte *)(*(longlong *)(param_1 + 0xff8) + 0xc) & 1) == 0) {
        fVar52 = auVar56._0_4_;
      }
      *(uint *)(param_1 + 0xc18) = *(uint *)(param_1 + 0x1650) ^ DAT_1402d3770;
      fVar44 = *(float *)(param_1 + 0x1664) * DAT_1402d2dbc;
      *(undefined4 *)(param_1 + 0xc1c) = *(undefined4 *)(param_1 + 0x1654);
      *(undefined4 *)(param_1 + 0xc20) = *(undefined4 *)(param_1 + 0x1658);
      *(undefined4 *)(param_1 + 0xc24) = *(undefined4 *)(param_1 + 0x1640);
      *(undefined4 *)(param_1 + 0xaf4) = *(undefined4 *)(param_1 + 0x1640);
      *(undefined4 *)(param_1 + 0xc28) = *(undefined4 *)(param_1 + 0x1854);
      *(float *)(param_1 + 0xc2c) = fVar52;
      *(undefined4 *)(param_1 + 0xc30) = *(undefined4 *)(param_1 + 0x1858);
      *(float *)(param_1 + 0xc34) = fVar44;
      if (auVar56._0_4_ <= fVar44) {
        if (auVar54._0_4_ < fVar44) {
          *(undefined4 *)(param_1 + 0xc34) = 0x3f800000;
        }
      }
      else {
        *(undefined4 *)(param_1 + 0xc34) = 0;
      }
      lVar31 = param_1 + 0x110;
      if ((*(byte *)(param_1 + 0x1676) & 1) == 0) {
        uVar25 = *(uint *)(param_1 + 0xd48) & 0xffffefff;
      }
      else {
        uVar25 = *(uint *)(param_1 + 0xd48) | 0x1000;
      }
      *(uint *)(param_1 + 0xd48) = uVar25;
      FUN_140155ec0(param_1 + 0x110);
      cVar21 = *(char *)(param_1 + 0x2094);
      if (cVar21 == '\0') {
        FUN_140156b40(param_1 + 0x110);
      }
      else if (cVar21 == '\x01') {
        FUN_140156b40(lVar31);
        if (((byte)DAT_14032844c & 1) != 0) {
          FUN_140156ce0(lVar31);
        }
      }
      else if (cVar21 == '\x02') {
        FUN_140156bf0(lVar31);
      }
    }
    uVar26 = (undefined4)(in_stack_fffffffffffffe10 >> 0x20);
    lVar31 = *(longlong *)(param_1 + 0x1fc0);
    if ((lVar31 == 0) || (((byte)*(undefined4 *)(lVar41 + 0x1f0) & 3) != 1)) {
LAB_140105f4b:
      fVar52 = DAT_1402d2168;
      goto LAB_140105f59;
    }
    local_1a8 = *(undefined8 *)(param_1 + 0x70);
    uStack_1a0 = *(undefined8 *)(param_1 + 0x78);
    if (*(short *)(lVar41 + 0x442) != -1) {
      uVar23 = FUN_140035b10(*(undefined8 *)(lVar31 + 0x66ee0),2,&local_1a8,
                             *(short *)(lVar41 + 0x442),0xffff);
      *(undefined2 *)(lVar41 + 0x442) = uVar23;
      goto LAB_140105f4b;
    }
    local_198 = 0;
    uVar23 = FUN_140031f80(*(undefined8 *)(lVar31 + 0x66ee0),2,&local_1a8,0);
    fVar52 = DAT_1402d2168;
    *(undefined2 *)(lVar41 + 0x442) = uVar23;
  }
  if ((*(uint *)(param_1 + 0x2058) >> 0x18 & 1) == 0) {
    if ((*(char *)(param_1 + 0x2094) == '\x02') || ((*(uint *)(param_1 + 0x2058) >> 10 & 1) != 0)) {
      auVar49 = ZEXT1664(auVar54._0_16_);
    }
    else {
      auVar49 = ZEXT464((uint)(*(float *)(param_1 + 0x1d70) * DAT_1402d1ef4));
    }
    auVar47 = *(undefined1 (*) [16])(param_1 + 0x1d10);
    *(int *)(param_1 + 0x10e0) = auVar47._0_4_;
    uVar30 = vextractps_avx(auVar47,1);
    *(undefined4 *)(param_1 + 0x10e4) = uVar30;
    uVar30 = vextractps_avx(auVar47,2);
    *(undefined4 *)(param_1 + 0x10e8) = uVar30;
    uVar30 = vextractps_avx(auVar47,3);
    *(undefined4 *)(param_1 + 0x10ec) = uVar30;
    auVar47 = *(undefined1 (*) [16])(param_1 + 0x1d20);
    *(int *)(param_1 + 0x10f0) = auVar47._0_4_;
    uVar30 = vextractps_avx(auVar47,1);
    *(undefined4 *)(param_1 + 0x10f4) = uVar30;
    uVar30 = vextractps_avx(auVar47,2);
    *(undefined4 *)(param_1 + 0x10f8) = uVar30;
    uVar30 = vextractps_avx(auVar47,3);
    *(undefined4 *)(param_1 + 0x10fc) = uVar30;
    *(int *)(param_1 + 0x10bc) = auVar49._0_4_;
    *(undefined4 *)(param_1 + 0x10b8) = *(undefined4 *)(param_1 + 0x1d70);
    FUN_1401fbec0();
    auVar47 = *(undefined1 (*) [16])(param_1 + 0x1d00);
    *(int *)(param_1 + 0x12a0) = auVar47._0_4_;
    uVar30 = vextractps_avx(auVar47,1);
    *(undefined4 *)(param_1 + 0x12a4) = uVar30;
    uVar30 = vextractps_avx(auVar47,2);
    *(undefined4 *)(param_1 + 0x12a8) = uVar30;
    uVar30 = vextractps_avx(auVar47,3);
    *(undefined4 *)(param_1 + 0x12ac) = uVar30;
    auVar47 = *(undefined1 (*) [16])(param_1 + 0x1d20);
    *(int *)(param_1 + 0x12b0) = auVar47._0_4_;
    uVar30 = vextractps_avx(auVar47,1);
    *(undefined4 *)(param_1 + 0x12b4) = uVar30;
    uVar30 = vextractps_avx(auVar47,2);
    *(undefined4 *)(param_1 + 0x12b8) = uVar30;
    uVar30 = vextractps_avx(auVar47,3);
    *(undefined4 *)(param_1 + 0x12bc) = uVar30;
    *(undefined4 *)(param_1 + 0x1278) = *(undefined4 *)(param_1 + 0x1d70);
    *(int *)(param_1 + 0x127c) = auVar49._0_4_;
  }
  else {
    auVar47 = *(undefined1 (*) [16])(param_1 + 0x90);
    *(int *)(param_1 + 0x10e0) = auVar47._0_4_;
    uVar30 = vextractps_avx(auVar47,1);
    *(undefined4 *)(param_1 + 0x10e4) = uVar30;
    uVar30 = vextractps_avx(auVar47,2);
    *(undefined4 *)(param_1 + 0x10e8) = uVar30;
    uVar30 = vextractps_avx(auVar47,3);
    *(undefined4 *)(param_1 + 0x10ec) = uVar30;
    auVar47 = *(undefined1 (*) [16])(param_1 + 0xa0);
    *(int *)(param_1 + 0x10f0) = auVar47._0_4_;
    uVar30 = vextractps_avx(auVar47,1);
    *(undefined4 *)(param_1 + 0x10f4) = uVar30;
    uVar30 = vextractps_avx(auVar47,2);
    *(undefined4 *)(param_1 + 0x10f8) = uVar30;
    uVar30 = vextractps_avx(auVar47,3);
    *(undefined4 *)(param_1 + 0x10fc) = uVar30;
    *(undefined4 *)(param_1 + 0x10b8) = 0x44000000;
  }
  FUN_1401fbec0();
  if ((*(byte *)(lVar41 + 0x1f0) & 1) != 0) {
    lVar31 = *(longlong *)(param_1 + 0x1fa8);
    uVar18 = *(undefined1 *)(param_1 + 0x2094);
    pbVar1 = (byte *)(lVar31 + 0x44);
    *pbVar1 = *pbVar1 & 0xfd;
    *(undefined1 *)(lVar31 + 0x41) = uVar18;
    lVar31 = *(longlong *)(param_1 + 0x1fa8);
    *(undefined4 *)(lVar31 + 0x4c) = *(undefined4 *)(param_1 + 0x70);
    *(undefined4 *)(lVar31 + 0x50) = *(undefined4 *)(param_1 + 0x74);
    *(undefined4 *)(lVar31 + 0x54) = *(undefined4 *)(param_1 + 0x78);
    *(undefined4 *)(lVar31 + 0x58) = *(undefined4 *)(param_1 + 0x7c);
    lVar31 = *(longlong *)(param_1 + 0x1fa8);
    *(undefined4 *)(lVar31 + 0x5c) = *(undefined4 *)(param_1 + 0x80);
    *(undefined4 *)(lVar31 + 0x60) = *(undefined4 *)(param_1 + 0x84);
    *(undefined4 *)(lVar31 + 100) = *(undefined4 *)(param_1 + 0x88);
    *(undefined4 *)(lVar31 + 0x68) = *(undefined4 *)(param_1 + 0x8c);
    FUN_1401c81f0(*(undefined8 *)(param_1 + 0x1fa8),*(undefined4 *)(param_1 + 0x1850),
                  *(undefined4 *)(param_1 + 0x1854));
    plVar8 = *(longlong **)(param_1 + 0x1fa8);
    if (((*(byte *)((longlong)plVar8 + 0x44) & 1) == 0) || ((*(byte *)(lVar41 + 0x1f0) & 2) == 0)) {
      (**(code **)(*plVar8 + 0x10))();
    }
    else {
      *(undefined4 *)(param_1 + 0x2084) = 0;
      (**(code **)*plVar8)();
    }
    FUN_14010c9a0(param_1,0);
    FUN_14010c3f0(param_1);
    if (((*(byte *)(lVar41 + 0x1f0) & 2) != 0) &&
       (FUN_14010be70(param_1), (*(byte *)(lVar41 + 0x1f0) & 2) != 0)) {
      FUN_14010dec0(param_1);
    }
    bVar20 = FUN_140078e50(*(undefined8 *)(param_1 + 0x2038),(undefined4 *)(param_1 + 0x70),
                           DAT_1402d20d0);
    bVar29 = (bVar20 ^ *(byte *)(param_1 + 0x20c3)) << 4;
    *(byte *)(param_1 + 0x20c3) = bVar29 | bVar20;
    if (bVar29 != 0 || (bVar20 & 0xf0) != 0) {
      DAT_140310a8c = 500;
      DAT_140310a98 = 2;
      _DAT_140310aac = 500;
      DAT_140310ab8 = 2;
      if (bVar20 == 0) {
        DAT_140310a90 = DAT_1402d2778 * DAT_1437decf8;
        DAT_140310a94 = (DAT_140310a90 - DAT_140310a84) * DAT_1402d1e6c;
        _DAT_140310ab0 = DAT_1402d2778 * DAT_1437decfc;
        _DAT_140310ab4 = (_DAT_140310ab0 - DAT_140310aa4) * DAT_1402d1e6c;
      }
      else {
        DAT_140310a94 = (DAT_1402d2778 - DAT_140310a84) * DAT_1402d1e6c;
        _DAT_140310ab4 = (DAT_1402d2778 - DAT_140310aa4) * DAT_1402d1e6c;
        DAT_140310a90 = DAT_1402d2778;
        _DAT_140310ab0 = DAT_1402d2778;
      }
    }
    cVar21 = *(char *)(param_1 + 0x2094);
    uVar36 = 0x101;
    uVar38 = 0x107;
    uVar23 = 0x10a;
    if (cVar21 == '\x02') {
      uVar36 = 0x102;
      uVar38 = 0x108;
      uVar23 = 0x10b;
    }
    else if (cVar21 == '\x01') {
      uVar36 = 0x103;
      uVar38 = 0x109;
      uVar23 = 0x10c;
    }
    uVar45 = *(undefined8 *)(param_1 + 0x15d0);
    uStack_120 = *(undefined8 *)(param_1 + 0x15d8);
    local_128 = uVar45;
    if (*(short *)(param_1 + 0xb48) == 1) {
      local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,uVar23);
      puVar57 = &local_1a8;
      local_res20[0] = '\x01';
      local_res20[1] = '\0';
      local_1a8 = uVar27;
      uStack_1a0 = uVar51;
      uVar45 = FUN_1401c5d20(cVar21,local_res20,&local_res8,param_1 + 0x70,&local_128,puVar57,
                             in_stack_fffffffffffffe18 & 0xffffffffffffff00);
      uVar26 = (undefined4)((ulonglong)puVar57 >> 0x20);
    }
    sVar22 = *(short *)(lVar41 + 0x428);
    if ((sVar22 <= *(char *)(param_1 + 0x20c1)) && (0 < sVar22)) {
      local_res8 = (undefined1 *)CONCAT62(local_res8._2_6_,uVar36);
      local_res20[0] = '\x01';
      local_res20[1] = '\0';
      uVar45 = FUN_1401c6150(sVar22,local_res20,&local_res8);
      *(char *)(param_1 + 0x20c1) = *(char *)(lVar41 + 0x428) + -1;
    }
    if ((*(float *)(param_1 + 0x207c) <= auVar56._0_4_) || ((*(byte *)(lVar41 + 0x1f0) & 2) == 0)) {
LAB_1401064aa:
      FUN_1401c6490(uVar45,param_1 + 0x2068);
    }
    else {
      uVar32 = (ulonglong)local_res8 >> 0x10;
      local_res8 = (undefined1 *)((ulonglong)local_res8 & 0xffffffffffff0000);
      if (*(char *)(param_1 + 0x20c2) == '\x01') {
        local_res8 = (undefined1 *)CONCAT62((int6)uVar32,0xfd44);
      }
      lVar31 = param_1 + 0x2068;
      cVar21 = FUN_1401c5910(uVar45,lVar31);
      if (cVar21 == '\0') {
        local_res20[0] = '\0';
        local_res20[1] = '\0';
        local_1b8[0] = (float)CONCAT22(local_1b8[0]._2_2_,1);
        local_188[0] = uVar38;
        uVar27 = FUN_1401c97a0();
        ppuVar58 = &local_res8;
        FUN_1401ca240(uVar27,local_1b8,local_188,param_1 + 0x207c,local_res20,ppuVar58,lVar31);
        uVar26 = (undefined4)((ulonglong)ppuVar58 >> 0x20);
      }
      else {
        uVar45 = extraout_XMM0_Qa_00;
        if (*(char *)(param_1 + 0x2094) != *(char *)(param_1 + 0x20a5)) goto LAB_1401064aa;
        local_res20[0] = '\0';
        local_res20[1] = '\0';
        FUN_1401c63a0(extraout_XMM0_Qa_00,lVar31,param_1 + 0x207c,local_res20,&local_res8);
      }
    }
  }
  if ((((*(byte *)(param_1 + 0x2058) & 2) == 0) && ((*(byte *)(lVar41 + 0x1f0) & 1) != 0)) &&
     (*(longlong *)(param_1 + 0x1fc0) != 0)) {
    lVar31 = *(longlong *)(*(longlong *)(param_1 + 0x1fc0) + 0x66ee0);
    if (*(char *)(param_1 + 0x2094) == '\x01') {
      *(undefined2 *)(lVar31 + 0x336d4) = 1;
    }
    else if (*(char *)(param_1 + 0x2094) == '\x02') {
      *(undefined2 *)(lVar31 + 0x336d4) = 2;
    }
    else {
      *(undefined2 *)(lVar31 + 0x336d4) = 0;
    }
    if ((*(byte *)(*(longlong *)(param_1 + 0x1fd0) + 0x2a6) & 0x42) == 2) {
      *(undefined2 *)(*(longlong *)(*(longlong *)(param_1 + 0x1fc0) + 0x66ee0) + 0x336d4) = 1;
    }
    uVar25 = *(uint *)(param_1 + 0x2058);
    if ((uVar25 & 4) != 0) {
      local_1a8 = *(undefined8 *)(param_1 + 0x15e0);
      uStack_1a0 = *(undefined8 *)(param_1 + 0x15e8);
      FUN_140102710(param_1 + 0x1db0,&local_1a8,*(undefined4 *)(param_1 + 0x1640));
      *(undefined4 *)(param_1 + 0xb24) = *(undefined4 *)(param_1 + 0x1e24);
      *(undefined4 *)(param_1 + 0xb30) = *(undefined4 *)(param_1 + 0x1e28);
      uVar25 = *(uint *)(param_1 + 0x2058);
    }
    if ((*(byte *)(*(longlong *)(param_1 + 0xff8) + 0xc) & 1) == 0) {
      uVar30 = auVar56._0_4_;
    }
    else {
      uVar30 = *(undefined4 *)(param_1 + 0x1850);
    }
    *(undefined4 *)(param_1 + 0xb00) = *(undefined4 *)(param_1 + 0x1854);
    *(undefined4 *)(param_1 + 0xb04) = uVar30;
    if ((uVar25 & 8) != 0) {
      *(ushort *)(param_1 + 0xae4) = *(ushort *)(param_1 + 0xae4) | 1;
      *(undefined4 *)(param_1 + 0xb20) = *(undefined4 *)(param_1 + 0x1854);
    }
    if ((uVar25 & 0x10) == 0) {
      uVar30 = 0;
      if (*(char *)(param_1 + 0x2094) == '\x02') {
        iVar34 = 3;
      }
      else {
        iVar34 = (*(char *)(param_1 + 0x2094) == '\x01') + 1;
      }
    }
    else {
      uVar30 = 1;
      iVar34 = 0;
    }
    FUN_14000eb50(param_1 + 0x110,*(undefined8 *)(param_1 + 0x1fc0),param_1 + 0x70,param_1 + 0x80,
                  uVar30,CONCAT44(uVar26,iVar34));
    local_1c8 = 0;
    uStack_1c0 = 0;
    FUN_140102590(*(undefined8 *)(param_1 + 0x1fc8),&local_1c8,&local_res8);
    FUN_140158ee0(param_1 + 0x110,(ulonglong)local_res8 & 0xffffffff);
    if ((*(byte *)(param_1 + 0x2058) & 0x10) == 0) {
      local_1a8 = local_1c8;
      uStack_1a0 = uStack_1c0;
    }
    else {
      _auStack_168 = ZEXT816(0);
      _local_178 = ZEXT816(0);
      _local_158 = ZEXT816(0);
      _local_148 = _auStack_168;
      FUN_140202920(local_178,param_1 + 0x80);
      auVar47 = vshufps_avx(_local_148,_local_148,0x55);
      auVar55 = vshufps_avx(_auStack_168,_auStack_168,0x55);
      local_1a8 = CONCAT44(uStack_1c0._4_4_ * auVar47._0_4_ +
                           (float)uStack_1c0 * (float)local_158._4_4_ +
                           local_1c8._4_4_ * auVar55._0_4_ +
                           (float)local_1c8 * (float)local_178._4_4_,
                           uStack_1c0._4_4_ * local_148._0_4_ +
                           (float)uStack_1c0 * (float)local_158._0_4_ +
                           local_1c8._4_4_ * auStack_168._0_4_ +
                           (float)local_1c8 * (float)local_178._0_4_);
      auVar47 = vshufps_avx(_local_148,_local_148,0xaa);
      auVar55 = vshufps_avx(_auStack_168,_auStack_168,0xaa);
      auVar9 = vshufps_avx(_local_148,_local_148,0xff);
      auVar10 = vshufps_avx(_auStack_168,_auStack_168,0xff);
      uStack_1a0 = CONCAT44(uStack_1c0._4_4_ * auVar9._0_4_ + (float)uStack_1c0 * fStack_14c +
                            local_1c8._4_4_ * auVar10._0_4_ + (float)local_1c8 * fStack_16c,
                            uStack_1c0._4_4_ * auVar47._0_4_ + (float)uStack_1c0 * fStack_150 +
                            local_1c8._4_4_ * auVar55._0_4_ + (float)local_1c8 * fStack_170);
    }
    FUN_140158e70(param_1 + 0x110,&local_1a8);
    auVar47 = auVar54._0_16_;
    auVar55 = auVar56._0_16_;
    if ((*(byte *)(param_1 + 0x2058) & 0x80) == 0) {
      local_1a8 = *(undefined8 *)(param_1 + 0x70);
      uStack_1a0 = *(undefined8 *)(param_1 + 0x78);
      local_res8 = (undefined1 *)((ulonglong)local_res8 & 0xffffffff00000000);
      fVar44 = (float)FUN_140078db0(*(undefined8 *)(param_1 + 0x2038),&local_1a8,&local_res8);
      auVar55 = _local_158;
      auVar47 = *(undefined1 (*) [16])(param_1 + 0x15d0);
      _local_178 = *(undefined1 (*) [16])(param_1 + 0x70);
      auStack_168._4_4_ = vextractps_avx(auVar47,1);
      auStack_168._0_4_ = auVar47._0_4_;
      fStack_160 = (float)vextractps_avx(auVar47,2);
      fStack_15c = (float)vextractps_avx(auVar47,3);
      local_158._4_4_ = 0;
      local_158._0_4_ = *(float *)(param_1 + 0x74) - fVar44;
      fStack_14c = auVar55._12_4_;
      fStack_150 = local_res8._0_4_;
      FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 0x1fc0) + 0x66ee0),5,local_178,0);
      auVar47 = auVar54._0_16_;
      auVar55 = auVar56._0_16_;
    }
    _local_178 = *(undefined1 (*) [16])(param_1 + 0x70);
    _auStack_168 = *(undefined1 (*) [16])(param_1 + 0x80);
    _local_158 = ZEXT816(0);
    auVar9 = vmaxss_avx(ZEXT416((uint)((*(float *)(param_1 + 0x1848) - DAT_1402d295c) *
                                      DAT_1402d1e48)),auVar55);
    vminss_avx(auVar9,auVar47);
    auVar54 = ZEXT1664(auVar47);
    auVar56 = ZEXT1664(auVar55);
    fVar44 = (float)FUN_140275650();
    auVar47 = _local_148;
    fStack_140 = fVar44 * DAT_1402d2134;
    local_148._0_4_ = auVar47._0_4_;
    local_148._4_4_ = auVar54._0_4_;
    fStack_13c = 5.90052e-39;
    uVar23 = FUN_140035b10(*(undefined8 *)(*(longlong *)(param_1 + 0x1fc0) + 0x66ee0),0x79,local_178
                           ,*(undefined2 *)(lVar41 + 0x444),0xffff);
    *(undefined2 *)(lVar41 + 0x444) = uVar23;
  }
  FUN_140103e40(param_1);
  if (((*(byte *)(param_1 + 0x2058) & 0x40) != 0) && (0 < *(short *)(param_1 + 0x1860))) {
    if (*(short *)(lVar41 + 0x428) < 1) {
      uVar26 = FUN_140079920(*(undefined8 *)(param_1 + 0x2030),lVar41 + 600);
      FUN_140117a10(lVar41,uVar26);
      *(uint *)(lVar41 + 0x1f0) = *(uint *)(lVar41 + 0x1f0) & 0xfffffffe;
    }
    else {
      local_res8 = (undefined1 *)0x0;
      FUN_140118040(lVar41,&local_res8,0,*(short *)(param_1 + 0x1860),5,0,
                    *(undefined1 *)(param_1 + 0x1865));
    }
  }
  if ((*(byte *)(param_1 + 0x2058) & 2) != 0) {
    return;
  }
  FUN_14010ead0(param_1);
  uVar27 = auVar54._0_8_;
  if ((*(byte *)(param_1 + 0x2058) & 2) != 0) {
    return;
  }
  puVar37 = (ushort *)(param_1 + 0x2090);
  lVar40 = (ulonglong)*(byte *)(param_1 + 0x20a2) * 0x520;
  lVar41 = *(longlong *)
            (**(longlong **)(param_1 + 0x2040) + (ulonglong)*(byte *)(param_1 + 0x20a1) * 8);
  uVar24 = *puVar37;
  lVar31 = *(longlong *)(lVar41 + 0x110);
  uVar39 = (undefined7)((ulonglong)lVar41 >> 8);
  if (*(short *)(lVar40 + 0x428 + lVar31) < 1) {
    if ((uVar24 & 0x10) == 0) {
      FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),CONCAT71(uVar39,6),
                    auVar56._0_8_);
      *puVar37 = *puVar37 | 0x10;
    }
  }
  else {
    *puVar37 = uVar24 & 0xffef;
    if ((uVar24 >> 8 & 1) == 0) {
      uVar6 = *(ushort *)(param_1 + 0x2792);
      if (uVar6 == 0) {
        *puVar37 = uVar24 & 0xfeef;
        uVar23 = 0;
      }
      else {
        if (0x77 < uVar6) {
          auVar47 = vmaxss_avx(ZEXT416((uint)(-((float)(uVar6 - 0x78) * DAT_1402d1e90) +
                                             auVar54._0_4_)),auVar56._0_16_);
          uVar27 = auVar47._0_8_;
        }
        FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),0,uVar27);
        *(undefined1 *)(param_1 + 0x1dae) = 5;
        *puVar37 = *puVar37 & 0xfeff;
        if (*(ushort *)(param_1 + 0x2792) < 0x1a4) {
          uVar23 = (undefined2)((*(ushort *)(param_1 + 0x2792) + 1) % 0xffff);
        }
        else {
          uVar23 = 0;
        }
      }
    }
    else {
      FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),CONCAT71(uVar39,6),
                    auVar56._0_8_);
      *(undefined1 *)(param_1 + 0x1dae) = 5;
      uVar23 = 1;
      *puVar37 = *puVar37 & 0xfeff;
    }
    puVar37 = (ushort *)(param_1 + 0x2090);
    *(undefined2 *)(param_1 + 0x2792) = uVar23;
    if ((*(byte *)puVar37 & 0x23) != 0) {
      FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),8,auVar56._0_8_);
      *(undefined1 *)(param_1 + 0x1dae) = 5;
      *puVar37 = *puVar37 & 0xffdc;
    }
    if (auVar56._0_4_ < *(float *)(param_1 + 0x1850)) {
      FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),1,auVar56._0_8_);
      *(undefined1 *)(param_1 + 0x1dae) = 1;
    }
    fVar44 = DAT_1402d2638;
    if ((*(float *)(param_1 + 0x1858) <= auVar56._0_4_) ||
       (*(float *)(param_1 + 0x1848) <= DAT_1402d2638)) {
      *(undefined4 *)(param_1 + 0x2794) = 0;
    }
    else {
      if ((*(float *)(param_1 + 0x184c) <= auVar56._0_4_) && (*(uint *)(param_1 + 0x2794) < 0x12d))
      {
        FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),0);
        *(undefined1 *)(param_1 + 0x1dae) = 2;
      }
      *(int *)(param_1 + 0x2794) = *(int *)(param_1 + 0x2794) + 1;
    }
    puVar3 = (undefined1 *)(param_1 + 0x20b3);
    if ((*(uint *)(lVar40 + 0x1f8 + lVar31) & 0x20000000) != 0) {
      FUN_140188d80(param_1 + 0x1010,*puVar3,4,auVar56._0_8_);
      *(undefined1 *)(param_1 + 0x1dae) = 10;
    }
    if ((*(uint *)(lVar40 + 0x1f8 + lVar31) & 0x10000000) != 0) {
      FUN_140188d80(param_1 + 0x1010,*puVar3,5,auVar56._0_8_);
      *(undefined1 *)(param_1 + 0x1dae) = 0x1e;
    }
    local_res8 = (undefined1 *)(param_1 + 0x1dae);
    if ((*(uint *)(lVar40 + 0x1f8 + lVar31) & 0x40000000) != 0) {
      FUN_140188d80(param_1 + 0x1010,*puVar3,5,auVar56._0_8_);
      *(undefined1 *)(param_1 + 0x1dae) = 0x1e;
    }
    if (*(int *)(lVar40 + 0x1f8 + lVar31) < 0) {
      FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),7,auVar56._0_8_);
      *local_res8 = 10;
    }
    lVar41 = param_1 + 0x1010;
    bVar20 = *(byte *)(param_1 + 0x1676);
    uVar27 = auVar56._0_8_;
    if ((bVar20 & 1) == 0) {
      *(undefined2 *)(param_1 + 0x2798) = 0;
      if (auVar56._0_4_ < *(float *)(param_1 + 0x184c)) {
        if (bVar20 == 0) {
          if (*(float *)(param_1 + 0x184c) <= fVar52) {
            if ((*(ushort *)(param_1 + 0x2090) & 0x400) == 0) {
              FUN_140188d80(lVar41,*(undefined1 *)(param_1 + 0x20b3),9,uVar27);
              *(undefined1 *)(param_1 + 0x1dae) = 5;
            }
          }
          else {
            FUN_140188d80(lVar41,*(undefined1 *)(param_1 + 0x20b3),10,uVar27);
            *(undefined1 *)(param_1 + 0x1dae) = 10;
            *(ushort *)(param_1 + 0x2090) = *(ushort *)(param_1 + 0x2090) | 0x400;
          }
        }
        goto LAB_140106e78;
      }
      uVar24 = 0xfbff;
    }
    else {
      if (((bVar20 & 8) != 0) && (DAT_1402d24d0 < *(float *)(param_1 + 0x1848))) {
        FUN_140188d80(lVar41,*(undefined1 *)(param_1 + 0x20b3),2,uVar27);
        *(undefined1 *)(param_1 + 0x1dae) = 5;
      }
      uVar27 = auVar56._0_8_;
      if (*(float *)(param_1 + 0x1848) <= fVar44) {
        sVar22 = 0;
      }
      else {
        *(undefined1 *)(param_1 + 0x1dae) = 5;
        if (*(ushort *)(param_1 + 0x2798) < (ushort)((ushort)*(byte *)(param_1 + 0x20a0) * 5)) {
          FUN_140188d80(lVar41,*(undefined1 *)(param_1 + 0x20b3),3);
          uVar27 = auVar56._0_8_;
        }
        sVar22 = *(ushort *)(param_1 + 0x2798) + 1;
        if ((ushort)((ushort)*(byte *)(param_1 + 0x20a0) * 6) <= *(ushort *)(param_1 + 0x2798)) {
          sVar22 = 0;
        }
      }
      *(short *)(param_1 + 0x2798) = sVar22;
      uVar24 = *(ushort *)(param_1 + 0x2090);
      if ((uVar24 & 4) != 0) {
        FUN_140188d80(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3),6,uVar27);
        *(undefined1 *)(param_1 + 0x1dae) = 10;
        uVar24 = *(ushort *)(param_1 + 0x2090) & 0xfffb;
        *(ushort *)(param_1 + 0x2090) = uVar24;
      }
      if ((uVar24 & 8) == 0) goto LAB_140106e78;
      *(undefined1 *)(param_1 + 0x1dae) = 10;
      uVar24 = 0xfff7;
    }
    *(ushort *)(param_1 + 0x2090) = *(ushort *)(param_1 + 0x2090) & uVar24;
  }
LAB_140106e78:
  FUN_140188fb0(param_1 + 0x1010,*(undefined1 *)(param_1 + 0x20b3));
  return;
}

