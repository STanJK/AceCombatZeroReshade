/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140196530; RVA 0x196530
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140196530(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4)

{
  if (*(int *)(param_1 + 0x750) == 2) {
    FUN_140191a00(param_1,(uint)((ulonglong)*(undefined8 *)(param_1 + 0x348) >> 0x20) & 0x3fff,
                  (uint)*(undefined8 *)(param_1 + 0x358) & 0xfff,
                  (uint)((ulonglong)*(undefined8 *)(param_1 + 0x358) >> 0x20) & 0xfff,param_3,
                  param_4,(byte)((ulonglong)*(undefined8 *)(param_1 + 0x348) >> 0x38) & 0x3f,
                  (int)((ulonglong)*(undefined8 *)(param_1 + 0x360) >> 0x20));
    *(undefined4 *)(param_1 + 0x750) = 0xffffffff;
    return;
  }
  FUN_1401961a0();
  return;
}

