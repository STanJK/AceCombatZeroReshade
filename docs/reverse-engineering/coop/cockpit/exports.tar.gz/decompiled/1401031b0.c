/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401031b0; RVA 0x1031b0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401031b0(longlong param_1,uchar param_2)

{
  ushort *puVar1;
  char *pcVar2;
  uint *puVar3;
  undefined1 auVar4 [32];
  byte bVar5;
  ushort uVar6;
  bool bVar7;
  undefined1 uVar8;
  uchar uVar9;
  char cVar10;
  short sVar11;
  uint uVar12;
  undefined4 *puVar13;
  byte bVar14;
  ulonglong arg1;
  longlong lVar15;
  longlong lVar16;
  longlong lVar17;
  byte bVar18;
  ushort uVar19;
  uint uVar20;
  undefined8 uVar21;
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  undefined1 auVar24 [16];
  undefined1 auVar25 [16];
  undefined1 auVar26 [16];
  float fVar27;
  float fVar28;
  undefined4 uVar29;
  float fVar30;
  float fVar31;
  undefined1 auVar32 [64];
  uint uVar33;
  undefined1 auVar34 [16];
  undefined1 auVar35 [64];
  undefined1 auVar36 [64];
  undefined1 auVar37 [16];
  undefined1 auVar38 [64];
  undefined1 auVar39 [64];
  undefined1 auVar40 [16];
  undefined1 auVar41 [64];
  undefined4 uVar42;
  float local_158;
  float fStack_154;
  float fStack_150;
  float fStack_14c;
  undefined1 local_148 [8];
  float fStack_140;
  float fStack_13c;
  undefined1 local_138 [16];
  undefined1 local_128 [16];
  undefined1 local_118 [8];
  float fStack_110;
  float fStack_10c;
  undefined1 local_108 [32];
  undefined1 local_e8 [32];
  
  bVar5 = *(byte *)(param_1 + 0x20a2);
  lVar17 = *(longlong *)
            (*(longlong *)
              (**(longlong **)(param_1 + 0x2040) + (ulonglong)*(byte *)(param_1 + 0x20a1) * 8) +
            0x110);
  if (*(short *)(param_1 + 0x1f10) == 0) {
    if ((*(byte *)(param_1 + 0x1f18) & 1) != 0) {
      sVar11 = (short)(int)(*(float *)(*(longlong *)(param_1 + 0x1f08) + 0x24) *
                            *(float *)(param_1 + 0x1f14) * (float)*(byte *)(param_1 + 0x1f19));
      goto LAB_140103247;
    }
  }
  else {
    sVar11 = *(short *)(param_1 + 0x1f10) + -1;
LAB_140103247:
    *(short *)(param_1 + 0x1f10) = sVar11;
    *(byte *)(param_1 + 0x1f18) = *(byte *)(param_1 + 0x1f18) & 0xfe;
  }
  bVar14 = *(byte *)(param_1 + 0x1f30);
  if (*(short *)(param_1 + 0x1f28) == 0) {
    if ((bVar14 & 1) != 0) {
      sVar11 = (short)(int)(*(float *)(*(longlong *)(param_1 + 0x1f20) + 0x24) *
                            *(float *)(param_1 + 0x1f2c) * (float)*(byte *)(param_1 + 0x1f31));
      goto LAB_14010329f;
    }
  }
  else {
    sVar11 = *(short *)(param_1 + 0x1f28) + -1;
LAB_14010329f:
    bVar14 = bVar14 & 0xfe;
    *(short *)(param_1 + 0x1f28) = sVar11;
    *(byte *)(param_1 + 0x1f30) = bVar14;
  }
  arg1 = (ulonglong)bVar14;
  *(undefined1 *)(param_1 + 0x209e) = 0;
  if (*(char *)(param_1 + 0x2099) != '\0') {
    if (*(char *)(param_1 + 0x2099) == '\x01') {
      if (*(char *)(param_1 + 0x209c) == '\0') {
        if (*(short *)(param_1 + 0x1f10) == 0) {
          *(undefined1 *)(param_1 + 0x209e) = 1;
        }
      }
      else if ((*(char *)(param_1 + 0x209c) == '\x01') && (*(short *)(param_1 + 0x1f28) == 0)) {
        *(undefined1 *)(param_1 + 0x209e) = 2;
      }
    }
    else {
      if (*(short *)(param_1 + 0x1f10) == 0) {
        *(undefined1 *)(param_1 + 0x209e) = 1;
        uVar8 = 3;
      }
      else {
        uVar8 = 2;
      }
      if (*(short *)(param_1 + 0x1f28) == 0) {
        *(undefined1 *)(param_1 + 0x209e) = uVar8;
      }
    }
  }
  FUN_1401c56d0();
  uVar20 = *(uint *)(param_1 + 0xd48) & 0x20000;
  if (uVar20 == 0) {
    cVar10 = '\x02';
  }
  else {
    cVar10 = *(char *)(param_1 + 0xc3c);
  }
  bVar7 = false;
  bVar14 = (byte)(*(uint *)(param_1 + 0x2058) >> 5) & 1;
  if (*(char *)(param_1 + 0x2098) != '\0') {
    bVar14 = 1;
  }
  if (*(char *)(param_1 + 0x2099) == '\0') {
    bVar14 = 1;
LAB_140103377:
    *(undefined2 *)(param_1 + 0x20be) = 0;
    *(undefined1 *)(param_1 + 0x20c0) = 0;
  }
  else {
    if (bVar14 != 0) goto LAB_140103377;
    if (((*(char *)(param_1 + 0x1ec8) != '\0') && ((*(byte *)(param_1 + 0x1e55) & 2) != 0)) &&
       ((*(char *)(param_1 + 0x1e53) != -1 || (*(char *)(param_1 + 0x1e54) != -1)))) {
      bVar7 = true;
    }
  }
  uVar9 = FUN_140187c80(arg1,param_2,'\f');
  if (uVar9 == '\0') {
    if ((!bVar7) && (*(short *)(param_1 + 0x20be) != 0)) {
      sVar11 = *(short *)(param_1 + 0x20be) + -1;
      goto LAB_140103451;
    }
  }
  else {
    if ((*(char *)(param_1 + 0x2099) == '\0') && (*(char *)(param_1 + 0x2098) == '\0')) {
      FUN_1401c6150();
      *(undefined1 *)(param_1 + 0x20bc) = 3;
      return;
    }
    if (*(byte *)(param_1 + 0x20c0) < 2) {
      *(byte *)(param_1 + 0x20c0) = *(byte *)(param_1 + 0x20c0) + 1;
    }
    if (!bVar7) {
      sVar11 = (ushort)*(byte *)(param_1 + 0x20a0) << 2;
LAB_140103451:
      *(short *)(param_1 + 0x20be) = sVar11;
    }
  }
  if (bVar14 == 0) {
    if (bVar7) {
      if (((cVar10 == '\x03') || (cVar10 == '\0')) && (uVar20 != 0)) {
        *(undefined1 *)(param_1 + 0xc3c) = 1;
      }
    }
    else if (*(short *)(param_1 + 0x20be) == 0) {
      if ((byte)(cVar10 - 1U) < 2) {
        uVar20 = *(uint *)(param_1 + 0xd48) & 0x20000;
        goto LAB_1401034c2;
      }
    }
    else if (((cVar10 == '\x03') || (cVar10 == '\0')) &&
            ((*(uint *)(param_1 + 0xd48) & 0x20000) != 0)) {
      *(undefined1 *)(param_1 + 0xc3c) = 1;
    }
  }
  else if ((byte)(cVar10 - 1U) < 2) {
LAB_1401034c2:
    if (uVar20 != 0) {
      *(undefined1 *)(param_1 + 0xc3c) = 3;
    }
  }
  if ((*(byte *)(param_1 + 0x2058) & 0x20) != 0) {
    return;
  }
  if (*(char *)(param_1 + 0x2098) != '\0') {
    return;
  }
  if (cVar10 != '\x02') {
    return;
  }
  if (*(char *)(param_1 + 0x20c0) == '\0') {
    return;
  }
  *(char *)(param_1 + 0x20c0) = *(char *)(param_1 + 0x20c0) + -1;
  if (*(char *)(param_1 + 0x209c) == '\0') {
    sVar11 = *(short *)(param_1 + 0x1f10);
LAB_140103527:
    if (sVar11 != 0) {
      return;
    }
  }
  else if (*(char *)(param_1 + 0x209c) == '\x01') {
    sVar11 = *(short *)(param_1 + 0x1f28);
    goto LAB_140103527;
  }
  auVar22 = vcvtdq2ps_avx(ZEXT116(*(byte *)(param_1 + 0x20a0)));
  auVar39 = ZEXT464((uint)((*(float *)(param_1 + 0x1848) * DAT_1402d2360) / auVar22._0_4_));
  if ((*(char *)(param_1 + 0x1ec8) == '\0') || ((*(byte *)(param_1 + 0x1e55) & 2) == 0)) {
    bVar14 = 0xff;
    bVar18 = 0xff;
  }
  else {
    bVar14 = *(byte *)(param_1 + 0x1e53);
    bVar18 = *(byte *)(param_1 + 0x1e54);
  }
  _local_148 = ZEXT816(0);
  local_138 = ZEXT816(0);
  _local_118 = ZEXT816(0);
  local_128 = _local_148;
  FUN_140202920(local_148,param_1 + 0x80);
  puVar1 = (ushort *)(param_1 + 0x1bc);
  fVar28 = fStack_110 + *(float *)(param_1 + 0x78);
  uVar19 = *(ushort *)(param_1 + 0x1b8);
  fStack_14c = 0.0;
  auVar22 = ZEXT416((uint)DAT_1402d22d0);
  auVar37 = ZEXT416((uint)((float)local_118._0_4_ + *(float *)(param_1 + 0x70)));
  auVar40 = ZEXT416((uint)((float)local_118._4_4_ + *(float *)(param_1 + 0x74)));
  if (*(char *)(param_1 + 0x209c) != '\0') {
    if (((uVar19 < 0x43) || (*puVar1 < 0x43)) || (*(int *)(*(longlong *)(param_1 + 0x1d0) + 8) == 0)
       ) {
      local_108 = ZEXT832(0);
      auVar23 = ZEXT816(0);
      auVar34 = auVar22;
      auVar25 = auVar22;
      local_e8 = local_108;
      if (0x42 < uVar19) goto LAB_14010387f;
LAB_1401038c1:
      fVar27 = 0.0;
      fVar30 = 0.0;
      fVar31 = 0.0;
    }
    else {
      lVar15 = (ulonglong)**(ushort **)(*(longlong *)(param_1 + 0x1d8) + 0x10) * 800;
      auVar4 = *(undefined1 (*) [32])(lVar15 + 0x94 + *(longlong *)(param_1 + 0x1b0));
      local_e8 = *(undefined1 (*) [32])(lVar15 + 0xb4 + *(longlong *)(param_1 + 0x1b0));
      auVar23 = auVar4._0_16_;
      auVar25 = auVar4._16_16_;
      auVar34 = vshufps_avx(auVar23,auVar23,0x55);
      auVar26 = local_e8._0_16_;
      auVar23 = vshufps_avx(auVar26,auVar26,0x55);
      local_108 = ZEXT1632(auVar34);
      auVar34 = vshufps_avx(auVar26,auVar26,0xaa);
      auVar25 = vshufps_avx(auVar25,auVar25,0x55);
LAB_14010387f:
      if (*puVar1 < 0x43) goto LAB_1401038c1;
      if (*(int *)(*(longlong *)(param_1 + 0x1d0) + 8) == 0) goto LAB_1401038c1;
      lVar16 = (ulonglong)**(ushort **)(*(longlong *)(param_1 + 0x1d8) + 0x10) * 800;
      lVar15 = *(longlong *)(param_1 + 0x1b0);
      fVar27 = *(float *)(lVar16 + 0xc4 + lVar15);
      fVar30 = *(float *)(lVar16 + 200 + lVar15);
      fVar31 = *(float *)(lVar16 + 0xcc + lVar15);
    }
    auVar26 = ZEXT416(DAT_1402d2d64);
    if (auVar23._0_4_ <= DAT_1402d22d0) {
      auVar24 = vcmpss_avx(auVar23,auVar26,1);
      auVar23 = vblendvps_avx(auVar23,auVar26,auVar24);
    }
    else {
      auVar23 = auVar22;
    }
    auVar23 = vmaxss_avx(auVar23,auVar26);
    vminss_avx(auVar23,auVar22);
    auVar32 = ZEXT1264(ZEXT812(0)) << 0x20;
    auVar35 = ZEXT1664(auVar34);
    auVar36 = ZEXT1664(auVar25);
    auVar38 = ZEXT1664(auVar37);
    auVar39 = ZEXT1664(auVar39._0_16_);
    auVar41 = ZEXT1664(auVar40);
    uVar20 = FUN_140272150();
    local_158 = (float)(uVar20 ^ DAT_1402d3770);
    uVar20 = DAT_1402d3770;
    fStack_154 = (float)FUN_140272370(local_e8._0_4_,auVar35._0_8_);
    uVar21 = auVar36._0_8_;
    uVar42 = local_108._0_4_;
    goto LAB_14010392b;
  }
  if (((uVar19 < 0x42) || (*puVar1 < 0x42)) || (*(int *)(*(longlong *)(param_1 + 0x1d0) + 4) == 0))
  {
    local_108 = ZEXT832(0);
    auVar23 = ZEXT816(0);
    auVar34 = auVar22;
    auVar25 = auVar22;
    local_e8 = local_108;
    if (0x41 < uVar19) goto LAB_140103715;
LAB_140103756:
    fVar27 = 0.0;
    fVar30 = 0.0;
    fVar31 = 0.0;
  }
  else {
    lVar15 = (ulonglong)**(ushort **)(*(longlong *)(param_1 + 0x1d8) + 8) * 800;
    auVar4 = *(undefined1 (*) [32])(lVar15 + 0x94 + *(longlong *)(param_1 + 0x1b0));
    local_108 = *(undefined1 (*) [32])(lVar15 + 0xb4 + *(longlong *)(param_1 + 0x1b0));
    auVar23 = auVar4._0_16_;
    auVar25 = auVar4._16_16_;
    auVar34 = vshufps_avx(auVar23,auVar23,0x55);
    auVar26 = local_108._0_16_;
    auVar23 = vshufps_avx(auVar26,auVar26,0x55);
    local_e8 = ZEXT1632(auVar34);
    auVar34 = vshufps_avx(auVar26,auVar26,0xaa);
    auVar25 = vshufps_avx(auVar25,auVar25,0x55);
LAB_140103715:
    if (*puVar1 < 0x42) goto LAB_140103756;
    if (*(int *)(*(longlong *)(param_1 + 0x1d0) + 4) == 0) goto LAB_140103756;
    lVar16 = (ulonglong)**(ushort **)(*(longlong *)(param_1 + 0x1d8) + 8) * 800;
    lVar15 = *(longlong *)(param_1 + 0x1b0);
    fVar27 = *(float *)(lVar16 + 0xc4 + lVar15);
    fVar30 = *(float *)(lVar16 + 200 + lVar15);
    fVar31 = *(float *)(lVar16 + 0xcc + lVar15);
  }
  auVar24 = ZEXT416(DAT_1402d2d64);
  auVar26 = auVar22;
  if (auVar23._0_4_ <= DAT_1402d22d0) {
    auVar26 = vcmpss_avx(auVar23,auVar24,1);
    auVar26 = vblendvps_avx(auVar23,auVar24,auVar26);
  }
  auVar23 = vmaxss_avx(auVar26,auVar24);
  vminss_avx(auVar23,auVar22);
  auVar32 = ZEXT1264(ZEXT812(0)) << 0x20;
  auVar35 = ZEXT1664(auVar34);
  auVar36 = ZEXT1664(auVar25);
  auVar38 = ZEXT1664(auVar37);
  auVar39 = ZEXT1664(auVar39._0_16_);
  auVar41 = ZEXT1664(auVar40);
  uVar20 = FUN_140272150();
  local_158 = (float)(uVar20 ^ DAT_1402d3770);
  uVar20 = DAT_1402d3770;
  fStack_154 = (float)FUN_140272370(local_108._0_4_,auVar35._0_8_);
  uVar21 = auVar36._0_8_;
  uVar42 = local_e8._0_4_;
LAB_14010392b:
  fStack_150 = (float)FUN_140272370(uVar42,uVar21);
  FUN_140203050(&local_158,param_1 + 0x80,&local_158);
  auVar4 = local_108;
  lVar15 = *(longlong *)(param_1 + 0x1fc8);
  if (lVar15 != 0) {
    local_108._4_4_ = fStack_154;
    local_108._0_4_ = local_158;
    local_108._12_4_ = fStack_14c;
    local_108._8_4_ = fStack_150;
    lVar16 = *(longlong *)(param_1 + 0x1fb8);
    local_108._16_16_ = auVar4._16_16_;
    auVar35 = ZEXT464((uint)(((float)*(int *)(lVar16 + 0x44) * DAT_1402d2358) /
                             (float)*(byte *)(param_1 + 0x20a0) + auVar39._0_4_));
    auVar22 = vshufps_avx(local_138,local_138,0x55);
    auVar37 = vshufps_avx(local_128,local_128,0x55);
    fStack_154 = fVar30 * auVar22._0_4_ + fVar27 * (float)local_148._4_4_ +
                 fVar31 * auVar37._0_4_ + auVar41._0_4_;
    auVar22 = vshufps_avx(local_138,local_138,0xaa);
    auVar37 = vshufps_avx(local_128,local_128,0xaa);
    fStack_150 = fVar30 * auVar22._0_4_ + fVar27 * fStack_140 + fVar31 * auVar37._0_4_ + fVar28;
    auVar22 = vshufps_avx(local_138,local_138,0xff);
    auVar37 = vshufps_avx(local_128,local_128,0xff);
    fStack_14c = fVar30 * auVar22._0_4_ + fVar27 * fStack_13c + fVar31 * auVar37._0_4_ + fStack_10c;
    local_158 = fVar30 * local_138._0_4_ + fVar27 * (float)local_148._0_4_ +
                fVar31 * local_128._0_4_ + auVar38._0_4_;
    uVar12 = FUN_14013d140(lVar15,&local_158,local_108,auVar39._0_8_,
                           *(undefined1 *)(param_1 + 0x20a1),*(undefined1 *)(param_1 + 0x20a2),
                           bVar14,bVar18,lVar16,
                           *(undefined1 *)(*(longlong *)(param_1 + 0xff8) + 0xb));
    uVar42 = (undefined4)((ulonglong)lVar16 >> 0x20);
    uVar33 = auVar35._0_4_;
    if (-1 < (int)uVar12) {
      *(undefined1 *)(lVar15 + 0x1fd90) = 0;
    }
    if (uVar12 != 0xffffffff) {
      if (*(char *)(param_1 + 0x209c) == '\0') {
        *(byte *)(param_1 + 0x1f18) = *(byte *)(param_1 + 0x1f18) | 1;
      }
      else if (*(char *)(param_1 + 0x209c) == '\x01') {
        *(byte *)(param_1 + 0x1f30) = *(byte *)(param_1 + 0x1f30) | 1;
      }
      pcVar2 = (char *)(param_1 + 0x2099);
      *pcVar2 = *pcVar2 + -1;
      if (*pcVar2 == '\0') {
        FUN_1400c04e0(param_1 + 0x1e38,0);
        uVar33 = auVar35._0_4_;
      }
      puVar3 = (uint *)((ulonglong)bVar5 * 0x520 + lVar17 + 0x1fc);
      *puVar3 = *puVar3 | 1;
      if (((bVar14 != 0xff) && (bVar18 != 0xff)) &&
         ((*(longlong **)(param_1 + 0x2040) != (longlong *)0x0 &&
          (lVar17 = *(longlong *)
                     (*(longlong *)(**(longlong **)(param_1 + 0x2040) + (ulonglong)bVar14 * 8) +
                     0x110) + (ulonglong)bVar18 * 0x520, lVar17 != 0)))) {
        uVar8 = *(undefined1 *)(param_1 + 0x20a2);
        *(undefined1 *)(lVar17 + 0x238) = *(undefined1 *)(param_1 + 0x20a1);
        *(undefined1 *)(lVar17 + 0x239) = uVar8;
      }
      lVar17 = *(longlong *)(param_1 + 0x1fd0);
      if (((lVar17 != 0) && ((*(byte *)(lVar17 + 0x2a6) & 4) == 0)) &&
         ((*(longlong *)(lVar17 + 0x288) == 0 ||
          (*(byte *)(*(longlong *)(lVar17 + 0x288) + 0x37) < 2)))) {
        lVar15 = *(longlong *)(lVar17 + 0x280);
        *(undefined2 *)(lVar17 + 0x2a8) = 0;
        *(byte *)(lVar17 + 0x2aa) = bVar14;
        *(byte *)(lVar17 + 0x2ab) = bVar18;
        *(undefined2 *)(lVar17 + 0x2ac) = 0;
        *(undefined1 *)(lVar17 + 0x2a6) = 5;
        *(char *)(lVar17 + 0x2a7) = (char)uVar12;
        *(undefined2 *)(lVar17 + 0x2a0) = 0;
        *(undefined2 *)(lVar17 + 0x2a4) = 0;
        lVar16 = ((ulonglong)uVar12 & 0xff) * 0x58;
        *(undefined4 *)(lVar17 + 0x1c0) = *(undefined4 *)(lVar16 + 0x158 + lVar15);
        *(undefined4 *)(lVar17 + 0x1c4) = *(undefined4 *)(lVar16 + 0x15c + lVar15);
        *(undefined4 *)(lVar17 + 0x1c8) = *(undefined4 *)(lVar16 + 0x160 + lVar15);
        *(undefined4 *)(lVar17 + 0x1cc) = *(undefined4 *)(lVar16 + 0x164 + lVar15);
        *(undefined1 *)(lVar17 + 0x2b9) = 0;
      }
      if (*(char *)(param_1 + 0x2094) == '\x01') {
        uVar19 = 99;
      }
      else {
        uVar19 = 0x62;
        if (*(char *)(param_1 + 0x2094) == '\0') {
          uVar19 = 0x61;
        }
      }
      _local_148 = ZEXT816(0);
      local_138 = ZEXT816(0);
      fVar28 = (float)(uVar33 ^ uVar20);
      local_128 = _local_148;
      _local_118 = local_138;
      uVar21 = FUN_140202920(local_148,param_1 + 0x80);
      uVar29 = auVar32._0_4_;
      auVar22 = vshufps_avx(local_128,local_128,0x55);
      auVar37 = vshufps_avx(_local_118,_local_118,0x55);
      fStack_154 = fVar28 * auVar22._0_4_ + auVar37._0_4_;
      auVar32 = ZEXT1664(CONCAT124(auVar37._4_12_,fStack_154));
      auVar22 = vshufps_avx(local_128,local_128,0xaa);
      local_158 = fVar28 * local_128._0_4_ + local_118._0_4_;
      auVar39 = ZEXT1664(CONCAT124(local_118._4_12_,local_158));
      auVar37 = vshufps_avx(local_128,local_128,0xff);
      auVar40 = vshufps_avx(_local_118,_local_118,0xaa);
      auVar23 = vshufps_avx(_local_118,_local_118,0xff);
      fStack_14c = fVar28 * auVar37._0_4_ + auVar23._0_4_;
      auVar36 = ZEXT1664(CONCAT124(auVar23._4_12_,fStack_14c));
      fStack_150 = fVar28 * auVar22._0_4_ + auVar40._0_4_;
      auVar35 = ZEXT1664(CONCAT124(auVar40._4_12_,fStack_150));
      cVar10 = FUN_1401c6a00(uVar21,1,uVar19,param_1 + 0x70,&local_158,uVar29,uVar29,uVar29,
                             CONCAT44(uVar42,uVar29),0,0);
      if ((((cVar10 != '\0') && (lVar17 = FUN_1401c97a0(), '\x01' < *(char *)(lVar17 + 0x3dc2))) &&
          (uVar6 = *(ushort *)(lVar17 + 0x138),
          (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar6 * 0x18) + 0x12 +
                     (ulonglong)uVar19 * 0x50) & 1) != 0)) &&
         (puVar13 = (undefined4 *)FUN_1401c9e60(lVar17), puVar13 != (undefined4 *)0x0)) {
        *(ushort *)(puVar13 + 0x11) = uVar6;
        *(ushort *)((longlong)puVar13 + 0x46) = uVar19;
        *puVar13 = *(undefined4 *)(param_1 + 0x70);
        puVar13[1] = *(undefined4 *)(param_1 + 0x74);
        puVar13[2] = *(undefined4 *)(param_1 + 0x78);
        uVar42 = *(undefined4 *)(param_1 + 0x7c);
        puVar13[4] = auVar39._0_4_;
        puVar13[5] = auVar32._0_4_;
        puVar13[6] = auVar35._0_4_;
        puVar13[7] = auVar36._0_4_;
        puVar13[3] = uVar42;
        *(undefined8 *)(puVar13 + 8) = 0;
        puVar13[10] = 0;
        puVar13[0xb] = 0x3f800000;
        puVar13[0xf] = 0x3f800000;
        *(undefined2 *)((longlong)puVar13 + 0x4a) = 0;
        *(byte *)(puVar13 + 0x1c) = *(byte *)(puVar13 + 0x1c) & 0xee | 6;
        *(code **)(puVar13 + 0xc) = FUN_1401caa00;
      }
      *(bool *)(param_1 + 0x209c) = *(char *)(param_1 + 0x209c) == '\0';
    }
  }
  return;
}

