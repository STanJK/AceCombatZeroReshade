/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140005380; RVA 0x5380
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140005380(float *param_1,longlong param_2)

{
  short sVar1;
  short sVar2;
  undefined2 uVar3;
  bool bVar4;
  undefined1 auVar5 [16];
  float fVar6;
  longlong lVar7;
  float fVar8;
  undefined1 extraout_var [56];
  undefined1 auVar9 [64];
  undefined1 auVar10 [16];
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  longlong lStack_98;
  longlong lStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  
  lVar7 = DAT_14032c8b8;
  sVar1 = *(short *)(DAT_14032c8b8 + 0x108);
  sVar2 = *(short *)(DAT_14032c8b8 + 0x10a);
  uVar3 = *(undefined2 *)(DAT_14032c8b8 + 0x104);
  param_1[0x98] = (float)((uint)param_1[0x98] | 3);
  param_1[0x30] = (float)(int)sVar1;
  param_1[0x31] = (float)(int)sVar2;
  param_1[0x38] = 16777215.0;
  param_1[0x39] = 0.0;
  *(short *)(param_1 + 0x3a) = sVar1;
  *(short *)((longlong)param_1 + 0xea) = sVar2;
  param_1[0x32] = 512.0;
  param_1[0x33] = 1.0;
  param_1[0x34] = 65535.0;
  param_1[0x35] = 0.0;
  param_1[0x3b] = 65535.0;
  *(short *)(param_1 + 0x36) = sVar1;
  *(short *)((longlong)param_1 + 0xda) = sVar2;
  param_1[0x37] = 1.0;
  *(undefined2 *)((longlong)param_1 + 0x272) = *(undefined2 *)(lVar7 + 0xdc);
  *(undefined2 *)(param_1 + 0x9c) = uVar3;
  lVar7 = FUN_140189320();
  if (*(char *)(lVar7 + 0x28) != '\0') {
    param_1[0x30] = param_1[0x30] * DAT_1402d2348;
  }
  fVar8 = param_1[0xa1];
  if ((int)param_1[0xa4] < (int)param_1[0xa3]) {
    fVar8 = ((fVar8 - param_1[0xa0]) * (float)(int)param_1[0xa4]) / (float)(int)param_1[0xa3] +
            param_1[0xa0];
  }
  else {
    param_1[0xa0] = fVar8;
  }
  param_1[0xa2] = fVar8;
  fVar8 = param_1[0xa6];
  if ((int)param_1[0xa9] < (int)param_1[0xa8]) {
    fVar8 = ((fVar8 - param_1[0xa5]) * (float)(int)param_1[0xa9]) / (float)(int)param_1[0xa8] +
            param_1[0xa5];
  }
  else {
    param_1[0xa5] = fVar8;
  }
  param_1[0xa7] = fVar8;
  fVar8 = param_1[0xab];
  if ((int)param_1[0xae] < (int)param_1[0xad]) {
    fVar8 = ((fVar8 - param_1[0xaa]) * (float)(int)param_1[0xae]) / (float)(int)param_1[0xad] +
            param_1[0xaa];
  }
  else {
    param_1[0xaa] = fVar8;
  }
  param_1[0xac] = fVar8;
  if ((int)param_1[0xa4] < (int)param_1[0xa3]) {
    param_1[0xa4] = (float)((int)param_1[0xa4] + 1);
  }
  if ((int)param_1[0xa9] < (int)param_1[0xa8]) {
    param_1[0xa9] = (float)((int)param_1[0xa9] + 1);
  }
  if ((int)param_1[0xae] < (int)param_1[0xad]) {
    param_1[0xae] = (float)((int)param_1[0xae] + 1);
  }
  fVar8 = param_1[0xb2];
  fVar6 = param_1[0xb3];
  if ((int)fVar6 < (int)fVar8) {
    fVar6 = (float)((int)fVar6 + 1);
    param_1[0xb3] = fVar6;
  }
  fVar11 = param_1[0xb0];
  if ((int)fVar6 < (int)fVar8) {
    fVar11 = ((fVar11 - param_1[0xaf]) * (float)(int)fVar6) / (float)(int)fVar8 + param_1[0xaf];
  }
  else {
    param_1[0xaf] = fVar11;
  }
  param_1[0xb1] = fVar11;
  fVar8 = param_1[0xb7];
  fVar6 = param_1[0xb8];
  if ((int)fVar6 < (int)fVar8) {
    fVar6 = (float)((int)fVar6 + 1);
    param_1[0xb8] = fVar6;
  }
  fVar11 = param_1[0xb5];
  if ((int)fVar6 < (int)fVar8) {
    fVar11 = ((fVar11 - param_1[0xb4]) * (float)(int)fVar6) / (float)(int)fVar8 + param_1[0xb4];
  }
  else {
    param_1[0xb4] = fVar11;
  }
  param_1[0xb6] = fVar11;
  if (param_2 != 0) {
    fVar8 = param_1[0xa2];
    *(float *)(param_2 + 0x5c14) = param_1[0xac];
    *(float *)(param_2 + 0x5c10) = fVar8;
    *(float *)(param_2 + 0x5c18) = param_1[0xb6];
  }
  if (*(char *)(param_1 + 0xb9) != '\0') {
    param_1[0xbb] = param_1[0xba] + param_1[0xbb];
  }
  fVar6 = DAT_1402d249c;
  fVar8 = param_1[0xbb];
  if (DAT_1402d2420 < fVar8) {
    fVar8 = fVar8 - DAT_1402d249c;
    param_1[0xbb] = fVar8;
  }
  if (fVar8 < DAT_1402d2db4) {
    fVar8 = fVar8 + fVar6;
    param_1[0xbb] = fVar8;
  }
  fVar12 = (float)((uint)param_1[0xb1] ^ DAT_1402d3770);
  auVar10._4_12_ = SUB1612(ZEXT816(0),4);
  auVar10._0_4_ = fVar12;
  auVar9._0_8_ = FUN_14026f3f3(fVar8,auVar10._0_8_);
  fVar13 = DAT_1402d2e2c;
  auVar9._8_56_ = extraout_var;
  auVar10 = vpermilps_avx(auVar9._0_16_,0xe);
  auVar5 = vpermilps_avx(auVar10,1);
  fVar6 = auVar5._0_4_ * DAT_1402d2698;
  auVar5 = vpermilps_avx(auVar9._0_16_,1);
  fVar11 = auVar10._0_4_ * DAT_1402d2e2c;
  if (param_2 != 0) {
    fVar11 = (DAT_1402d287c / *(float *)(param_2 + 0x5c18)) * param_1[0xa7] *
             *(float *)(param_2 + 0x5c1c) + fVar11;
  }
  param_1[0x3f] = 1.0;
  param_1[0x3c] = (float)auVar9._0_8_ * fVar6;
  param_1[0x3e] = auVar5._0_4_ * fVar6;
  param_1[0x3d] = fVar11;
  param_1[0x40] = fVar12;
  param_1[0x41] = fVar8;
  param_1[0x42] = 0.0;
  param_1[0x43] = 0.0;
  FUN_1401fbec0(param_1 + 0x30);
  local_88 = *(undefined8 *)(param_1 + 0x74);
  uStack_80 = *(undefined8 *)(param_1 + 0x76);
  uStack_78 = *(undefined8 *)(param_1 + 0x78);
  uStack_70 = *(undefined8 *)(param_1 + 0x7a);
  local_68 = *(undefined8 *)(param_1 + 0x7c);
  uStack_60 = *(undefined8 *)(param_1 + 0x7e);
  uStack_58 = *(undefined8 *)(param_1 + 0x80);
  uStack_50 = *(undefined8 *)(param_1 + 0x82);
  local_c8 = _DAT_1402d38a0;
  uStack_c0 = _UNK_1402d38a8;
  uStack_b8 = _UNK_1402d38b0;
  uStack_b0 = _UNK_1402d38b8;
  local_a8 = _DAT_1402d4160;
  uStack_a0 = _UNK_1402d4168;
  lStack_98 = _UNK_1402d4170;
  lStack_90 = _UNK_1402d4178;
  FUN_140005940(&local_c8,&local_c8,&local_88);
  *(undefined8 *)(param_1 + 0x10) = local_c8;
  *(undefined8 *)(param_1 + 0x12) = uStack_c0;
  *(undefined8 *)(param_1 + 0x14) = uStack_b8;
  *(undefined8 *)(param_1 + 0x16) = uStack_b0;
  *(undefined8 *)(param_1 + 0x18) = local_a8;
  *(undefined8 *)(param_1 + 0x1a) = uStack_a0;
  *(longlong *)(param_1 + 0x1c) = lStack_98;
  *(longlong *)(param_1 + 0x1e) = lStack_90;
  local_88 = *(undefined8 *)(param_1 + 0x84);
  uStack_80 = *(undefined8 *)(param_1 + 0x86);
  uStack_78 = *(undefined8 *)(param_1 + 0x88);
  uStack_70 = *(undefined8 *)(param_1 + 0x8a);
  local_68 = *(undefined8 *)(param_1 + 0x8c);
  uStack_60 = *(undefined8 *)(param_1 + 0x8e);
  uStack_58 = *(undefined8 *)(param_1 + 0x90);
  uStack_50 = *(undefined8 *)(param_1 + 0x92);
  local_c8 = _DAT_1402d38a0;
  uStack_c0 = _UNK_1402d38a8;
  uStack_b8 = _UNK_1402d38b0;
  uStack_b0 = _UNK_1402d38b8;
  local_a8 = _DAT_1402d3190;
  uStack_a0 = _UNK_1402d3198;
  lStack_98 = (ulonglong)(uint)(fVar13 / param_1[0x31]) << 0x20;
  lStack_90 = (ulonglong)DAT_1402d22d0 << 0x20;
  FUN_140005940(&local_c8,&local_c8,&local_88);
  bVar4 = DAT_1402d2abc <= param_1[0xb6];
  *(undefined8 *)(param_1 + 0x20) = local_c8;
  *(undefined8 *)(param_1 + 0x22) = uStack_c0;
  *(undefined8 *)(param_1 + 0x24) = uStack_b8;
  *(undefined8 *)(param_1 + 0x26) = uStack_b0;
  *(undefined8 *)(param_1 + 0x28) = local_a8;
  *(undefined8 *)(param_1 + 0x2a) = uStack_a0;
  *(longlong *)(param_1 + 0x2c) = lStack_98;
  *(longlong *)(param_1 + 0x2e) = lStack_90;
  if (bVar4) {
    fVar8 = DAT_1402d23c0;
  }
  else {
    fVar8 = DAT_1402d2af0 / param_1[0xb6];
  }
  *param_1 = fVar8;
  param_1[5] = fVar8;
  param_1[10] = fVar8;
  return;
}

