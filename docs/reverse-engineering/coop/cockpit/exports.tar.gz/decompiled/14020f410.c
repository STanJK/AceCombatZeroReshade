/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020f410; RVA 0x20f410
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14020f410(int param_1,byte param_2,int param_3)

{
  int iVar1;
  longlong lVar2;
  code *pcVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined4 uVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  longlong lVar15;
  undefined8 ******ppppppuVar16;
  longlong lVar17;
  undefined1 auStackY_348 [32];
  int iStack_318;
  undefined4 uStack_314;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  longlong lStack_308;
  longlong lStack_300;
  undefined1 auStack_2f8 [12];
  undefined4 uStack_2ec;
  undefined8 auStack_2e8 [82];
  undefined8 ******appppppuStack_58 [2];
  undefined8 uStack_48;
  ulonglong uStack_40;
  ulonglong uStack_38;
  
  if (param_1 == 4) {
    DAT_14031e0e8 = param_1;
    return;
  }
  DAT_14031e3a8 = 0;
  if (((DAT_14031e0e8 != param_1) || (DAT_14031e3ac != param_2)) || (DAT_14031e3b0 != param_3)) {
    DAT_14031e110 = 1;
    DAT_14031e0e8 = param_1;
    DAT_14031e3ac = param_2;
    DAT_14031e3b0 = param_3;
    if (param_1 == 3) {
      _DAT_14031e308 = 0;
      DAT_14031e314 = 0;
      return;
    }
    _DAT_14031e308 = 1;
    DAT_14031e314 = 1;
    _DAT_14031e310 = *(undefined4 *)(&DAT_1402ce1f0 + (longlong)param_1 * 4);
    _DAT_14031e30c = (uint)param_2;
    if (param_3 == 1) {
      _DAT_14031e328 = 6;
      _DAT_14031e334 = CONCAT44(6,_DAT_14031e334);
    }
    else if (param_3 == 2) {
      _DAT_14031e328 = 3;
      _DAT_14031e334 = CONCAT44(3,_DAT_14031e334);
    }
    else {
      _DAT_14031e328 = 8;
      _DAT_14031e334 = CONCAT44(8,_DAT_14031e334);
      if (param_3 == 0) {
        DAT_14031e110 = 1;
        _DAT_14031e308 = 1;
        DAT_14031e314 = 1;
        _DAT_14031e328 = 8;
        DAT_14031e3a8 = 0;
        return;
      }
    }
    if (DAT_14030f270 == 0) {
      uStack_38 = DAT_140309040 ^ (ulonglong)auStackY_348;
      iStack_318 = *(int *)(DAT_140356730 + -4);
      if (iStack_318 != -1) {
        plVar12 = (longlong *)FUN_140211b80(&DAT_1403566e8,auStack_2f8,&iStack_318);
        lVar2 = *plVar12;
        if ((*(char *)(lVar2 + 0x79) != '\0') && (*(int *)(lVar2 + 0x90) != -1)) {
          lVar17 = 5;
          lVar15 = 5;
          *(undefined1 *)(lVar2 + 0x79) = 0;
          puVar10 = (undefined8 *)&DAT_14031e118;
          puVar11 = auStack_2e8;
          do {
            puVar14 = puVar11;
            puVar13 = puVar10;
            uVar6 = puVar13[1];
            uVar7 = puVar13[2];
            uVar8 = puVar13[3];
            uVar4 = puVar13[0xe];
            uVar5 = puVar13[0xf];
            *puVar14 = *puVar13;
            puVar14[1] = uVar6;
            puVar14[2] = uVar7;
            puVar14[3] = uVar8;
            uVar6 = puVar13[5];
            uVar7 = puVar13[6];
            uVar8 = puVar13[7];
            puVar14[4] = puVar13[4];
            puVar14[5] = uVar6;
            puVar14[6] = uVar7;
            puVar14[7] = uVar8;
            uVar6 = puVar13[9];
            uVar7 = puVar13[10];
            uVar8 = puVar13[0xb];
            puVar14[8] = puVar13[8];
            puVar14[9] = uVar6;
            puVar14[10] = uVar7;
            puVar14[0xb] = uVar8;
            uVar6 = puVar13[0xd];
            puVar14[0xc] = puVar13[0xc];
            puVar14[0xd] = uVar6;
            puVar14[0xe] = uVar4;
            puVar14[0xf] = uVar5;
            lVar15 = lVar15 + -1;
            puVar10 = puVar13 + 0x10;
            puVar11 = puVar14 + 0x10;
          } while (lVar15 != 0);
          uVar4 = puVar13[0x11];
          puVar14[0x10] = puVar13[0x10];
          puVar14[0x11] = uVar4;
          FUN_1402082b0(appppppuStack_58,&DAT_14031e0f0);
          uVar9 = DAT_14031e0d0;
          uStack_30c = DAT_14031e0d4;
          uStack_310 = DAT_14031e0d8;
          uStack_314 = DAT_14031e0dc;
          plVar12 = *(longlong **)(DAT_14033da48 + 0x10);
          FUN_14020e490(iStack_318);
          FUN_14020e550(iStack_318,0,0);
          puVar10 = DAT_14033da70;
          iVar1 = *(int *)(lVar2 + 0x90);
          (**(code **)(*(longlong *)*DAT_14033da70 + 0x48))((longlong *)*DAT_14033da70,&lStack_308);
          lStack_300 = iVar1 * *(int *)(puVar10 + 1) + lStack_308;
          (**(code **)(*plVar12 + 0x170))(plVar12,0,0,0);
          DAT_1403566e0 = 0x14;
          DAT_1403566dc = 0;
          DAT_1403566d8 = *(undefined4 *)(lVar2 + 0xa0);
          FUN_14020f500(&DAT_14031e438);
          DAT_14031e324 = 2;
          _DAT_14031e328 = 3;
          _DAT_14031e32c = _DAT_14031e31c;
          _DAT_14031e334 = 0x300000002;
          _DAT_14031e308 = 0;
          _DAT_14031e30c = 1;
          _DAT_14031e310 = 2;
          DAT_14031e314 = 1;
          DAT_14031e198 = 0;
          _DAT_14031e1a0 = 1;
          _DAT_14031e1a4 = 2;
          DAT_14031e1ac = 1;
          _DAT_14031e1b0 = 2;
          _DAT_14031e1a8 = 1;
          _DAT_14031e1b4 = 1;
          _DAT_14031e340 = 0;
          _DAT_14031e348 = 0;
          _DAT_14031e34c = uStack_2ec;
          _DAT_14031e358 = 0;
          DAT_14031e110 = 1;
          FUN_14020f600(0);
          FUN_140209d40(&DAT_14031e0d0);
          puVar10 = DAT_14033da58;
          iVar1 = *(int *)(lVar2 + 0x4c);
          pcVar3 = *(code **)(*plVar12 + 0x100);
          (**(code **)(*(longlong *)*DAT_14033da58 + 0x50))((longlong *)*DAT_14033da58,&lStack_308);
          (*pcVar3)(plVar12,0,iVar1 * *(int *)(puVar10 + 1) + lStack_308);
          (**(code **)(*plVar12 + 0x60))(plVar12,3,1,0);
          puVar10 = auStack_2e8;
          puVar11 = (undefined8 *)&DAT_14031e118;
          do {
            puVar14 = puVar11;
            puVar13 = puVar10;
            uVar6 = puVar13[1];
            uVar7 = puVar13[2];
            uVar8 = puVar13[3];
            uVar4 = puVar13[0xe];
            uVar5 = puVar13[0xf];
            *puVar14 = *puVar13;
            puVar14[1] = uVar6;
            puVar14[2] = uVar7;
            puVar14[3] = uVar8;
            uVar6 = puVar13[5];
            uVar7 = puVar13[6];
            uVar8 = puVar13[7];
            puVar14[4] = puVar13[4];
            puVar14[5] = uVar6;
            puVar14[6] = uVar7;
            puVar14[7] = uVar8;
            uVar6 = puVar13[9];
            uVar7 = puVar13[10];
            uVar8 = puVar13[0xb];
            puVar14[8] = puVar13[8];
            puVar14[9] = uVar6;
            puVar14[10] = uVar7;
            puVar14[0xb] = uVar8;
            uVar6 = puVar13[0xd];
            puVar14[0xc] = puVar13[0xc];
            puVar14[0xd] = uVar6;
            puVar14[0xe] = uVar4;
            puVar14[0xf] = uVar5;
            lVar17 = lVar17 + -1;
            puVar10 = puVar13 + 0x10;
            puVar11 = puVar14 + 0x10;
          } while (lVar17 != 0);
          uVar4 = puVar13[0x11];
          ppppppuVar16 = appppppuStack_58;
          if (0xf < uStack_40) {
            ppppppuVar16 = appppppuStack_58[0];
          }
          puVar14[0x10] = puVar13[0x10];
          puVar14[0x11] = uVar4;
          DAT_14031e110 = 1;
          FUN_140212710(&DAT_14031e0f0,ppppppuVar16,uStack_48);
          FUN_14020e000(iStack_318,*(undefined4 *)(lVar2 + 0x98),*(undefined4 *)(lVar2 + 0x9c),0);
          FUN_14020eeb0(uVar9,uStack_30c);
          if (0xf < uStack_40) {
            if ((0xfff < uStack_40 + 1) &&
               (0x1f < (ulonglong)
                       ((longlong)appppppuStack_58[0] + (-8 - (longlong)appppppuStack_58[0][-1]))))
            {
                    /* WARNING: Subroutine does not return */
              _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
            }
            thunk_FUN_1402500f0();
          }
        }
      }
      return;
    }
  }
  return;
}

