/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b2d00; RVA 0xb2d00
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1400b2d00(longlong param_1,undefined8 param_2,longlong param_3,longlong *param_4,int *param_5)

{
  longlong lVar1;
  longlong lVar2;
  int iVar3;
  int iVar4;
  byte *pbVar5;
  char cVar6;
  float *pfVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined4 uVar14;
  float fVar15;
  float fVar16;
  undefined1 auStack_178 [32];
  undefined8 local_158;
  float local_150;
  float local_148;
  float local_140;
  float local_138;
  float local_130;
  undefined1 local_128;
  undefined1 local_127;
  undefined1 local_126;
  undefined1 local_125;
  undefined4 local_11c;
  undefined8 local_10c;
  undefined1 local_104;
  undefined1 local_103;
  undefined1 local_102;
  undefined1 local_101;
  undefined4 local_f8;
  undefined8 local_e8;
  ulonglong local_d8;
  
  local_d8 = DAT_140309040 ^ (ulonglong)auStack_178;
  if (((*(char *)(param_1 + 0x3b2) != '\x03') || (*(char *)(param_1 + 0xfc) != '\x01')) &&
     (iVar4 = 0, *(char *)(param_1 + 0xec) != '\0')) {
    pbVar5 = (byte *)(param_1 + 0xe4);
    pfVar7 = (float *)(param_1 + 0xb0);
    fVar12 = DAT_1402d2544;
    uVar14 = DAT_1402d22d0;
    fVar16 = DAT_1402d2868;
    do {
      if ((((pbVar5[-4] & 1) != 0) &&
          (lVar1 = *(longlong *)(*param_4 + (ulonglong)*pbVar5 * 8),
          (&DAT_1402accc0)
          [(ulonglong)*(byte *)(lVar1 + 0x15d) +
           (ulonglong)
           *(byte *)(*(longlong *)(*param_4 + (ulonglong)*(byte *)(param_1 + 0x3ca) * 8) + 0x15d) *
           8] != '\0')) && ((pbVar5[-4] & 2) == 0)) {
        fVar11 = *(float *)(param_3 + 0x19c);
        fVar10 = *(float *)(param_3 + 0x198);
        fVar9 = *(float *)(param_1 + 0x54);
        fVar13 = (fVar11 / fVar10) * fVar12;
        fVar15 = (float)*param_5;
        fVar8 = (float)FUN_140275cc0(pfVar7[4] - *(float *)(param_1 + 0x58));
        fVar8 = -(fVar10 * fVar8 * *(float *)(param_3 + 8)) + fVar16;
        fVar10 = fVar13 * DAT_1402d2168;
        fVar9 = (float)FUN_140275cc0(*pfVar7 - fVar9);
        lVar1 = *(longlong *)(lVar1 + 0x110);
        lVar2 = **(longlong **)((ulonglong)pbVar5[4] * 0x520 + 0x1a0 + lVar1);
        if (lVar2 == 0) {
LAB_1400b2f26:
          cVar6 = '\x03';
        }
        else {
          cVar6 = *(char *)(lVar2 + 0x71);
          if (cVar6 == '\0') {
            cVar6 = *(char *)((ulonglong)pbVar5[4] * 0x520 + 0x42b + lVar1);
            if (cVar6 == '\x01') {
              cVar6 = '\x01';
            }
            else {
              if (cVar6 != '\x02') goto LAB_1400b2f26;
              cVar6 = '\x02';
            }
          }
        }
        local_126 = *(undefined1 *)(param_1 + 0x24e);
        local_125 = *(undefined1 *)(param_1 + 0x24f);
        local_127 = *(undefined1 *)(param_1 + 0x24d);
        local_128 = *(undefined1 *)(param_1 + 0x24c);
        iVar3 = 0x4f;
        if (cVar6 != '\x01') {
          iVar3 = 0x61;
        }
        local_150 = (float)iVar3;
        iVar3 = 0x92;
        if (*(char *)(param_1 + 0xfc) != '\0') {
          iVar3 = 0xa4;
        }
        local_10c = 0xfffffff;
        local_e8 = 0xfffffff;
        local_158 = CONCAT44(local_158._4_4_,(float)iVar3);
        local_148 = fVar12;
        local_140 = fVar13;
        local_138 = fVar12;
        local_130 = fVar12;
        local_11c = uVar14;
        local_104 = local_128;
        local_103 = local_127;
        local_102 = local_126;
        local_101 = local_125;
        local_f8 = uVar14;
        FUN_1400ad600(&local_128,&local_104,fVar15 + fVar8,
                      (DAT_1402d2840 - (fVar11 * fVar9 * *(float *)(param_3 + 8) + fVar10)) +
                      (float)param_5[1]);
        local_158 = *(undefined8 *)(*(longlong *)(param_1 + 0x300) + 0x398);
        param_2 = FUN_1401fe080(param_2,0x156,2,&local_128);
      }
      iVar4 = iVar4 + 1;
      pfVar7 = pfVar7 + 1;
      pbVar5 = pbVar5 + 1;
    } while (iVar4 < (int)(uint)*(byte *)(param_1 + 0xec));
  }
  return param_2;
}

