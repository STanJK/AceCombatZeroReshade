/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140158d00; RVA 0x158d00
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_140158d00(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = 0x10000005;
  *(undefined4 *)(param_2 + 1) = 0;
  param_2[6] = 0;
  *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000005;
  *(undefined4 *)(param_2 + 2) = 0x8004;
  *(undefined4 *)((longlong)param_2 + 0x14) = 0x10000000;
  param_2[3] = 0xe;
  *(undefined4 *)(param_2 + 4) = 0x10000a8;
  *(undefined4 *)((longlong)param_2 + 0x24) = 1;
  *(undefined4 *)(param_2 + 5) = 0x4e;
  *(undefined4 *)(param_2 + 7) = 0x18;
  *(undefined4 *)(param_2 + 8) = 0x30000;
  *(undefined4 *)(param_2 + 9) = 0x47;
  param_2[10] = 0x68;
  *(undefined4 *)(param_2 + 0xb) = 0x42;
  param_2[0xc] = 0x10000005;
  *(undefined4 *)(param_2 + 0xd) = 0;
  *(undefined4 *)(param_2 + 0x16) = 0;
  *(undefined4 *)((longlong)param_2 + 0x6c) = 0x50000005;
  *(undefined4 *)(param_2 + 0xe) = 0x8001;
  *(undefined4 *)((longlong)param_2 + 0x74) = 0x34000000;
  param_2[0xf] = 0x160;
  *(undefined4 *)(param_2 + 0x10) = 0x46;
  *(undefined4 *)(param_2 + 0x11) = 0x20013000;
  *(undefined8 *)((longlong)param_2 + 0x8c) = 6;
  *(undefined4 *)((longlong)param_2 + 0x94) = 0x3f800000;
  *(undefined4 *)(param_2 + 0x14) = 0x8001;
  *(undefined4 *)((longlong)param_2 + 0xa4) = 0x24000000;
  param_2[0x15] = 0x55;
  *(undefined4 *)((longlong)param_2 + 0xb4) = 0xffffff;
  *(undefined4 *)(param_2 + 0x17) = 0x1c002000;
  *(undefined4 *)((longlong)param_2 + 0xbc) = 0xffffff;
  param_2[0x18] = 0x10000003;
  *(undefined4 *)(param_2 + 0x19) = 0;
  *(undefined4 *)((longlong)param_2 + 0xcc) = 0x50000003;
  *(undefined4 *)(param_2 + 0x1a) = 0x8002;
  *(undefined4 *)((longlong)param_2 + 0xd4) = 0x10000000;
  param_2[0x1b] = 0xe;
  param_2[0x1c] = 0x10000a8;
  *(undefined4 *)(param_2 + 0x1d) = 0x4e;
  *(undefined4 *)(param_2 + 0x1e) = 0x7000;
  *(undefined4 *)((longlong)param_2 + 0xf4) = 0x7200;
  *(undefined4 *)(param_2 + 0x1f) = 0x18;
  return param_2 + 0x20;
}

