/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020ef50; RVA 0x20ef50
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14020ef50(int param_1,undefined8 param_2,char param_3,byte param_4,char param_5)

{
  longlong lVar1;
  undefined1 in_XMM1 [16];
  undefined1 auVar2 [64];
  undefined1 auStack_1b8 [32];
  byte local_198 [4];
  undefined4 local_194 [3];
  undefined1 local_188;
  undefined2 local_187;
  undefined1 local_185;
  undefined4 local_184;
  undefined4 local_180;
  undefined4 local_17c;
  undefined1 local_178;
  undefined2 local_177;
  undefined1 local_175;
  undefined4 local_174;
  undefined4 local_170;
  undefined4 local_16c;
  undefined1 local_168;
  undefined2 local_167;
  undefined1 local_165;
  undefined4 local_164;
  undefined4 local_160;
  undefined4 local_15c;
  undefined1 local_158;
  undefined2 local_157;
  undefined1 local_155;
  undefined4 local_154;
  undefined4 local_150;
  undefined4 local_14c;
  undefined1 local_148;
  undefined2 local_147;
  undefined1 local_145;
  undefined4 local_144;
  undefined4 local_140;
  undefined4 local_13c;
  undefined1 local_138;
  undefined2 local_137;
  undefined1 local_135;
  undefined4 local_134;
  undefined4 local_130;
  undefined4 local_12c;
  undefined1 local_128;
  undefined2 local_127;
  undefined1 local_125;
  undefined4 local_124;
  undefined4 local_120;
  undefined4 local_11c;
  undefined1 local_118;
  undefined2 local_117;
  undefined1 local_115;
  undefined4 local_114;
  undefined4 local_110;
  undefined4 local_10c;
  undefined1 local_108;
  undefined2 local_107;
  undefined1 local_105;
  undefined4 local_104;
  undefined4 local_100;
  undefined4 local_fc;
  undefined1 local_f8;
  undefined2 local_f7;
  undefined1 local_f5;
  undefined4 local_f4;
  undefined4 local_f0;
  undefined4 local_ec;
  undefined1 local_e8;
  undefined2 local_e7;
  undefined1 local_e5;
  undefined4 local_e4;
  undefined4 local_e0;
  undefined4 local_dc;
  undefined1 local_d8;
  undefined2 local_d7;
  undefined1 local_d5;
  undefined4 local_d4;
  undefined4 local_d0;
  undefined4 local_cc;
  undefined1 local_c8;
  undefined2 local_c7;
  undefined1 local_c5;
  undefined4 local_c4;
  undefined4 local_c0;
  undefined4 local_bc;
  undefined1 local_b8;
  undefined2 local_b7;
  undefined1 local_b5;
  undefined4 local_b4;
  undefined4 local_b0;
  undefined4 local_ac;
  undefined1 local_a8;
  undefined2 local_a7;
  undefined1 local_a5;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined4 local_9c;
  undefined1 local_98;
  undefined2 local_97;
  undefined1 local_95;
  undefined4 local_94;
  undefined4 local_90;
  undefined4 local_8c;
  undefined1 local_88;
  undefined2 local_87;
  undefined1 local_85;
  undefined4 local_84;
  undefined4 local_80;
  undefined4 local_7c;
  undefined1 local_78;
  undefined2 local_77;
  undefined1 local_75;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined1 local_68;
  undefined2 local_67;
  undefined1 local_65;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined1 local_58;
  undefined2 local_57;
  undefined1 local_55;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined1 local_48;
  undefined2 local_47;
  undefined1 local_45;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined1 local_38 [16];
  ulonglong local_28;
  
  local_28 = DAT_140309040 ^ (ulonglong)auStack_1b8;
  lVar1 = (longlong)param_1;
  local_38 = vshufps_avx(in_XMM1,in_XMM1,0);
  auVar2 = ZEXT1664(local_38);
  if (param_1 == 0x16) {
    DAT_14031e0e4 = param_1;
    return;
  }
  DAT_14031e3a8 = 0;
  if ((((DAT_14031e0e4 == param_1) && (DAT_14031e3aa == param_3)) && (DAT_14031e3a9 == param_4)) &&
     (DAT_14031e3ab == param_5)) goto LAB_14020f3a2;
  DAT_14031e110 = 1;
  DAT_14031e324 = 3;
  local_198[1] = 0;
  local_198[2] = 0;
  local_198[3] = 0;
  local_187 = 0;
  local_185 = 0;
  local_177 = 0;
  local_175 = 0;
  local_167 = 0;
  local_165 = 0;
  local_160 = 3;
  local_157 = 0;
  local_155 = 0;
  local_150 = 3;
  local_147 = 0;
  local_145 = 0;
  local_137 = 0;
  local_135 = 0;
  local_127 = 0;
  local_125 = 0;
  local_117 = 0;
  local_115 = 0;
  local_107 = 0;
  local_105 = 0;
  local_f7 = 0;
  local_f5 = 0;
  local_e7 = 0;
  local_e5 = 0;
  local_d7 = 0;
  DAT_14031e3ab = param_5;
  local_198[0] = 1;
  local_194[0] = 5;
  local_194[1] = 1;
  local_194[2] = 6;
  local_188 = 1;
  local_184 = 5;
  local_180 = 1;
  local_17c = 2;
  local_178 = 1;
  local_174 = 9;
  local_170 = 1;
  local_16c = 1;
  local_168 = 1;
  local_164 = 2;
  local_15c = 2;
  local_158 = 1;
  local_154 = 5;
  local_14c = 2;
  local_148 = 1;
  local_144 = 1;
  local_140 = 1;
  local_13c = 5;
  local_138 = 1;
  local_134 = 0xe;
  local_130 = 1;
  local_12c = 2;
  local_128 = 1;
  local_124 = 1;
  local_120 = 1;
  local_11c = 0xe;
  local_118 = 1;
  local_114 = 1;
  local_110 = 1;
  local_10c = 2;
  local_108 = 1;
  local_104 = 7;
  local_100 = 1;
  local_fc = 2;
  local_f8 = 1;
  local_f4 = 7;
  local_f0 = 1;
  local_ec = 8;
  local_e8 = 1;
  local_e4 = 0xe;
  local_e0 = 1;
  local_dc = 0xf;
  local_d8 = 1;
  local_d5 = 0;
  local_d4 = 8;
  local_d0 = 1;
  local_cc = 1;
  local_c8 = 1;
  local_c7 = 0;
  local_c5 = 0;
  local_c4 = 0xe;
  local_c0 = 2;
  local_bc = 0xe;
  local_b8 = 1;
  local_b7 = 0;
  local_b5 = 0;
  local_b4 = 7;
  local_b0 = 3;
  local_ac = 2;
  local_a8 = 1;
  local_a7 = 0;
  local_a5 = 0;
  local_a4 = 8;
  local_a0 = 1;
  local_9c = 2;
  local_98 = 1;
  local_97 = 0;
  local_95 = 0;
  local_94 = 0xe;
  local_90 = 3;
  local_8c = 2;
  local_88 = 1;
  local_87 = 0;
  local_85 = 0;
  local_84 = 5;
  local_80 = 1;
  local_7c = 1;
  local_78 = 1;
  local_77 = 0;
  local_75 = 0;
  local_74 = 1;
  local_70 = 1;
  local_6c = 6;
  local_68 = 1;
  local_67 = 0;
  local_65 = 0;
  local_64 = 5;
  local_60 = 1;
  local_5c = 5;
  local_58 = 1;
  local_57 = 0;
  local_55 = 0;
  local_54 = 2;
  local_50 = 1;
  local_4c = 1;
  local_48 = 1;
  local_47 = 0;
  local_45 = 0;
  local_44 = 2;
  local_40 = 1;
  local_3c = 1;
  DAT_14031e198 = (uint)local_198[lVar1 * 0x10];
  _DAT_14031e1a8 = local_194[lVar1 * 4 + 1];
  _DAT_14031e1a0 = local_194[lVar1 * 4];
  _DAT_14031e1a4 = local_194[lVar1 * 4 + 2];
  DAT_14031e1bc = 0xf;
  _DAT_14031e1b4 = 1;
  if (param_3 == '\0') {
    DAT_14031e1ac = 1;
    _DAT_14031e1b0 = 2;
LAB_14020f38e:
    DAT_14031e324 = 1;
  }
  else {
    if (param_5 != '\0') {
      DAT_14031e1ac = 0x12;
      _DAT_14031e1b0 = 0x13;
      goto LAB_14020f38e;
    }
    DAT_14031e1ac = (uint)param_4 * 0x10 + 2;
    _DAT_14031e1b0 = 1;
    if (param_4 == 0) {
      if (param_1 == 8) {
        DAT_14031e198 = 0;
        DAT_14031e1bc = 8;
      }
      else {
        if (param_1 != 0x14) goto LAB_14020f394;
        DAT_14031e198 = 0;
      }
      goto LAB_14020f38e;
    }
  }
LAB_14020f394:
  DAT_14031e0e4 = param_1;
  _DAT_14031e334 = DAT_14031e324;
  DAT_14031e3a9 = param_4;
  DAT_14031e3aa = param_3;
LAB_14020f3a2:
  if ((DAT_14031e3b4 != local_38._0_4_) && (0.0 <= local_38._0_4_)) {
    (**(code **)(**(longlong **)(DAT_14033da48 + 0x10) + 0xb8))
              (*(longlong **)(DAT_14033da48 + 0x10),local_38);
    DAT_14031e3b4 = auVar2._0_4_;
  }
  return;
}

