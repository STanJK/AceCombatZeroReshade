/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400ad6f0; RVA 0xad6f0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400ad6f0(longlong param_1,char param_2,float param_3,float param_4,float param_5,
                  float param_6)

{
  int iVar1;
  int iVar2;
  
  *(char *)(param_1 + 0x10c9) = param_2;
  if (param_2 != '\0') {
    iVar2 = -(int)(param_3 - param_5);
    if (iVar2 < 0) {
      iVar2 = (int)(param_3 - param_5);
    }
    iVar1 = -(int)(param_4 - param_6);
    if (iVar1 < 0) {
      iVar1 = (int)(param_4 - param_6);
    }
    if (iVar2 < iVar1) {
      param_5 = (float)(int)(param_3 * DAT_1402d2168 + param_5 * DAT_1402d2168);
      param_3 = param_5;
    }
    else {
      param_6 = (float)(int)(param_4 * DAT_1402d2168 + param_6 * DAT_1402d2168);
      param_4 = param_6;
    }
    *(float *)(param_1 + 0x1414) = param_3;
    *(float *)(param_1 + 0x1418) = param_4;
    *(float *)(param_1 + 0x141c) = param_5;
    *(float *)(param_1 + 0x1420) = param_6;
  }
  return;
}

