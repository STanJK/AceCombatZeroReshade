/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020e550; RVA 0x20e550
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14020e550(undefined4 param_1,char param_2,char param_3)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 in_stack_fffffffffffffea0;
  undefined4 uVar5;
  undefined8 local_148;
  undefined8 uStack_140;
  undefined8 uStack_138;
  ulonglong uStack_130;
  undefined8 local_128;
  undefined8 uStack_120;
  undefined4 uStack_118;
  int iStack_114;
  ulonglong uStack_110;
  undefined4 local_108 [4];
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 uStack_e8;
  ulonglong uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  undefined1 local_b8 [16];
  undefined8 local_a8;
  undefined4 local_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  ulonglong uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined1 local_38 [16];
  
  uVar5 = (undefined4)((ulonglong)in_stack_fffffffffffffea0 >> 0x20);
  if (DAT_14030f270 == 0) {
    plVar1 = *(longlong **)(DAT_14033da48 + 0x10);
    local_108[0] = param_1;
    plVar4 = (longlong *)FUN_140211de0(&DAT_1403566e8,local_38,local_108);
    lVar2 = *plVar4;
    if ((param_2 == '\0') && (param_3 == '\0')) {
      iStack_114 = *(int *)(lVar2 + 0x40);
      if (iStack_114 != 0x80) {
        if (*(int *)(lVar2 + 0xa0) == 1) {
          uStack_140 = *(undefined8 *)(lVar2 + 0x18);
          local_128 = 0;
          uStack_110 = 0x80;
          uStack_118 = 0xffffffff;
          uStack_138 = CONCAT44(iStack_114,0xffffffff);
          local_148 = 0;
          uStack_130 = 0x80;
          uStack_120 = uStack_140;
          (**(code **)(*plVar1 + 0xd0))(plVar1,1,&local_148);
          *(undefined4 *)(lVar2 + 0x40) = 0x80;
          *(undefined1 *)(lVar2 + 0x60) = 1;
        }
        else {
          plVar4 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_b8,lVar2 + 0x80);
          lVar3 = *plVar4;
          uStack_f0 = *(undefined8 *)(lVar2 + 0x18);
          uStack_e8 = CONCAT44(*(undefined4 *)(lVar2 + 0x40),0xffffffff);
          uStack_120 = *(undefined8 *)(lVar3 + 0x18);
          iStack_114 = *(undefined4 *)(lVar3 + 0x40);
          local_f8 = 0;
          uStack_e0 = 0x2000;
          uStack_110 = 0x1000;
          local_128 = 0;
          uStack_118 = 0xffffffff;
          uStack_c8 = CONCAT44(iStack_114,0xffffffff);
          local_d8 = 0;
          uStack_c0 = 0x1000;
          uStack_d0 = uStack_120;
          (**(code **)(*plVar1 + 0xd0))(plVar1,2,&local_f8);
          (**(code **)(*plVar1 + 0x98))
                    (plVar1,*(undefined8 *)(lVar3 + 0x18),0,*(undefined8 *)(lVar2 + 0x18),0,
                     CONCAT44(uVar5,*(undefined4 *)(lVar2 + 0x48)));
          uStack_f0 = *(undefined8 *)(lVar2 + 0x18);
          uStack_120 = *(undefined8 *)(lVar3 + 0x18);
          uStack_110 = (ulonglong)*(uint *)(lVar2 + 0x40);
          local_f8 = 0;
          uStack_e8 = 0x2000ffffffff;
          uStack_e0 = uStack_110;
          uStack_110 = 0x80;
          local_128 = 0;
          iStack_114 = 0x1000;
          uStack_118 = 0xffffffff;
          local_d8 = 0;
          uStack_c8 = 0x1000ffffffff;
          uStack_c0 = 0x80;
          uStack_d0 = uStack_120;
          (**(code **)(*plVar1 + 0xd0))(plVar1,2,&local_f8);
          *(undefined4 *)(lVar3 + 0x40) = 0x80;
          *(undefined1 *)(lVar3 + 0x60) = 1;
          *(undefined1 *)(lVar2 + 0x60) = 1;
        }
      }
    }
    else {
      if (*(longlong *)(lVar2 + 0x20) == 0) {
        plVar4 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_b8,lVar2 + 0x94);
        lVar3 = *plVar4;
      }
      else {
        lVar3 = lVar2;
      }
      if ((param_2 != '\0') && (*(int *)(lVar3 + 0xa0) != 1)) {
        FUN_14020abe0(param_1,*(undefined4 *)(lVar3 + 0x80),1);
      }
      if ((param_3 == '\0') || (*(longlong *)(lVar2 + 0xa8) == 0)) {
        if ((*(int *)(lVar3 + 0xa0) == 1) && (*(int *)(lVar3 + 0x44) != 0x80)) {
          uStack_140 = *(undefined8 *)(lVar3 + 0x20);
          uStack_138 = CONCAT44(*(int *)(lVar3 + 0x44),0xffffffff);
          local_148 = 0;
          uStack_130 = 0x80;
          (**(code **)(*plVar1 + 0xd0))(plVar1,1,&local_148);
          *(undefined4 *)(lVar3 + 0x44) = 0x80;
          *(undefined1 *)(lVar3 + 0x78) = 1;
        }
      }
      else {
        if (*(int *)(lVar3 + 0xa0) != 1) {
          plVar4 = (longlong *)FUN_140211b80(&DAT_1403566e8,&local_128,lVar3 + 0x80);
          lVar3 = *plVar4;
        }
        uStack_70 = *(undefined8 *)(lVar3 + 0x20);
        uStack_138 = CONCAT44(*(undefined4 *)(lVar3 + 0x44),0xffffffff);
        local_78 = 0;
        uStack_68 = uStack_138;
        uStack_60 = 0x800;
        uStack_130 = 0x400;
        local_148 = 0;
        uStack_140 = *(undefined8 *)(**(longlong **)(lVar2 + 0xa8) + 0x20);
        uStack_138 = 0x80ffffffff;
        local_58 = 0;
        uStack_48 = 0x80ffffffff;
        uStack_40 = 0x400;
        uStack_50 = uStack_140;
        (**(code **)(*plVar1 + 0xd0))
                  (plVar1,(*(char *)(**(longlong **)(lVar2 + 0xa8) + 0x18) != '\0') + '\x01',
                   &local_78);
        local_a8 = *(undefined8 *)(lVar3 + 0x20);
        uStack_90 = 0;
        uStack_88 = 0;
        uStack_80 = 0;
        local_a0 = 0;
        local_98 = 1;
        local_f8 = *(undefined8 *)(**(longlong **)(lVar2 + 0xa8) + 0x20);
        uStack_f0 = (ulonglong)uStack_f0._4_4_ << 0x20;
        uStack_e8 = 0;
        uStack_e0 = 0;
        local_d8 = 0;
        uStack_d0 = 0;
        (**(code **)(*plVar1 + 0x80))(plVar1,&local_f8,0,0,0,&local_a8,0);
        uStack_70 = *(undefined8 *)(lVar3 + 0x20);
        uStack_130 = (ulonglong)*(uint *)(lVar3 + 0x44);
        local_78 = 0;
        uStack_68 = 0x800ffffffff;
        uStack_60 = uStack_130;
        uStack_130 = 0x80;
        local_148 = 0;
        uStack_140 = *(undefined8 *)(**(longlong **)(lVar2 + 0xa8) + 0x20);
        uStack_138 = 0x400ffffffff;
        local_58 = 0;
        uStack_48 = 0x400ffffffff;
        uStack_40 = 0x80;
        uStack_50 = uStack_140;
        (**(code **)(*plVar1 + 0xd0))(plVar1,2,&local_78);
        *(undefined1 *)(**(longlong **)(lVar2 + 0xa8) + 0x18) = 1;
      }
    }
  }
  return;
}

