/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020e000; RVA 0x20e000
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_14020e000(uint param_1,undefined8 param_2,undefined8 param_3,char param_4)

{
  uint uVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  char cVar9;
  ulonglong uVar10;
  ulonglong in_stack_ffffffffffffff28;
  ulonglong in_stack_ffffffffffffff30;
  undefined8 local_b8;
  ulonglong uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined8 uStack_90;
  longlong local_88;
  longlong lStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined8 local_68;
  ulonglong uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 local_48;
  ulonglong uStack_40;
  undefined8 uStack_38;
  undefined8 uStack_30;
  
  local_88 = CONCAT44(local_88._4_4_,param_1);
  uVar10 = (((((ulonglong)param_1 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
             (ulonglong)(param_1 >> 8 & 0xff)) * 0x100000001b3 ^ (ulonglong)(param_1 >> 0x10 & 0xff)
            ) * 0x100000001b3 ^ (ulonglong)(param_1 >> 0x18)) * 0x100000001b3 & DAT_140356718;
  lVar5 = *(longlong *)(DAT_140356700 + 8 + uVar10 * 0x10);
  if (lVar5 == DAT_1403566f0) {
LAB_14020e0aa:
    lVar5 = 0;
  }
  else {
    uVar1 = *(uint *)(lVar5 + 0x10);
    while (param_1 != uVar1) {
      if (lVar5 == *(longlong *)(DAT_140356700 + uVar10 * 0x10)) goto LAB_14020e0aa;
      lVar5 = *(longlong *)(lVar5 + 8);
      uVar1 = *(uint *)(lVar5 + 0x10);
    }
  }
  lVar8 = DAT_1403566f0;
  if (lVar5 != 0) {
    lVar8 = lVar5;
  }
  if (lVar8 != DAT_1403566f0) {
    FUN_140210f30(&DAT_140356728,&local_88);
    lVar5 = *(longlong *)(lVar8 + 0x20);
    plVar3 = *(longlong **)(DAT_14033da48 + 0x10);
    if ((lVar5 == 0) || (cVar9 = '\x01', *(int *)(lVar8 + 0x44) == 0x10)) {
      cVar9 = '\0';
    }
    iVar2 = *(int *)(lVar8 + 0x40);
    cVar9 = (iVar2 != 4) + cVar9;
    if (cVar9 != '\0') {
      uStack_60 = *(undefined8 *)(lVar8 + 0x18);
      uStack_74 = *(undefined4 *)(lVar8 + 0x44);
      uStack_58 = CONCAT44(iVar2,0xffffffff);
      lVar6 = 0;
      if (iVar2 == 4) {
        lVar6 = 0x20;
      }
      uStack_70 = 0x10;
      local_68 = 0;
      uStack_50 = 4;
      local_88 = 0;
      uStack_78 = 0xffffffff;
      uStack_38 = CONCAT44(uStack_74,0xffffffff);
      local_48 = 0;
      uStack_30 = 0x10;
      lStack_80 = lVar5;
      uStack_40 = lVar5;
      (**(code **)(*plVar3 + 0xd0))(plVar3,cVar9,(longlong)&local_68 + lVar6);
      *(undefined4 *)(lVar8 + 0x40) = 4;
      *(undefined4 *)(lVar8 + 0x44) = 0x10;
      *(undefined1 *)(lVar8 + 0x60) = 0;
      *(undefined1 *)(lVar8 + 0x78) = 0;
    }
    puVar4 = DAT_14033da68;
    if (param_4 == '\0') {
      if (*(int *)(lVar8 + 0x94) != -1) {
        plVar7 = (longlong *)FUN_140211b80(&DAT_1403566e8,&local_88,lVar8 + 0x94);
        lVar5 = *plVar7;
        if (*(int *)(lVar5 + 0xa0) == 1) {
          iVar2 = *(int *)(lVar5 + 0x44);
          if (*(int *)(lVar5 + 0x80) == -1) {
            uStack_60 = *(ulonglong *)(lVar5 + 0x20);
            uStack_b0 = *(ulonglong *)(lVar8 + 0x20);
            uStack_a8 = CONCAT44(iVar2,0xffffffff);
            local_68 = 0;
            uStack_58 = uStack_a8;
            uStack_50 = 0x800;
            uStack_a0 = 0x400;
            local_b8 = 0;
            uStack_a8 = CONCAT44(*(undefined4 *)(lVar8 + 0x44),0xffffffff);
            local_48 = 0;
            uStack_38 = uStack_a8;
            uStack_30 = 0x400;
            uStack_40 = uStack_b0;
            (**(code **)(*plVar3 + 0xd0))(plVar3,2,&local_68);
            if (DAT_14030f270 == 0) {
              local_b8 = *(undefined8 *)(lVar5 + 0x20);
              local_68 = *(undefined8 *)(lVar8 + 0x20);
              uStack_b0 = uStack_b0 & 0xffffffff00000000;
              uStack_a8 = 0;
              uStack_a0 = 0;
              uStack_98 = 0;
              uStack_90 = 0;
              uStack_60 = uStack_60 & 0xffffffff00000000;
              uStack_58 = 0;
              uStack_50 = 0;
              local_48 = 0;
              uStack_40 = 0;
              (**(code **)(*plVar3 + 0x80))
                        (plVar3,&local_68,0,0,in_stack_ffffffffffffff28 & 0xffffffff00000000,
                         &local_b8,0);
            }
            uStack_60 = *(undefined8 *)(lVar5 + 0x20);
            uStack_b0 = *(longlong *)(lVar8 + 0x20);
            local_68 = 0;
            uStack_58 = 0x800ffffffff;
            uStack_50 = 0x80;
            uStack_a0 = 0x10;
            local_b8 = 0;
            uStack_a8 = 0x400ffffffff;
            local_48 = 0;
            uStack_38 = 0x400ffffffff;
            uStack_30 = 0x10;
            uStack_40 = uStack_b0;
            (**(code **)(*plVar3 + 0xd0))(plVar3,2,&local_68);
            *(undefined4 *)(lVar5 + 0x44) = 0x80;
            *(undefined4 *)(lVar8 + 0x44) = 0x10;
            *(undefined1 *)(lVar5 + 0x78) = 1;
          }
          else if (iVar2 != 0x10) {
            uStack_b0 = *(longlong *)(lVar5 + 0x20);
            uStack_a8 = CONCAT44(iVar2,0xffffffff);
            local_b8 = 0;
            uStack_a0 = 0x10;
            (**(code **)(*plVar3 + 0xd0))(plVar3,1,&local_b8);
            *(undefined4 *)(lVar5 + 0x44) = 0x10;
          }
        }
        else {
          FUN_14020abe0(*(undefined4 *)(lVar8 + 0x94),*(int *)(lVar5 + 0x80),0);
        }
      }
    }
    else if (DAT_14030f270 == 0) {
      iVar2 = *(int *)(lVar8 + 0x8c);
      (**(code **)(*(longlong *)*DAT_14033da68 + 0x48))((longlong *)*DAT_14033da68,&local_88);
      uVar10 = 0;
      (**(code **)(*plVar3 + 0x180))
                (plVar3,iVar2 * *(int *)(puVar4 + 1) + local_88,&DAT_1402ce2c0,0,0);
      puVar4 = DAT_14033da70;
      if (lVar5 != 0) {
        iVar2 = *(int *)(lVar8 + 0x90);
        (**(code **)(*(longlong *)*DAT_14033da70 + 0x48))((longlong *)*DAT_14033da70,&local_88);
        (**(code **)(*plVar3 + 0x178))
                  (plVar3,iVar2 * *(int *)(puVar4 + 1) + local_88,3,0,uVar10 & 0xffffffffffffff00,
                   in_stack_ffffffffffffff30 & 0xffffffff00000000,0);
      }
    }
    FUN_14020a000(&DAT_1403566c0,param_1);
  }
  return 0;
}

