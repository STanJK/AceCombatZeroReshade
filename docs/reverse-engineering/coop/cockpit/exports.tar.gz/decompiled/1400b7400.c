/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b7400; RVA 0xb7400
 * Ghidra-generated research pseudocode, inferred types, not original source. */

bool FUN_1400b7400(longlong param_1,longlong *param_2)

{
  undefined1 auVar1 [16];
  longlong lVar2;
  longlong lVar3;
  undefined1 auVar4 [16];
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float local_b8;
  float local_b4;
  float local_b0;
  float local_ac;
  float local_a8;
  float local_a4;
  float local_a0;
  float local_9c;
  float local_98;
  float local_94;
  float local_90;
  float local_8c;
  float local_88;
  float local_84;
  float local_80;
  float local_7c;
  
  if ((((*(longlong *)(param_1 + 0x2f0) != 0) &&
       (lVar2 = *(longlong *)(param_1 + 0x328), lVar2 != 0)) && (*(short *)(param_1 + 0xf8) != 0))
     && (*(float *)(lVar2 + 0x20c + (ulonglong)*(byte *)(param_1 + 0x3ca) * 4) <=
         *(float *)(*(longlong *)(param_1 + 0x2f0) + 0x10) * DAT_1402d2478)) {
    lVar3 = *(longlong *)(*param_2 + (ulonglong)*(byte *)(param_1 + 0x3ca) * 8);
    if ((((&DAT_1402accc0)
          [(ulonglong)
           *(byte *)(*(longlong *)(*param_2 + (ulonglong)*(byte *)(lVar2 + 0x234) * 8) + 0x15d) +
           (ulonglong)*(byte *)(lVar3 + 0x15d) * 8] != '\0') &&
        ((*(uint *)(lVar2 + 0x1f0) & 0x10000) == 0)) &&
       (*(char *)(**(longlong **)(lVar2 + 0x1a0) + 0x71) != '\x03')) {
      lVar3 = *(longlong *)(lVar3 + 0x110);
      fVar11 = 0.0;
      local_b8 = DAT_1402d22d0;
      local_a4 = DAT_1402d22d0;
      local_90 = DAT_1402d22d0;
      local_7c = DAT_1402d22d0;
      local_a8 = 0.0;
      local_98 = 0.0;
      local_88 = 0.0;
      local_b4 = 0.0;
      local_94 = 0.0;
      local_84 = 0.0;
      local_b0 = 0.0;
      local_a0 = 0.0;
      local_80 = 0.0;
      local_ac = 0.0;
      local_9c = 0.0;
      local_8c = 0.0;
      fVar9 = DAT_1402d22d0;
      FUN_140202230(&local_b8,&local_b8,lVar3 + 0x268);
      auVar1 = *(undefined1 (*) [16])(lVar2 + 600);
      fVar5 = auVar1._0_4_ - *(float *)(lVar3 + 600);
      auVar4 = vshufps_avx(auVar1,auVar1,0x55);
      fVar6 = auVar4._0_4_ - *(float *)(lVar3 + 0x25c);
      auVar4 = vshufps_avx(auVar1,auVar1,0xaa);
      fVar7 = auVar4._0_4_ - *(float *)(lVar3 + 0x260);
      auVar1 = vshufps_avx(auVar1,auVar1,0xff);
      fVar8 = auVar1._0_4_ - *(float *)(lVar3 + 0x264);
      fVar12 = fVar8 * local_7c + fVar7 * local_80 + fVar6 * local_84 + fVar5 * local_88;
      fVar13 = fVar8 * local_8c + fVar7 * local_90 + fVar6 * local_94 + fVar5 * local_98;
      fVar10 = fVar8 * local_9c + fVar7 * local_a0 + fVar6 * local_a4 + fVar5 * local_a8;
      fVar5 = fVar6 * local_b4 + fVar5 * local_b8 + fVar7 * local_b0 + fVar8 * local_ac;
      fVar10 = SQRT(fVar12 * fVar12 + fVar13 * fVar13 + fVar10 * fVar10 + fVar5 * fVar5);
      if (fVar10 != fVar11) {
        fVar9 = fVar9 / fVar10;
        fVar13 = fVar9 * fVar13;
        fVar12 = fVar9 * fVar12;
      }
      return DAT_1402d2210 <= fVar12 - fVar13;
    }
  }
  return false;
}

