/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020b9c0; RVA 0x20b9c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14020b9c0(void)

{
  char cVar1;
  ulonglong *puVar2;
  code *pcVar3;
  undefined8 uVar4;
  bool bVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined1 auVar10 [32];
  int iVar11;
  int iVar12;
  uint *puVar13;
  undefined8 *puVar14;
  BOOL BVar15;
  uint uVar16;
  longlong lVar17;
  longlong *plVar18;
  undefined8 *puVar19;
  undefined8 *puVar20;
  ulonglong uVar21;
  longlong *plVar22;
  undefined8 *puVar23;
  ulonglong uVar24;
  ulonglong *puVar25;
  undefined1 auVar26 [16];
  undefined1 extraout_var [56];
  undefined1 auVar27 [64];
  undefined1 extraout_var_00 [56];
  undefined1 auVar28 [64];
  double dVar29;
  double dVar30;
  LARGE_INTEGER local_res8;
  longlong *local_1f8;
  undefined8 uStack_1f0;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined8 uStack_1e0;
  ulonglong local_1d8;
  undefined8 uStack_1d0;
  undefined2 uStack_1c8;
  undefined2 uStack_1c6;
  undefined4 uStack_1c4;
  undefined8 uStack_1c0;
  undefined4 local_1b8;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  undefined4 uStack_1a8;
  undefined8 local_1a0;
  undefined8 local_198;
  undefined8 local_188;
  undefined8 uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined8 uStack_158;
  undefined8 uStack_150;
  undefined8 uStack_148;
  undefined8 uStack_140;
  undefined8 local_138;
  undefined8 local_130;
  undefined8 uStack_128;
  undefined8 uStack_120;
  undefined8 uStack_118;
  undefined8 uStack_110;
  undefined8 local_108;
  undefined8 uStack_100;
  undefined8 uStack_f8;
  undefined8 uStack_f0;
  undefined8 local_e8;
  undefined8 local_e0;
  undefined8 uStack_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 local_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 local_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 local_48;
  
  bVar5 = true;
  SteamAPI_RunCallbacks();
  puVar13 = DAT_14033da48;
  if (*(longlong *)(DAT_14033da48 + 0x42) != 0) {
    local_1f8 = (longlong *)0x0;
    uStack_1f0 = (longlong *)CONCAT44((int)(float)_DAT_14035674c,(int)(float)_DAT_140356748);
    if ((char)DAT_14033da48[0x39] == '\0') {
      if (((int)(float)_DAT_140356748 == DAT_14033da48[0x46]) &&
         ((int)(float)_DAT_14035674c == DAT_14033da48[0x47])) goto LAB_14020ba55;
    }
    else {
      *(undefined1 *)(DAT_14033da48 + 0x39) = 0;
    }
    puVar13[0x44] = 0;
    puVar13[0x45] = 0;
    *(longlong **)(puVar13 + 0x46) = uStack_1f0;
    FUN_140225bc0(puVar13);
  }
LAB_14020ba55:
  iVar11 = DAT_14031e410;
  if (DAT_14030f270 < 0) {
    DAT_14030f270 = 1;
    BVar15 = QueryPerformanceCounter((LARGE_INTEGER *)&DAT_14031e3e8);
    if (BVar15 == 0) {
      FUN_140214210(&local_1f8);
                    /* WARNING: Subroutine does not return */
      FUN_14023848c(&local_1f8,&DAT_140306648);
    }
    DAT_14031e408 = 0;
    _DAT_14031e414 = 0;
    DAT_14031e420 = 0;
    uVar16 = *DAT_14033da48;
    DAT_14030f270 = DAT_14030f270 + -1;
LAB_14020bcb4:
    if (DAT_14033bd4c < (uint)(&DAT_14033da80)[(ulonglong)uVar16 * 6]) {
      DAT_14033bd4c = (&DAT_14033da80)[(ulonglong)uVar16 * 6];
    }
    DAT_1403567a8 = (ulonglong)(uVar16 << 0x1b);
    (&DAT_14033da80)[(ulonglong)uVar16 * 6] = 0;
    FUN_140209440();
    DAT_14033ad70 = DAT_14033ad70 + 1 & 0x80000003;
    if ((int)DAT_14033ad70 < 0) {
      DAT_14033ad70 = (DAT_14033ad70 - 1 | 0xfffffffc) + 1;
    }
    puVar2 = (ulonglong *)(&DAT_14033ad18)[(longlong)(int)DAT_14033ad70 * 3];
    puVar25 = (ulonglong *)(&DAT_14033ad10)[(longlong)(int)DAT_14033ad70 * 3];
    if (puVar25 != puVar2) {
      do {
        uVar21 = *puVar25;
        plVar22 = (longlong *)DAT_14033ad00[1];
        cVar1 = *(char *)((longlong)plVar22 + 0x19);
        plVar18 = plVar22;
        uStack_1f0 = DAT_14033ad00;
        local_1f8 = DAT_14033ad00;
        while (cVar1 == '\0') {
          if ((ulonglong)plVar18[4] < uVar21) {
            plVar18 = plVar18 + 2;
          }
          else {
            if ((*(char *)((longlong)uStack_1f0 + 0x19) != '\0') && (uVar21 < (ulonglong)plVar18[4])
               ) {
              uStack_1f0 = plVar18;
            }
            local_1f8 = plVar18;
          }
          plVar18 = (longlong *)*plVar18;
          cVar1 = *(char *)((longlong)plVar18 + 0x19);
        }
        if (*(char *)((longlong)uStack_1f0 + 0x19) == '\0') {
          plVar22 = (longlong *)*uStack_1f0;
        }
        cVar1 = *(char *)((longlong)plVar22 + 0x19);
        while (cVar1 == '\0') {
          if (uVar21 < (ulonglong)plVar22[4]) {
            plVar18 = (longlong *)*plVar22;
            uStack_1f0 = plVar22;
          }
          else {
            plVar18 = (longlong *)plVar22[2];
          }
          plVar22 = plVar18;
          cVar1 = *(char *)((longlong)plVar18 + 0x19);
        }
        FUN_140212560(plVar22,&local_1f8);
        puVar25 = puVar25 + 1;
      } while (puVar25 != puVar2);
      lVar17 = (longlong)(int)DAT_14033ad70;
      if ((&DAT_14033ad10)[lVar17 * 3] != (&DAT_14033ad18)[lVar17 * 3]) {
        (&DAT_14033ad18)[lVar17 * 3] = (&DAT_14033ad10)[lVar17 * 3];
        uVar21 = (ulonglong)DAT_14033da48[1];
        (**(code **)(*(longlong *)(&DAT_14033acf0)[uVar21] + 0x40))();
        goto LAB_14020be25;
      }
    }
    uVar21 = (ulonglong)DAT_14033da48[1];
    (**(code **)(*(longlong *)(&DAT_14033acf0)[uVar21] + 0x40))();
  }
  else {
    if (DAT_14030f270 == 0) {
      BVar15 = QueryPerformanceCounter(&local_res8);
      if (BVar15 != 0) {
        dVar29 = DAT_1402d20a8;
        dVar30 = DAT_1402d2268;
        do {
          iVar12 = DAT_14031e410;
          uVar21 = local_res8.QuadPart - _DAT_14031e3e8;
          DAT_14031e420 = DAT_14031e420 + uVar21;
          if (DAT_14031e3f0 < uVar21) {
            uVar21 = DAT_14031e3f0;
          }
          _DAT_14031e3e8 = local_res8.QuadPart;
          uVar21 = (uVar21 * 10000000) / DAT_14031e3e0;
          if (DAT_14031e428 == '\0') {
            DAT_14031e400 = DAT_14031e400 + uVar21;
            DAT_14031e408 = 0;
            DAT_14031e410 = DAT_14031e410 + 1;
            _DAT_14031e3f8 = uVar21;
          }
          else {
            uVar24 = -(uVar21 - DAT_14031e430);
            if ((longlong)uVar24 < 0) {
              uVar24 = uVar21 - DAT_14031e430;
            }
            if (uVar24 < 0x9c4) {
              uVar21 = DAT_14031e430;
            }
            DAT_14031e408 = DAT_14031e408 + uVar21;
            if (DAT_14031e430 <= DAT_14031e408) {
              do {
                DAT_14031e410 = DAT_14031e410 + 1;
                _DAT_14031e3f8 = DAT_14031e430;
                DAT_14031e400 = DAT_14031e400 + DAT_14031e430;
                DAT_14031e408 = DAT_14031e408 - DAT_14031e430;
              } while (DAT_14031e430 <= DAT_14031e408);
            }
          }
          uVar16 = DAT_14031e418;
          if (DAT_14031e410 != iVar12) {
            uVar16 = DAT_14031e418 + 1;
            _DAT_14031e414 = CONCAT44(uVar16,_DAT_14031e414);
          }
          if (DAT_14031e3e0 <= DAT_14031e420) {
            _DAT_14031e414 = (ulonglong)uVar16;
            DAT_14031e420 = DAT_14031e420 % DAT_14031e3e0;
          }
          if (DAT_14031e410 != iVar11) {
            uVar16 = *DAT_14033da48;
            DAT_14030f270 = DAT_14030f270 + -1 + (DAT_14031e410 - iVar11);
            goto LAB_14020bcb4;
          }
          if (dVar30 < (double)(DAT_14031e430 - DAT_14031e408) * dVar29) {
            Sleep(1);
          }
          BVar15 = QueryPerformanceCounter(&local_res8);
        } while (BVar15 != 0);
      }
      FUN_140214210(&local_1f8);
                    /* WARNING: Subroutine does not return */
      FUN_14023848c(&local_1f8,&DAT_140306648);
    }
    uVar21 = (ulonglong)DAT_14033da48[1];
    bVar5 = false;
    DAT_14030f270 = DAT_14030f270 + -1;
  }
LAB_14020be25:
  (**(code **)(*DAT_14033ace8 + 0x50))(DAT_14033ace8,(&DAT_14033acf0)[uVar21],0);
  puVar13 = DAT_14033da48;
  if (bVar5) {
    (**(code **)(**(longlong **)(DAT_14033da48 + (ulonglong)DAT_14033da48[1] * 2 + 8) + 0x40))();
  }
  (**(code **)(**(longlong **)(puVar13 + 4) + 0x50))
            (*(longlong **)(puVar13 + 4),*(undefined8 *)(puVar13 + (ulonglong)puVar13[1] * 2 + 8),0)
  ;
  uStack_1e0 = 4;
  local_1f8 = (longlong *)0x0;
  uStack_1e4 = 0;
  uStack_1f0 = *(longlong **)(puVar13 + (ulonglong)*puVar13 * 2 + 0x12);
  uStack_1e8 = 0xffffffff;
  local_1d8 = 0;
  uStack_1c8 = 0xffff;
  uStack_1c6 = 0xffff;
  uStack_1c4 = 0;
  uStack_1c0 = 4;
  uStack_1d0 = uStack_1f0;
  (**(code **)(**(longlong **)(puVar13 + 4) + 0xd0))(*(longlong **)(puVar13 + 4),1,&local_1d8);
  lVar17 = 2;
  plVar22 = *(longlong **)(DAT_14033da48 + 4);
  local_1a0 = *DAT_14033da58;
  local_198 = *DAT_14033da60;
  auVar27._0_8_ = (**(code **)(*plVar22 + 0xe0))(plVar22,2,&local_1a0);
  auVar27._8_56_ = extraout_var;
  auVar26 = auVar27._0_16_;
  if (DAT_14030f270 == 0) {
    FUN_14020a000(&DAT_1403566c0,0xffffffff);
    puVar13 = DAT_14033da48;
    pcVar3 = *(code **)(*plVar22 + 0x180);
    plVar18 = (longlong *)
              (**(code **)(**(longlong **)(DAT_14033da48 + 0x26) + 0x48))
                        (*(longlong **)(DAT_14033da48 + 0x26),&local_res8);
    auVar28._0_8_ =
         (*pcVar3)(plVar22,(ulonglong)(puVar13[0x2a] * *puVar13) + *plVar18,&DAT_1402ce2c0,0,0);
    auVar28._8_56_ = extraout_var_00;
    auVar26 = auVar28._0_16_;
  }
  uStack_168 = _UNK_1402d3a38;
  uStack_170 = _UNK_1402d3a30;
  uStack_178 = _UNK_1402d3a28;
  uStack_180 = _DAT_1402d3a20;
  _DAT_14031e0d0 = vpcmpeqd_avx(auVar26,auVar26);
  puVar19 = &DAT_14031e0f0;
  if (0xf < DAT_14031e108) {
    puVar19 = DAT_14031e0f0;
  }
  DAT_14031e0e0 = DAT_1402d22d0;
  uStack_1b4 = CONCAT31(uStack_1b4._1_3_,0xf);
  uStack_160 = CONCAT44(uStack_1b4,4);
  DAT_14031e0e4 = 0x16;
  DAT_14031e100 = 0;
  *(undefined1 *)puVar19 = 0;
  DAT_14031e110 = 1;
  local_188 = 0;
  uStack_158 = uStack_180;
  uStack_150 = uStack_178;
  uStack_148 = uStack_170;
  uStack_140 = uStack_168;
  local_138 = uStack_160;
  local_130 = uStack_180;
  uStack_128 = uStack_178;
  uStack_120 = uStack_170;
  uStack_118 = uStack_168;
  uStack_110 = uStack_160;
  local_108 = uStack_180;
  uStack_100 = uStack_178;
  uStack_f8 = uStack_170;
  uStack_f0 = uStack_168;
  local_e8 = uStack_160;
  local_e0 = uStack_180;
  uStack_d8 = uStack_178;
  uStack_d0 = uStack_170;
  uStack_c8 = uStack_168;
  local_c0 = uStack_160;
  local_b8 = uStack_180;
  uStack_b0 = uStack_178;
  uStack_a8 = uStack_170;
  uStack_a0 = uStack_168;
  local_98 = uStack_160;
  local_90 = uStack_180;
  uStack_88 = uStack_178;
  uStack_80 = uStack_170;
  uStack_78 = uStack_168;
  local_70 = uStack_160;
  local_68 = uStack_180;
  uStack_60 = uStack_178;
  uStack_58 = uStack_170;
  uStack_50 = uStack_168;
  local_48 = uStack_160;
  puVar19 = &local_188;
  puVar14 = (undefined8 *)&DAT_14031e190;
  do {
    puVar23 = puVar14;
    puVar20 = puVar19;
    uVar7 = puVar20[1];
    uVar8 = puVar20[2];
    uVar9 = puVar20[3];
    uVar4 = puVar20[0xe];
    uVar6 = puVar20[0xf];
    *puVar23 = *puVar20;
    puVar23[1] = uVar7;
    puVar23[2] = uVar8;
    puVar23[3] = uVar9;
    uVar7 = puVar20[5];
    uVar8 = puVar20[6];
    uVar9 = puVar20[7];
    puVar23[4] = puVar20[4];
    puVar23[5] = uVar7;
    puVar23[6] = uVar8;
    puVar23[7] = uVar9;
    uVar7 = puVar20[9];
    uVar8 = puVar20[10];
    uVar9 = puVar20[0xb];
    puVar23[8] = puVar20[8];
    puVar23[9] = uVar7;
    puVar23[10] = uVar8;
    puVar23[0xb] = uVar9;
    uVar7 = puVar20[0xd];
    puVar23[0xc] = puVar20[0xc];
    puVar23[0xd] = uVar7;
    puVar23[0xe] = uVar4;
    puVar23[0xf] = uVar6;
    auVar10 = _DAT_1402d3ac0;
    lVar17 = lVar17 + -1;
    puVar19 = puVar20 + 0x10;
    puVar14 = puVar23 + 0x10;
  } while (lVar17 != 0);
  uVar4 = puVar20[0x11];
  uVar6 = puVar20[0x12];
  uVar7 = puVar20[0x13];
  puVar23[0x10] = puVar20[0x10];
  puVar23[0x11] = uVar4;
  puVar23[0x12] = uVar6;
  puVar23[0x13] = uVar7;
  uVar6 = puVar20[0x15];
  uVar7 = puVar20[0x16];
  uVar8 = puVar20[0x17];
  uVar4 = puVar20[0x18];
  puVar23[0x14] = puVar20[0x14];
  puVar23[0x15] = uVar6;
  puVar23[0x16] = uVar7;
  puVar23[0x17] = uVar8;
  puVar23[0x18] = uVar4;
  _DAT_14031e2ec = 0;
  _DAT_14031e2f0 = 0;
  local_1d8 = _DAT_1402d2fc0;
  uStack_1d0 = _UNK_1402d2fc8;
  uStack_1c4 = auVar10._0_4_;
  uStack_1c0 = auVar10._4_8_;
  local_1b8 = auVar10._12_4_;
  uStack_1b4 = auVar10._16_4_;
  uStack_1b0 = auVar10._20_8_;
  uStack_1a8 = auVar10._28_4_;
  _DAT_14031e328 = auVar10._12_8_;
  uStack_1c8 = 0xffff;
  uRam000000014031e318 = CONCAT44(uStack_1c4,CONCAT22(uStack_1c6,0xffff));
  _DAT_14031e310 = _UNK_1402d2fc8;
  DAT_14031e3b4 = DAT_1402d2d64;
  _DAT_14031e2d8 = 0xffffffff;
  _DAT_14031e2dc = 3;
  _DAT_14031e2e0 = 3;
  _DAT_14031e2e8 = 0;
  _DAT_14031e2f4 = 1;
  _DAT_14031e2fc = 0;
  _DAT_14031e304 = 0;
  _DAT_14031e308 = _DAT_1402d2fc0 & 0xffffffff00000000;
  uRam000000014031e320 = CONCAT44(3,auVar10._4_4_);
  uRam000000014031e330 = CONCAT44(3,auVar10._20_4_);
  _DAT_14031e350 = 1;
  _DAT_14031e358 = 1;
  DAT_14031e37c = 0;
  _DAT_14031e380 = 1;
  _DAT_14031e3a8 = 0;
  DAT_14031e3ac = 0;
  DAT_14031e3b0 = 0xffffffff;
  _DAT_14031e338 = uStack_1a8;
  (**(code **)(*plVar22 + 0xc0))(plVar22,0xff);
  FUN_140210f30(&DAT_140356728,&DAT_140291ccc);
  FUN_14020ea20(0xffffffff,1);
  return;
}

