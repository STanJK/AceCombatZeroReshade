/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020e490; RVA 0x20e490
 * Ghidra-generated research pseudocode, inferred types, not original source. */

longlong FUN_14020e490(undefined4 param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined4 local_res8 [2];
  int local_res10 [6];
  undefined1 local_b8 [16];
  undefined1 local_a8 [168];
  
  lVar2 = DAT_140356730 + -4;
  local_res8[0] = param_1;
  if (DAT_140356728 != lVar2) {
    local_res10[0] = *(int *)(DAT_140356730 + -8);
    if (local_res10[0] == -1) {
      DAT_140356730 = lVar2;
      FUN_14020a000(&DAT_1403566c0,0xffffffff);
      lVar2 = DAT_140356730;
    }
    else {
      DAT_140356730 = DAT_140356730 + -8;
      plVar1 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_b8,local_res10);
      FUN_14020d8c0(local_a8,*plVar1 + 0x18);
      FUN_14020e000(local_res10[0]);
      FUN_14020da10(local_a8);
      lVar2 = DAT_140356730;
    }
  }
  DAT_140356730 = lVar2;
  plVar1 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_b8,local_res8);
  return *plVar1 + 0x48;
}

