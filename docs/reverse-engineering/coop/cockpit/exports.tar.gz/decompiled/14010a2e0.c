/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14010a2e0; RVA 0x10a2e0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_14010a2e0(longlong param_1,undefined8 param_2,float *param_3,float *param_4,undefined8 param_5)

{
  undefined1 auVar1 [32];
  undefined1 auVar2 [32];
  float fVar3;
  float fVar4;
  float fVar5;
  uint uVar6;
  char cVar7;
  ushort *puVar8;
  float *pfVar9;
  byte bVar10;
  longlong lVar11;
  uint uVar12;
  byte bVar13;
  longlong *plVar14;
  int iVar15;
  longlong *plVar16;
  longlong lVar17;
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  undefined1 auVar21 [64];
  int local_a8 [2];
  int local_a0;
  longlong local_98;
  undefined1 local_88 [16];
  undefined1 local_78 [16];
  undefined1 local_68 [16];
  undefined1 local_58 [8];
  float fStack_50;
  float fStack_4c;
  
  cVar7 = DAT_14033bd60;
  plVar14 = *(longlong **)(param_1 + 0xfd8);
  if ((plVar14 != (longlong *)0x0) && (*plVar14 != 0)) {
    bVar13 = *(byte *)(param_1 + 0x209d);
    local_a0 = (uint)*(byte *)(param_1 + 0x279a) * 4 + 0x43;
    iVar15 = 0;
    if (*(char *)((longlong)plVar14 + 0xe) != '\0') {
      auVar21 = ZEXT464(DAT_1402d291c);
      plVar16 = plVar14;
      do {
        if ((int)(uint)*(byte *)(param_1 + 0x209a) <= iVar15) {
          return param_2;
        }
        bVar10 = 0;
        if (bVar13 < *(byte *)(param_1 + 0x20b4)) {
          bVar10 = bVar13;
        }
        if (*(short *)(param_1 + 8000 + (ulonglong)bVar10 * 0x18) == 0) {
          local_88 = ZEXT816(0);
          local_78 = ZEXT816(0);
          local_68 = local_88;
          _local_58 = local_78;
          puVar8 = (ushort *)FUN_14015e5a0(param_1 + 0x120,local_a0 + (uint)bVar10,local_a8);
          if (local_a8[0] == 0) {
            auVar1 = _DAT_1402d38a0;
            auVar2 = _DAT_1402d4140;
          }
          else {
            auVar1 = *(undefined1 (*) [32])
                      ((ulonglong)*puVar8 * 800 + 0x94 + *(longlong *)(param_1 + 0x1b0));
            auVar2 = *(undefined1 (*) [32])
                      ((ulonglong)*puVar8 * 800 + 0xb4 + *(longlong *)(param_1 + 0x1b0));
          }
          auVar18 = auVar1._0_16_;
          auVar19 = auVar1._16_16_;
          local_78._4_4_ = vextractps_avx(auVar19,1);
          local_78._0_4_ = auVar1._16_4_;
          local_78._8_4_ = vextractps_avx(auVar19,2);
          local_78._12_4_ = vextractps_avx(auVar19,3);
          auVar19 = auVar2._0_16_;
          auVar20 = auVar2._16_16_;
          local_58._4_4_ = vextractps_avx(auVar20,1);
          local_58._0_4_ = auVar2._16_4_;
          fStack_50 = (float)vextractps_avx(auVar20,2);
          fStack_4c = (float)vextractps_avx(auVar20,3);
          local_88._4_4_ = vextractps_avx(auVar18,1);
          local_88._0_4_ = auVar1._0_4_;
          local_88._8_4_ = vextractps_avx(auVar18,2);
          local_88._12_4_ = vextractps_avx(auVar18,3);
          local_68._4_4_ = vextractps_avx(auVar19,1);
          local_68._0_4_ = auVar2._0_4_;
          local_68._8_4_ = vextractps_avx(auVar19,2);
          local_68._12_4_ = vextractps_avx(auVar19,3);
          auVar21 = ZEXT1664(auVar21._0_16_);
          FUN_140202230(local_88,local_88,param_5);
          uVar12 = 0;
          lVar11 = 0;
          fVar3 = (float)local_58._4_4_ + param_4[1];
          fVar4 = (fStack_50 + param_4[2]) - param_3[2];
          fVar5 = ((float)local_58._0_4_ + *param_4) - *param_3;
          local_58._4_4_ = fVar3;
          local_58._0_4_ = (float)local_58._0_4_ + *param_4;
          fVar3 = fVar3 - param_3[1];
          fStack_50 = fStack_50 + param_4[2];
          local_98 = *plVar16;
          pfVar9 = *(float **)(local_98 + 0x10);
          do {
            if (SQRT((fStack_4c - param_3[3]) * (fStack_4c - param_3[3]) +
                     fVar4 * fVar4 + fVar3 * fVar3 + fVar5 * fVar5) *
                (auVar21._0_4_ / *(float *)(param_1 + 0x1d70)) < *pfVar9) goto LAB_14010a58c;
            uVar12 = uVar12 + 1;
            lVar11 = lVar11 + 1;
            pfVar9 = pfVar9 + 1;
          } while (lVar11 < 3);
          uVar12 = 0xffffffff;
          lVar11 = -1;
LAB_14010a58c:
          if ((cVar7 != '\0') && (1 < (int)uVar12)) {
            uVar12 = 1;
            lVar11 = 1;
          }
          lVar17 = 0;
          uVar6 = 0;
          if ((*(uint *)(param_1 + 0x2058) >> 0x19 & 1) == 0) {
            lVar17 = lVar11;
            uVar6 = uVar12;
          }
          plVar14 = plVar16;
          if ((-1 < (int)uVar6) && ((int)uVar6 < 3)) {
            FUN_140162e80(local_98,uVar6,0);
            FUN_14015e840(*(undefined8 *)(local_98 + 0x30 + lVar17 * 8));
            plVar14 = *(longlong **)(param_1 + 0xfd8);
          }
          plVar16 = plVar14;
          if (uVar6 < 3) {
            param_2 = FUN_14015e8a0(*(undefined8 *)
                                     (**(longlong **)(param_1 + 0xfd8) + 0x30 + lVar17 * 8),param_2)
            ;
            plVar14 = *(longlong **)(param_1 + 0xfd8);
            plVar16 = plVar14;
          }
        }
        bVar13 = bVar10 + 1;
        iVar15 = iVar15 + 1;
        if ((int)(*(byte *)((longlong)plVar14 + 0xe) - 1) <= (int)(uint)bVar10) {
          bVar13 = 0;
        }
      } while (iVar15 < (int)(uint)*(byte *)((longlong)plVar14 + 0xe));
    }
  }
  return param_2;
}

