/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401fe080; RVA 0x1fe080
 * Ghidra-generated research pseudocode, inferred types, not original source. */

uint * FUN_1401fe080(undefined8 *param_1,ushort param_2,short param_3,uint *param_4,
                    undefined8 param_5)

{
  uint *puVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  undefined2 uVar4;
  uint uVar5;
  uint *puVar6;
  uint *puVar7;
  int iVar8;
  uint *puVar9;
  undefined2 *puVar10;
  ulonglong uVar11;
  uint uVar12;
  uint uVar13;
  
  *param_1 = 0x10000002;
  puVar6 = (uint *)(param_1 + 6);
  iVar8 = 0;
  uVar12 = (uint)param_3;
  *(undefined4 *)(param_1 + 1) = 0;
  puVar7 = (uint *)(param_1 + 10);
  *(undefined4 *)((longlong)param_1 + 0xc) = 0x50000002;
  *(undefined4 *)(param_1 + 2) = 1;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0x24000000;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  param_1[4] = (ulonglong)param_2;
  if ((param_2 & 0x10) == 0) {
    *(undefined4 *)(param_1 + 3) = 0xf0;
    *(undefined8 *)((longlong)param_1 + 0x34) = 0;
    *puVar6 = uVar12 + 1 | 0x10000000;
    *(uint *)((longlong)param_1 + 0x3c) = uVar12 + 1 | 0x50000000;
    *(uint *)(param_1 + 8) = uVar12;
    *(undefined4 *)((longlong)param_1 + 0x44) = 0x24000000;
    param_1[9] = 0x41;
    if (3 < (int)uVar12) {
      uVar5 = (uVar12 - 4 >> 2) + 1;
      uVar11 = (ulonglong)uVar5;
      iVar8 = uVar5 * 4;
      puVar6 = (uint *)((longlong)param_1 + 0x6c);
      do {
        uVar5 = *param_4;
        puVar6[-6] = 0x3f800000;
        *puVar7 = uVar5;
        puVar7 = puVar7 + 0x10;
        uVar5 = param_4[7];
        puVar6[-5] = param_4[6] << 0x10 | param_4[5];
        puVar6[-4] = uVar5 >> 4;
        uVar5 = param_4[9];
        puVar6[-2] = 0x3f800000;
        puVar6[-3] = uVar5;
        uVar5 = param_4[0x10];
        puVar6[-1] = param_4[0xf] << 0x10 | param_4[0xe];
        *puVar6 = uVar5 >> 4;
        uVar5 = param_4[0x12];
        puVar6[2] = 0x3f800000;
        puVar6[1] = uVar5;
        uVar5 = param_4[0x19];
        puVar6[3] = param_4[0x18] << 0x10 | param_4[0x17];
        puVar6[4] = uVar5 >> 4;
        uVar5 = param_4[0x1b];
        puVar6[6] = 0x3f800000;
        puVar6[5] = uVar5;
        puVar9 = param_4 + 0x21;
        uVar5 = param_4[0x22];
        puVar1 = param_4 + 0x20;
        param_4 = param_4 + 0x24;
        puVar6[7] = *puVar9 << 0x10 | *puVar1;
        puVar6[8] = uVar5 >> 4;
        uVar11 = uVar11 - 1;
        puVar6 = puVar6 + 0x10;
      } while (uVar11 != 0);
    }
    if (iVar8 < (int)uVar12) {
      puVar10 = (undefined2 *)((longlong)param_4 + 2);
      do {
        iVar8 = iVar8 + 1;
        uVar4 = *puVar10;
        uVar2 = *(undefined1 *)((longlong)puVar10 + -1);
        uVar3 = *(undefined1 *)(puVar10 + -1);
        puVar7[1] = 0x3f800000;
        *puVar7 = CONCAT31(CONCAT21(uVar4,uVar2),uVar3);
        uVar5 = *(uint *)(puVar10 + 0xd);
        puVar7[2] = *(int *)(puVar10 + 0xb) << 0x10 | *(uint *)(puVar10 + 9);
        puVar7[3] = uVar5 >> 4;
        puVar7 = puVar7 + 4;
        puVar10 = puVar10 + 0x12;
      } while (iVar8 < (int)uVar12);
    }
    return puVar7;
  }
  param_1[5] = param_5;
  *(undefined4 *)(param_1 + 3) = 0x60;
  uVar5 = (int)(uVar12 * 3 + 1) / 2 + 1;
  uVar13 = uVar5 | 0x50000000;
  *puVar6 = uVar5 | 0x10000000;
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  if ((param_2 >> 8 & 1) == 0) {
    FUN_140197b30(puVar6,0);
    *(undefined4 *)(param_1 + 7) = 0;
    *(uint *)((longlong)param_1 + 0x3c) = uVar13;
    *(uint *)(param_1 + 8) = uVar12;
    *(undefined4 *)((longlong)param_1 + 0x44) = 0x34000000;
    param_1[9] = 0x412;
    if (3 < (int)uVar12) {
      uVar5 = (uVar12 - 4 >> 2) + 1;
      uVar11 = (ulonglong)uVar5;
      iVar8 = uVar5 * 4;
      puVar6 = (uint *)((longlong)param_1 + 100);
      do {
        uVar5 = param_4[2];
        *puVar7 = param_4[1];
        puVar6[-4] = uVar5;
        uVar5 = param_4[3];
        puVar6[-3] = *param_4;
        puVar6[-2] = uVar5;
        uVar5 = param_4[7];
        puVar6[-1] = param_4[6] << 0x10 | param_4[5];
        *puVar6 = uVar5 >> 4;
        uVar5 = param_4[0xb];
        puVar6[1] = param_4[10];
        puVar6[2] = uVar5;
        uVar5 = param_4[0xc];
        puVar6[3] = param_4[9];
        puVar6[4] = uVar5;
        uVar5 = param_4[0x10];
        puVar6[5] = param_4[0xf] << 0x10 | param_4[0xe];
        puVar6[6] = uVar5 >> 4;
        uVar5 = param_4[0x14];
        puVar6[7] = param_4[0x13];
        puVar6[8] = uVar5;
        uVar5 = param_4[0x15];
        puVar6[9] = param_4[0x12];
        puVar6[10] = uVar5;
        uVar5 = param_4[0x19];
        puVar6[0xb] = param_4[0x18] << 0x10 | param_4[0x17];
        puVar6[0xc] = uVar5 >> 4;
        uVar5 = param_4[0x1c];
        puVar6[0xe] = param_4[0x1d];
        puVar6[0xd] = uVar5;
        uVar5 = param_4[0x1e];
        puVar7 = puVar7 + 0x18;
        puVar6[0xf] = param_4[0x1b];
        puVar6[0x10] = uVar5;
        puVar9 = param_4 + 0x21;
        uVar5 = param_4[0x22];
        puVar1 = param_4 + 0x20;
        param_4 = param_4 + 0x24;
        puVar6[0x11] = *puVar9 << 0x10 | *puVar1;
        puVar6[0x12] = uVar5 >> 4;
        uVar11 = uVar11 - 1;
        puVar6 = puVar6 + 0x18;
      } while (uVar11 != 0);
    }
    if (iVar8 < (int)uVar12) {
      puVar6 = puVar7 + 5;
      puVar9 = param_4 + 1;
      do {
        uVar5 = puVar9[1];
        *puVar7 = *puVar9;
        puVar6[-4] = uVar5;
        puVar7 = puVar7 + 6;
        iVar8 = iVar8 + 1;
        uVar5 = puVar9[2];
        puVar6[-3] = puVar9[-1];
        puVar6[-2] = uVar5;
        uVar5 = puVar9[6];
        puVar6[-1] = puVar9[5] << 0x10 | puVar9[4];
        *puVar6 = uVar5 >> 4;
        puVar6 = puVar6 + 6;
        puVar9 = puVar9 + 9;
      } while (iVar8 < (int)uVar12);
    }
  }
  else {
    *(undefined4 *)(param_1 + 7) = 0;
    *(uint *)((longlong)param_1 + 0x3c) = uVar13;
    *(uint *)(param_1 + 8) = uVar12;
    *(undefined4 *)((longlong)param_1 + 0x44) = 0x34000000;
    param_1[9] = 0x413;
    if (3 < (int)uVar12) {
      uVar5 = (uVar12 - 4 >> 2) + 1;
      uVar11 = (ulonglong)uVar5;
      iVar8 = uVar5 * 4;
      puVar6 = (uint *)((longlong)param_1 + 100);
      do {
        *puVar7 = (int)*(short *)((longlong)param_4 + 0x12) << 0x10 | (int)(short)param_4[4];
        puVar6[-3] = *param_4;
        puVar6[-2] = 0x3f800000;
        uVar5 = param_4[7];
        puVar6[-1] = param_4[6] << 0x10 | param_4[5];
        *puVar6 = uVar5 >> 4;
        puVar6[1] = (int)*(short *)((longlong)param_4 + 0x36) << 0x10 | (int)(short)param_4[0xd];
        puVar6[3] = param_4[9];
        puVar6[4] = 0x3f800000;
        uVar5 = param_4[0x10];
        puVar6[5] = param_4[0xf] << 0x10 | param_4[0xe];
        puVar6[6] = uVar5 >> 4;
        puVar6[7] = (int)*(short *)((longlong)param_4 + 0x5a) << 0x10 | (int)(short)param_4[0x16];
        puVar6[9] = param_4[0x12];
        puVar6[10] = 0x3f800000;
        uVar5 = param_4[0x19];
        puVar6[0xb] = param_4[0x18] << 0x10 | param_4[0x17];
        puVar6[0xc] = uVar5 >> 4;
        puVar6[0xd] = (int)*(short *)((longlong)param_4 + 0x7e) << 0x10 | (int)(short)param_4[0x1f];
        puVar7 = puVar7 + 0x18;
        puVar6[0xf] = param_4[0x1b];
        puVar6[0x10] = 0x3f800000;
        puVar9 = param_4 + 0x21;
        uVar5 = param_4[0x22];
        puVar1 = param_4 + 0x20;
        param_4 = param_4 + 0x24;
        puVar6[0x11] = *puVar9 << 0x10 | *puVar1;
        puVar6[0x12] = uVar5 >> 4;
        uVar11 = uVar11 - 1;
        puVar6 = puVar6 + 0x18;
      } while (uVar11 != 0);
    }
    if (iVar8 < (int)uVar12) {
      puVar6 = puVar7 + 5;
      puVar9 = param_4 + 4;
      do {
        iVar8 = iVar8 + 1;
        *puVar7 = (int)*(short *)((longlong)puVar9 + 2) << 0x10 | (int)(short)*puVar9;
        puVar7 = puVar7 + 6;
        uVar5 = puVar9[-4];
        puVar6[-2] = 0x3f800000;
        puVar6[-3] = uVar5;
        uVar5 = puVar9[3];
        puVar6[-1] = puVar9[2] << 0x10 | puVar9[1];
        *puVar6 = uVar5 >> 4;
        puVar6 = puVar6 + 6;
        puVar9 = puVar9 + 9;
      } while (iVar8 < (int)uVar12);
    }
  }
  puVar6 = puVar7 + 2;
  if ((uVar12 & 1) == 0) {
    puVar6 = puVar7;
  }
  return puVar6;
}

