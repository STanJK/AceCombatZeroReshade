/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140202ed0; RVA 0x202ed0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

bool FUN_140202ed0(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  fVar7 = *param_2;
  fVar3 = param_2[1];
  fVar1 = param_2[2];
  fVar2 = param_2[3];
  fVar4 = fVar2 * param_1[0xf] + fVar1 * param_1[0xb] + fVar3 * param_1[7] + fVar7 * param_1[3];
  fVar5 = fVar2 * param_1[0xe] + fVar1 * param_1[10] + fVar3 * param_1[6] + fVar7 * param_1[2];
  fVar6 = fVar2 * param_1[0xd] + fVar1 * param_1[9] + fVar3 * param_1[5] + fVar7 * param_1[1];
  fVar7 = fVar2 * param_1[0xc] + fVar1 * param_1[8] + fVar3 * param_1[4] + fVar7 * *param_1;
  if ((((fVar7 < fVar4) && (fVar3 = (float)((uint)fVar4 ^ DAT_1402d3770), fVar3 < fVar7)) &&
      (fVar6 < fVar4)) && ((fVar3 < fVar6 && (fVar5 < fVar4)))) {
    return fVar5 <= fVar3;
  }
  return true;
}

