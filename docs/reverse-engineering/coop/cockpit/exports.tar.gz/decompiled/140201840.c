/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140201840; RVA 0x201840
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140201840(undefined8 param_1,int *param_2)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  int iVar4;
  
  uVar1 = DAT_14032c8f8;
  puVar2 = (undefined8 *)FUN_140200de0(DAT_14032c8f8,0xf0,4);
  iVar4 = *param_2;
  DAT_14032c8b0 = puVar2;
  *(undefined4 *)((longlong)puVar2 + 0xc) = 0xffffffff;
  puVar2[2] = 0;
  *puVar2 = 0;
  *(int *)(puVar2 + 1) = iVar4;
  puVar3 = (undefined8 *)FUN_140200de0(uVar1,iVar4 << 5,0x10);
  iVar4 = 0;
  *puVar2 = puVar3;
  if (0 < *(int *)(puVar2 + 1)) {
    do {
      *puVar3 = 0;
      iVar4 = iVar4 + 1;
      puVar3[1] = 0;
      puVar3[2] = 0;
      *(undefined4 *)(puVar3 + 3) = 0;
      puVar3 = puVar3 + 4;
    } while (iVar4 < *(int *)(puVar2 + 1));
  }
  iVar4 = param_2[1];
  *(undefined4 *)((longlong)puVar2 + 0x3c) = 0xffffffff;
  puVar2[8] = 0;
  puVar2[6] = 0;
  *(int *)(puVar2 + 7) = iVar4;
  puVar3 = (undefined8 *)FUN_140200de0(uVar1,iVar4 << 5,0x10);
  iVar4 = 0;
  puVar2[6] = puVar3;
  if (0 < *(int *)(puVar2 + 7)) {
    do {
      *puVar3 = 0;
      iVar4 = iVar4 + 1;
      puVar3[1] = 0;
      puVar3[2] = 0;
      *(undefined4 *)(puVar3 + 3) = 0;
      puVar3 = puVar3 + 4;
    } while (iVar4 < *(int *)(puVar2 + 7));
  }
  iVar4 = param_2[2];
  *(undefined4 *)((longlong)puVar2 + 0x6c) = 0xffffffff;
  puVar2[0xe] = 0;
  puVar2[0xc] = 0;
  *(int *)(puVar2 + 0xd) = iVar4;
  puVar3 = (undefined8 *)FUN_140200de0(uVar1,iVar4 << 5,0x10);
  iVar4 = 0;
  puVar2[0xc] = puVar3;
  if (0 < *(int *)(puVar2 + 0xd)) {
    do {
      *puVar3 = 0;
      iVar4 = iVar4 + 1;
      puVar3[1] = 0;
      puVar3[2] = 0;
      *(undefined4 *)(puVar3 + 3) = 0;
      puVar3 = puVar3 + 4;
    } while (iVar4 < *(int *)(puVar2 + 0xd));
  }
  iVar4 = param_2[3];
  *(undefined4 *)((longlong)puVar2 + 0x9c) = 0xffffffff;
  puVar2[0x14] = 0;
  puVar2[0x12] = 0;
  *(int *)(puVar2 + 0x13) = iVar4;
  puVar3 = (undefined8 *)FUN_140200de0(uVar1,iVar4 << 5,0x10);
  iVar4 = 0;
  puVar2[0x12] = puVar3;
  if (0 < *(int *)(puVar2 + 0x13)) {
    do {
      *puVar3 = 0;
      iVar4 = iVar4 + 1;
      puVar3[1] = 0;
      puVar3[2] = 0;
      *(undefined4 *)(puVar3 + 3) = 0;
      puVar3 = puVar3 + 4;
    } while (iVar4 < *(int *)(puVar2 + 0x13));
  }
  iVar4 = param_2[4];
  *(undefined4 *)((longlong)puVar2 + 0xcc) = 0xffffffff;
  puVar2[0x1a] = 0;
  puVar2[0x18] = 0;
  *(int *)(puVar2 + 0x19) = iVar4;
  puVar3 = (undefined8 *)FUN_140200de0(uVar1,iVar4 << 5,0x10);
  iVar4 = 0;
  puVar2[0x18] = puVar3;
  if (0 < *(int *)(puVar2 + 0x19)) {
    do {
      *puVar3 = 0;
      iVar4 = iVar4 + 1;
      puVar3[1] = 0;
      puVar3[2] = 0;
      *(undefined4 *)(puVar3 + 3) = 0;
      puVar3 = puVar3 + 4;
    } while (iVar4 < *(int *)(puVar2 + 0x19));
  }
  return;
}

