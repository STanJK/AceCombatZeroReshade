/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140004e80; RVA 0x4e80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined4 * FUN_140004e80(undefined4 *param_1)

{
  *param_1 = 0x44200000;
  param_1[0x68] = 0;
  *(undefined8 *)(param_1 + 0xd) = 0;
  *(undefined8 *)(param_1 + 0x11) = 0;
  param_1[0x13] = 0;
  param_1[0x18] = 0;
  *(undefined8 *)(param_1 + 0x1c) = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x16) = 0;
  param_1[0x22] = 0;
  param_1[0x1b] = 0;
  param_1[0x28] = 0;
  *(undefined8 *)(param_1 + 0x2c) = 0;
  *(undefined8 *)(param_1 + 0x30) = 0;
  *(undefined8 *)(param_1 + 0x26) = 0;
  param_1[0x32] = 0;
  param_1[0x2b] = 0;
  param_1[0x38] = 0;
  *(undefined8 *)(param_1 + 0x3c) = 0;
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x36) = 0;
  param_1[0x42] = 0;
  param_1[0x3b] = 0;
  param_1[0x48] = 0;
  *(undefined8 *)(param_1 + 0x4c) = 0;
  *(undefined8 *)(param_1 + 0x50) = 0;
  *(undefined8 *)(param_1 + 0x46) = 0;
  param_1[0x52] = 0;
  param_1[0x4b] = 0;
  param_1[0x58] = 0;
  *(undefined8 *)(param_1 + 0x5c) = 0;
  *(undefined8 *)(param_1 + 0x60) = 0;
  *(undefined8 *)(param_1 + 0x56) = 0;
  param_1[0x62] = 0;
  param_1[0x5b] = 0;
  *(undefined1 *)((longlong)param_1 + 0x1aa) = 0;
  param_1[1] = 0x43f00000;
  param_1[2] = 0x44000000;
  param_1[3] = 0x3f800000;
  *(undefined8 *)(param_1 + 4) = 0x477fff00;
  *(undefined8 *)(param_1 + 0xb) = 0x477fff00;
  param_1[6] = 0x1c00200;
  param_1[7] = 0x3f800000;
  *(undefined8 *)(param_1 + 8) = 0x4b7fffff;
  param_1[10] = 0x1c00200;
  *(undefined8 *)(param_1 + 0xf) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x14) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x19) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x1e) = 0x3f800000;
  param_1[0x23] = 0x3f800000;
  *(undefined8 *)(param_1 + 0x24) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x29) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x2e) = 0x3f800000;
  param_1[0x33] = 0x3f800000;
  *(undefined8 *)(param_1 + 0x34) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x39) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x3e) = 0x3f800000;
  param_1[0x43] = 0x3f800000;
  *(undefined8 *)(param_1 + 0x44) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x49) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x4e) = 0x3f800000;
  param_1[0x53] = 0x3f800000;
  *(undefined8 *)(param_1 + 0x54) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x59) = 0x3f800000;
  *(undefined8 *)(param_1 + 0x5e) = 0x3f800000;
  param_1[99] = 0x3f800000;
  *(undefined2 *)(param_1 + 0x6a) = 1;
  return param_1;
}

