/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b3560; RVA 0xb3560
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_1400b3560(longlong param_1,undefined8 param_2,undefined8 *param_3)

{
  float fVar1;
  undefined1 auVar2 [16];
  float fVar3;
  float fVar4;
  float fVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  int iVar12;
  undefined8 *puVar13;
  longlong lVar14;
  undefined8 *puVar15;
  undefined1 *puVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  undefined1 auVar20 [64];
  float fVar21;
  undefined1 auVar22 [64];
  float fVar23;
  float fVar24;
  float fVar25;
  undefined1 auStack_348 [32];
  undefined8 local_328;
  float local_318;
  float local_314;
  float local_310;
  float local_30c;
  float local_308;
  float local_304;
  float local_300;
  float local_2fc;
  float local_2f8;
  float local_2f4;
  float local_2e8 [6];
  undefined4 local_2d0;
  undefined4 local_2cc;
  float local_2c8;
  float local_2c4;
  float local_2c0;
  float local_2bc;
  float local_2b8;
  float fStack_2b4;
  float fStack_2b0;
  float fStack_2ac;
  undefined1 local_2a8 [16];
  undefined8 local_298;
  undefined4 uStack_290;
  float fStack_28c;
  int iStack_284;
  int iStack_280;
  undefined8 uStack_27c;
  undefined1 uStack_274;
  undefined1 uStack_273;
  undefined1 uStack_272;
  undefined1 uStack_271;
  float fStack_268;
  float fStack_264;
  float fStack_260;
  float fStack_25c;
  undefined8 local_258;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  float fStack_244;
  int iStack_23c;
  int local_238;
  undefined8 uStack_234;
  undefined1 uStack_22c;
  undefined1 uStack_22b;
  undefined1 uStack_22a;
  undefined1 uStack_229;
  float fStack_220;
  int local_218;
  int local_214;
  undefined8 local_210;
  undefined1 local_208;
  undefined1 local_207;
  undefined1 local_206;
  undefined1 local_205;
  float local_1fc;
  int local_1f4;
  int local_1f0;
  undefined8 local_1ec;
  undefined1 local_1e4;
  undefined1 local_1e3;
  undefined1 local_1e2;
  undefined1 local_1e1;
  float local_1d8;
  int local_1d0;
  int local_1cc;
  undefined8 local_1c8;
  undefined1 local_1c0;
  undefined1 local_1bf;
  undefined1 local_1be;
  undefined1 local_1bd;
  float local_1b4;
  int local_1ac;
  int local_1a8;
  undefined8 local_1a4;
  float fStack_188;
  float fStack_184;
  float fStack_17c;
  float local_178;
  float fStack_174;
  float fStack_16c;
  float fStack_168;
  float fStack_164;
  float fStack_15c;
  float local_158;
  float local_154;
  float local_14c;
  ulonglong local_d8;
  
  local_d8 = DAT_140309040 ^ (ulonglong)auStack_348;
  if (*(char *)(param_1 + 0xfd) != '\0') {
    return param_2;
  }
  local_2a8 = *(undefined1 (*) [16])(param_1 + 0x54);
  auVar20 = ZEXT1664(local_2a8);
  auVar2 = vshufps_avx(local_2a8,local_2a8,0x55);
  auVar22 = ZEXT1664(auVar2);
  if ((((local_2a8._0_4_ <= DAT_1402d1ff8) && (DAT_1402d2cd4 <= local_2a8._0_4_)) &&
      (auVar2._0_4_ <= DAT_1402d1ff8)) && (DAT_1402d2cd4 <= auVar2._0_4_)) {
    return param_2;
  }
  local_2e8[0] = DAT_1402d22d0;
  local_2e8[4] = 0.0;
  local_2c8 = 0.0;
  local_2b8 = 0.0;
  local_2e8[1] = 0.0;
  local_2e8[5] = DAT_1402d22d0;
  local_2c4 = 0.0;
  fStack_2b4 = 0.0;
  local_2e8[2] = 0.0;
  local_2d0 = 0;
  local_2c0 = DAT_1402d22d0;
  fStack_2b0 = 0.0;
  local_2e8[3] = 0.0;
  local_2cc = 0;
  local_2bc = 0.0;
  fStack_2ac = DAT_1402d22d0;
  FUN_140202230(local_2e8,local_2e8,local_2a8);
  lVar14 = 3;
  puVar11 = &local_298;
  do {
    puVar15 = param_3;
    puVar13 = puVar11;
    uVar8 = puVar15[1];
    uVar9 = puVar15[2];
    uVar10 = puVar15[3];
    uVar6 = puVar15[0xe];
    uVar7 = puVar15[0xf];
    *puVar13 = *puVar15;
    puVar13[1] = uVar8;
    puVar13[2] = uVar9;
    puVar13[3] = uVar10;
    uVar8 = puVar15[5];
    uVar9 = puVar15[6];
    uVar10 = puVar15[7];
    puVar13[4] = puVar15[4];
    puVar13[5] = uVar8;
    puVar13[6] = uVar9;
    puVar13[7] = uVar10;
    uVar8 = puVar15[9];
    uVar9 = puVar15[10];
    uVar10 = puVar15[0xb];
    puVar13[8] = puVar15[8];
    puVar13[9] = uVar8;
    puVar13[10] = uVar9;
    puVar13[0xb] = uVar10;
    uVar8 = puVar15[0xd];
    puVar13[0xc] = puVar15[0xc];
    puVar13[0xd] = uVar8;
    puVar13[0xe] = uVar6;
    puVar13[0xf] = uVar7;
    lVar14 = lVar14 + -1;
    puVar11 = puVar13 + 0x10;
    param_3 = puVar15 + 0x10;
  } while (lVar14 != 0);
  uVar6 = puVar15[0x11];
  uVar7 = puVar15[0x12];
  uVar8 = puVar15[0x13];
  fStack_268 = _DAT_1402d3710 * local_2c8 + local_2b8;
  fStack_264 = _UNK_1402d3714 * local_2c4 + fStack_2b4;
  fStack_260 = _UNK_1402d3718 * local_2c0 + fStack_2b0;
  fStack_25c = _UNK_1402d371c * local_2bc + fStack_2ac;
  puVar13[0x10] = puVar15[0x10];
  puVar13[0x11] = uVar6;
  puVar13[0x12] = uVar7;
  puVar13[0x13] = uVar8;
  uVar6 = puVar15[0x15];
  uVar7 = puVar15[0x16];
  uVar8 = puVar15[0x17];
  puVar13[0x14] = puVar15[0x14];
  puVar13[0x15] = uVar6;
  puVar13[0x16] = uVar7;
  puVar13[0x17] = uVar8;
  uStack_290 = *(undefined4 *)(param_1 + 0x368);
  local_258 = CONCAT44(auVar22._0_4_,auVar20._0_4_);
  uStack_250 = vextractps_avx(auVar20._0_16_,2);
  uStack_24c = vextractps_avx(auVar20._0_16_,3);
  FUN_1401fbec0(&local_298);
  fStack_28c = DAT_1402d22d0;
  local_178 = DAT_1402d2504 * local_178;
  fStack_16c = DAT_1402d2504 * fStack_16c;
  fStack_174 = DAT_1402d2504 * fStack_174;
  fVar19 = DAT_1402d256c * fStack_168;
  fVar24 = DAT_1402d256c * fStack_15c;
  fVar1 = DAT_1402d256c * fStack_164;
  local_318 = -(DAT_1402d25c0 * fStack_168) + local_178 + local_158;
  local_310 = (local_178 - DAT_1402d256c * fStack_188) + fVar19 + local_158;
  local_308 = DAT_1402d256c * fStack_188 + local_178 + fVar19 + local_158;
  local_300 = local_158 + fVar19;
  local_2f8 = fVar19 + local_178 + local_158;
  fVar19 = DAT_1402d22d0 / (-(DAT_1402d25c0 * fStack_15c) + fStack_16c + local_14c);
  local_314 = -(DAT_1402d25c0 * fStack_164) + fStack_174 + local_154;
  local_30c = (fStack_174 - DAT_1402d256c * fStack_184) + fVar1 + local_154;
  fVar21 = DAT_1402d22d0 / ((fStack_16c - DAT_1402d256c * fStack_17c) + fVar24 + local_14c);
  fVar23 = DAT_1402d22d0 / (DAT_1402d256c * fStack_17c + fStack_16c + fVar24 + local_14c);
  local_304 = DAT_1402d256c * fStack_184 + fStack_174 + fVar1 + local_154;
  local_2fc = local_154 + fVar1;
  fVar25 = DAT_1402d22d0 / (fVar24 + fStack_16c + local_14c);
  fVar24 = DAT_1402d22d0 / (local_14c + fVar24);
  iVar12 = *(int *)(param_1 + 0x388);
  local_2f4 = fVar1 + fStack_174 + local_154;
  if (*(char *)(param_1 + 0x3cb) != '\0') {
    if (*(char *)(param_1 + 0x3ca) == '\0') {
      iVar12 = iVar12 + -0x80;
    }
    else if (*(char *)(param_1 + 0x3ca) == '\x01') {
      iVar12 = iVar12 + 0x80;
    }
  }
  auVar2 = vcvtdq2ps_avx(ZEXT416(iVar12 + 0xff));
  fVar17 = auVar2._0_4_;
  fVar1 = (fVar19 * local_318 + fVar17) - DAT_1402d2a04;
  fVar3 = (fVar21 * local_310 + fVar17) - DAT_1402d2a04;
  fVar4 = (fVar23 * local_308 + fVar17) - DAT_1402d2a04;
  fVar5 = (fVar24 * local_300 + fVar17) - DAT_1402d2a04;
  auVar2 = vcvtdq2ps_avx(ZEXT416(*(int *)(param_1 + 0x38c) + 0x17d));
  fVar18 = auVar2._0_4_;
  fVar19 = (fVar19 * local_314 + fVar18) - DAT_1402d2a04;
  fVar21 = (fVar21 * local_30c + fVar18) - DAT_1402d2a04;
  fVar23 = (fVar23 * local_304 + fVar18) - DAT_1402d2a04;
  fVar24 = (fVar24 * local_2fc + fVar18) - DAT_1402d2a04;
  fVar18 = (fVar25 * local_2f4 + fVar18) - DAT_1402d2a04;
  fVar25 = (fVar25 * local_2f8 + fVar17) - DAT_1402d2a04;
  if (*(ushort *)(param_1 + 0x39c) == 0xffff) {
    if ((*(uint *)(param_1 + 0x34c) & 0x10001) != 0) {
      uStack_250 = *(undefined4 *)(param_1 + 0x1f8);
      goto LAB_1400b3a2f;
    }
  }
  else {
    if ((*(uint *)(param_1 + 0x348) >> 0x1a & 1) == 0) {
      *(uint *)(param_1 + 0x348) = *(uint *)(param_1 + 0x348) | 0x4000000;
    }
    if ((*(ushort *)(param_1 + 0x39c) & 4) == 0) {
      uStack_250 = *(undefined4 *)(param_1 + 0x1f8);
      goto LAB_1400b3a2f;
    }
  }
  uStack_250 = *(undefined4 *)(param_1 + 600);
LAB_1400b3a2f:
  local_298._0_1_ = (undefined1)uStack_250;
  local_298._2_1_ = (undefined1)((uint)uStack_250 >> 0x10);
  iStack_284 = (int)(fVar1 * DAT_1402d2544 + DAT_1402d2b1c);
  fStack_260 = (float)(int)(fVar4 * DAT_1402d2544 + DAT_1402d2b1c);
  local_298._3_1_ = (undefined1)((uint)uStack_250 >> 0x18);
  iStack_280 = (int)(fVar19 * DAT_1402d2544 + DAT_1402d2b2c);
  fStack_25c = (float)(int)(fVar23 * DAT_1402d2544 + DAT_1402d2b2c);
  iStack_23c = (int)(fVar3 * DAT_1402d2544 + DAT_1402d2b1c);
  local_238 = (int)(fVar21 * DAT_1402d2544 + DAT_1402d2b2c);
  local_1f4 = (int)(fVar5 * DAT_1402d2544 + DAT_1402d2b1c);
  fStack_268 = fStack_28c;
  fStack_244 = fStack_28c;
  fStack_220 = fStack_28c;
  local_1fc = fStack_28c;
  local_1d8 = fStack_28c;
  local_1b4 = fStack_28c;
  uStack_27c = 0xfffffff;
  local_298._1_1_ = (undefined1)((uint)uStack_250 >> 8);
  local_258 = 0xfffffff;
  uStack_234 = 0xfffffff;
  local_210 = 0xfffffff;
  local_1ec = 0xfffffff;
  local_1c8 = 0xfffffff;
  local_1a4 = 0xfffffff;
  puVar16 = (undefined1 *)&local_298;
  local_1f0 = (int)(fVar24 * DAT_1402d2544 + DAT_1402d2b2c);
  lVar14 = 6;
  local_1d0 = (int)(fVar25 * DAT_1402d2544 + DAT_1402d2b1c);
  local_1cc = (int)(fVar18 * DAT_1402d2544 + DAT_1402d2b2c);
  uStack_274 = (undefined1)local_298;
  uStack_273 = local_298._1_1_;
  uStack_272 = local_298._2_1_;
  uStack_271 = local_298._3_1_;
  uStack_22c = (undefined1)local_298;
  uStack_22b = local_298._1_1_;
  uStack_22a = local_298._2_1_;
  uStack_229 = local_298._3_1_;
  local_218 = iStack_284;
  local_214 = iStack_280;
  local_208 = (undefined1)local_298;
  local_207 = local_298._1_1_;
  local_206 = local_298._2_1_;
  local_205 = local_298._3_1_;
  local_1e4 = (undefined1)local_298;
  local_1e3 = local_298._1_1_;
  local_1e2 = local_298._2_1_;
  local_1e1 = local_298._3_1_;
  local_1c0 = (undefined1)local_298;
  local_1bf = local_298._1_1_;
  local_1be = local_298._2_1_;
  local_1bd = local_298._3_1_;
  local_1ac = iStack_284;
  local_1a8 = iStack_280;
  do {
    local_328 = 0;
    param_2 = FUN_1401fe080(param_2,0x141,2,puVar16);
    puVar16 = puVar16 + 0x24;
    lVar14 = lVar14 + -1;
  } while (lVar14 != 0);
  return param_2;
}

