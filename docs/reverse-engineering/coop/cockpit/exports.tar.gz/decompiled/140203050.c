/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140203050; RVA 0x203050
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140203050(uint *param_1,uint *param_2,float *param_3)

{
  uint uVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined1 auVar4 [64];
  uint local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  uint local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  float local_34;
  uint local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  uint local_1c;
  
  if (((*param_3 == 0.0) && (param_3[1] == 0.0)) && (param_3[2] == 0.0)) {
    *param_1 = *param_2;
    param_1[1] = param_2[1];
    param_1[2] = param_2[2];
    param_1[3] = param_2[3];
    return;
  }
  auVar4 = ZEXT464(DAT_1402d22d0);
  local_58 = DAT_1402d22d0;
  local_44 = DAT_1402d22d0;
  local_30 = DAT_1402d22d0;
  local_1c = DAT_1402d22d0;
  local_48 = 0;
  local_38 = 0;
  local_28 = 0;
  local_54 = 0;
  local_34 = 0.0;
  local_24 = 0;
  local_50 = 0;
  local_40 = 0;
  local_20 = 0;
  local_4c = 0;
  local_3c = 0;
  local_2c = 0;
  FUN_140202230(&local_58,&local_58);
  FUN_140202230(&local_58,&local_58,param_2);
  auVar3 = ZEXT416(DAT_1402d2d64);
  if (local_34 <= auVar4._0_4_) {
    auVar2 = vcmpss_avx(ZEXT416((uint)local_34),auVar3,1);
    auVar2 = vblendvps_avx(ZEXT416((uint)local_34),auVar3,auVar2);
  }
  else {
    auVar2 = auVar4._0_16_;
  }
  auVar3 = vmaxss_avx(auVar2,auVar3);
  auVar3 = vminss_avx(auVar3,auVar4._0_16_);
  uVar1 = FUN_140272150(auVar3._0_8_);
  *param_1 = uVar1 ^ DAT_1402d3770;
  uVar1 = FUN_140272370(local_38,local_30);
  param_1[1] = uVar1;
  uVar1 = FUN_140272370(local_54,local_44);
  param_1[2] = uVar1;
  return;
}

