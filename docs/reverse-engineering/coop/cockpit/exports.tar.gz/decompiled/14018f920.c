/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14018f920; RVA 0x18f920
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14018f920(undefined8 param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  
  do {
    while( true ) {
      while( true ) {
        while( true ) {
          while( true ) {
            while( true ) {
              uVar2 = *param_2;
              uVar1 = uVar2 & 0xffff;
              if ((param_2[1] & 0x7fffffff) == 0) {
                puVar3 = (uint *)0x0;
              }
              else {
                puVar3 = *(uint **)(DAT_14033acb8 + (ulonglong)(param_2[1] & 0x3fffffff) * 8);
              }
              FUN_14019d160();
              uVar2 = uVar2 & 0x70000000;
              if (uVar2 != 0x10000000) break;
              param_2 = (uint *)((longlong)param_2 + (ulonglong)(uVar1 * 0x10 + 0x10));
            }
            if (uVar2 != 0x20000000) break;
            param_2 = puVar3;
          }
          if (uVar2 != 0x30000000) break;
          param_2 = param_2 + 4;
        }
        if (uVar2 != 0x50000000) break;
        *(ulonglong *)(&DAT_14031d690 + (longlong)DAT_14031d6a0 * 8) =
             (ulonglong)((uVar1 + 1) * 0x10) + (longlong)param_2;
        DAT_14031d6a0 = DAT_14031d6a0 + 1;
        param_2 = puVar3;
      }
      if (uVar2 != 0x60000000) break;
      if ((((DAT_14033bbf0 != -1) && (*(longlong *)(DAT_14031cf20 + 0x88) != 0)) &&
          (*(longlong *)(DAT_14031cf20 + 0x90) != 0)) &&
         ((*(longlong *)(DAT_14031cf20 + 0x98) != 0 && (*(longlong *)(DAT_14031cf20 + 0xa0) != 0))))
      {
        if (*(code **)(&DAT_14031d7c0 + (longlong)DAT_14033bbf0 * 0x48) != (code *)0x0) {
          (**(code **)(&DAT_14031d7c0 + (longlong)DAT_14033bbf0 * 0x48))();
        }
      }
      DAT_14031d6a0 = DAT_14031d6a0 + -1;
      param_2 = *(uint **)(&DAT_14031d690 + (longlong)DAT_14031d6a0 * 8);
    }
  } while (uVar2 != 0x70000000);
  return;
}

