/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140201a40; RVA 0x201a40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140201a40(ulonglong param_1,undefined8 param_2,uint param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  undefined8 *puVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  
  plVar7 = (longlong *)((param_1 & 0xffffffff) * 0x30 + DAT_14032c8b0);
  puVar6 = (undefined8 *)((ulonglong)param_3 * 0x30 + DAT_14032c8b0);
  puVar6[3] = plVar7[3];
  puVar3 = (undefined8 *)FUN_140201120(plVar7);
  puVar5 = (undefined8 *)*puVar6;
  iVar4 = 0;
  if (0 < *(int *)(puVar6 + 1)) {
    do {
      *puVar5 = puVar3;
      puVar5[2] = puVar3 + 2;
      puVar5[1] = puVar3;
      *(undefined4 *)(puVar5 + 3) = 0;
      *puVar3 = 0x20000000;
      FUN_140197b30(puVar3);
      puVar3[1] = 0;
      puVar5 = puVar5 + 4;
      puVar3 = puVar3 + 2;
      iVar4 = iVar4 + 1;
    } while (iVar4 < *(int *)(puVar6 + 1));
  }
  puVar6[2] = puVar3;
  if (*(int *)((longlong)plVar7 + 0xc) != -1) {
    *(undefined8 **)((longlong)*(int *)((longlong)plVar7 + 0xc) * 0x20 + 8 + *plVar7) = puVar3;
    uVar1 = *(undefined8 *)((longlong)*(int *)((longlong)plVar7 + 0xc) * 0x20 + 0x10 + *plVar7);
    *puVar3 = 0x20000000;
    FUN_140197b30(puVar3,uVar1);
    puVar3[1] = 0;
    lVar2 = plVar7[3];
    *(undefined4 *)((longlong)plVar7 + 0xc) = 0xffffffff;
    if (*(char *)(lVar2 + 0x21) != '\0') {
      *(undefined1 *)(lVar2 + 0x21) = 0;
      *(undefined8 **)(lVar2 + 0x10) = puVar3 + 2;
    }
  }
  return;
}

