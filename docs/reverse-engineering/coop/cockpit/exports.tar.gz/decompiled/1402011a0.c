/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1402011a0; RVA 0x2011a0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1402011a0(longlong *param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  longlong lVar2;
  
  if (*(int *)((longlong)param_1 + 0xc) != -1) {
    *(undefined8 **)((longlong)*(int *)((longlong)param_1 + 0xc) * 0x20 + 8 + *param_1) = param_2;
    uVar1 = *(undefined8 *)((longlong)*(int *)((longlong)param_1 + 0xc) * 0x20 + 0x10 + *param_1);
    *param_2 = 0x20000000;
    FUN_140197b30(param_2,uVar1);
    param_2[1] = 0;
    lVar2 = param_1[3];
    *(undefined4 *)((longlong)param_1 + 0xc) = 0xffffffff;
    if (*(char *)(lVar2 + 0x21) != '\0') {
      *(undefined1 *)(lVar2 + 0x21) = 0;
      *(undefined8 **)(lVar2 + 0x10) = param_2 + 2;
    }
  }
  return;
}

