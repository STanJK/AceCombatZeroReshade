/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140157f40; RVA 0x157f40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 *
FUN_140157f40(undefined8 param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  
  *param_2 = 0x10000006;
  *(undefined4 *)(param_2 + 1) = 0;
  *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000006;
  *(undefined4 *)(param_2 + 2) = 0x8005;
  *(undefined4 *)((longlong)param_2 + 0x14) = 0x10000000;
  param_2[3] = 0xe;
  *(undefined4 *)(param_2 + 4) = 0x7000d;
  *(undefined4 *)(param_2 + 5) = 0x47;
  *(undefined4 *)(param_2 + 6) = 1;
  *(undefined4 *)(param_2 + 7) = 0x46;
  *(undefined4 *)(param_2 + 8) = 0x44;
  *(undefined4 *)((longlong)param_2 + 0x44) = 0x80;
  *(undefined4 *)(param_2 + 9) = 0x42;
  param_2[10] = 5;
  *(undefined4 *)(param_2 + 0xb) = 8;
  param_2[0xc] = 0x60;
  *(undefined4 *)(param_2 + 0xd) = 0x14;
  param_2[0xe] = 0x10000005;
  *(undefined4 *)(param_2 + 0xf) = 0;
  *(undefined4 *)((longlong)param_2 + 0x7c) = 0x50000005;
  *(undefined4 *)(param_2 + 0x10) = 0x8004;
  *(undefined4 *)((longlong)param_2 + 0x84) = 0x10000000;
  param_2[0x11] = 0xe;
  param_2[0x12] = 0x58;
  *(undefined4 *)(param_2 + 0x13) = 0x43;
  *(undefined4 *)(param_2 + 0x14) = 0x5000d;
  *(undefined4 *)(param_2 + 0x15) = 0x48;
  param_2[0x16] = 0x60;
  *(undefined4 *)(param_2 + 0x17) = 0x15;
  *(undefined4 *)(param_2 + 0x18) = 1;
  *(undefined4 *)(param_2 + 0x19) = 0x4b;
  param_2[0x1a] = 0x10000008;
  *(undefined4 *)(param_2 + 0x1b) = 0x11000000;
  *(undefined4 *)((longlong)param_2 + 0xdc) = 0x6c084010;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  param_2[0x1c] = *param_3;
  param_2[0x1d] = uVar1;
  param_2[0x1e] = uVar2;
  param_2[0x1f] = uVar3;
  uVar1 = param_3[5];
  uVar2 = param_3[6];
  uVar3 = param_3[7];
  param_2[0x20] = param_3[4];
  param_2[0x21] = uVar1;
  param_2[0x22] = uVar2;
  param_2[0x23] = uVar3;
  uVar1 = param_4[1];
  uVar2 = param_4[2];
  uVar3 = param_4[3];
  param_2[0x24] = *param_4;
  param_2[0x25] = uVar1;
  param_2[0x26] = uVar2;
  param_2[0x27] = uVar3;
  uVar1 = param_4[5];
  uVar2 = param_4[6];
  uVar3 = param_4[7];
  param_2[0x28] = param_4[4];
  param_2[0x29] = uVar1;
  param_2[0x2a] = uVar2;
  param_2[0x2b] = uVar3;
  return param_2 + 0x2c;
}

