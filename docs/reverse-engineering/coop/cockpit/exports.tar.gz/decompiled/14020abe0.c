/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020abe0; RVA 0x20abe0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14020abe0(undefined4 param_1,undefined4 param_2,byte param_3)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  code *pcVar4;
  undefined8 *puVar5;
  size_t sVar6;
  int iVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 *_Buf1;
  char cVar10;
  undefined8 *puVar11;
  undefined4 uVar12;
  undefined1 auStack_148 [32];
  longlong *local_128;
  byte local_118;
  undefined4 local_110 [2];
  undefined4 local_108 [2];
  longlong local_100;
  longlong local_f8;
  longlong local_f0;
  undefined1 local_e8 [12];
  undefined4 local_dc;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined1 local_98 [16];
  undefined8 local_88;
  undefined8 uStack_80;
  undefined4 uStack_78;
  int iStack_74;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined4 local_60;
  undefined4 local_5c;
  ulonglong local_58;
  
  local_58 = DAT_140309040 ^ (ulonglong)auStack_148;
  plVar1 = *(longlong **)(DAT_14033da48 + 0x10);
  local_118 = param_3;
  local_110[0] = param_1;
  local_108[0] = param_2;
  plVar8 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_98,local_110);
  lVar2 = *plVar8;
  plVar8 = (longlong *)FUN_140211b80(&DAT_1403566e8,local_e8,local_108);
  iVar7 = *(int *)(lVar2 + 0x44);
  lVar3 = *plVar8;
  uStack_d0 = *(undefined8 *)(lVar2 + 0x20);
  iStack_74 = *(int *)(lVar3 + 0x44);
  uStack_b0 = *(undefined8 *)(lVar3 + 0x20);
  uStack_c8 = CONCAT44(iVar7,0xffffffff);
  local_d8 = 0;
  uStack_c0 = 0x80;
  uStack_70 = 0x10;
  local_88 = 0;
  cVar10 = (iVar7 != 0x80) + (iStack_74 != 0x10);
  uStack_78 = 0xffffffff;
  uStack_a8 = CONCAT44(iStack_74,0xffffffff);
  local_b8 = 0;
  uStack_a0 = 0x10;
  uStack_80 = uStack_b0;
  if (cVar10 != '\0') {
    lVar9 = 0;
    if (iVar7 == 0x80) {
      lVar9 = 0x20;
    }
    (**(code **)(*plVar1 + 0xd0))(plVar1,cVar10,local_e8 + lVar9 + 0x10);
  }
  sVar6 = DAT_14031e468;
  puVar5 = DAT_14031e458;
  if (*(char *)(lVar2 + 0x7b) == '\0') {
    puVar11 = &DAT_14031e458;
    if (0xf < DAT_14031e470) {
      puVar11 = DAT_14031e458;
    }
    _Buf1 = &DAT_14031e0f0;
    if (0xf < DAT_14031e108) {
      _Buf1 = DAT_14031e0f0;
    }
    if ((DAT_14031e100 != DAT_14031e468) ||
       ((DAT_14031e100 != 0 && (iVar7 = memcmp(_Buf1,puVar11,DAT_14031e100), iVar7 != 0)))) {
      puVar11 = &DAT_14031e458;
      if (0xf < DAT_14031e470) {
        puVar11 = puVar5;
      }
      FUN_140212710(&DAT_14031e0f0,puVar11,sVar6);
      if (DAT_14031e468 != 0) {
        FUN_14020f590(0);
        DAT_14031e110 = 1;
      }
    }
    puVar5 = DAT_14033da70;
    iVar7 = *(int *)(lVar3 + 0x90);
    (**(code **)(*(longlong *)*DAT_14033da70 + 0x48))((longlong *)*DAT_14033da70,&local_100);
    local_128 = &local_f8;
    local_f8 = iVar7 * *(int *)(puVar5 + 1) + local_100;
    (**(code **)(*plVar1 + 0x170))(plVar1,0,0,0);
    DAT_1403566e0 = 0x14;
    DAT_1403566d8 = 1;
    DAT_1403566dc = 0;
    iStack_74 = DAT_1402d22d0;
    uStack_80 = CONCAT44((float)*(int *)(lVar3 + 0x9c),(float)*(int *)(lVar3 + 0x98));
    uStack_78 = 0;
    local_88 = 0;
    (**(code **)(*plVar1 + 0xa8))(plVar1,1,&local_88);
    local_60 = *(undefined4 *)(lVar3 + 0x98);
    local_5c = *(undefined4 *)(lVar3 + 0x9c);
    local_68 = 0;
    (**(code **)(*plVar1 + 0xb0))(plVar1,1,&local_68);
    FUN_14020f600(1);
    local_128 = (longlong *)((ulonglong)local_128 & 0xffffffffffffff00);
    FUN_14020ef50(0x14,0,0,0);
    _DAT_14031e34c = local_dc;
    DAT_14031e0e8 = 4;
    _DAT_14031e308 = 1;
    _DAT_14031e310 = 8;
    _DAT_14031e30c = 1;
    DAT_14031e314 = 0;
    _DAT_14031e328 = 8;
    _DAT_14031e338 = 8;
    _DAT_14031e340 = 0;
    _DAT_14031e348 = 0;
    _DAT_14031e358 = 0;
    DAT_14031e110 = 1;
    FUN_140209d40(&DAT_14031e0d0);
    local_f0 = FUN_14020d480(local_110[0]);
    puVar5 = DAT_14033da58;
    iVar7 = *(int *)(local_f0 + 4);
    pcVar4 = *(code **)(*plVar1 + 0x100);
    (**(code **)(*(longlong *)*DAT_14033da58 + 0x50))((longlong *)*DAT_14033da58,&local_100);
    (*pcVar4)(plVar1,0,iVar7 * *(int *)(puVar5 + 1) + local_100);
    local_128 = (longlong *)((ulonglong)local_128 & 0xffffffff00000000);
    (**(code **)(*plVar1 + 0x60))(plVar1,3,1,0);
    lVar9 = local_f0;
    plVar8 = *(longlong **)(local_f0 + 0x28);
    if (plVar8 != (longlong *)0x0) {
      *(undefined8 *)(local_f0 + 0x28) = 0;
      (**(code **)(*plVar8 + 0x10))();
    }
    plVar8 = *(longlong **)(lVar9 + 0x20);
    if (plVar8 != (longlong *)0x0) {
      *(undefined8 *)(lVar9 + 0x20) = 0;
      (**(code **)(*plVar8 + 0x10))();
    }
    thunk_FUN_1402500f0(lVar9,0x30);
    _DAT_14031e358 = 1;
    DAT_14031e110 = 1;
    FUN_14020a000(&DAT_1403566c0,*(undefined4 *)(DAT_140356730 + -4));
    param_3 = local_118;
  }
  uStack_d0 = *(undefined8 *)(lVar2 + 0x20);
  uStack_b0 = *(undefined8 *)(lVar3 + 0x20);
  local_d8 = 0;
  uStack_c8 = 0x80ffffffff;
  uStack_c0 = 0x10;
  uStack_70 = 0x80;
  local_88 = 0;
  iStack_74 = 0x10;
  uStack_78 = 0xffffffff;
  local_b8 = 0;
  uStack_a8 = 0x10ffffffff;
  uStack_a0 = 0x80;
  uStack_80 = uStack_b0;
  (**(code **)(*plVar1 + 0xd0))(plVar1,param_3 + 1,&local_d8);
  *(undefined4 *)(lVar2 + 0x44) = 0x10;
  uVar12 = 0x10;
  if (param_3 != 0) {
    uVar12 = 0x80;
  }
  *(undefined4 *)(lVar3 + 0x44) = uVar12;
  *(undefined1 *)(lVar2 + 0x78) = 0;
  *(undefined1 *)(lVar3 + 0x78) = 0;
  *(undefined1 *)(lVar2 + 0x7b) = 1;
  return;
}

