/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b1680; RVA 0xb1680
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400b1680(longlong param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  byte bVar2;
  char cVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  longlong lVar7;
  undefined2 *puVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  longlong lVar12;
  char *pcVar13;
  char *pcVar14;
  int iVar15;
  undefined1 auStack_b8 [32];
  float local_98;
  undefined4 *local_90;
  undefined8 local_88;
  undefined4 *local_80;
  longlong local_78;
  undefined4 local_68;
  char local_64 [11];
  undefined2 uStack_59;
  char local_57 [23];
  ulonglong local_40;
  
  local_40 = DAT_140309040 ^ (ulonglong)auStack_b8;
  iVar15 = *(int *)(param_1 + 0x36c);
  if (((iVar15 < 0) || (*(char *)(param_1 + 0x3c7) == -1)) || (*(char *)(param_1 + 0x3c8) == -1)) {
    return param_2;
  }
  bVar2 = *(byte *)(param_1 + 0x3c0);
  local_68 = *(undefined4 *)(*(longlong *)(param_1 + 0x300) + 0x310);
  puVar1 = (undefined8 *)(*(longlong *)(param_1 + 0x300) + 0x328);
  iVar9 = (iVar15 / 0x3c) / (int)(uint)bVar2;
  uVar5 = (longlong)iVar15 % (longlong)(int)((uint)bVar2 * 0x3c);
  uVar10 = (uint)bVar2;
  local_90 = &local_68;
  iVar15 = (int)(((float)(iVar15 % (int)uVar10) / (float)uVar10) * DAT_1402d271c);
  local_98 = (float)DAT_1402d2798;
  uVar6 = FUN_1400bff50(param_2,DAT_1402d282c,DAT_1402d2760,DAT_1402d28a0);
  uStack_59._1_1_ = 0x30;
  if (iVar9 < 0) {
    uStack_59._1_1_ = 0x2d;
  }
  local_57[0] = '0';
  pcVar13 = (char *)((longlong)&uStack_59 + 1);
  if (iVar9 < 0) {
    pcVar13 = local_57;
  }
  iVar11 = -iVar9;
  if (-1 < iVar9) {
    iVar11 = iVar9;
  }
  pcVar14 = pcVar13;
  if (iVar11 == 0) {
LAB_1400b1801:
    *pcVar14 = '0';
  }
  else {
    do {
      iVar9 = iVar11 / 10;
      *pcVar14 = (char)iVar11 + (char)iVar9 * -10 + '0';
      pcVar14 = pcVar14 + 1;
      iVar11 = iVar9;
    } while (iVar9 != 0);
    if (pcVar13 == pcVar14) goto LAB_1400b1801;
  }
  pcVar13[2] = '\0';
  lVar7 = -1;
  do {
    lVar7 = lVar7 + 1;
  } while (pcVar13[lVar7] != '\0');
  iVar9 = (int)lVar7 / 2;
  lVar12 = (longlong)iVar9;
  if (0 < iVar9) {
    pcVar14 = pcVar13 + (longlong)(int)lVar7 + -1;
    do {
      cVar3 = *pcVar13;
      *pcVar13 = *pcVar14;
      pcVar13 = pcVar13 + 1;
      *pcVar14 = cVar3;
      lVar12 = lVar12 + -1;
      pcVar14 = pcVar14 + -1;
    } while (lVar12 != 0);
  }
  puVar8 = &uStack_59;
  do {
    pcVar13 = (char *)((longlong)puVar8 + 1);
    puVar8 = (undefined2 *)((longlong)puVar8 + 1);
  } while (*pcVar13 != '\0');
  iVar9 = (int)((longlong)((ulonglong)(uint)((int)uVar5 >> 0x1f) << 0x20 | uVar5 & 0xffffffff) /
               (longlong)(int)uVar10);
  *puVar8 = DAT_1402ab8bc;
  local_64[1] = 0x30;
  local_64[0] = '0';
  if (iVar9 < 0) {
    local_64[0] = '-';
  }
  pcVar13 = local_64;
  if (iVar9 < 0) {
    pcVar13 = local_64 + 1;
  }
  iVar11 = -iVar9;
  if (-1 < iVar9) {
    iVar11 = iVar9;
  }
  pcVar14 = pcVar13;
  if (iVar11 == 0) {
LAB_1400b18f6:
    *pcVar14 = '0';
  }
  else {
    do {
      iVar9 = iVar11 / 10;
      *pcVar14 = (char)iVar11 + (char)iVar9 * -10 + '0';
      pcVar14 = pcVar14 + 1;
      iVar11 = iVar9;
    } while (iVar9 != 0);
    if (pcVar13 == pcVar14) goto LAB_1400b18f6;
  }
  pcVar13[2] = '\0';
  lVar7 = -1;
  do {
    lVar7 = lVar7 + 1;
  } while (pcVar13[lVar7] != '\0');
  iVar9 = (int)lVar7 / 2;
  lVar12 = (longlong)iVar9;
  if (0 < iVar9) {
    pcVar14 = pcVar13 + (longlong)(int)lVar7 + -1;
    do {
      cVar3 = *pcVar13;
      *pcVar13 = *pcVar14;
      pcVar13 = pcVar13 + 1;
      *pcVar14 = cVar3;
      lVar12 = lVar12 + -1;
      pcVar14 = pcVar14 + -1;
    } while (lVar12 != 0);
  }
  puVar8 = &uStack_59;
  do {
    pcVar13 = (char *)((longlong)puVar8 + 1);
    puVar8 = (undefined2 *)((longlong)puVar8 + 1);
  } while (*pcVar13 != '\0');
  lVar7 = 0;
  do {
    cVar3 = local_64[lVar7];
    *(char *)((longlong)puVar8 + lVar7) = cVar3;
    lVar7 = lVar7 + 1;
  } while (cVar3 != '\0');
  puVar8 = &uStack_59;
  do {
    pcVar13 = (char *)((longlong)puVar8 + 1);
    puVar8 = (undefined2 *)((longlong)puVar8 + 1);
  } while (*pcVar13 != '\0');
  *puVar8 = DAT_1402ab8b8;
  local_64[1] = 0x30;
  local_64[0] = '0';
  if (iVar15 < 0) {
    local_64[0] = '-';
  }
  pcVar13 = local_64;
  if (iVar15 < 0) {
    pcVar13 = local_64 + 1;
  }
  iVar9 = -iVar15;
  if (-1 < iVar15) {
    iVar9 = iVar15;
  }
  pcVar14 = pcVar13;
  if (iVar9 != 0) {
    do {
      iVar15 = iVar9 / 10;
      *pcVar14 = (char)iVar9 + (char)iVar15 * -10 + '0';
      pcVar14 = pcVar14 + 1;
      iVar9 = iVar15;
    } while (iVar15 != 0);
    if (pcVar13 != pcVar14) goto LAB_1400b19fc;
  }
  *pcVar14 = '0';
LAB_1400b19fc:
  pcVar13[2] = '\0';
  lVar7 = -1;
  do {
    lVar7 = lVar7 + 1;
  } while (pcVar13[lVar7] != '\0');
  iVar15 = (int)lVar7 / 2;
  lVar12 = (longlong)iVar15;
  if (0 < iVar15) {
    pcVar14 = pcVar13 + (longlong)(int)lVar7 + -1;
    do {
      cVar3 = *pcVar13;
      *pcVar13 = *pcVar14;
      pcVar13 = pcVar13 + 1;
      *pcVar14 = cVar3;
      lVar12 = lVar12 + -1;
      pcVar14 = pcVar14 + -1;
    } while (lVar12 != 0);
  }
  puVar8 = &uStack_59;
  do {
    pcVar13 = (char *)((longlong)puVar8 + 1);
    puVar8 = (undefined2 *)((longlong)puVar8 + 1);
  } while (*pcVar13 != '\0');
  lVar7 = 0;
  do {
    cVar3 = local_64[lVar7];
    *(char *)((longlong)puVar8 + lVar7) = cVar3;
    lVar7 = lVar7 + 1;
  } while (cVar3 != '\0');
  uVar4 = *(undefined8 *)(*(longlong *)(param_1 + 0x300) + 0x398);
  lVar7 = -1;
  do {
    lVar12 = lVar7 + 1;
    pcVar13 = local_57 + lVar7;
    lVar7 = lVar12;
  } while (*pcVar13 != '\0');
  local_98 = (float)lVar12;
  iVar15 = FUN_1400bba00(puVar1,2,2,(longlong)&uStack_59 + 1);
  local_98 = DAT_1402d2780 - (float)(*(byte *)*puVar1 >> 1);
  local_78 = (longlong)&uStack_59 + 1;
  local_80 = &local_68;
  local_90 = (undefined4 *)CONCAT44(local_90._4_4_,2);
  local_88 = uVar4;
  uVar6 = FUN_1400bb3e0(puVar1,uVar6,2,
                        DAT_1402d287c - (float)(int)((float)iVar15 * DAT_1402d2168 + DAT_1402d2168))
  ;
  return uVar6;
}

