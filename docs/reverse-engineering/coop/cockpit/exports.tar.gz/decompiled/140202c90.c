/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140202c90; RVA 0x202c90
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140202c90(undefined8 *param_1,undefined4 param_2,float param_3,float param_4,float param_5,
                  float param_6,short param_7,short param_8,float param_9,float param_10,
                  float param_11,float param_12,int param_13,int param_14,int param_15)

{
  float fVar1;
  undefined4 uVar2;
  float fVar3;
  float local_108;
  undefined4 local_104;
  undefined4 local_100;
  undefined4 local_fc;
  undefined4 local_f8;
  undefined4 local_f4;
  undefined4 local_f0;
  undefined4 local_ec;
  undefined4 local_e8;
  undefined4 local_e4;
  undefined4 local_e0;
  undefined4 local_dc;
  undefined4 local_d8;
  undefined4 local_d4;
  undefined4 local_d0;
  float local_cc;
  float local_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  float fStack_b4;
  undefined1 auStack_b0 [16];
  float fStack_a0;
  undefined4 uStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  
  fVar3 = DAT_1402d22d0;
  if (param_13 != 1) {
    param_5 = (float)(((int)param_7 / 2) * (param_13 + -1) - param_7 * param_14) + param_5;
    param_6 = (float)(((int)param_8 / 2) * (param_13 + -1) - param_8 * param_15) + param_6;
  }
  fVar1 = DAT_1402d22d0 / (param_12 - param_11);
  param_1[7] = 0x3f800000;
  local_c8 = (float)param_13 * param_3;
  fStack_b4 = (float)param_13 * param_4;
  *(undefined4 *)param_1 = param_2;
  *(undefined4 *)((longlong)param_1 + 0x14) = param_2;
  auStack_b0 = ZEXT816(0);
  uStack_c4 = 0;
  uStack_c0 = 0;
  uStack_b8 = 0;
  fStack_90 = (param_12 * param_9 - param_10 * param_11) * fVar1;
  fStack_a0 = (param_10 - param_9) * param_11 * fVar1 * param_12;
  uVar2 = 0;
  *(undefined8 *)((longlong)param_1 + 0xc) = 0;
  param_1[4] = 0;
  param_1[6] = 0;
  uStack_9c = 0;
  fStack_8c = fVar3;
  *(undefined8 *)((longlong)param_1 + 4) = 0;
  param_1[3] = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  *(undefined4 *)((longlong)param_1 + 0x2c) = 0x3f800000;
  fStack_98 = param_5;
  fStack_94 = param_6;
  FUN_140005940(&local_c8,&local_c8,param_1);
  uStack_60 = CONCAT44(uStack_9c,fStack_a0);
  uStack_58 = CONCAT44(fStack_94,fStack_98);
  uStack_50 = CONCAT44(fStack_8c,fStack_90);
  local_f4 = DAT_1402d2d64;
  local_e0 = DAT_1402d2d64;
  local_88 = CONCAT44(uStack_c4,local_c8);
  uStack_78 = CONCAT44(fStack_b4,uStack_b8);
  uStack_80 = uStack_c0;
  uStack_70 = auStack_b0._0_8_;
  local_68 = auStack_b0._8_8_;
  local_108 = fVar3;
  local_104 = uVar2;
  local_100 = uVar2;
  local_fc = uVar2;
  local_f8 = uVar2;
  local_f0 = uVar2;
  local_ec = uVar2;
  local_e8 = uVar2;
  local_e4 = uVar2;
  local_dc = uVar2;
  local_d8 = uVar2;
  local_d4 = uVar2;
  local_d0 = uVar2;
  local_cc = fVar3;
  FUN_140005940(&local_88,&local_88,&local_108);
  *param_1 = local_88;
  param_1[1] = uStack_80;
  param_1[2] = uStack_78;
  param_1[3] = uStack_70;
  param_1[4] = local_68;
  param_1[5] = uStack_60;
  param_1[6] = uStack_58;
  param_1[7] = uStack_50;
  return;
}

