/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14019cd40; RVA 0x19cd40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

uint FUN_14019cd40(undefined8 param_1,uint *param_2)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  uint *puVar9;
  uint uVar10;
  ulonglong uVar11;
  byte bVar12;
  ulonglong uVar13;
  uint uVar14;
  undefined1 auStack_78 [32];
  uint local_58;
  uint local_54;
  longlong local_50;
  uint local_48 [4];
  ulonglong local_38;
  
  local_38 = DAT_140309040 ^ (ulonglong)auStack_78;
  uVar3 = *param_2;
  puVar9 = param_2 + 1;
  local_58 = CONCAT31((uint3)(uVar3 >> 0x16),(char)(uVar3 >> 0xe)) & 0xffffff01;
  bVar12 = (byte)(uVar3 >> 0x1c) & 1;
  if ((uVar3 >> 0xf & 1) == 0) {
    uVar7 = 0;
  }
  else {
    uVar7 = (uint)DAT_14031cf2c;
  }
  uVar10 = uVar3 >> 0x10 & 0xff;
  local_50 = (ulonglong)(((uVar3 & 0x3ff) + uVar7) * 0x10) + *(longlong *)(DAT_14031cf20 + 0xd8);
  if ((char)(uVar3 >> 0x10) == '\0') {
    uVar10 = 0x100;
  }
  uVar14 = uVar3 >> 0x1a & 3;
  uVar7 = uVar14 + 1;
  uVar13 = (ulonglong)uVar7;
  local_54 = uVar10;
  if ((((bVar12 == 0) && ((uVar3 & 0x3000000) == 0)) && (uVar7 == 4)) &&
     ((DAT_14031cf29 == 4 && (DAT_14031cf28 == 4)))) {
    FUN_140277ba0(local_50,puVar9,(ulonglong)uVar10 << 4);
    local_54 = uVar10;
  }
  else if ((bVar12 == 0) && (uVar14 != 0)) {
    uVar3 = 0;
    if (uVar10 != 0) {
      do {
        lVar4 = 0;
        lVar5 = local_50 +
                (longlong)
                (int)((uVar3 % (uint)DAT_14031cf28 + (uVar3 / DAT_14031cf28) * (uint)DAT_14031cf29)
                     * 4) * 4;
        if (uVar7 != 0) {
          if ((char)local_58 == '\0') {
            do {
              uVar14 = *param_2 & 0x3000000;
              if (uVar14 == 0) {
                uVar14 = *puVar9;
                puVar9 = puVar9 + 1;
LAB_14019cf2f:
                *(uint *)(lVar5 + lVar4 * 4) = uVar14;
              }
              else {
                if (uVar14 == 0x1000000) {
                  uVar14 = (uint)(short)(ushort)*puVar9;
                  puVar9 = (uint *)((longlong)puVar9 + 2);
                  goto LAB_14019cf2f;
                }
                if (uVar14 == 0x2000000) {
                  uVar14 = (uint)(char)(byte)*puVar9;
                  puVar9 = (uint *)((longlong)puVar9 + 1);
                  goto LAB_14019cf2f;
                }
              }
              lVar4 = lVar4 + 1;
            } while (lVar4 < (longlong)uVar13);
          }
          else {
            do {
              uVar14 = *param_2 & 0x3000000;
              if (uVar14 == 0) {
                uVar14 = *puVar9;
                puVar9 = puVar9 + 1;
LAB_14019ceef:
                *(uint *)(lVar5 + lVar4 * 4) = uVar14;
              }
              else {
                if (uVar14 == 0x1000000) {
                  uVar14 = (uint)(ushort)*puVar9;
                  puVar9 = (uint *)((longlong)puVar9 + 2);
                  goto LAB_14019ceef;
                }
                if (uVar14 == 0x2000000) {
                  uVar14 = (uint)(byte)*puVar9;
                  puVar9 = (uint *)((longlong)puVar9 + 1);
                  goto LAB_14019ceef;
                }
              }
              lVar4 = lVar4 + 1;
            } while (lVar4 < (longlong)uVar13);
          }
        }
        uVar3 = uVar3 + 1;
      } while ((int)uVar3 < (int)uVar10);
    }
  }
  else {
    uVar3 = 0;
    if (uVar10 != 0) {
      uVar10 = local_48[0];
      uVar8 = local_58;
      do {
        bVar1 = DAT_14031cf34;
        lVar5 = 0;
        if (uVar7 != 0) {
          uVar10 = *param_2 & 0x3000000;
          if ((char)uVar8 == '\0') {
            do {
              if (uVar10 == 0) {
                uVar2 = *puVar9;
                puVar9 = puVar9 + 1;
LAB_14019cfeb:
                local_48[lVar5] = uVar2;
              }
              else {
                if (uVar10 == 0x1000000) {
                  uVar2 = (uint)(short)(ushort)*puVar9;
                  puVar9 = (uint *)((longlong)puVar9 + 2);
                  goto LAB_14019cfeb;
                }
                if (uVar10 == 0x2000000) {
                  uVar2 = (uint)(char)(byte)*puVar9;
                  puVar9 = (uint *)((longlong)puVar9 + 1);
                  goto LAB_14019cfeb;
                }
              }
              lVar5 = lVar5 + 1;
            } while (lVar5 < (longlong)uVar13);
          }
          else {
            do {
              if (uVar10 == 0) {
                uVar2 = *puVar9;
                puVar9 = puVar9 + 1;
LAB_14019cfab:
                local_48[lVar5] = uVar2;
              }
              else {
                if (uVar10 == 0x1000000) {
                  uVar2 = (uint)(ushort)*puVar9;
                  puVar9 = (uint *)((longlong)puVar9 + 2);
                  goto LAB_14019cfab;
                }
                if (uVar10 == 0x2000000) {
                  uVar2 = (uint)(byte)*puVar9;
                  puVar9 = (uint *)((longlong)puVar9 + 1);
                  goto LAB_14019cfab;
                }
              }
              lVar5 = lVar5 + 1;
            } while (lVar5 < (longlong)uVar13);
          }
          uVar10 = local_48[0];
        }
        uVar11 = uVar13;
        if (uVar14 == 0) {
          local_48[1] = uVar10;
          uVar11 = 4;
          local_48[2] = uVar10;
          local_48[3] = uVar10;
        }
        puVar6 = (undefined4 *)
                 (local_50 +
                 (longlong)
                 (int)((uVar3 % (uint)DAT_14031cf28 + (uVar3 / DAT_14031cf28) * (uint)DAT_14031cf29)
                      * 4) * 4);
        if (bVar12 == 0) {
          if ((int)uVar11 != 0) {
            FUN_140277ba0(puVar6,local_48,uVar11 << 2);
            goto LAB_14019d0b4;
          }
        }
        else {
          if ((int)uVar11 != 0) {
            uVar8 = 0;
            lVar5 = (longlong)local_48 - (longlong)puVar6;
            do {
              if ((bVar1 >> (uVar8 & 0x1f) & 3) == 0) {
                *puVar6 = *(undefined4 *)((longlong)puVar6 + lVar5);
              }
              uVar8 = uVar8 + 2;
              puVar6 = puVar6 + 1;
              uVar11 = uVar11 - 1;
            } while (uVar11 != 0);
          }
LAB_14019d0b4:
          uVar8 = local_58;
        }
        uVar3 = uVar3 + 1;
      } while ((int)uVar3 < (int)local_54);
    }
  }
  local_54 = ((*param_2 >> 0x1a & 3) + 1) * local_54;
  uVar3 = *param_2 & 0x3000000;
  if (uVar3 != 0) {
    if (uVar3 == 0x1000000) {
      return local_54 + 1 >> 1;
    }
    local_54 = local_54 + 3 >> 2;
  }
  return local_54;
}

