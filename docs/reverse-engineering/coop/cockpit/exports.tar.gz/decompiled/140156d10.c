/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140156d10; RVA 0x156d10
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140156d10(longlong param_1,undefined8 *param_2,undefined1 (*param_3) [32])

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined1 auVar4 [32];
  undefined1 auVar5 [32];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined8 uVar9;
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  
  auVar4 = param_3[1];
  fVar1 = *(float *)(param_1 + 0xc40);
  fVar2 = *(float *)(param_1 + 0xc48);
  fVar3 = *(float *)(param_1 + 0xc44);
  auVar5 = *param_3;
  auVar11 = auVar5._0_16_;
  auVar12 = auVar5._16_16_;
  *(float *)(param_1 + 0xc40) = fVar2 * auVar4._0_4_ + fVar3 * auVar5._16_4_ + auVar5._0_4_ * fVar1;
  auVar6 = vshufps_avx(auVar11,auVar11,0x55);
  auVar10 = auVar4._0_16_;
  auVar7 = vshufps_avx(auVar10,auVar10,0x55);
  auVar8 = vshufps_avx(auVar12,auVar12,0x55);
  *(float *)(param_1 + 0xc44) = fVar2 * auVar7._0_4_ + fVar3 * auVar8._0_4_ + auVar6._0_4_ * fVar1;
  auVar6 = vshufps_avx(auVar11,auVar11,0xaa);
  auVar7 = vshufps_avx(auVar10,auVar10,0xaa);
  auVar8 = vshufps_avx(auVar12,auVar12,0xaa);
  *(float *)(param_1 + 0xc48) = auVar7._0_4_ * fVar2 + auVar8._0_4_ * fVar3 + fVar1 * auVar6._0_4_;
  auVar6 = vshufps_avx(auVar10,auVar10,0xff);
  auVar7 = vshufps_avx(auVar11,auVar11,0xff);
  auVar8 = vshufps_avx(auVar4._16_16_,auVar4._16_16_,0xff);
  auVar10 = vshufps_avx(auVar12,auVar12,0xff);
  *(float *)(param_1 + 0xc4c) =
       auVar8._0_4_ * *(float *)(param_1 + 0xc4c) + fVar2 * auVar6._0_4_ +
       auVar10._0_4_ * fVar3 + fVar1 * auVar7._0_4_;
  *param_2 = 0x10000002;
  *(undefined4 *)(param_2 + 1) = 0x20000000;
  *(undefined4 *)((longlong)param_2 + 0xc) = 0xcfcfcfcf;
  *(undefined4 *)(param_2 + 2) = 0x70030020;
  *(undefined4 *)((longlong)param_2 + 0x14) = *(undefined4 *)(param_1 + 0xc40);
  *(undefined4 *)(param_2 + 3) = *(undefined4 *)(param_1 + 0xc44);
  *(undefined4 *)((longlong)param_2 + 0x1c) = *(undefined4 *)(param_1 + 0xc48);
  *(undefined4 *)(param_2 + 4) = 0x68010026;
  *(undefined4 *)((longlong)param_2 + 0x24) = *(undefined4 *)(param_1 + 0xc50);
  *(undefined4 *)(param_2 + 5) = *(undefined4 *)(param_1 + 0xc54);
  *(undefined4 *)((longlong)param_2 + 0x2c) = *(undefined4 *)(param_1 + 0xc58);
  *(undefined8 *)(param_1 + 0xc58) = 0;
  *(undefined8 *)(param_1 + 0xc50) = 0;
  uVar9 = FUN_14015e8a0(param_1 + 0x10,param_2 + 6);
  if (*(char *)(param_1 + 0xb28) != '\0') {
    FUN_14015e8a0(param_1 + 0x110,uVar9,param_3);
  }
  return;
}

