/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140109dc0; RVA 0x109dc0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_140109dc0(longlong param_1,undefined8 param_2,float *param_3,float *param_4,undefined8 param_5)

{
  longlong lVar1;
  byte bVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  char cVar10;
  byte bVar11;
  undefined8 uVar12;
  float *pfVar13;
  uint uVar14;
  longlong lVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  undefined1 auVar19 [16];
  undefined1 auVar20 [32];
  undefined1 auVar21 [16];
  undefined1 auVar22 [32];
  undefined1 auVar23 [16];
  undefined1 auVar24 [16];
  undefined1 auVar25 [64];
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  float local_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  
  cVar10 = DAT_14033bd60;
  uVar17 = 0;
  bVar2 = *(byte *)(*(longlong *)(param_1 + 0xff8) + 0xb);
  bVar11 = 0;
  if (bVar2 < 4) {
    bVar11 = bVar2;
  }
  lVar1 = *(longlong *)(param_1 + 0x1fc8) + (ulonglong)bVar11 * 0x48;
  uVar12 = FUN_140203b30(&DAT_14030f800);
  uVar18 = 0xffffffff;
  auVar24 = ZEXT416(DAT_1402d291c);
  if ((*(byte *)(param_1 + 0x209e) & 1) != 0) {
    if (((*(ushort *)(param_1 + 0x1b8) < 0x42) || (*(ushort *)(param_1 + 0x1bc) < 0x42)) ||
       (*(int *)(*(longlong *)(param_1 + 0x1d0) + 4) == 0)) {
      auVar20 = _DAT_1402d38a0;
      auVar22 = _DAT_1402d4140;
    }
    else {
      lVar15 = (ulonglong)**(ushort **)(*(longlong *)(param_1 + 0x1d8) + 8) * 800;
      auVar20 = *(undefined1 (*) [32])(lVar15 + 0x94 + *(longlong *)(param_1 + 0x1b0));
      auVar22 = *(undefined1 (*) [32])(lVar15 + 0xb4 + *(longlong *)(param_1 + 0x1b0));
    }
    auVar19 = auVar20._0_16_;
    auVar21 = auVar20._16_16_;
    uStack_64 = vextractps_avx(auVar21,1);
    local_68 = auVar20._16_4_;
    uStack_60 = vextractps_avx(auVar21,2);
    uStack_5c = vextractps_avx(auVar21,3);
    auVar21 = auVar22._0_16_;
    auVar23 = auVar22._16_16_;
    fStack_44 = (float)vextractps_avx(auVar23,1);
    local_48 = (float)auVar22._16_4_;
    fStack_40 = (float)vextractps_avx(auVar23,2);
    fStack_3c = (float)vextractps_avx(auVar23,3);
    uVar3 = vextractps_avx(auVar19,1);
    _local_78 = CONCAT44(uVar3,auVar20._0_4_);
    uVar3 = vextractps_avx(auVar19,2);
    uVar4 = vextractps_avx(auVar19,3);
    _uStack_70 = CONCAT44(uVar4,uVar3);
    uVar3 = vextractps_avx(auVar21,1);
    _local_58 = CONCAT44(uVar3,auVar22._0_4_);
    uVar3 = vextractps_avx(auVar21,2);
    uVar4 = vextractps_avx(auVar21,3);
    _uStack_50 = CONCAT44(uVar4,uVar3);
    auVar25 = ZEXT1664(auVar24);
    FUN_140202230(&local_78,&local_78,param_5);
    auVar24 = auVar25._0_16_;
    fVar5 = local_48 + *param_4;
    fVar6 = fStack_44 + param_4[1];
    fVar7 = (fStack_40 + param_4[2]) - param_3[2];
    fVar8 = fStack_3c - param_3[3];
    fStack_40 = fStack_40 + param_4[2];
    fVar9 = fVar5 - *param_3;
    fStack_44 = fVar6;
    local_48 = fVar5;
    fVar6 = fVar6 - param_3[1];
    pfVar13 = *(float **)(lVar1 + 0x48);
    fVar5 = SQRT(fVar8 * fVar8 + fVar7 * fVar7 + fVar6 * fVar6 + fVar9 * fVar9) *
            (auVar25._0_4_ / *(float *)(param_1 + 0x1d70));
    if (cVar10 == '\0') {
      uVar16 = 0;
      lVar15 = 0;
      do {
        if (fVar5 < *pfVar13) goto joined_r0x00014010a078;
        uVar16 = uVar16 + 1;
        lVar15 = lVar15 + 1;
        pfVar13 = pfVar13 + 1;
      } while (lVar15 < 3);
    }
    else {
      uVar14 = 0;
      lVar15 = 0;
      do {
        if (fVar5 < *pfVar13) {
          if (1 < (int)uVar14) {
            uVar14 = 1;
          }
          goto LAB_14010a040;
        }
        uVar14 = uVar14 + 1;
        lVar15 = lVar15 + 1;
        pfVar13 = pfVar13 + 1;
      } while (lVar15 < 3);
      uVar14 = 0xffffffff;
LAB_14010a040:
      uVar16 = 0;
      if ((*(uint *)(param_1 + 0x2058) & 0x2000000) == 0) {
        uVar16 = uVar14;
      }
joined_r0x00014010a078:
      if (uVar16 < 3) {
        uVar12 = FUN_14015e8a0(*(undefined8 *)(lVar1 + 0x68 + (longlong)(int)uVar16 * 8),uVar12,
                               &local_78);
        auVar24 = auVar25._0_16_;
      }
    }
  }
  if ((*(byte *)(param_1 + 0x209e) & 2) != 0) {
    if (((*(ushort *)(param_1 + 0x1b8) < 0x43) || (*(ushort *)(param_1 + 0x1bc) < 0x43)) ||
       (*(int *)(*(longlong *)(param_1 + 0x1d0) + 8) == 0)) {
      auVar20 = _DAT_1402d38a0;
      auVar22 = _DAT_1402d4140;
    }
    else {
      lVar15 = (ulonglong)**(ushort **)(*(longlong *)(param_1 + 0x1d8) + 0x10) * 800;
      auVar20 = *(undefined1 (*) [32])(lVar15 + 0x94 + *(longlong *)(param_1 + 0x1b0));
      auVar22 = *(undefined1 (*) [32])(lVar15 + 0xb4 + *(longlong *)(param_1 + 0x1b0));
    }
    auVar19 = auVar20._0_16_;
    auVar21 = auVar20._16_16_;
    uStack_64 = vextractps_avx(auVar21,1);
    local_68 = auVar20._16_4_;
    uStack_60 = vextractps_avx(auVar21,2);
    uStack_5c = vextractps_avx(auVar21,3);
    auVar21 = auVar22._0_16_;
    auVar23 = auVar22._16_16_;
    fStack_44 = (float)vextractps_avx(auVar23,1);
    local_48 = (float)auVar22._16_4_;
    fStack_40 = (float)vextractps_avx(auVar23,2);
    fStack_3c = (float)vextractps_avx(auVar23,3);
    uVar3 = vextractps_avx(auVar19,1);
    _local_78 = CONCAT44(uVar3,auVar20._0_4_);
    uVar3 = vextractps_avx(auVar19,2);
    uVar4 = vextractps_avx(auVar19,3);
    _uStack_70 = CONCAT44(uVar4,uVar3);
    uVar3 = vextractps_avx(auVar21,1);
    _local_58 = CONCAT44(uVar3,auVar22._0_4_);
    uVar3 = vextractps_avx(auVar21,2);
    uVar4 = vextractps_avx(auVar21,3);
    _uStack_50 = CONCAT44(uVar4,uVar3);
    auVar25 = ZEXT1664(auVar24);
    FUN_140202230(&local_78,&local_78,param_5);
    lVar15 = 0;
    fVar5 = local_48 + *param_4;
    fVar6 = fStack_44 + param_4[1];
    fVar7 = (fStack_40 + param_4[2]) - param_3[2];
    fVar8 = fStack_3c - param_3[3];
    fStack_40 = fStack_40 + param_4[2];
    fVar9 = fVar5 - *param_3;
    fStack_44 = fVar6;
    local_48 = fVar5;
    fVar6 = fVar6 - param_3[1];
    pfVar13 = *(float **)(lVar1 + 0x48);
    fVar5 = SQRT(fVar8 * fVar8 + fVar7 * fVar7 + fVar6 * fVar6 + fVar9 * fVar9) *
            (auVar25._0_4_ / *(float *)(param_1 + 0x1d70));
    if (cVar10 == '\0') {
      do {
        if (fVar5 < *pfVar13) goto LAB_14010a286;
        uVar17 = uVar17 + 1;
        lVar15 = lVar15 + 1;
        pfVar13 = pfVar13 + 1;
      } while (lVar15 < 3);
    }
    else {
      uVar17 = 0;
      do {
        if (fVar5 < *pfVar13) {
          uVar18 = uVar17;
          if (1 < (int)uVar17) {
            uVar18 = 1;
          }
          break;
        }
        uVar17 = uVar17 + 1;
        lVar15 = lVar15 + 1;
        pfVar13 = pfVar13 + 1;
      } while (lVar15 < 3);
      uVar17 = 0;
      if ((*(uint *)(param_1 + 0x2058) & 0x2000000) == 0) {
        uVar17 = uVar18;
      }
LAB_14010a286:
      if (uVar17 < 3) {
        uVar12 = FUN_14015e8a0(*(undefined8 *)(lVar1 + 0x68 + (longlong)(int)uVar17 * 8),uVar12,
                               &local_78);
      }
    }
  }
  return uVar12;
}

