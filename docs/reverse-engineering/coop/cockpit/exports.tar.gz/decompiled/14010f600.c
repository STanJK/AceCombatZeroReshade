/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14010f600; RVA 0x10f600
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14010f600(longlong param_1,byte param_2,byte param_3,byte param_4)

{
  undefined1 auVar1 [16];
  char cVar2;
  byte bVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  uchar uVar6;
  ulonglong context_or_unused;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined4 uVar15;
  undefined1 auVar16 [16];
  undefined1 auVar17 [64];
  undefined4 uVar18;
  undefined4 uVar19;
  undefined4 uVar20;
  
  cVar2 = *(char *)(param_1 + 0x432);
  if (cVar2 == '\0') {
    auVar16 = *(undefined1 (*) [16])(param_1 + 0x3d8);
    auVar1 = *(undefined1 (*) [16])(param_1 + 0x3c8);
    *(int *)(param_1 + 0x250) = auVar1._0_4_;
    uVar18 = vextractps_avx(auVar1,1);
    *(undefined4 *)(param_1 + 0x254) = uVar18;
    uVar18 = vextractps_avx(auVar1,2);
    *(undefined4 *)(param_1 + 600) = uVar18;
    uVar18 = vextractps_avx(auVar1,3);
    *(undefined4 *)(param_1 + 0x25c) = uVar18;
    *(int *)(param_1 + 0x260) = auVar16._0_4_;
    uVar18 = vextractps_avx(auVar16,1);
    *(undefined4 *)(param_1 + 0x264) = uVar18;
    uVar18 = vextractps_avx(auVar16,2);
    *(undefined4 *)(param_1 + 0x268) = uVar18;
    uVar18 = vextractps_avx(auVar16,3);
    *(undefined4 *)(param_1 + 0x26c) = uVar18;
    FUN_140110bd0(param_1 + 0x250,param_2);
    *(undefined4 *)(param_1 + 0x3c8) = *(undefined4 *)(param_1 + 0x250);
    *(undefined4 *)(param_1 + 0x3cc) = *(undefined4 *)(param_1 + 0x254);
    *(undefined4 *)(param_1 + 0x3d0) = *(undefined4 *)(param_1 + 600);
    *(undefined4 *)(param_1 + 0x3d4) = *(undefined4 *)(param_1 + 0x25c);
    *(undefined4 *)(param_1 + 0x3d8) = *(undefined4 *)(param_1 + 0x260);
    *(undefined4 *)(param_1 + 0x3dc) = *(undefined4 *)(param_1 + 0x264);
    *(undefined4 *)(param_1 + 0x3e0) = *(undefined4 *)(param_1 + 0x268);
    *(undefined4 *)(param_1 + 0x3e4) = *(undefined4 *)(param_1 + 0x26c);
LAB_14010f8d2:
    *(undefined8 *)(param_1 + 1000) = 0;
    *(undefined4 *)(param_1 + 0x3f0) = 0;
    *(undefined4 *)(param_1 + 0x3f4) = 0x3f800000;
    return;
  }
  if (cVar2 == '\x03') {
    *(undefined4 *)(param_1 + 0x180) = *(undefined4 *)(param_1 + 0x3c8);
    *(undefined4 *)(param_1 + 0x184) = *(undefined4 *)(param_1 + 0x3cc);
    *(undefined4 *)(param_1 + 0x188) = *(undefined4 *)(param_1 + 0x3d0);
    *(undefined4 *)(param_1 + 0x18c) = *(undefined4 *)(param_1 + 0x3d4);
    *(undefined4 *)(param_1 + 400) = *(undefined4 *)(param_1 + 0x3d8);
    *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x3dc);
    *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x3e0);
    *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x3e4);
    *(undefined8 *)(param_1 + 1000) = 0;
    *(undefined4 *)(param_1 + 0x3f0) = 0;
    *(undefined4 *)(param_1 + 0x3f4) = 0x3f800000;
    return;
  }
  if (cVar2 == '\x01') {
    *(uint *)(param_1 + 0x388) = (uint)param_2;
    *(undefined8 *)(param_1 + 0x380) = 0;
    auVar16 = *(undefined1 (*) [16])(param_1 + 0x3d8);
    auVar1 = *(undefined1 (*) [16])(param_1 + 0x3c8);
    *(int *)(param_1 + 0x310) = auVar1._0_4_;
    uVar18 = vextractps_avx(auVar1,1);
    *(undefined4 *)(param_1 + 0x314) = uVar18;
    uVar18 = vextractps_avx(auVar1,2);
    *(undefined4 *)(param_1 + 0x318) = uVar18;
    uVar18 = vextractps_avx(auVar1,3);
    *(undefined4 *)(param_1 + 0x31c) = uVar18;
    *(int *)(param_1 + 800) = auVar16._0_4_;
    uVar18 = vextractps_avx(auVar16,1);
    *(undefined4 *)(param_1 + 0x324) = uVar18;
    uVar18 = vextractps_avx(auVar16,2);
    *(undefined4 *)(param_1 + 0x328) = uVar18;
    uVar18 = vextractps_avx(auVar16,3);
    *(undefined4 *)(param_1 + 0x32c) = uVar18;
    FUN_140110f80();
    *(undefined4 *)(param_1 + 0x3c8) = *(undefined4 *)(param_1 + 0x310);
    *(undefined4 *)(param_1 + 0x3cc) = *(undefined4 *)(param_1 + 0x314);
    *(undefined4 *)(param_1 + 0x3d0) = *(undefined4 *)(param_1 + 0x318);
    *(undefined4 *)(param_1 + 0x3d4) = *(undefined4 *)(param_1 + 0x31c);
    *(undefined4 *)(param_1 + 0x3d8) = *(undefined4 *)(param_1 + 800);
    *(undefined4 *)(param_1 + 0x3dc) = *(undefined4 *)(param_1 + 0x324);
    *(undefined4 *)(param_1 + 0x3e0) = *(undefined4 *)(param_1 + 0x328);
    *(undefined4 *)(param_1 + 0x3e4) = *(undefined4 *)(param_1 + 0x32c);
    *(undefined4 *)(param_1 + 0x41c) = *(undefined4 *)(param_1 + 0x38c);
    *(float *)(param_1 + 0x418) =
         SQRT(*(float *)(param_1 + 0x33c) * *(float *)(param_1 + 0x33c) +
              *(float *)(param_1 + 0x338) * *(float *)(param_1 + 0x338) +
              *(float *)(param_1 + 0x334) * *(float *)(param_1 + 0x334) +
              *(float *)(param_1 + 0x330) * *(float *)(param_1 + 0x330)) * DAT_1402d2610;
    *(undefined4 *)(param_1 + 0x424) = *(undefined4 *)(param_1 + 0x390);
    *(undefined4 *)(param_1 + 0x420) = *(undefined4 *)(param_1 + 0x394);
    *(undefined4 *)(param_1 + 0x428) = *(undefined4 *)(param_1 + 0x398);
    goto LAB_14010f8d2;
  }
  if (cVar2 != '\x02') {
    return;
  }
  *(undefined4 *)(param_1 + 0x180) = *(undefined4 *)(param_1 + 0x3c8);
  *(undefined4 *)(param_1 + 0x184) = *(undefined4 *)(param_1 + 0x3cc);
  *(undefined4 *)(param_1 + 0x188) = *(undefined4 *)(param_1 + 0x3d0);
  *(undefined4 *)(param_1 + 0x18c) = *(undefined4 *)(param_1 + 0x3d4);
  *(undefined4 *)(param_1 + 400) = *(undefined4 *)(param_1 + 0x3d8);
  *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x3dc);
  *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x3e0);
  *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x3e4);
  context_or_unused = (ulonglong)param_4 * 0x520;
  if ((*(byte *)(*(longlong *)
                  (*(longlong *)(**(longlong **)(param_1 + 0x410) + (ulonglong)param_3 * 8) + 0x110)
                 + 0x1f0 + context_or_unused) & 2) == 0) {
    fVar7 = 0.0;
    fVar9 = 0.0;
    fVar13 = 0.0;
  }
  else {
    bVar3 = *(byte *)(param_1 + 0x433);
    *(byte *)(param_1 + 0x433) = bVar3 & 0xfd;
    fVar7 = FUN_140187ec0(context_or_unused,param_2,'\x15');
    fVar8 = FUN_140187ec0(context_or_unused,param_2,'\x16');
    fVar9 = FUN_140187ec0(context_or_unused,param_2,'\x14');
    fVar10 = FUN_140187ec0(context_or_unused,param_2,'\x13');
    fVar11 = FUN_140187ec0(context_or_unused,param_2,'\x11');
    fVar12 = FUN_140187ec0(context_or_unused,param_2,'\x12');
    fVar13 = FUN_140187ec0(context_or_unused,param_2,'\x18');
    fVar14 = FUN_140187ec0(context_or_unused,param_2,'\x17');
    uVar6 = FUN_140187a40(DAT_14032c8f0,param_2,'$');
    if (((bVar3 & 1) != 0) || (uVar6 != '\0')) {
      fVar9 = *(float *)(param_1 + 0x3e0);
      fVar7 = DAT_1402d2d2c;
      if ((fVar9 < DAT_1402d2cec) || (fVar7 = DAT_1402d2168, DAT_1402d2054 < fVar9)) {
LAB_14010fb68:
        fVar9 = 0.0;
      }
      else {
        if ((DAT_1402d1f34 < fVar9) || (fVar9 < DAT_1402d2ca4)) {
          fVar7 = fVar9 * DAT_1402d2414;
        }
        else {
          fVar7 = 0.0;
        }
        fVar9 = *(float *)(param_1 + 0x3d8);
        if (DAT_1402d2cb4 <= fVar9) {
          if (DAT_1402d1f80 < fVar9) {
            fVar9 = DAT_1402d2d2c;
          }
          else {
            if ((fVar9 <= DAT_1402d1dc8) && (DAT_1402d2c6c <= fVar9)) goto LAB_14010fb68;
            fVar9 = fVar9 * DAT_1402d2e00;
          }
        }
        else {
          fVar9 = DAT_1402d2168;
        }
      }
      fVar13 = 0.0;
      fVar8 = *(float *)(param_1 + 0x42c);
      *(byte *)(param_1 + 0x433) = bVar3 & 0xfd | 2;
      goto LAB_14010fb95;
    }
    fVar7 = fVar7 - fVar8;
    fVar9 = fVar9 - fVar10;
    fVar13 = fVar13 - fVar14;
    fVar8 = fVar11 - fVar12;
    if ((bVar3 & 4) == 0) goto LAB_14010fb95;
    if (DAT_1402d1ff8 < fVar11) {
      *(byte *)(param_1 + 0x433) = bVar3 & 0xf9;
      goto LAB_14010fb95;
    }
  }
  fVar8 = DAT_1402d2d64;
LAB_14010fb95:
  auVar17 = ZEXT1664(*(undefined1 (*) [16])(param_1 + 0x180));
  *(float *)(param_1 + 0x220) = fVar9;
  *(float *)(param_1 + 0x224) = fVar7;
  *(float *)(param_1 + 0x228) = fVar13;
  *(float *)(param_1 + 0x22c) = fVar8;
  FUN_14012aa30(param_1);
  auVar16 = *(undefined1 (*) [16])(param_1 + 0x180);
  auVar1 = vshufps_avx(auVar16,auVar16,0x55);
  auVar4 = vshufps_avx(auVar16,auVar16,0xaa);
  auVar5 = vshufps_avx(auVar16,auVar16,0xff);
  *(float *)(param_1 + 0x180) = auVar16._0_4_ + *(float *)(param_1 + 0x3f8);
  *(float *)(param_1 + 0x18c) = auVar5._0_4_ + *(float *)(param_1 + 0x404);
  *(float *)(param_1 + 0x184) = auVar1._0_4_ + *(float *)(param_1 + 0x3fc);
  *(float *)(param_1 + 0x188) = auVar4._0_4_ + *(float *)(param_1 + 0x400);
  auVar16 = *(undefined1 (*) [16])(param_1 + 0x1a0);
  auVar1 = vshufps_avx(auVar16,auVar16,0x55);
  auVar4 = vshufps_avx(auVar16,auVar16,0xaa);
  auVar5 = vshufps_avx(auVar16,auVar16,0xff);
  *(float *)(param_1 + 0x1a0) = auVar16._0_4_ + *(float *)(param_1 + 0x3f8);
  *(float *)(param_1 + 0x1a4) = auVar1._0_4_ + *(float *)(param_1 + 0x3fc);
  *(float *)(param_1 + 0x1a8) = auVar4._0_4_ + *(float *)(param_1 + 0x400);
  *(float *)(param_1 + 0x1ac) = auVar5._0_4_ + *(float *)(param_1 + 0x404);
  FUN_1401295b0(param_1);
  auVar16 = auVar17._0_16_;
  uVar18 = *(undefined4 *)(param_1 + 0x238);
  uVar19 = *(undefined4 *)(param_1 + 0x23c);
  uVar20 = *(undefined4 *)(param_1 + 0x240);
  if (DAT_14033bd60 == '\0') {
    FUN_14010fe60();
    auVar16 = auVar17._0_16_;
  }
  if (*(short *)(param_1 + 0x430) == 1000) {
    *(int *)(param_1 + 0x180) = auVar16._0_4_;
    uVar15 = vextractps_avx(auVar16,1);
    *(undefined4 *)(param_1 + 0x184) = uVar15;
    uVar15 = vextractps_avx(auVar16,2);
    *(undefined4 *)(param_1 + 0x188) = uVar15;
    uVar15 = vextractps_avx(auVar16,3);
    *(undefined4 *)(param_1 + 0x18c) = uVar15;
    *(undefined8 *)(param_1 + 0x1a0) = 0;
    *(undefined8 *)(param_1 + 0x1a8) = 0;
  }
  *(undefined4 *)(param_1 + 0x3c8) = *(undefined4 *)(param_1 + 0x180);
  *(undefined4 *)(param_1 + 0x3cc) = *(undefined4 *)(param_1 + 0x184);
  *(undefined4 *)(param_1 + 0x3d0) = *(undefined4 *)(param_1 + 0x188);
  *(undefined4 *)(param_1 + 0x3d4) = *(undefined4 *)(param_1 + 0x18c);
  *(undefined4 *)(param_1 + 0x3d8) = *(undefined4 *)(param_1 + 400);
  *(undefined4 *)(param_1 + 0x3dc) = *(undefined4 *)(param_1 + 0x194);
  *(undefined4 *)(param_1 + 0x3e0) = *(undefined4 *)(param_1 + 0x198);
  *(undefined4 *)(param_1 + 0x3e4) = *(undefined4 *)(param_1 + 0x19c);
  fVar7 = DAT_1402d26b4;
  fVar9 = (float)*(byte *)(param_1 + 0x244) * *(float *)(param_1 + 0x210) * DAT_1402d21d0;
  *(undefined4 *)(param_1 + 0x41c) = *(undefined4 *)(param_1 + 0x230);
  *(float *)(param_1 + 0x418) = fVar9;
  uVar15 = DAT_1402d22d0;
  if (fVar9 <= fVar7 / (float)*(byte *)(param_1 + 0x434)) {
    *(undefined8 *)(param_1 + 1000) = 0;
    *(undefined4 *)(param_1 + 0x3f0) = 0;
    *(undefined4 *)(param_1 + 0x41c) = 0;
  }
  else {
    *(undefined4 *)(param_1 + 1000) = *(undefined4 *)(param_1 + 0x1e0);
    *(undefined4 *)(param_1 + 0x3ec) = *(undefined4 *)(param_1 + 0x1e4);
    *(undefined4 *)(param_1 + 0x3f0) = *(undefined4 *)(param_1 + 0x1e8);
    uVar15 = *(undefined4 *)(param_1 + 0x1ec);
  }
  *(undefined4 *)(param_1 + 0x3f4) = uVar15;
  *(undefined4 *)(param_1 + 0x420) = uVar18;
  *(undefined4 *)(param_1 + 0x424) = uVar19;
  *(undefined4 *)(param_1 + 0x428) = uVar20;
  return;
}

