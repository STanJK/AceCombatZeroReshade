/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140005940; RVA 0x5940
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140005940(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  
  fVar1 = param_2[4];
  fVar2 = *param_2;
  fVar3 = param_2[8];
  fVar4 = param_2[0xc];
  fVar5 = param_3[0xf];
  fVar6 = param_3[2];
  fVar7 = param_2[0xf];
  fVar8 = param_3[0xe];
  fVar9 = param_2[0xb];
  fVar10 = param_2[3];
  fVar11 = param_3[1];
  fVar12 = *param_3;
  fVar13 = param_2[5];
  fVar14 = param_2[0xe];
  fVar15 = param_2[10];
  fVar16 = param_2[2];
  fVar17 = param_2[6];
  fVar18 = param_2[0xd];
  fVar19 = param_2[9];
  fVar20 = param_2[1];
  fVar21 = param_3[0xc];
  fVar22 = param_2[7];
  fVar23 = param_3[0xd];
  fVar24 = param_3[0xb];
  fVar25 = param_3[10];
  fVar26 = param_3[8];
  fVar27 = param_3[9];
  fVar28 = param_3[7];
  fVar29 = param_3[6];
  fVar30 = param_3[4];
  fVar31 = param_3[5];
  fVar32 = param_3[3];
  *param_1 = fVar4 * fVar32 + fVar6 * fVar3 + fVar12 * fVar2 + fVar1 * fVar11;
  param_1[4] = fVar4 * fVar28 + fVar3 * fVar29 + fVar2 * fVar30 + fVar1 * fVar31;
  param_1[8] = fVar4 * fVar24 + fVar3 * fVar25 + fVar2 * fVar26 + fVar1 * fVar27;
  param_1[0xc] = fVar4 * fVar5 + fVar3 * fVar8 + fVar2 * fVar21 + fVar1 * fVar23;
  param_1[1] = fVar32 * fVar18 + fVar6 * fVar19 + fVar12 * fVar20 + fVar13 * fVar11;
  param_1[9] = fVar18 * fVar24 + fVar19 * fVar25 + fVar20 * fVar26 + fVar13 * fVar27;
  param_1[2] = fVar32 * fVar14 + fVar6 * fVar15 + fVar12 * fVar16 + fVar17 * fVar11;
  param_1[10] = fVar14 * fVar24 + fVar15 * fVar25 + fVar16 * fVar26 + fVar17 * fVar27;
  param_1[5] = fVar18 * fVar28 + fVar19 * fVar29 + fVar30 * fVar20 + fVar13 * fVar31;
  param_1[0xd] = fVar18 * fVar5 + fVar19 * fVar8 + fVar20 * fVar21 + fVar13 * fVar23;
  param_1[6] = fVar14 * fVar28 + fVar15 * fVar29 + fVar30 * fVar16 + fVar17 * fVar31;
  param_1[0xe] = fVar14 * fVar5 + fVar15 * fVar8 + fVar16 * fVar21 + fVar17 * fVar23;
  param_1[3] = fVar7 * fVar32 + fVar9 * fVar6 + fVar10 * fVar12 + fVar11 * fVar22;
  param_1[7] = fVar7 * fVar28 + fVar9 * fVar29 + fVar10 * fVar30 + fVar31 * fVar22;
  param_1[0xf] = fVar7 * fVar5 + fVar9 * fVar8 + fVar10 * fVar21 + fVar22 * fVar23;
  param_1[0xb] = fVar7 * fVar24 + fVar9 * fVar25 + fVar10 * fVar26 + fVar22 * fVar27;
  return;
}

