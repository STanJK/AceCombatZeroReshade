/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020f500; RVA 0x20f500
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14020f500(undefined8 *param_1)

{
  int iVar1;
  undefined8 *_Buf1;
  undefined8 *puVar2;
  
  puVar2 = param_1;
  if (0xf < (ulonglong)param_1[3]) {
    puVar2 = (undefined8 *)*param_1;
  }
  _Buf1 = &DAT_14031e0f0;
  if (0xf < DAT_14031e108) {
    _Buf1 = DAT_14031e0f0;
  }
  if (DAT_14031e100 == param_1[2]) {
    if (DAT_14031e100 == 0) {
      return;
    }
    iVar1 = memcmp(_Buf1,puVar2,DAT_14031e100);
    if (iVar1 == 0) {
      return;
    }
  }
  if ((undefined8 **)param_1 != &DAT_14031e0f0) {
    puVar2 = param_1;
    if (0xf < (ulonglong)param_1[3]) {
      puVar2 = (undefined8 *)*param_1;
    }
    FUN_140212710(&DAT_14031e0f0,puVar2,param_1[2]);
  }
  if (param_1[2] != 0) {
    FUN_14020f590(0);
    DAT_14031e110 = 1;
  }
  return;
}

