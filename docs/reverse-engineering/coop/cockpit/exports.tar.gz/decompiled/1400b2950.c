/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b2950; RVA 0xb2950
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_1400b2950(longlong param_1,undefined8 param_2)

{
  byte *pbVar1;
  int *piVar2;
  undefined1 auVar3 [16];
  byte bVar4;
  int *piVar5;
  undefined8 uVar6;
  uint uVar7;
  int iVar8;
  longlong lVar9;
  char cVar10;
  int *piVar11;
  int *piVar12;
  int iVar13;
  longlong lVar14;
  longlong lVar15;
  uint uVar16;
  undefined1 auVar17 [16];
  undefined4 local_res18;
  
  if (*(char *)(param_1 + 0x175) != '\0') {
    return param_2;
  }
  if (*(ushort *)(param_1 + 0x39c) == 0xffff) {
    if ((*(uint *)(param_1 + 0x34c) & 0x10001) == 0) goto LAB_1400b29b6;
    uVar16 = *(uint *)(param_1 + 0x1f8);
  }
  else {
    if ((*(uint *)(param_1 + 0x348) >> 0x1a & 1) == 0) {
      *(uint *)(param_1 + 0x348) = *(uint *)(param_1 + 0x348) | 0x4000000;
    }
    if ((*(ushort *)(param_1 + 0x39c) & 4) == 0) {
      uVar16 = *(uint *)(param_1 + 0x1f8);
    }
    else {
LAB_1400b29b6:
      uVar16 = *(uint *)(param_1 + 0x248);
    }
  }
  lVar15 = 0;
  uVar7 = (uint)*(byte *)(param_1 + 0x3c0);
  cVar10 = *(char *)(param_1 + 0x177);
  pbVar1 = (byte *)(param_1 + 0x178);
  auVar17._0_4_ = (float)(*(int *)(param_1 + 0x354) % (int)uVar7) / (float)uVar7;
  auVar17._4_12_ = SUB1612(ZEXT816(0),4);
  auVar3 = vpcmpeqd_avx(ZEXT416(*(int *)(param_1 + 0x354) / (int)uVar7 & 1),SUB6416(ZEXT464(0),0));
  auVar3 = vblendvps_avx(ZEXT416((uint)(DAT_1402d22d0 - auVar17._0_4_)),auVar17,auVar3);
  local_res18 = CONCAT13((char)(int)(auVar3._0_4_ * (float)(uVar16 >> 0x18)),(int3)uVar16);
  if (cVar10 != '\0') goto LAB_1400b2a60;
  bVar4 = *pbVar1;
  if ((byte)(bVar4 - 0xc) < 6) {
    bVar4 = bVar4 - 0xc;
  }
  else {
    if ((byte)(bVar4 - 0x14) < 7) {
      cVar10 = '\x05';
      bVar4 = *pbVar1 - 0x14;
      if (5 < (byte)(*pbVar1 - 0x14)) goto LAB_1400b2a60;
    }
    else {
LAB_1400b2a60:
      bVar4 = *pbVar1;
      if (*pbVar1 == 0x1a) {
        bVar4 = 4;
      }
    }
    if (cVar10 == '\x05') {
      if (bVar4 == 5) {
        return param_2;
      }
      goto LAB_1400b2a9e;
    }
    if (cVar10 != '\x04') {
      if (cVar10 != '\x06') {
        return param_2;
      }
      if ((byte)(bVar4 - 4) < 2) {
        return param_2;
      }
      goto LAB_1400b2a9e;
    }
  }
  if ((byte)(bVar4 - 5) < 2) {
    return param_2;
  }
LAB_1400b2a9e:
  piVar2 = *(int **)(param_1 + 0x300);
  iVar8 = *piVar2;
  if (iVar8 < 0x18) {
    piVar5 = (int *)0x0;
  }
  else if (*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar5 = (int *)((longlong)*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) +
                    *(longlong *)(piVar2 + 2));
  }
  lVar14 = 0;
  if ((0x29 < *piVar5) && (piVar5[0x2a] != 0)) {
    lVar14 = (longlong)piVar5 + (longlong)piVar5[0x2a];
  }
  if (iVar8 < 0x18) {
    piVar5 = (int *)0x0;
  }
  else if (*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar5 = (int *)((longlong)*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) +
                    *(longlong *)(piVar2 + 2));
  }
  if (*piVar5 < 0x2a) {
    lVar9 = 0;
  }
  else if (piVar5[0x2a] == 0) {
    lVar9 = 0;
  }
  else {
    lVar9 = (longlong)piVar5[0x2a] + (longlong)piVar5;
  }
  iVar13 = *(int *)(lVar9 + 4);
  if ((*(byte *)(lVar9 + 0x16) & 4) == 0) {
    if ((*(byte *)(lVar9 + 0x16) & 2) != 0) {
      if (iVar8 < 0x18) {
        piVar5 = (int *)0x0;
      }
      else if (*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) == 0) {
        piVar5 = (int *)0x0;
      }
      else {
        piVar5 = (int *)((longlong)*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) +
                        *(longlong *)(piVar2 + 2));
      }
      if (*piVar5 < 0x2a) {
        piVar5 = (int *)0x0;
      }
      else if (piVar5[0x2a] == 0) {
        piVar5 = (int *)0x0;
      }
      else {
        piVar5 = (int *)((longlong)piVar5[0x2a] + (longlong)piVar5);
      }
      if (iVar8 < 0x18) {
        piVar11 = (int *)0x0;
      }
      else if (*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) == 0) {
        piVar11 = (int *)0x0;
      }
      else {
        piVar11 = (int *)((longlong)*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) +
                         *(longlong *)(piVar2 + 2));
      }
      piVar12 = (int *)0x0;
      if ((0x29 < *piVar11) && (piVar11[0x2a] != 0)) {
        piVar12 = (int *)((longlong)piVar11 + (longlong)piVar11[0x2a]);
      }
      uVar16 = (int)*(short *)((longlong)piVar12 + 0xe) * (*piVar12 + -1) + (int)(short)piVar12[5] &
               0x80000001;
      if ((int)uVar16 < 0) {
        uVar16 = (uVar16 - 1 | 0xfffffffe) + 1;
      }
      iVar13 = iVar13 + (-uVar16 -
                        ((int)*(short *)((longlong)piVar5 + 0xe) * (*piVar5 + -1) +
                        (int)(short)piVar5[5]) / 2);
    }
  }
  else {
    if (iVar8 < 0x18) {
      piVar5 = (int *)0x0;
    }
    else if (*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) == 0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = (int *)((longlong)*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) +
                      *(longlong *)(piVar2 + 2));
    }
    piVar11 = (int *)0x0;
    if ((0x29 < *piVar5) && (piVar5[0x2a] != 0)) {
      piVar11 = (int *)((longlong)piVar5 + (longlong)piVar5[0x2a]);
    }
    iVar13 = iVar13 - ((int)*(short *)((longlong)piVar11 + 0xe) * (*piVar11 + -1) +
                      (int)(short)piVar11[5]);
  }
  if (iVar8 < 0x18) {
    piVar5 = (int *)0x0;
  }
  else if (*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar5 = (int *)((longlong)*(int *)(*(longlong *)(piVar2 + 4) + 0x5c) +
                    *(longlong *)(piVar2 + 2));
  }
  if ((0x29 < *piVar5) && (piVar5[0x2a] != 0)) {
    lVar15 = (longlong)piVar5 + (longlong)piVar5[0x2a];
  }
  iVar8 = *(int *)(lVar15 + 8);
  if ((*(byte *)(lVar15 + 0x16) & 2) != 0) {
    iVar8 = iVar8 - (int)*(short *)(lVar15 + 0xc) / 2;
  }
  uVar6 = FUN_1400bef00(piVar2,param_2,lVar14,(float)iVar13,(float)iVar8,
                        (int)*(short *)(lVar14 + 0xe),local_res18,10000);
  return uVar6;
}

