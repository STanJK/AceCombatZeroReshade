/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020f8e0; RVA 0x20f8e0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14020f8e0(longlong param_1,uint param_2,longlong param_3,int param_4,int param_5,
                  float param_6,byte param_7,undefined4 param_8,undefined4 param_9,
                  undefined4 param_10,undefined4 param_11,char param_12,undefined8 *param_13,
                  undefined2 *param_14,int param_15)

{
  short sVar1;
  size_t sVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 uVar6;
  short sVar7;
  int iVar8;
  ulonglong uVar9;
  float *pfVar10;
  longlong *plVar11;
  longlong lVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  short *psVar15;
  undefined8 *puVar16;
  longlong lVar17;
  short sVar18;
  longlong lVar19;
  longlong unaff_GS_OFFSET;
  undefined1 auVar20 [64];
  undefined1 auStack_158 [32];
  uint local_138;
  int local_130;
  int local_128;
  char local_118;
  undefined1 local_117;
  undefined1 local_116;
  int local_114;
  uint local_110;
  longlong *local_108;
  longlong local_100;
  ulonglong local_f8;
  longlong local_f0;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  longlong local_a8;
  int local_a0;
  undefined4 local_9c;
  uint local_98;
  float local_94;
  uint local_90;
  uint local_8c;
  undefined4 local_88;
  undefined4 local_84;
  undefined4 local_80;
  undefined4 local_7c;
  ulonglong local_78;
  
  local_78 = DAT_140309040 ^ (ulonglong)auStack_158;
  if (DAT_14030f270 != 0) {
    DAT_14032c900 = 0;
    return;
  }
  local_108 = *(longlong **)(DAT_14033da48 + 4);
  if (((param_5 == 5) || (param_5 < 3)) || (7 < param_5)) {
    local_118 = '\0';
  }
  else {
    local_118 = '\x01';
  }
  lVar17 = 0;
  local_88 = param_8;
  local_98 = (uint)(param_1 != 0);
  local_90 = (uint)param_7;
  local_84 = param_9;
  local_80 = param_10;
  local_7c = param_11;
  local_94 = param_6;
  if (local_118 == '\0') {
    local_8c = (local_90 - param_7) - (uint)(param_12 != '\0') & 0xff;
  }
  else {
    local_8c = DAT_14031e0e0;
  }
  uVar9 = (ulonglong)*DAT_14033da48;
  if (0x400000 < (longlong)param_4 * 0x40 + (ulonglong)(uint)(&DAT_14033da80)[uVar9 * 6]) {
    return;
  }
  local_114 = param_4;
  local_110 = param_2;
  local_100 = param_1;
  local_f8 = uVar9;
  local_f0 = param_3;
  FUN_140277ba0((ulonglong)(uint)(&DAT_14033da80)[uVar9 * 6] + (&DAT_14033da88)[uVar9 * 3],param_3);
  local_a8 = (ulonglong)(uint)(&DAT_14033da80)[uVar9 * 6] + (&DAT_14033da90)[uVar9 * 3];
  local_9c = 0x40;
  local_a0 = param_4 * 0x40;
  (**(code **)(*local_108 + 0x160))(local_108,0,1,&local_a8);
  _DAT_14031e348 = 4;
  (&DAT_14033da80)[uVar9 * 6] = (&DAT_14033da80)[uVar9 * 6] + param_4 * 0x40;
  _DAT_14031e340 = &PTR_s_ATTRIBUTE_1402a9d50;
  _DAT_14031e34c = local_9c;
  if ((param_5 == 2) && (param_5 = 1, 3 < param_4)) {
    if (param_14 == (undefined2 *)0x0) {
      param_15 = param_4 * 3 + -6;
      param_14 = &DAT_14033dac0;
    }
    else {
      lVar19 = (longlong)param_15;
      sVar18 = -1;
      sVar7 = -1;
      param_15 = 0;
      if (0 < lVar19) {
        lVar12 = 0;
        psVar15 = &DAT_14033e6c2;
        do {
          sVar1 = param_14[lVar12];
          if (sVar1 == -1) {
            sVar18 = -1;
            sVar7 = -1;
          }
          else if (sVar18 == -1) {
            sVar18 = sVar1;
          }
          else if (sVar7 == -1) {
            sVar7 = sVar1;
          }
          else {
            psVar15[-1] = sVar18;
            param_15 = param_15 + 3;
            *psVar15 = sVar7;
            psVar15[1] = param_14[lVar12];
            psVar15 = psVar15 + 3;
            sVar7 = param_14[lVar12];
          }
          lVar12 = lVar12 + 1;
        } while (lVar12 < lVar19);
      }
      param_14 = &DAT_14033e6c0;
    }
  }
  local_e8 = _DAT_1402d3a40;
  uStack_e0 = _UNK_1402d3a48;
  uStack_d8 = _UNK_1402d3a50;
  uStack_d0 = _UNK_1402d3a58;
  local_c8 = _DAT_1402d3a60;
  uStack_c0 = _UNK_1402d3a68;
  uStack_b8 = _UNK_1402d3a70;
  uStack_b0 = _UNK_1402d3a78;
  lVar19 = (longlong)param_5;
  if ((DAT_14031e110 != '\0') ||
     (DAT_14031e110 = '\0', DAT_14031e354 != *(int *)((longlong)&local_e8 + lVar19 * 8 + 4))) {
    DAT_14031e110 = '\x01';
  }
  DAT_14031e354 = *(undefined4 *)((longlong)&local_e8 + lVar19 * 8 + 4);
  (**(code **)(**(longlong **)(DAT_14033da48 + 4) + 0xa0))
            (*(longlong **)(DAT_14033da48 + 4),*(undefined4 *)(&local_e8 + lVar19));
  uVar9 = local_f8;
  if (param_14 != (undefined2 *)0x0) {
    iVar8 = (int)((longlong)param_15 * 2 + 0x3fU >> 6);
    if (0x400000 <
        (longlong)iVar8 * 0x40 + (ulonglong)(uint)(&DAT_14033da80)[(local_f8 & 0xffffffff) * 6]) {
      return;
    }
    FUN_140277ba0((&DAT_14033da88)[(local_f8 & 0xffffffff) * 3] +
                  (ulonglong)(uint)(&DAT_14033da80)[(local_f8 & 0xffffffff) * 6],param_14);
    local_9c = 0x39;
    local_a8 = (ulonglong)(uint)(&DAT_14033da80)[(uVar9 & 0xffffffff) * 6] +
               (&DAT_14033da90)[(uVar9 & 0xffffffff) * 3];
    local_a0 = param_15 * 2;
    (**(code **)(*local_108 + 0x158))(local_108,&local_a8);
    (&DAT_14033da80)[(uVar9 & 0xffffffff) * 6] =
         iVar8 * 0x40 + (&DAT_14033da80)[(uVar9 & 0xffffffff) * 6];
  }
  local_128 = param_15;
  if (param_7 == 0) {
LAB_14020fef7:
    cVar5 = local_118;
    lVar17 = **(longlong **)(unaff_GS_OFFSET + 0x58);
    if ((*(int *)(lVar17 + 4) < DAT_1437dfd00) &&
       (FUN_14022d540(&DAT_1437dfd00), DAT_1437dfd00 == -1)) {
      DAT_14031f9e8._0_4_ = DAT_1402c40e4;
      DAT_14031f9e8._4_4_ = CONCAT31(DAT_14031f9e8._5_3_,DAT_1402c40e8);
      atexit(FUN_14027a3c0);
      _Init_thread_footer(&DAT_1437dfd00);
    }
    if ((*(int *)(lVar17 + 4) < DAT_1437dfd04) &&
       (FUN_14022d540(&DAT_1437dfd04), DAT_1437dfd04 == -1)) {
      DAT_14031fa08._0_1_ = s_ps2Line_1402c4108[0];
      DAT_14031fa08._1_1_ = s_ps2Line_1402c4108[1];
      DAT_14031fa08._2_1_ = s_ps2Line_1402c4108[2];
      DAT_14031fa08._3_1_ = s_ps2Line_1402c4108[3];
      DAT_14031fa08._4_1_ = s_ps2Line_1402c4108[4];
      DAT_14031fa08._5_1_ = s_ps2Line_1402c4108[5];
      DAT_14031fa08._6_1_ = s_ps2Line_1402c4108[6];
      atexit(FUN_14027a340);
      _Init_thread_footer(&DAT_1437dfd04);
    }
    uVar9 = DAT_14031fa20;
    sVar2 = DAT_14031fa18;
    if (cVar5 == '\0') {
      if (DAT_14031e1ac == 0x12) {
        sVar2 = param_13[2];
        puVar16 = &DAT_14031e088;
        if (0xf < DAT_14031e0a0) {
          puVar16 = DAT_14031e088;
        }
        puVar13 = param_13;
        if (0xf < (ulonglong)param_13[3]) {
          puVar13 = (undefined8 *)*param_13;
        }
        if ((sVar2 == DAT_14031e098) &&
           ((sVar2 == 0 || (iVar8 = memcmp(puVar13,puVar16,sVar2), iVar8 == 0)))) {
          uVar9 = DAT_14031fa00;
          sVar2 = DAT_14031f9f8;
          if ((*(int *)(DAT_140356730 + -4) != -1) && (DAT_14031e198 != 0)) {
            puVar16 = (undefined8 *)CONCAT44(DAT_14031f9e8._4_4_,(undefined4)DAT_14031f9e8);
            puVar13 = &DAT_14031f9e8;
            if (0xf < DAT_14031fa00) {
              puVar13 = puVar16;
            }
            puVar14 = &DAT_14031e0f0;
            if (0xf < DAT_14031e108) {
              puVar14 = DAT_14031e0f0;
            }
            if ((DAT_14031e100 != DAT_14031f9f8) ||
               ((DAT_14031e100 != 0 && (iVar8 = memcmp(puVar14,puVar13,DAT_14031e100), iVar8 != 0)))
               ) {
              puVar13 = &DAT_14031f9e8;
              if (0xf < uVar9) {
                puVar13 = puVar16;
              }
              FUN_140212710(&DAT_14031e0f0,puVar13,sVar2);
              sVar2 = DAT_14031f9f8;
              goto joined_r0x0001402100b0;
            }
            goto LAB_1402100ca;
          }
        }
      }
      FUN_14020f500(param_13);
    }
    else {
      puVar16 = (undefined8 *)
                CONCAT17(DAT_14031fa08._7_1_,
                         CONCAT16(DAT_14031fa08._6_1_,
                                  CONCAT24(DAT_14031fa08._4_2_,(undefined4)DAT_14031fa08)));
      puVar13 = &DAT_14031fa08;
      if (0xf < DAT_14031fa20) {
        puVar13 = puVar16;
      }
      puVar14 = &DAT_14031e0f0;
      if (0xf < DAT_14031e108) {
        puVar14 = DAT_14031e0f0;
      }
      if ((DAT_14031e100 != DAT_14031fa18) ||
         ((DAT_14031e100 != 0 && (iVar8 = memcmp(puVar14,puVar13,DAT_14031e100), iVar8 != 0)))) {
        puVar13 = &DAT_14031fa08;
        if (0xf < uVar9) {
          puVar13 = puVar16;
        }
        FUN_140212710(&DAT_14031e0f0,puVar13,sVar2);
        sVar2 = DAT_14031fa18;
joined_r0x0001402100b0:
        if (sVar2 != 0) {
          FUN_14020f590(0);
          DAT_14031e110 = '\x01';
        }
      }
    }
LAB_1402100ca:
    local_130 = param_4;
  }
  else {
    sVar2 = param_13[2];
    puVar16 = &DAT_14031e088;
    if (0xf < DAT_14031e0a0) {
      puVar16 = DAT_14031e088;
    }
    puVar13 = param_13;
    if (0xf < (ulonglong)param_13[3]) {
      puVar13 = (undefined8 *)*param_13;
    }
    if ((sVar2 != DAT_14031e098) ||
       ((sVar2 != 0 && (iVar8 = memcmp(puVar13,puVar16,sVar2), iVar8 != 0)))) goto LAB_14020fef7;
    uVar6 = DAT_14031e3b0;
    cVar5 = DAT_14031e3ac;
    uVar4 = DAT_14031e0e8;
    uVar3 = DAT_14031e0e4;
    if (local_118 != '\0') goto LAB_14020fef7;
    local_116 = DAT_14031e3aa;
    local_117 = DAT_14031e3a9;
    local_118 = DAT_14031e3ab;
    auVar20 = ZEXT464(DAT_14031e3b4);
    if (DAT_14031e3ac != '\0') {
      FUN_14020f410(DAT_14031e0e8,0,DAT_14031e3b0);
      if ((DAT_14031e110 != '\0') || (DAT_14031e110 = '\0', DAT_14031e1bc != '\a')) {
        DAT_14031e110 = '\x01';
      }
      DAT_14031e1bc = '\a';
      if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dfcf4) &&
         (FUN_14022d540(&DAT_1437dfcf4), DAT_1437dfcf4 == -1)) {
        DAT_14031f988._0_1_ = s_ps2AtestC_1402c40d8[0];
        DAT_14031f988._1_1_ = s_ps2AtestC_1402c40d8[1];
        DAT_14031f988._2_1_ = s_ps2AtestC_1402c40d8[2];
        DAT_14031f988._3_1_ = s_ps2AtestC_1402c40d8[3];
        DAT_14031f988._4_1_ = s_ps2AtestC_1402c40d8[4];
        DAT_14031f988._5_1_ = s_ps2AtestC_1402c40d8[5];
        DAT_14031f988._6_1_ = s_ps2AtestC_1402c40d8[6];
        DAT_14031f988._7_1_ = s_ps2AtestC_1402c40d8[7];
        DAT_14031f990 = s_ps2AtestC_1402c40d8[8];
        atexit(FUN_14027a540);
        _Init_thread_footer(&DAT_1437dfcf4);
      }
      FUN_14020f500(&DAT_14031f988);
      local_130 = local_114;
      local_138 = local_110;
      FUN_14020f680(local_108,&local_88,&local_98,local_100);
      if (0 < (longlong)local_114) {
        pfVar10 = (float *)(local_f0 + 0x1c);
        do {
          if (param_6 < *pfVar10) {
            FUN_14020f410(uVar4,cVar5,uVar6);
            DAT_14031e1bc = '\b';
            if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dfcfc) &&
               (FUN_14022d540(&DAT_1437dfcfc), DAT_1437dfcfc == -1)) {
              DAT_14031f9c8._0_1_ = s_ps2AtestAZ_1402c40b8[0];
              DAT_14031f9c8._1_1_ = s_ps2AtestAZ_1402c40b8[1];
              DAT_14031f9c8._2_1_ = s_ps2AtestAZ_1402c40b8[2];
              DAT_14031f9c8._3_1_ = s_ps2AtestAZ_1402c40b8[3];
              DAT_14031f9c8._4_1_ = s_ps2AtestAZ_1402c40b8[4];
              DAT_14031f9c8._5_1_ = s_ps2AtestAZ_1402c40b8[5];
              DAT_14031f9c8._6_1_ = s_ps2AtestAZ_1402c40b8[6];
              DAT_14031f9c8._7_1_ = s_ps2AtestAZ_1402c40b8[7];
              DAT_14031f9d0 = s_ps2AtestAZ_1402c40b8[8];
              register0x00000001 = s_ps2AtestAZ_1402c40b8[9];
              atexit(FUN_14027a440);
              _Init_thread_footer(&DAT_1437dfcfc);
            }
            FUN_14020f500(&DAT_14031f9c8);
            local_130 = local_114;
            local_138 = local_110;
            local_128 = param_15;
            FUN_14020f680(local_108,&local_88,&local_98,local_100);
            break;
          }
          lVar17 = lVar17 + 1;
          pfVar10 = pfVar10 + 0x10;
        } while (lVar17 < local_114);
      }
      local_138 = local_138 & 0xffffff00;
      FUN_14020ef50(0x16,0,1,0);
      local_138 = CONCAT31(local_138._1_3_,local_118);
      FUN_14020ef50(uVar3,auVar20._0_8_,local_116,local_117);
      DAT_14031e0e8 = 4;
      FUN_14020f410(uVar4,cVar5,uVar6);
      goto LAB_1402100f3;
    }
    if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dfcf8) &&
       (FUN_14022d540(&DAT_1437dfcf8), DAT_1437dfcf8 == -1)) {
      DAT_14031f9a8._0_1_ = s_ps2AtestCA_1402c40c8[0];
      DAT_14031f9a8._1_1_ = s_ps2AtestCA_1402c40c8[1];
      DAT_14031f9a8._2_1_ = s_ps2AtestCA_1402c40c8[2];
      DAT_14031f9a8._3_1_ = s_ps2AtestCA_1402c40c8[3];
      DAT_14031f9a8._4_1_ = s_ps2AtestCA_1402c40c8[4];
      DAT_14031f9a8._5_1_ = s_ps2AtestCA_1402c40c8[5];
      DAT_14031f9a8._6_1_ = s_ps2AtestCA_1402c40c8[6];
      DAT_14031f9a8._7_1_ = s_ps2AtestCA_1402c40c8[7];
      DAT_14031f9b0 = s_ps2AtestCA_1402c40c8[8];
      register0x00000001 = s_ps2AtestCA_1402c40c8[9];
      atexit(FUN_14027a4c0);
      _Init_thread_footer(&DAT_1437dfcf8);
    }
    FUN_14020f500(&DAT_14031f9a8);
    local_130 = local_114;
  }
  local_138 = local_110;
  FUN_14020f680(local_108,&local_88,&local_98,local_100);
LAB_1402100f3:
  if ((DAT_14031e3ac != '\0') && (*(int *)(DAT_140356730 + -4) != -1)) {
    plVar11 = (longlong *)FUN_140211b80(&DAT_1403566e8,&local_a8);
    *(undefined1 *)(*plVar11 + 0x7b) = 0;
  }
  if ((((DAT_14031e37c != 0) && (DAT_14031e314 != 0)) && (DAT_14031e324 == 3)) &&
     (*(int *)(DAT_140356730 + -4) != -1)) {
    plVar11 = (longlong *)FUN_140211b80(&DAT_1403566e8,&local_a8);
    *(undefined1 *)(*plVar11 + 0x79) = 1;
  }
  return;
}

