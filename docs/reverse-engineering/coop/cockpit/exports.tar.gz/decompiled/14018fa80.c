/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14018fa80; RVA 0x18fa80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14018fa80(void)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  char cVar5;
  void *pvVar6;
  longlong lVar7;
  ulonglong uVar8;
  longlong lVar9;
  undefined8 uVar10;
  undefined8 extraout_XMM0_Qa;
  undefined8 extraout_XMM0_Qa_00;
  undefined8 extraout_XMM0_Qa_01;
  
  lVar7 = DAT_14033acc0;
  if (DAT_14033acb8 != DAT_14033acc0) {
    DAT_14033acc0 = DAT_14033acb8;
  }
  if ((ulonglong)(DAT_14033acc8 - DAT_14033acb8 >> 3) < 0x4000) {
    lVar9 = DAT_14033acb8;
    if (DAT_14033acb8 == lVar7) {
      lVar9 = lVar7;
    }
    lVar9 = lVar9 - DAT_14033acb8;
    pvVar6 = operator_new(0x20027);
    if (pvVar6 == (void *)0x0) {
                    /* WARNING: Subroutine does not return */
      _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
    }
    uVar8 = (longlong)pvVar6 + 0x27U & 0xffffffffffffffe0;
    *(void **)(uVar8 - 8) = pvVar6;
    uVar10 = FUN_140277ba0(uVar8,DAT_14033acb8,DAT_14033acc0 - DAT_14033acb8);
    FUN_140197c80(uVar10,uVar8,lVar9 >> 3,0x4000);
  }
  lVar7 = DAT_14031cf20;
  plVar1 = (longlong *)(DAT_14031cf20 + 0x88);
  plVar2 = (longlong *)(DAT_14031cf20 + 0x90);
  plVar3 = (longlong *)(DAT_14031cf20 + 0x98);
  plVar4 = (longlong *)(DAT_14031cf20 + 0xa0);
  if (DAT_14033ad74 != '\0') {
    *plVar1 = 0;
    *plVar2 = 0;
    *plVar3 = 0;
    *plVar4 = 0;
    *(undefined8 *)(lVar7 + 0xd0) = 0;
  }
  if ((((*plVar1 == 0) || (*plVar2 == 0)) || (*plVar3 == 0)) || (*plVar4 == 0)) {
    lVar7 = FUN_140210a00(lVar7,0xc00000);
    *plVar1 = lVar7;
    lVar7 = FUN_140210a00(extraout_XMM0_Qa,0xc00000);
    *plVar2 = lVar7;
    lVar7 = FUN_140210a00(extraout_XMM0_Qa_00,0x400000);
    *plVar3 = lVar7;
    lVar7 = FUN_140210a00(extraout_XMM0_Qa_01,0x400000);
    *plVar4 = lVar7;
  }
  cVar5 = DAT_14033ad74;
  DAT_14033ad74 = 0;
  if (cVar5 != '\0') {
    FUN_140190630(&DAT_14031cf38);
  }
  if (DAT_14030cab8 != -1) {
    FUN_14020e000();
    FUN_14020e490(DAT_14030cab8);
  }
  _DAT_14033bc60 = _DAT_1402d41a0;
  _DAT_14033bc68 = _UNK_1402d41a8;
  _DAT_14033bc70 = _UNK_1402d41b0;
  _DAT_14033bc78 = _UNK_1402d41b8;
  _DAT_14033bc80 = _DAT_1402d41a0;
  _DAT_14033bc88 = _UNK_1402d41a8;
  _DAT_14033bc90 = _UNK_1402d41b0;
  _DAT_14033bc98 = _UNK_1402d41b8;
  return;
}

