/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400afd00; RVA 0xafd00
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_1400afd00(longlong param_1,undefined8 param_2,undefined8 param_3,longlong *param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  char cVar5;
  uint uVar6;
  undefined8 uVar7;
  int iVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined4 uVar11;
  float local_res8 [2];
  undefined8 local_res20;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  
  uVar10 = (ulonglong)*(byte *)(param_1 + 0x3ca);
  iVar8 = 0;
  lVar2 = *param_4;
  lVar9 = *(longlong *)(lVar2 + uVar10 * 8);
  lVar3 = *(longlong *)(lVar9 + 0x110);
  uVar11 = DAT_1402d28a4;
  local_res20 = param_4;
  if (0 < *(int *)(lVar9 + 0x118)) {
    lVar9 = 0;
    do {
      if (*(ushort *)(param_1 + 0x39c) == 0xffff) {
        if ((*(uint *)(param_1 + 0x34c) & 0x10001) == 0) goto LAB_1400afdaa;
        local_res8[0] = *(float *)(param_1 + 0x1f8);
      }
      else {
        if ((*(uint *)(param_1 + 0x348) >> 0x1a & 1) == 0) {
          *(uint *)(param_1 + 0x348) = *(uint *)(param_1 + 0x348) | 0x4000000;
        }
        if ((*(ushort *)(param_1 + 0x39c) & 4) == 0) {
          local_res8[0] = *(float *)(param_1 + 0x1f8);
        }
        else {
LAB_1400afdaa:
          local_res8[0] = *(float *)(param_1 + 0x208);
        }
      }
      lVar4 = *(longlong *)(*(longlong *)(lVar2 + uVar10 * 8) + 0x110);
      if ((*(byte *)(lVar4 + 0x1f0 + lVar9) & 1) != 0) {
        puVar1 = (undefined8 *)(lVar4 + 600 + lVar9);
        local_68 = *puVar1;
        uStack_60 = puVar1[1];
        local_78 = *(undefined8 *)(lVar3 + 600);
        uStack_70 = *(undefined8 *)(lVar3 + 0x260);
        param_2 = FUN_1400b00c0(param_1,param_2,param_3,local_res8,&local_68,&local_78,uVar11);
      }
      iVar8 = iVar8 + 1;
      lVar9 = lVar9 + 0x520;
    } while (iVar8 < *(int *)(*(longlong *)(lVar2 + uVar10 * 8) + 0x118));
  }
  lVar9 = *(longlong *)(param_1 + 0x330);
  if (lVar9 != 0) {
    if (*(ushort *)(param_1 + 0x39c) == 0xffff) {
      if ((*(uint *)(param_1 + 0x34c) & 0x10001) == 0) goto LAB_1400afea0;
      local_res8[0] = *(float *)(param_1 + 0x1f8);
    }
    else {
      if ((*(uint *)(param_1 + 0x348) >> 0x1a & 1) == 0) {
        *(uint *)(param_1 + 0x348) = *(uint *)(param_1 + 0x348) | 0x4000000;
      }
      if ((*(ushort *)(param_1 + 0x39c) & 4) == 0) {
        local_res8[0] = *(float *)(param_1 + 0x1f8);
      }
      else {
LAB_1400afea0:
        local_res8[0] = *(float *)(param_1 + 0x208);
      }
    }
    if ((*(byte *)(lVar9 + 0x1f0) & 1) != 0) {
      local_78 = *(undefined8 *)(lVar9 + 600);
      uStack_70 = *(undefined8 *)(lVar9 + 0x260);
      local_68 = *(undefined8 *)(lVar3 + 600);
      uStack_60 = *(undefined8 *)(lVar3 + 0x260);
      param_2 = FUN_1400b00c0(param_1,param_2,param_3,local_res8,&local_78,&local_68,uVar11);
    }
  }
  lVar9 = *(longlong *)(param_1 + 0x328);
  if ((((lVar9 == 0) || (lVar9 == *(longlong *)(param_1 + 0x330))) ||
      ((&DAT_1402accc0)
       [(ulonglong)
        *(byte *)(*(longlong *)(*local_res20 + (ulonglong)*(byte *)(lVar9 + 0x234) * 8) + 0x15d) +
        (ulonglong)*(byte *)(*(longlong *)(lVar2 + uVar10 * 8) + 0x15d) * 8] == '\0')) ||
     ((cVar5 = FUN_1400bf770(lVar9,*(undefined8 *)(param_1 + 0x2f8),
                             *(undefined4 *)
                              (lVar9 + 0x20c + (ulonglong)*(byte *)(param_1 + 0x3ca) * 4)),
      cVar5 != '\x01' || (cVar5 = FUN_1400bf910(lVar9,lVar3,local_res8), cVar5 == '\0')))) {
    return param_2;
  }
  if (*(ushort *)(param_1 + 0x39c) == 0xffff) {
    if ((*(uint *)(param_1 + 0x34c) & 0x10001) == 0) {
      uVar6 = *(uint *)(param_1 + 0x204);
      goto LAB_1400afffe;
    }
  }
  else {
    if ((*(uint *)(param_1 + 0x348) >> 0x1a & 1) == 0) {
      *(uint *)(param_1 + 0x348) = *(uint *)(param_1 + 0x348) | 0x4000000;
    }
    if ((*(ushort *)(param_1 + 0x39c) & 4) != 0) {
      uVar6 = *(uint *)(param_1 + 0x204);
      goto LAB_1400afffe;
    }
  }
  uVar6 = *(uint *)(param_1 + 0x1f8);
LAB_1400afffe:
  local_68 = *(undefined8 *)(lVar3 + 600);
  uStack_60 = *(undefined8 *)(lVar3 + 0x260);
  local_78 = *(undefined8 *)(lVar9 + 600);
  uStack_70 = *(undefined8 *)(lVar9 + 0x260);
  local_res20._0_4_ = CONCAT13((char)(int)((float)(uVar6 >> 0x18) * local_res8[0]),(int3)uVar6);
  uVar7 = FUN_1400b00c0(param_1,param_2,param_3,&local_res20,&local_78,&local_68,DAT_1402d2760);
  return uVar7;
}

