/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020f680; RVA 0x20f680
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14020f680(longlong *param_1,undefined8 param_2,undefined8 param_3,longlong param_4,
                  int param_5,undefined4 param_6,int param_7)

{
  int iVar1;
  undefined8 *puVar2;
  code *pcVar3;
  longlong local_res8;
  
  FUN_140209d40(&DAT_14031e0d0);
  (**(code **)(*param_1 + 0x120))(param_1,0,4,param_2,0);
  (**(code **)(*param_1 + 0x120))(param_1,1,4,param_3,0);
  puVar2 = DAT_14033da58;
  if (param_4 == 0) {
    if (*(longlong *)(*DAT_1403567a0 + 0x20) == 0) {
      return;
    }
    iVar1 = *(int *)(*DAT_1403567a0 + 4);
    pcVar3 = *(code **)(*param_1 + 0x100);
    (**(code **)(*(longlong *)*DAT_14033da58 + 0x50))((longlong *)*DAT_14033da58,&local_res8);
    (*pcVar3)(param_1,2,iVar1 * *(int *)(puVar2 + 1) + local_res8);
    puVar2 = DAT_14033da60;
    pcVar3 = *(code **)(*param_1 + 0x100);
    (**(code **)(*(longlong *)*DAT_14033da60 + 0x50))((longlong *)*DAT_14033da60,&local_res8);
    param_5 = *(int *)(puVar2 + 1) * 3;
  }
  else {
    iVar1 = *(int *)(param_4 + 4);
    pcVar3 = *(code **)(*param_1 + 0x100);
    (**(code **)(*(longlong *)*DAT_14033da58 + 0x50))((longlong *)*DAT_14033da58,&local_res8);
    (*pcVar3)(param_1,2,iVar1 * *(int *)(puVar2 + 1) + local_res8);
    puVar2 = DAT_14033da60;
    pcVar3 = *(code **)(*param_1 + 0x100);
    (**(code **)(*(longlong *)*DAT_14033da60 + 0x50))((longlong *)*DAT_14033da60,&local_res8);
    param_5 = param_5 * *(int *)(puVar2 + 1);
  }
  (*pcVar3)(param_1,3,param_5 + local_res8);
  puVar2 = DAT_14033da58;
  if (DAT_14032c900 != 0) {
    if (*(longlong *)(DAT_14032c900 + 0x20) == 0) {
      DAT_14032c900 = 0;
      return;
    }
    iVar1 = *(int *)(DAT_14032c900 + 4);
    pcVar3 = *(code **)(*param_1 + 0x100);
    (**(code **)(*(longlong *)*DAT_14033da58 + 0x50))((longlong *)*DAT_14033da58,&local_res8);
    (*pcVar3)(param_1,4,iVar1 * *(int *)(puVar2 + 1) + local_res8);
    puVar2 = DAT_14033da60;
    iVar1 = DAT_14032c908;
    pcVar3 = *(code **)(*param_1 + 0x100);
    (**(code **)(*(longlong *)*DAT_14033da60 + 0x50))((longlong *)*DAT_14033da60,&local_res8);
    (*pcVar3)(param_1,5,iVar1 * *(int *)(puVar2 + 1) + local_res8);
    DAT_14032c900 = 0;
  }
  if (param_7 == 0) {
    (**(code **)(*param_1 + 0x60))(param_1,param_6,1,0,0);
  }
  else {
    (**(code **)(*param_1 + 0x68))();
  }
  return;
}

