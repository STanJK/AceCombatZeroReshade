/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14020c280; RVA 0x20c280
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14020c280(void)

{
  longlong lVar1;
  undefined8 *puVar2;
  size_t sVar3;
  uint *puVar4;
  int iVar5;
  uint uVar6;
  ulonglong uVar7;
  undefined8 *_Buf1;
  undefined8 *puVar8;
  bool bVar9;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  sVar3 = DAT_14031e0b8;
  puVar2 = DAT_14031e0a8;
  puVar8 = &DAT_14031e0a8;
  if (0xf < DAT_14031e0c0) {
    puVar8 = DAT_14031e0a8;
  }
  _Buf1 = &DAT_14031e0f0;
  if (0xf < DAT_14031e108) {
    _Buf1 = DAT_14031e0f0;
  }
  if ((DAT_14031e100 != DAT_14031e0b8) ||
     ((DAT_14031e100 != 0 && (iVar5 = memcmp(_Buf1,puVar8,DAT_14031e100), iVar5 != 0)))) {
    puVar8 = &DAT_14031e0a8;
    if (0xf < DAT_14031e0c0) {
      puVar8 = puVar2;
    }
    FUN_140212710(&DAT_14031e0f0,puVar8,sVar3);
    if (DAT_14031e0b8 != 0) {
      FUN_14020f590(0);
      DAT_14031e110 = 1;
    }
  }
  (**(code **)(*DAT_14033ace8 + 0x48))();
  (**(code **)(**(longlong **)(DAT_14033da48 + 6) + 0x50))
            (*(longlong **)(DAT_14033da48 + 6),1,&DAT_14033ace8);
  puVar4 = DAT_14033da48;
  bVar9 = DAT_14030f270 == 0;
  uStack_20 = *(undefined8 *)(DAT_14033da48 + (ulonglong)*DAT_14033da48 * 2 + 0x12);
  local_28 = 0;
  uStack_18 = 0x4ffffffff;
  uStack_10 = 0;
  (**(code **)(**(longlong **)(DAT_14033da48 + 4) + 0xd0))
            (*(longlong **)(DAT_14033da48 + 4),1,&local_28);
  (**(code **)(**(longlong **)(puVar4 + 4) + 0x48))();
  (**(code **)(**(longlong **)(puVar4 + 6) + 0x50))(*(longlong **)(puVar4 + 6),1,puVar4 + 4);
  if (bVar9) {
    iVar5 = (**(code **)(**(longlong **)(puVar4 + 0x10) + 0x40))(*(longlong **)(puVar4 + 0x10),1,0);
    if ((iVar5 + 0x7785fffbU & 0xfffffffd) == 0) {
      FUN_140226040(puVar4);
    }
    lVar1 = *(longlong *)(puVar4 + (ulonglong)*puVar4 * 2 + 0x1c);
    (**(code **)(**(longlong **)(puVar4 + 6) + 0x70))
              (*(longlong **)(puVar4 + 6),*(undefined8 *)(puVar4 + 0x1a),lVar1);
    uVar6 = (**(code **)(**(longlong **)(puVar4 + 0x10) + 0x120))();
    *puVar4 = uVar6;
    uVar7 = (**(code **)(**(longlong **)(puVar4 + 0x1a) + 0x40))();
    if (uVar7 < *(ulonglong *)(puVar4 + (ulonglong)*puVar4 * 2 + 0x1c)) {
      (**(code **)(**(longlong **)(puVar4 + 0x1a) + 0x40))();
      (**(code **)(**(longlong **)(puVar4 + 0x1a) + 0x48))
                (*(longlong **)(puVar4 + 0x1a),
                 *(undefined8 *)(puVar4 + (ulonglong)*puVar4 * 2 + 0x1c),
                 *(undefined8 *)(puVar4 + 0x24));
      WaitForSingleObjectEx(*(HANDLE *)(puVar4 + 0x24),0xffffffff,0);
    }
    *(longlong *)(puVar4 + (ulonglong)*puVar4 * 2 + 0x1c) = lVar1 + 1;
    puVar4[1] = puVar4[1] ^ 1;
  }
  _DAT_14033da50 = _DAT_14033da50 + 1;
  return;
}

