/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021ea80; RVA 0x21ea80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

int FUN_14021ea80(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = 0;
  uVar3 = (DAT_14033b188 - DAT_14033b180 >> 5) * -0x3333333333333333;
  if (uVar3 != 0) {
    plVar2 = (longlong *)(DAT_14033b180 + 0x28);
    do {
      if (*plVar2 == param_1) {
        return iVar1;
      }
      iVar1 = iVar1 + 1;
      plVar2 = plVar2 + 0x14;
    } while ((ulonglong)(longlong)iVar1 < uVar3);
  }
  return -1;
}

