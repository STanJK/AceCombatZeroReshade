/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021e260; RVA 0x21e260
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */

int FUN_14021e260(longlong *param_1)

{
  char cVar1;
  ulonglong uVar2;
  longlong *plVar3;
  int *piVar4;
  void *pvVar5;
  int iVar6;
  longlong lVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  undefined1 *puVar12;
  int *piVar13;
  undefined1 (*pauVar14) [16];
  ulonglong uVar15;
  undefined4 *puVar16;
  short *psVar17;
  longlong lVar18;
  longlong lVar19;
  int *piVar20;
  ulonglong uVar21;
  longlong unaff_GS_OFFSET;
  bool bVar22;
  undefined1 auStackY_758 [32];
  int local_728;
  undefined1 (*local_718) [16];
  undefined1 *local_710;
  undefined8 local_6f8;
  undefined8 uStack_6f0;
  undefined8 local_6d8;
  undefined1 local_6b8 [16];
  ulonglong local_6a8;
  ulonglong local_6a0;
  undefined4 local_698 [2];
  undefined1 local_690 [32];
  undefined4 local_670;
  undefined1 local_668 [32];
  undefined4 local_648;
  undefined1 local_640 [32];
  undefined4 local_620;
  undefined1 local_618 [32];
  undefined4 local_5f8;
  undefined1 local_5f0 [32];
  undefined4 local_5d0;
  undefined1 local_5c8 [32];
  undefined4 local_5a8;
  undefined1 local_5a0 [32];
  undefined4 local_580;
  undefined1 local_578 [32];
  undefined4 local_558;
  undefined1 local_550 [32];
  undefined4 local_530;
  undefined1 local_528 [32];
  undefined4 local_508;
  undefined1 local_500 [32];
  undefined4 local_4e0;
  undefined1 local_4d8 [32];
  undefined4 local_4b8;
  undefined1 local_4b0 [32];
  undefined4 local_490;
  undefined1 local_488 [32];
  undefined4 local_468;
  undefined1 local_460 [32];
  undefined4 local_440 [2];
  short local_438 [512];
  ulonglong local_38;
  
  local_38 = DAT_140309040 ^ (ulonglong)auStackY_758;
  FUN_140219cc0();
  piVar4 = DAT_14033b188;
  iVar6 = 0;
  local_728 = 0;
  piVar20 = DAT_14033b180;
  do {
    if (piVar20 == piVar4) {
      return iVar6;
    }
    if (*piVar20 != 3) {
      local_718 = (undefined1 (*) [16])(piVar20 + 0x1c);
      uVar2 = *(ulonglong *)(piVar20 + 0x20);
      local_6b8 = (undefined1  [16])0x0;
      local_6a0 = 0;
      pauVar14 = local_718;
      if (7 < *(ulonglong *)(piVar20 + 0x22)) {
        pauVar14 = *(undefined1 (**) [16])*local_718;
      }
      if (0x7ffffffffffffffe < uVar2) {
                    /* WARNING: Subroutine does not return */
        FUN_14006a510();
      }
      if (uVar2 < 8) {
        local_710 = *(undefined1 **)*pauVar14;
        local_6b8 = *pauVar14;
        uVar21 = 7;
        local_6a0 = 7;
        local_6a8 = uVar2;
      }
      else {
        uVar21 = uVar2 | 7;
        if (uVar21 < 0x7fffffffffffffff) {
          if (uVar21 < 10) {
            uVar21 = 10;
          }
          uVar10 = uVar21 + 1;
          if (0x7fffffffffffffff < uVar10) goto LAB_14021e76d;
        }
        else {
          uVar21 = 0x7ffffffffffffffe;
          uVar10 = 0x7fffffffffffffff;
        }
        local_710 = (undefined1 *)FUN_14006ac30(uVar10 * 2);
        local_6b8._0_8_ = local_710;
        local_6a8 = uVar2;
        local_6a0 = uVar21;
        FUN_140277ba0(local_710,pauVar14,uVar2 * 2 + 2);
      }
      FUN_1402777e0(local_438,0,0x400);
      iVar6 = *piVar20;
      if (iVar6 == 0) {
        plVar9 = *(longlong **)(DAT_14033b1a0 + 8);
        cVar1 = *(char *)((longlong)plVar9 + 0x19);
        while (cVar1 == '\0') {
          if (*(uint *)(plVar9 + 4) < (uint)piVar20[1]) {
            plVar9 = plVar9 + 2;
          }
          plVar9 = (longlong *)*plVar9;
          cVar1 = *(char *)((longlong)plVar9 + 0x19);
        }
        FUN_140221160(local_438,0x200,L"%s  (DirectInput %x #%llx)");
      }
      else if (iVar6 == 1) {
        FUN_140221160(local_438,0x200,L"%s  (XInput %d #%llx)");
      }
      else if (iVar6 == 2) {
        if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dfd24) &&
           (FUN_14022d540(&DAT_1437dfd24), DAT_1437dfd24 == -1)) {
          local_698[0] = 1;
          FUN_14021f3e0(local_690,L"SteamController");
          local_670 = 2;
          FUN_14021f3e0(local_668,L"XBox360Controller");
          local_648 = 3;
          FUN_14021f3e0(local_640,L"XBoxOneController");
          local_620 = 4;
          FUN_14021f3e0(local_618,L"GenericGamepad");
          local_5f8 = 5;
          FUN_14021f3e0(local_5f0,L"PS4Controller");
          local_5d0 = 6;
          FUN_14021f3e0(local_5c8,L"AppleMFiController");
          local_5a8 = 7;
          FUN_14021f3e0(local_5a0,L"AndroidController");
          local_580 = 8;
          FUN_14021f3e0(local_578,L"SwitchJoyConPair");
          local_558 = 9;
          FUN_14021f3e0(local_550,L"SwitchJoyConSingle");
          local_530 = 10;
          FUN_14021f3e0(local_528,L"SwitchProController");
          local_508 = 0xb;
          FUN_14021f3e0(local_500,L"MobileTouch");
          local_4e0 = 0xc;
          FUN_14021f3e0(local_4d8,L"PS3Controller");
          local_4b8 = 0xd;
          FUN_14021f3e0(local_4b0,L"PS5Controller");
          local_490 = 0xe;
          FUN_14021f3e0(local_488,L"SteamDeckController");
          local_468 = 0;
          FUN_14021f3e0(local_460,L"Unknown");
          DAT_1437dfd28 = (void *)0x0;
          DAT_1437dfd30 = 0;
          DAT_1437dfd28 = operator_new(0x48);
          puVar16 = local_698;
          *(void **)DAT_1437dfd28 = DAT_1437dfd28;
          *(void **)((longlong)DAT_1437dfd28 + 8) = DAT_1437dfd28;
          *(void **)((longlong)DAT_1437dfd28 + 0x10) = DAT_1437dfd28;
          *(undefined2 *)((longlong)DAT_1437dfd28 + 0x18) = 0x101;
          do {
            puVar8 = (undefined8 *)FUN_140220a00();
            pvVar5 = DAT_1437dfd28;
            local_6f8 = *puVar8;
            uStack_6f0 = puVar8[1];
            local_6d8 = puVar8[2];
            if ((char)local_6d8 == '\0') {
              if (DAT_1437dfd30 == 0x38e38e38e38e38e) {
                    /* WARNING: Subroutine does not return */
                FUN_140183020();
              }
              plVar9 = operator_new(0x48);
              *(undefined4 *)(plVar9 + 4) = *puVar16;
              FUN_14021f4f0(plVar9 + 5,puVar16 + 2);
              *plVar9 = (longlong)pvVar5;
              plVar9[1] = (longlong)pvVar5;
              plVar9[2] = (longlong)pvVar5;
              *(undefined2 *)(plVar9 + 3) = 0;
              FUN_140185940(&DAT_1437dfd28,&local_6f8,plVar9);
            }
            puVar16 = puVar16 + 10;
          } while (puVar16 != local_440);
          lVar18 = 0xf;
          psVar17 = local_438;
          do {
            psVar17 = psVar17 + -0x14;
            FUN_1402216b0(psVar17);
            lVar18 = lVar18 + -1;
          } while (lVar18 != 0);
          atexit(FUN_14027ad30);
          _Init_thread_footer(&DAT_1437dfd24);
        }
        plVar9 = *(longlong **)((longlong)DAT_1437dfd28 + 8);
        if (*(char *)((longlong)plVar9 + 0x19) == '\0') {
          do {
            if ((int)plVar9[4] < piVar20[0x25]) {
              plVar9 = plVar9 + 2;
            }
            plVar9 = (longlong *)*plVar9;
          } while (*(char *)((longlong)plVar9 + 0x19) == '\0');
        }
        FUN_140221160(local_438,0x200,L"SteamInput  (%s #%llx)");
      }
      lVar18 = -1;
      do {
        lVar18 = lVar18 + 1;
      } while (local_438[lVar18] != 0);
      FUN_14021f2c0(local_718,local_438);
      if (7 < *(ulonglong *)(piVar20 + 0x22)) {
        local_718 = *(undefined1 (**) [16])*local_718;
      }
      plVar9 = (longlong *)param_1[1];
      if (plVar9 == (longlong *)param_1[2]) {
        lVar18 = (longlong)plVar9 - *param_1 >> 3;
        if (lVar18 == 0x1fffffffffffffff) {
                    /* WARNING: Subroutine does not return */
          FUN_140185860();
        }
        uVar10 = lVar18 + 1;
        uVar11 = param_1[2] - *param_1 >> 3;
        if (0x1fffffffffffffff - (uVar11 >> 1) < uVar11) {
          uVar15 = 0x1fffffffffffffff;
        }
        else {
          uVar11 = (uVar11 >> 1) + uVar11;
          uVar15 = uVar10;
          if (uVar10 <= uVar11) {
            uVar15 = uVar11;
          }
          if (0x1fffffffffffffff < uVar15) {
LAB_14021e76d:
                    /* WARNING: Subroutine does not return */
            FUN_14006a4f0();
          }
        }
        lVar7 = FUN_14006ac30(uVar15 * 8);
        *(undefined1 (**) [16])(lVar7 + lVar18 * 8) = local_718;
        plVar3 = (longlong *)*param_1;
        if (plVar9 == (longlong *)param_1[1]) {
          lVar19 = param_1[1] - (longlong)plVar3;
          lVar18 = lVar7;
          plVar9 = plVar3;
        }
        else {
          FUN_140277ba0(lVar7,plVar3,(longlong)plVar9 - (longlong)plVar3);
          lVar18 = lVar7 + 8 + lVar18 * 8;
          lVar19 = param_1[1] - (longlong)plVar9;
        }
        FUN_140277ba0(lVar18,plVar9,lVar19);
        FUN_1401976d0(param_1,lVar7,uVar10);
      }
      else {
        *plVar9 = (longlong)local_718;
        param_1[1] = param_1[1] + 8;
      }
      piVar13 = piVar20 + 0x1c;
      if (7 < *(ulonglong *)(piVar20 + 0x22)) {
        piVar13 = *(int **)(piVar20 + 0x1c);
      }
      puVar12 = local_6b8;
      if (7 < uVar21) {
        puVar12 = local_710;
      }
      if (uVar2 == *(ulonglong *)(piVar20 + 0x20)) {
        if (uVar2 == 0) {
          bVar22 = false;
        }
        else {
          iVar6 = FUN_140220fc0(puVar12,piVar13,uVar2);
          bVar22 = iVar6 != 0;
          local_710 = (undefined1 *)local_6b8._0_8_;
          uVar21 = local_6a0;
        }
      }
      else {
        bVar22 = true;
      }
      if (bVar22) {
        local_728 = local_728 + 1;
      }
      if (7 < uVar21) {
        puVar12 = local_710;
        if ((0xfff < uVar21 * 2 + 2) &&
           (puVar12 = *(undefined1 **)(local_710 + -8),
           (undefined1 *)0x1f < local_710 + (-8 - (longlong)puVar12))) {
                    /* WARNING: Subroutine does not return */
          _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
        }
        thunk_FUN_1402500f0(puVar12);
      }
      iVar6 = local_728;
    }
    piVar20 = piVar20 + 0x28;
  } while( true );
}

