/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021c530; RVA 0x21c530
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14021c530(byte *param_1,longlong param_2)

{
  float fVar1;
  uint uVar2;
  uint uVar3;
  ushort uVar4;
  int iVar5;
  undefined8 uVar6;
  float fVar7;
  float fVar8;
  undefined1 auVar9 [16];
  float fVar10;
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auStack_78 [32];
  short local_58;
  short local_56;
  undefined1 local_50 [16];
  ulonglong local_40;
  
  local_40 = DAT_140309040 ^ (ulonglong)auStack_78;
  local_50 = (undefined1  [16])0x0;
  iVar5 = Ordinal_2(*(undefined4 *)(param_2 + 0x90),local_50);
  if (iVar5 == 0) {
    uVar4 = *(ushort *)(param_1 + 0x28);
    if (((byte)local_50[4] & 1) != 0) {
      uVar4 = uVar4 | 0x10;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if (((byte)local_50[4] & 2) != 0) {
      uVar4 = uVar4 | 0x40;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if (((byte)local_50[4] & 4) != 0) {
      uVar4 = uVar4 | 0x80;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if (((byte)local_50[4] & 8) != 0) {
      uVar4 = uVar4 | 0x20;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if (((byte)local_50[4] & 0x10) != 0) {
      uVar4 = uVar4 | 8;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if (((byte)local_50[4] & 0x20) != 0) {
      uVar4 = uVar4 | 1;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if (((byte)local_50[4] & 0x40) != 0) {
      uVar4 = uVar4 | 2;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if (local_50[4] < '\0') {
      uVar4 = uVar4 | 4;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if ((local_50._4_2_ & 0x100) != 0) {
      uVar4 = uVar4 | 0x400;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if ((local_50._4_2_ & 0x200) != 0) {
      uVar4 = uVar4 | 0x800;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if ((local_50._4_2_ & 0x400) != 0) {
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if ((local_50._4_2_ & 0x800) != 0) {
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if ((local_50._4_2_ & 0x1000) != 0) {
      uVar4 = uVar4 | 0x4000;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if ((local_50._4_2_ & 0x2000) != 0) {
      uVar4 = uVar4 | 0x2000;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if ((local_50._4_2_ & 0x4000) != 0) {
      uVar4 = uVar4 | 0x8000;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if ((short)local_50._4_2_ < 0) {
      *(ushort *)(param_1 + 0x28) = uVar4 | 0x1000;
    }
    uVar3 = DAT_1402d3770;
    uVar2 = DAT_1402d2b54;
    fVar8 = DAT_1402d2aa8;
    auVar12 = vcvtdq2ps_avx(ZEXT116(local_50[6]));
    auVar12 = vmaxss_avx(auVar12,ZEXT416((uint)DAT_1402d25c0));
    auVar12 = vminss_avx(auVar12,ZEXT416(DAT_1402d2858));
    fVar1 = (auVar12._0_4_ - DAT_1402d25c0) * DAT_1402d1ea8;
    auVar12 = vcvtdq2ps_avx(ZEXT116(local_50[7]));
    auVar12 = vmaxss_avx(auVar12,ZEXT416((uint)DAT_1402d25c0));
    auVar11 = vminss_avx(auVar12,ZEXT416(DAT_1402d2858));
    auVar12 = vcvtdq2ps_avx(ZEXT416((uint)(int)(short)local_50._8_2_));
    *(float *)(param_1 + 0x24) = (auVar11._0_4_ - DAT_1402d25c0) * DAT_1402d1ea8;
    *(float *)(param_1 + 0x20) = fVar1;
    auVar11 = ZEXT416((uint)fVar8);
    auVar13 = ZEXT416(uVar2);
    if (auVar12._0_4_ <= 0.0) {
      auVar9._0_4_ = (uint)auVar12._0_4_ ^ uVar3;
      auVar9._4_4_ = auVar12._4_4_;
      auVar9._8_4_ = auVar12._8_4_;
      auVar9._12_4_ = auVar12._12_4_;
      auVar12 = vmaxss_avx(auVar9,auVar11);
      auVar12 = vminss_avx(auVar12,auVar13);
      fVar10 = (auVar12._0_4_ - fVar8) * DAT_1402d2c54;
    }
    else {
      auVar12 = vmaxss_avx(auVar12,auVar11);
      auVar12 = vminss_avx(auVar12,auVar13);
      fVar10 = (auVar12._0_4_ - fVar8) * DAT_1402d1d78;
    }
    fVar7 = (float)-(int)(short)local_50._10_2_;
    *(float *)(param_1 + 8) = fVar10;
    fVar10 = DAT_1402d2ab0;
    if (fVar7 <= 0.0) {
      auVar12 = vmaxss_avx(ZEXT416((uint)fVar7 ^ uVar3),auVar11);
      auVar12 = vminss_avx(auVar12,auVar13);
      fVar8 = (auVar12._0_4_ - fVar8) * DAT_1402d2c54;
    }
    else {
      auVar12 = vmaxss_avx(ZEXT416((uint)fVar7),auVar11);
      auVar12 = vminss_avx(auVar12,auVar13);
      fVar8 = (auVar12._0_4_ - fVar8) * DAT_1402d1d78;
    }
    *(float *)(param_1 + 0xc) = fVar8;
    fVar8 = (float)(int)(short)local_50._12_2_;
    auVar12 = ZEXT416((uint)fVar10);
    if (fVar8 <= 0.0) {
      auVar11 = vmaxss_avx(ZEXT416((uint)fVar8 ^ uVar3),auVar12);
      auVar11 = vminss_avx(auVar11,auVar13);
      fVar8 = (auVar11._0_4_ - fVar10) * DAT_1402d2c58;
    }
    else {
      auVar11 = vmaxss_avx(ZEXT416((uint)fVar8),auVar12);
      auVar11 = vminss_avx(auVar11,auVar13);
      fVar8 = (auVar11._0_4_ - fVar10) * DAT_1402d1d80;
    }
    *(float *)(param_1 + 0x10) = fVar8;
    fVar8 = (float)-(int)(short)local_50._14_2_;
    if (fVar8 <= 0.0) {
      auVar12 = vmaxss_avx(ZEXT416((uint)fVar8 ^ uVar3),auVar12);
      auVar12 = vminss_avx(auVar12,auVar13);
      fVar8 = (auVar12._0_4_ - fVar10) * DAT_1402d2c58;
    }
    else {
      auVar12 = vmaxss_avx(ZEXT416((uint)fVar8),auVar12);
      auVar12 = vminss_avx(auVar12,auVar13);
      fVar8 = (auVar12._0_4_ - fVar10) * DAT_1402d1d80;
    }
    *(float *)(param_1 + 0x14) = fVar8;
    uVar4 = *(ushort *)(param_1 + 0x28);
    if ((uVar4 & 0x400) != 0) {
      param_1[0x18] = 0;
      param_1[0x19] = 0;
      param_1[0x1a] = 0x80;
      param_1[0x1b] = 0x3f;
    }
    if ((uVar4 & 0x800) != 0) {
      param_1[0x1c] = 0;
      param_1[0x1d] = 0;
      param_1[0x1e] = 0x80;
      param_1[0x1f] = 0x3f;
    }
    fVar8 = DAT_1402d20f0;
    if (DAT_1402d20f0 < fVar1) {
      uVar4 = uVar4 | 0x100;
      *(ushort *)(param_1 + 0x28) = uVar4;
    }
    if (fVar8 < *(float *)(param_1 + 0x24)) {
      *(ushort *)(param_1 + 0x28) = uVar4 | 0x200;
    }
    local_58 = (ushort)*param_1 * 0x101;
    local_56 = (ushort)param_1[1] * 0x101;
    Ordinal_3(*(undefined4 *)(param_2 + 0x90),&local_58);
    uVar6 = 1;
    param_1[0x2c] = 1;
    param_1[0x2d] = 0;
    param_1[0x2e] = 0;
    param_1[0x2f] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0;
    param_1[7] = 0;
  }
  else {
    uVar6 = 0;
  }
  return uVar6;
}

