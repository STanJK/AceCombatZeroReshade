/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021a260; RVA 0x21a260
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14021a260(longlong param_1,uint *param_2)

{
  undefined1 auVar1 [16];
  float fVar2;
  uint uVar3;
  ushort *puVar4;
  ushort *puVar5;
  
  uVar3 = DAT_1402d3770;
  auVar1 = vcmpss_avx(ZEXT416(param_2[1]),ZEXT416(*param_2),1);
  auVar1 = vblendvps_avx(ZEXT416(param_2[1]),ZEXT416(*param_2 ^ DAT_1402d3770),auVar1);
  *(int *)(param_1 + 8) = auVar1._0_4_;
  auVar1 = vcmpss_avx(ZEXT416(param_2[3]),ZEXT416(param_2[2]),1);
  auVar1 = vblendvps_avx(ZEXT416(param_2[3]),ZEXT416(param_2[2] ^ uVar3),auVar1);
  *(int *)(param_1 + 0xc) = auVar1._0_4_;
  auVar1 = vcmpss_avx(ZEXT416(param_2[5]),ZEXT416(param_2[4]),1);
  auVar1 = vblendvps_avx(ZEXT416(param_2[5]),ZEXT416(param_2[4] ^ uVar3),auVar1);
  *(int *)(param_1 + 0x10) = auVar1._0_4_;
  auVar1 = vcmpss_avx(ZEXT416(param_2[7]),ZEXT416(param_2[6]),1);
  auVar1 = vblendvps_avx(ZEXT416(param_2[7]),ZEXT416(param_2[6] ^ uVar3),auVar1);
  *(int *)(param_1 + 0x14) = auVar1._0_4_;
  fVar2 = DAT_1402d20f0;
  *(uint *)(param_1 + 0x20) = param_2[8];
  *(uint *)(param_1 + 0x24) = param_2[9];
  *(uint *)(param_1 + 0x18) = param_2[10];
  *(uint *)(param_1 + 0x1c) = param_2[0xb];
  if (fVar2 < (float)param_2[8]) {
    *(ushort *)(param_1 + 0x28) = *(ushort *)(param_1 + 0x28) | 0x100;
  }
  if (fVar2 < (float)param_2[9]) {
    *(ushort *)(param_1 + 0x28) = *(ushort *)(param_1 + 0x28) | 0x200;
  }
  if (fVar2 < (float)param_2[10]) {
    *(ushort *)(param_1 + 0x28) = *(ushort *)(param_1 + 0x28) | 0x400;
  }
  puVar5 = (ushort *)(param_1 + 0x28);
  if (fVar2 < (float)param_2[0xb]) {
    *puVar5 = *(ushort *)(param_1 + 0x28) | 0x800;
  }
  if (fVar2 < (float)param_2[0xc]) {
    *puVar5 = *puVar5 | 0x4000;
  }
  puVar4 = (ushort *)(param_1 + 0x28);
  if (fVar2 < (float)param_2[0xd]) {
    *puVar4 = *puVar5 | 0x2000;
  }
  if (fVar2 < (float)param_2[0xe]) {
    *puVar4 = *puVar4 | 0x8000;
  }
  puVar5 = (ushort *)(param_1 + 0x28);
  if (fVar2 < (float)param_2[0xf]) {
    *puVar5 = *puVar4 | 0x1000;
  }
  if (fVar2 < (float)param_2[0x10]) {
    *puVar5 = *puVar5 | 2;
  }
  puVar4 = (ushort *)(param_1 + 0x28);
  if (fVar2 < (float)param_2[0x11]) {
    *puVar4 = *puVar5 | 4;
  }
  if (fVar2 < (float)param_2[0x12]) {
    *puVar4 = *puVar4 | 8;
  }
  puVar5 = (ushort *)(param_1 + 0x28);
  if (fVar2 < (float)param_2[0x13]) {
    *puVar5 = *puVar4 | 1;
  }
  if (fVar2 < (float)param_2[0x14]) {
    *puVar5 = *puVar5 | 0x80;
  }
  puVar4 = (ushort *)(param_1 + 0x28);
  if (fVar2 < (float)param_2[0x15]) {
    *puVar4 = *puVar5 | 0x20;
  }
  if (fVar2 < (float)param_2[0x16]) {
    *puVar4 = *puVar4 | 0x10;
  }
  if (fVar2 < (float)param_2[0x17]) {
    *(ushort *)(param_1 + 0x28) = *puVar4 | 0x40;
  }
  return;
}

