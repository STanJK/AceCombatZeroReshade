/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140187480; RVA 0x187480
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_140187480(undefined8 *param_1)

{
  param_1[0xf] = 0x230d0f17;
  *(undefined4 *)(param_1 + 2) = 0x3020100;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0x100d0504;
  *(undefined4 *)(param_1 + 3) = 0x7060e0f;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0x13121108;
  *(undefined4 *)(param_1 + 4) = 0xc0b0a09;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0x17161514;
  *(undefined4 *)(param_1 + 5) = 0xff0d0f;
  *(undefined4 *)((longlong)param_1 + 0x2c) = 0x4030201;
  *(undefined2 *)(param_1 + 6) = 0xd05;
  *(undefined1 *)((longlong)param_1 + 0x32) = 0x10;
  *(undefined4 *)((longlong)param_1 + 0x35) = 0x11080706;
  *(undefined4 *)((longlong)param_1 + 0x39) = 0xa091312;
  *(undefined4 *)((longlong)param_1 + 0x3d) = 0x15140c0b;
  *(undefined2 *)((longlong)param_1 + 0x41) = 0x1716;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0x100ff0d;
  *(undefined4 *)(param_1 + 9) = 0x5040302;
  *(undefined4 *)((longlong)param_1 + 0x4c) = 0xe0f100d;
  *(undefined4 *)(param_1 + 10) = 0x11080706;
  *(undefined4 *)((longlong)param_1 + 0x54) = 0xa091312;
  *(undefined4 *)(param_1 + 0xb) = 0x15140c0b;
  *(undefined4 *)((longlong)param_1 + 0x5c) = 0xd0f1716;
  *(undefined4 *)(param_1 + 0xc) = 0x20100ff;
  *(undefined4 *)((longlong)param_1 + 100) = 0xd050403;
  *(undefined4 *)(param_1 + 0xd) = 0x60e0f10;
  *(undefined4 *)((longlong)param_1 + 0x6c) = 0x12110807;
  *(undefined4 *)(param_1 + 0xe) = 0xb0a0913;
  *(undefined4 *)((longlong)param_1 + 0x74) = 0x1615140c;
  *(undefined2 *)((longlong)param_1 + 0x33) = 0xf0e;
  *(undefined1 *)((longlong)param_1 + 0x43) = 0xe;
  *(undefined2 *)(param_1 + 0x10) = 0xffff;
  *param_1 = 0;
  param_1[1] = 0;
  return param_1;
}

