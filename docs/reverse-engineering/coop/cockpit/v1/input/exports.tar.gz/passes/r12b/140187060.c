/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140187060; RVA 0x187060
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_140187060(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longlong lVar4;
  undefined2 uVar5;
  undefined2 uVar6;
  
  lVar4 = *(longlong *)((&DAT_14033bc00)[param_1] + 8);
  if (lVar4 == 0) {
    *(undefined2 *)(param_2 + 4) = 0;
    return 0;
  }
  uVar5 = 4;
  if ((*(char *)(lVar4 + 0xb8) == '\0') || (uVar6 = 4, *(int *)(lVar4 + 0x4c) == 0)) {
    uVar6 = (undefined2)*(undefined4 *)(lVar4 + 0x4c);
  }
  cVar1 = *(char *)(lVar4 + 0xb8);
  *(undefined2 *)(param_2 + 4) = uVar6;
  if ((cVar1 == '\0') || (*(int *)(lVar4 + 0x4c) == 0)) {
    uVar5 = (undefined2)*(undefined4 *)(lVar4 + 0x4c);
  }
  param_2[10] = (int)(((float)*(uint *)(lVar4 + 0xac) / (float)*(int *)(lVar4 + 0x90)) *
                     DAT_1402d2994);
  *(undefined2 *)(param_2 + 4) = uVar5;
  iVar2 = *(int *)(lVar4 + 0x84);
  iVar3 = *(int *)(lVar4 + 0x80);
  *(char *)((longlong)param_2 + 9) = (char)iVar2;
  *param_2 = iVar2 * iVar3;
  param_2[8] = *(int *)(lVar4 + 0x58);
  return 0;
}

