/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140102ab0; RVA 0x102ab0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140102ab0(longlong param_1)

{
  char cVar1;
  undefined1 uVar2;
  float fVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  undefined1 uVar7;
  byte bVar8;
  ulonglong uVar9;
  uint uVar10;
  ulonglong uVar11;
  longlong unaff_GS_OFFSET;
  undefined4 uVar12;
  
  *(undefined1 *)(param_1 + 0x20a5) = *(undefined1 *)(param_1 + 0x2094);
  FUN_1401c56d0();
  if (*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437daf04) {
    FUN_14022d540(&DAT_1437daf04);
    if (DAT_1437daf04 == -1) {
      FUN_1401c93c0();
      _Init_thread_footer(&DAT_1437daf04);
    }
  }
  DAT_1437dece0 = DAT_1437dece0 | 1;
  cVar1 = *(char *)(param_1 + 0x2094);
  *(char *)(param_1 + 0x1da6) = cVar1;
  if (cVar1 == '\x01') {
    uVar12 = *(undefined4 *)(param_1 + 0x1d68);
  }
  else if (cVar1 == '\x02') {
    uVar12 = *(undefined4 *)(param_1 + 0x1d6c);
  }
  else {
    uVar12 = *(undefined4 *)(param_1 + 0x1d64);
  }
  *(undefined4 *)(param_1 + 0x1d70) = uVar12;
  *(undefined4 *)(param_1 + 0x1d74) = uVar12;
  lVar6 = param_1 + 0x110;
  *(undefined8 *)(param_1 + 0x1d40) = 0;
  lVar5 = param_1 + 0x1430;
  *(undefined8 *)(param_1 + 0x1d48) = 0;
  *(longlong *)(param_1 + 0x1630) = lVar6;
  FUN_140129300();
  *(undefined8 *)(lVar5 + 0x3f8) = 0;
  *(undefined8 *)(lVar5 + 0x400) = 0;
  bVar8 = *(byte *)(param_1 + 0x1676) | 0x20;
  if (*(char *)(param_1 + 0x20ac) != '\x01') {
    bVar8 = *(byte *)(param_1 + 0x1676) & 0xdf;
  }
  *(byte *)(param_1 + 0x1676) = bVar8;
  *(undefined1 *)(param_1 + 0x1dae) = 0;
  *(undefined8 *)(param_1 + 0x1d30) = 0;
  *(undefined8 *)(param_1 + 0x1d38) = 0;
  *(undefined8 *)(param_1 + 0x1e18) = 0xffffffffffffffff;
  *(undefined1 *)(param_1 + 0x1e20) = 0;
  *(undefined8 *)(param_1 + 0x1e24) = 0;
  FUN_1401554c0(lVar6);
  lVar6 = *(longlong *)(param_1 + 0xfe0);
  *(undefined4 *)(param_1 + 0x1644) = *(undefined4 *)(lVar6 + 4);
  *(undefined2 *)(param_1 + 0x1f10) = 0;
  *(undefined2 *)(param_1 + 0x1f28) = 0;
  *(undefined2 *)(param_1 + 8000) = 0;
  *(undefined2 *)(param_1 + 0x1f58) = 0;
  *(undefined2 *)(param_1 + 0x1f70) = 0;
  *(undefined2 *)(param_1 + 0x1f88) = 0;
  *(undefined1 *)(param_1 + 0x1fa1) = 0;
  *(undefined2 *)(param_1 + 0x1f9c) = 0;
  *(undefined1 *)(param_1 + 0x1f9e) = 0;
  *(undefined2 *)(param_1 + 0x208e) = *(undefined2 *)(lVar6 + 8);
  *(undefined1 *)(param_1 + 0x2099) = *(undefined1 *)(lVar6 + 10);
  uVar10 = (uint)*(byte *)(param_1 + 0x279a) * 4;
  uVar11 = (ulonglong)uVar10;
  *(undefined1 *)(param_1 + 0x209a) =
       *(undefined1 *)((ulonglong)*(byte *)(param_1 + 0x279a) + 0xb + lVar6);
  *(undefined2 *)(param_1 + 0x209b) = 0;
  *(undefined1 *)(param_1 + 0x209d) = 0;
  *(undefined1 *)(param_1 + 0x20b4) = 0;
  iVar4 = FUN_14015e530(param_1 + 0x120,uVar10 + 0x43);
  if (iVar4 != 0) {
    uVar9 = 0;
    do {
      if (3 < (byte)uVar9) break;
      bVar8 = (byte)uVar9 + 1;
      uVar9 = (ulonglong)bVar8;
      *(byte *)(param_1 + 0x20b4) = bVar8;
      iVar4 = FUN_14015e530(param_1 + 0x120,bVar8 + 0x43 + (int)uVar11);
    } while (iVar4 != 0);
  }
  lVar6 = *(longlong *)(param_1 + 0xff8);
  *(undefined1 *)(param_1 + 0x2098) = 0;
  FUN_140102800(param_1 + 0xf90,*(undefined1 *)(lVar6 + 4));
  FUN_140102800(param_1 + 0xfa8,*(undefined1 *)(lVar6 + 5));
  FUN_140102800(param_1 + 0xfc0,*(undefined1 *)(lVar6 + 6));
  *(undefined1 *)(param_1 + 0x18a8) = 1;
  *(undefined8 *)(param_1 + 0x1bf0) = 0;
  *(undefined8 *)(param_1 + 0x1bdc) = 0xffffffffffffffff;
  *(undefined8 *)(param_1 + 0x1bb0) = 0xfffffff;
  *(undefined8 *)(param_1 + 0x1c0a) = 0xffffffffffffffff;
  *(undefined4 *)(param_1 + 0x1c12) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x1c16) = 0xffffff;
  *(undefined2 *)(param_1 + 0x1c26) = 0xffff;
  *(undefined8 *)(param_1 + 0x1bfc) = 0;
  *(undefined4 *)(param_1 + 0x1bf8) = 0;
  *(ushort *)(param_1 + 0x1c20) = *(ushort *)(param_1 + 0x1c20) & 0xa1;
  *(undefined2 *)(param_1 + 0x1c04) = 0xffff;
  *(undefined1 *)(param_1 + 0x1c29) = 0;
  *(undefined1 *)(param_1 + 0x1c2b) = 1;
  (**(code **)(**(longlong **)(param_1 + 0x1868) + 0x60))();
  (**(code **)(**(longlong **)(param_1 + 0x1870) + 0x60))();
  lVar5 = *(longlong *)(param_1 + 0xfd8);
  uVar7 = *(undefined1 *)(lVar5 + 0xe);
  if (*(char *)(lVar5 + 0xd) == '\x15') {
    uVar7 = 1;
  }
  FUN_1400b7750(param_1 + 0x1868,
                *(undefined1 *)
                 ((ulonglong)*(byte *)(param_1 + 0x279a) + 4 + *(longlong *)(param_1 + 0xff8)),uVar7
                ,*(undefined1 *)(lVar5 + 0xf),*(undefined8 *)(param_1 + 0x1fc8));
  uVar7 = *(undefined1 *)(param_1 + 0x20a1);
  uVar2 = *(undefined1 *)(param_1 + 0x20a2);
  *(undefined1 *)(param_1 + 0x1eeb) = uVar2;
  *(undefined1 *)(param_1 + 0x1eea) = uVar7;
  *(undefined1 *)(param_1 + 0x1eca) = uVar2;
  *(undefined1 *)(param_1 + 0x1ec9) = uVar7;
  *(undefined1 *)(param_1 + 0x1e52) = uVar2;
  *(undefined1 *)(param_1 + 0x1e51) = uVar7;
  *(undefined1 *)(param_1 + 0x1e71) = uVar7;
  *(undefined1 *)(param_1 + 0x1e72) = uVar2;
  *(undefined1 *)(param_1 + 0x1e91) = uVar7;
  *(undefined1 *)(param_1 + 0x1e92) = uVar2;
  *(undefined1 *)(param_1 + 0x1eb1) = uVar7;
  *(undefined1 *)(param_1 + 0x1eb2) = uVar2;
  *(longlong *)(param_1 + 0x1ed8) = param_1;
  FUN_1400c04e0(param_1 + 0x1e38,1);
  *(undefined1 *)(param_1 + 0x1eef) = *(undefined1 *)(param_1 + 0x20a0);
  *(undefined4 *)(param_1 + 0x1ee0) = 0x46f00000;
  fVar3 = *(float *)(*(longlong *)(param_1 + 0x1fb8) + 0x10) * DAT_1402d2478;
  *(float *)(param_1 + 0x1ec4) = fVar3;
  *(float *)(param_1 + 0x1e44) = fVar3;
  *(float *)(param_1 + 0x1e64) = fVar3;
  *(float *)(param_1 + 0x1e84) = fVar3;
  *(float *)(param_1 + 0x1ea4) = fVar3;
  *(byte *)(param_1 + 0x1eee) = *(byte *)(param_1 + 0x1eee) & 0xf3;
  *(byte *)(param_1 + 0x1ecd) = *(byte *)(param_1 + 0x1ecd) & 0xfc;
  *(undefined1 *)(param_1 + 0x1ece) = *(undefined1 *)(lVar6 + 0xd);
  *(undefined4 *)(param_1 + 0x2086) = 0;
  *(undefined4 *)(param_1 + 0x2080) = 0xffff;
  *(undefined2 *)(param_1 + 0x2084) = 0;
  FUN_14010e220(param_1,0);
  (**(code **)(**(longlong **)(param_1 + 0x1fa8) + 8))();
  *(undefined2 *)(param_1 + 0x20c1) = 10;
  *(undefined1 *)(param_1 + 0x20c3) = 0;
  *(undefined4 *)(param_1 + 0x207c) = 0;
  *(undefined4 *)(param_1 + 0x272a) = 0;
  *(undefined1 *)(param_1 + 0x272e) = 0;
  *(undefined2 *)(param_1 + 0x2728) = 0;
  *(undefined2 *)(param_1 + 0x60) = 0;
  *(undefined1 *)(param_1 + 0x20c0) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0x7f7fffff;
  if (*(char *)(param_1 + 0x20a3) == '\x15') {
    *(ushort *)(param_1 + 0xae4) = *(ushort *)(param_1 + 0xae4) | 0x1000;
  }
  uVar10 = *(uint *)(param_1 + 0x2058);
  *(uint *)(param_1 + 0x2058) = uVar10 | 0x200;
  if ((*(longlong **)(param_1 + 0x2040) == (longlong *)0x0) ||
     (*(int *)(*(longlong *)
                (**(longlong **)(param_1 + 0x2040) + (ulonglong)*(byte *)(param_1 + 0x20a1) * 8) +
              0x118) < 2)) {
    *(uint *)(param_1 + 0x2058) = uVar10 | 0x1200;
    *(ushort *)(param_1 + 0x1c20) = *(ushort *)(param_1 + 0x1c20) | 1;
  }
  else {
    *(uint *)(param_1 + 0x2058) = uVar10 & 0xffffefff | 0x200;
    *(ushort *)(param_1 + 0x1c20) = *(ushort *)(param_1 + 0x1c20) & 0xfffe;
  }
  *(undefined8 *)(param_1 + 0x1010) = 0;
  *(undefined8 *)(param_1 + 0x1018) = 0;
  *(undefined8 *)(param_1 + 0x1020) = 0;
  *(undefined8 *)(param_1 + 0x1030) = 0;
  *(undefined8 *)(param_1 + 0x1038) = 0;
  *(undefined8 *)(param_1 + 0x1040) = 0;
  *(undefined8 *)(param_1 + 0x1050) = 0;
  *(undefined8 *)(param_1 + 0x1058) = 0;
  *(undefined8 *)(param_1 + 0x1060) = 0;
  *(undefined1 *)(param_1 + 0x102c) = 0xff;
  *(undefined4 *)(param_1 + 0x1028) = 1;
  *(undefined1 *)(param_1 + 0x104c) = 0xff;
  *(undefined4 *)(param_1 + 0x1048) = 1;
  *(undefined1 *)(param_1 + 0x106c) = 0xff;
  *(undefined4 *)(param_1 + 0x1068) = 1;
  *(undefined2 *)(param_1 + 0x10a2) = 0;
  *(bool *)(param_1 + 0x10a5) = *(char *)(param_1 + 0x20b1) == '\0';
  *(undefined1 *)(param_1 + 0x20a8) = 0;
  *(undefined2 *)(param_1 + 0x2798) = 0;
  *(undefined4 *)(param_1 + 0x2784) = *(undefined4 *)(param_1 + 0x2780);
  return;
}

