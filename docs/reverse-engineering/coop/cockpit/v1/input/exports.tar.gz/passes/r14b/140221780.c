/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140221780; RVA 0x221780
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Removing unreachable block (ram,0x00014022181e) */
/* WARNING: Removing unreachable block (ram,0x0001402217eb) */
/* WARNING: Removing unreachable block (ram,0x0001402217d0) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_140221780(undefined8 *param_1)

{
  byte *pbVar1;
  int *piVar2;
  LONG *pLVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [12];
  LONG LVar13;
  HWND pHVar14;
  char cVar15;
  char cVar16;
  char cVar17;
  char cVar18;
  ATOM AVar19;
  int iVar20;
  DWORD DVar21;
  undefined4 uVar22;
  int iVar23;
  int iVar24;
  int iVar25;
  undefined8 *puVar26;
  ulonglong uVar27;
  longlong lVar28;
  undefined8 uVar29;
  undefined8 uVar30;
  undefined8 uVar31;
  HICON pHVar32;
  HBRUSH pHVar33;
  LPCSTR lpPathName;
  byte *pbVar34;
  char *lpWindowName;
  int nHeight;
  byte *pbVar35;
  ulonglong uVar36;
  ulonglong uVar37;
  byte *pbVar38;
  int Y;
  int nWidth;
  undefined1 auStackY_798 [32];
  WNDCLASSEXA local_728;
  tagMSG local_6d8;
  undefined1 local_6a8 [16];
  ulonglong uStack_698;
  ulonglong uStack_690;
  tagRECT local_688;
  undefined8 local_678;
  ulonglong local_670;
  undefined1 local_668 [16];
  ulonglong uStack_658;
  ulonglong uStack_650;
  char *local_648;
  char *pcStack_640;
  undefined1 auStack_638 [16];
  undefined1 local_628 [16];
  undefined8 uStack_618;
  undefined8 uStack_610;
  undefined1 auStack_608 [16];
  undefined8 local_5f8;
  undefined8 uStack_5f0;
  undefined8 uStack_5e8;
  undefined8 uStack_5e0;
  undefined1 local_5d8 [16];
  undefined8 local_5b0;
  undefined1 local_590 [16];
  undefined8 local_580;
  ulonglong local_578;
  undefined1 local_570;
  CHAR local_548;
  char acStack_547 [271];
  undefined1 local_438 [1024];
  ulonglong local_38;
  
  local_38 = DAT_140309040 ^ (ulonglong)auStackY_798;
  CoInitializeEx((LPVOID)0x0,0);
  DAT_1403589f0 = (HINSTANCE)*param_1;
  piVar2 = (int *)cpuid_basic_info(0);
  local_688.left = (LONG)_DAT_1402d2f30;
  local_688.top = piVar2[1];
  local_688.right = piVar2[3];
  local_688.bottom = piVar2[2];
  if (*piVar2 < 7) {
LAB_1402226a3:
    MessageBoxA((HWND)0x0,"ERROR: This hardware does not support the required instruction set.",
                "Error",0);
    return 0xffffffff;
  }
  puVar26 = (undefined8 *)cpuid_Version_info(1);
  local_688._0_8_ = *puVar26;
  if (((*(uint *)((longlong)puVar26 + 0xc) & 0x38081001) != 0x38081001) ||
     ((*(uint *)(puVar26 + 1) & 0x6000000) != 0x6000000)) goto LAB_1402226a3;
  pLVar3 = (LONG *)cpuid_Extended_Feature_Enumeration_info(7);
  local_688.left = *pLVar3;
  local_688.right = pLVar3[3];
  local_688.bottom = pLVar3[2];
  if ((pLVar3[1] & 0x20U) == 0) goto LAB_1402226a3;
  cVar15 = SteamAPI_RestartAppIfNecessary(0x22ead4);
  if (cVar15 != '\0') {
    return 0xffffffff;
  }
  FUN_1402777e0(local_438,0,0x400);
  iVar20 = SteamInternal_SteamAPI_Init("SteamUtils010",local_438);
  if (iVar20 != 0) {
    return 0xffffffff;
  }
  puVar26 = (undefined8 *)SteamInternal_ContextInit(&PTR_FUN_14031e5a0);
  cVar15 = (**(code **)(*(longlong *)*puVar26 + 0x38))((longlong *)*puVar26,0x377aa8);
  if (cVar15 == '\0') {
    return 0xffffffff;
  }
  FUN_1402777e0(&local_548,0,0x104);
  DVar21 = GetModuleFileNameA((HMODULE)0x0,&local_548,0x104);
  if (DVar21 != 0) {
    local_668 = (undefined1  [16])0x0;
    uStack_658 = 0;
    uStack_650 = 0;
    uVar36 = 0xffffffffffffffff;
    do {
      uVar27 = uVar36;
      uVar36 = uVar27 + 1;
    } while (acStack_547[uVar27] != '\0');
    if (0x7fffffffffffffff < uVar36) {
LAB_140222702:
                    /* WARNING: Subroutine does not return */
      FUN_14006a510();
    }
    if (uVar36 < 0x10) {
      uStack_650 = 0xf;
      uStack_658 = uVar36;
      FUN_140277ba0(local_668,&local_548,uVar36);
      local_668[uVar27 + 1] = 0;
    }
    else {
      uVar27 = uVar36 | 0xf;
      if (uVar27 < 0x8000000000000000) {
        if (uVar27 < 0x16) {
          uVar27 = 0x16;
        }
      }
      else {
        uVar27 = 0x7fffffffffffffff;
      }
      lVar28 = FUN_14006ac30(uVar27 + 1);
      local_668._0_8_ = lVar28;
      uStack_658 = uVar36;
      uStack_650 = uVar27;
      FUN_140277ba0(lVar28,&local_548,uVar36);
      *(undefined1 *)(lVar28 + uVar36) = 0;
    }
    uVar27 = uStack_650;
    uVar36 = uStack_658;
    pbVar35 = (byte *)local_668._0_8_;
    uVar37 = 0xffffffffffffffff;
    pbVar34 = local_668;
    if (0xf < uStack_650) {
      pbVar34 = (byte *)local_668._0_8_;
    }
    if (uStack_658 != 0) {
      if (uStack_658 - 1 != 0xffffffffffffffff) {
        uVar37 = uStack_658 - 1;
      }
      if (uVar37 + 2 < 0x10) {
        local_648 = (char *)0x0;
        pcStack_640 = (char *)0x0;
        auStack_638 = ZEXT816(0);
        local_628 = ZEXT816(0);
        uStack_618 = 0;
        uStack_610 = 0;
        auStack_608 = (undefined1  [16])0x0;
        local_5f8 = 0;
        uStack_5f0 = uStack_5f0 & 0xffffffff00000000;
        FUN_1402777e0((longlong)&uStack_5f0 + 5,0,0xa3);
        pbVar38 = pbVar34 + uVar37;
        uStack_5f0._0_5_ = CONCAT14(1,(undefined4)uStack_5f0);
        cVar15 = auStack_638[(ulonglong)*pbVar38 - 0x10];
        while (cVar15 == '\0') {
          if (pbVar38 == pbVar34) {
            uVar37 = 0xffffffffffffffff;
            goto LAB_140221a7b;
          }
          pbVar1 = pbVar38 + -1;
          pbVar38 = pbVar38 + -1;
          cVar15 = auStack_638[(ulonglong)*pbVar1 - 0x10];
        }
        uVar37 = (longlong)pbVar38 - (longlong)pbVar34;
      }
      else {
        uVar37 = thunk_FUN_14026b740(pbVar34,uVar37 + 1,&DAT_1402cdd2c);
        pbVar35 = (byte *)local_668._0_8_;
        uVar36 = uStack_658;
        uVar27 = uStack_650;
      }
    }
LAB_140221a7b:
    if (uVar36 < uVar37) {
      uVar37 = uVar36;
    }
    local_6a8 = (undefined1  [16])0x0;
    pbVar34 = local_668;
    if (0xf < uVar27) {
      pbVar34 = pbVar35;
    }
    if (0x7fffffffffffffff < uVar37) goto LAB_140222702;
    uStack_698 = uVar37;
    if (uVar37 < 0x10) {
      uStack_690 = 0xf;
      FUN_140277ba0(local_6a8,pbVar34);
      local_6a8[uVar37] = 0;
    }
    else {
      uVar27 = uVar37 | 0xf;
      uVar36 = 0x7fffffffffffffff;
      if ((uVar27 < 0x8000000000000000) && (uVar36 = uVar27, uVar27 < 0x16)) {
        uVar36 = 0x16;
      }
      lVar28 = FUN_14006ac30(uVar36 + 1);
      local_6a8._0_8_ = lVar28;
      uStack_690 = uVar36;
      FUN_140277ba0(lVar28,pbVar34);
      *(undefined1 *)(lVar28 + uVar37) = 0;
      pbVar35 = (byte *)local_668._0_8_;
      uVar27 = uStack_650;
    }
    if (0xf < uVar27) {
      pbVar34 = pbVar35;
      if ((0xfff < uVar27 + 1) &&
         (pbVar34 = *(byte **)(pbVar35 + -8), (byte *)0x1f < pbVar35 + (-8 - (longlong)pbVar34)))
      goto LAB_1402226d8;
      thunk_FUN_1402500f0(pbVar34);
    }
    local_668 = local_6a8;
    uStack_658 = uStack_698;
    uStack_650 = uStack_690;
    lpPathName = local_668;
    if (0xf < uStack_690) {
      lpPathName = (LPCSTR)local_6a8._0_8_;
    }
    SetCurrentDirectoryA(lpPathName);
    if (0xf < uStack_650) {
      if ((0xfff < uStack_650 + 1) &&
         (0x1f < (local_668._0_8_ - *(longlong *)(local_668._0_8_ + -8)) - 8U)) {
LAB_1402226d8:
                    /* WARNING: Subroutine does not return */
        _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
      }
      thunk_FUN_1402500f0();
    }
  }
  FUN_14021cd80();
  FUN_140222e00();
  FUN_1402244b0();
  if (DAT_14032c939 == '\0') {
    local_6a8[4] = DAT_1402cf078;
    local_6a8._0_4_ = DAT_1402cf074;
    local_678 = 0;
    local_670 = 0xf;
    local_688._1_15_ = SUB1615((undefined1  [16])0x0,1);
    auVar4[0xf] = 0;
    auVar4._0_15_ = local_688._1_15_;
    local_688 = (tagRECT)(auVar4 << 8);
    uStack_698 = 5;
    uStack_690 = 0xf;
    local_6a8._6_10_ = SUB1610((undefined1  [16])0x0,6);
    local_6a8[5] = 0;
    uVar29 = FUN_1402246a0(local_6a8,&local_688);
    if (0xf < uStack_690) {
      if ((0xfff < uStack_690 + 1) &&
         (0x1f < (local_6a8._0_8_ - *(longlong *)(local_6a8._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
      thunk_FUN_1402500f0();
    }
    if (0xf < local_670) {
      if ((0xfff < local_670 + 1) &&
         (0x1f < (local_688._0_8_ - *(longlong *)(local_688._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
      thunk_FUN_1402500f0();
    }
    cVar15 = FUN_140224780(uVar29);
    if (cVar15 == '\0') {
      return 0xffffffff;
    }
  }
  local_6a8[4] = DAT_1402cf080;
  local_6a8._0_4_ = DAT_1402cf07c;
  local_678 = 0;
  local_670 = 0xf;
  local_688._1_15_ = SUB1615((undefined1  [16])0x0,1);
  auVar5[0xf] = 0;
  auVar5._0_15_ = local_688._1_15_;
  local_688 = (tagRECT)(auVar5 << 8);
  uStack_698 = 5;
  uStack_690 = 0xf;
  local_6a8._6_10_ = SUB1610((undefined1  [16])0x0,6);
  local_6a8[5] = 0;
  uVar29 = FUN_1402246a0(local_6a8,&local_688);
  if (0xf < uStack_690) {
    if ((0xfff < uStack_690 + 1) &&
       (0x1f < (local_6a8._0_8_ - *(longlong *)(local_6a8._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
    thunk_FUN_1402500f0();
  }
  if (0xf < local_670) {
    if ((0xfff < local_670 + 1) &&
       (0x1f < (local_688._0_8_ - *(longlong *)(local_688._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
    thunk_FUN_1402500f0();
  }
  local_6a8[4] = DAT_1402cf3d8;
  local_6a8._0_4_ = DAT_1402cf3d4;
  local_678 = 0;
  local_670 = 0xf;
  local_688._1_15_ = SUB1615((undefined1  [16])0x0,1);
  auVar6[0xf] = 0;
  auVar6._0_15_ = local_688._1_15_;
  local_688 = (tagRECT)(auVar6 << 8);
  uStack_698 = 5;
  uStack_690 = 0xf;
  local_6a8._6_10_ = SUB1610((undefined1  [16])0x0,6);
  local_6a8[5] = 0;
  uVar30 = FUN_1402246a0(local_6a8,&local_688);
  if (0xf < uStack_690) {
    if ((0xfff < uStack_690 + 1) &&
       (0x1f < (local_6a8._0_8_ - *(longlong *)(local_6a8._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
    thunk_FUN_1402500f0();
  }
  if (0xf < local_670) {
    if ((0xfff < local_670 + 1) &&
       (0x1f < (local_688._0_8_ - *(longlong *)(local_688._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
    thunk_FUN_1402500f0();
  }
  local_6a8[4] = DAT_1402cf3e0;
  local_6a8._0_4_ = DAT_1402cf3dc;
  local_678 = 0;
  local_670 = 0xf;
  local_688._1_15_ = SUB1615((undefined1  [16])0x0,1);
  auVar7[0xf] = 0;
  auVar7._0_15_ = local_688._1_15_;
  local_688 = (tagRECT)(auVar7 << 8);
  uStack_698 = 5;
  uStack_690 = 0xf;
  local_6a8._6_10_ = SUB1610((undefined1  [16])0x0,6);
  local_6a8[5] = 0;
  uVar31 = FUN_1402246a0(local_6a8,&local_688);
  if (0xf < uStack_690) {
    if ((0xfff < uStack_690 + 1) &&
       (0x1f < (local_6a8._0_8_ - *(longlong *)(local_6a8._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
    thunk_FUN_1402500f0();
  }
  if (0xf < local_670) {
    if ((0xfff < local_670 + 1) &&
       (0x1f < (local_688._0_8_ - *(longlong *)(local_688._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
    thunk_FUN_1402500f0();
  }
  if (DAT_14032c939 == '\0') {
    pcStack_640 = "ACE COMBAT THE BELKAN WAR";
    local_590._2_14_ = SUB1614((undefined1  [16])0x0,2);
    auVar8._14_2_ = 0;
    auVar8._0_14_ = local_590._2_14_;
    local_590 = auVar8 << 0x10;
    local_648 = "ACE COMBAT ZERO THE BELKAN WAR";
    auStack_638 = (undefined1  [16])0x0;
    local_628 = (undefined1  [16])0x0;
    uStack_618 = 0;
    uStack_610 = 0;
    auStack_608 = ZEXT816(0);
    local_5f8 = 0;
    uStack_5f0 = 0;
    uStack_5e8 = 0;
    uStack_5e0 = 0;
    local_5d8 = (undefined1  [16])0x0;
    local_5b0 = 0;
    local_580 = 0;
    local_578 = 7;
    local_570 = 0;
    cVar15 = FUN_14022cf00(&local_648);
    if (7 < local_578) {
      if ((0xfff < local_578 * 2 + 2) &&
         (0x1f < (local_590._0_8_ - *(longlong *)(local_590._0_8_ + -8)) - 8U)) goto LAB_1402226ed;
      thunk_FUN_1402500f0();
    }
    local_580 = 0;
    local_578 = 7;
    auVar9._14_2_ = 0;
    auVar9._0_14_ = local_590._2_14_;
    local_590 = auVar9 << 0x10;
    if (auStack_638._0_8_ != 0) {
      if ((0xfff < (local_628._0_8_ - auStack_638._0_8_ & 0xfffffffffffffffc)) &&
         (0x1f < (auStack_638._0_8_ - *(longlong *)(auStack_638._0_8_ + -8)) - 8U)) {
LAB_1402226ed:
                    /* WARNING: Subroutine does not return */
        _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
      }
      thunk_FUN_1402500f0();
    }
    if (cVar15 == '\0') {
      FUN_140224780(uVar29);
      FUN_140224780(uVar30);
      FUN_140224780(uVar31);
      FUN_140224670();
      SteamAPI_Shutdown();
      return 0;
    }
  }
  if (DAT_1437dfcf0 == '\0') {
    DAT_1437dfcf0 = '\x01';
  }
  cVar15 = FUN_140224780(uVar29);
  cVar16 = FUN_140224780(uVar30);
  cVar17 = FUN_140224780(uVar31);
  local_6a8._1_15_ = SUB1615((undefined1  [16])0x0,1);
  auVar10[0xf] = 0;
  auVar10._0_15_ = local_6a8._1_15_;
  local_6a8 = auVar10 << 8;
  uStack_698 = 0;
  uStack_690 = 0xf;
  uVar22 = FUN_140223440();
  auVar4 = local_6a8;
  switch(uVar22) {
  case 1:
    local_6a8[8] = DAT_1402cf3f0;
    local_6a8._0_8_ = DAT_1402cf3e8;
    break;
  case 2:
    local_6a8[8] = DAT_1402cf400;
    local_6a8._0_8_ = DAT_1402cf3f8;
    break;
  case 3:
    local_6a8[8] = DAT_1402cf3a0;
    local_6a8._0_8_ = DAT_1402cf398;
    break;
  case 4:
    local_6a8[8] = DAT_1402cf3b0;
    local_6a8._0_8_ = DAT_1402cf3a8;
    break;
  case 5:
    local_6a8[8] = DAT_1402cf3c0;
    local_6a8._0_8_ = DAT_1402cf3b8;
    break;
  case 6:
    local_6a8[8] = DAT_1402cf3d0;
    local_6a8._0_8_ = DAT_1402cf3c8;
    break;
  case 7:
    local_6a8[8] = DAT_1402cf448;
    local_6a8._0_8_ = DAT_1402cf440;
    break;
  default:
    goto switchD_1402220e2_default;
  }
  uStack_698 = 9;
  local_6a8._10_6_ = auVar4._10_6_;
  local_6a8[9] = 0;
switchD_1402220e2_default:
  local_688.top._0_1_ = DAT_1402cf450;
  local_688.left = DAT_1402cf44c;
  local_678 = 5;
  local_670 = 0xf;
  local_688._6_10_ = SUB1610((undefined1  [16])0x0,6);
  local_688.top._1_1_ = 0;
  uVar29 = FUN_1402246a0(&local_688,local_6a8);
  if (0xf < local_670) {
    if ((0xfff < local_670 + 1) &&
       (0x1f < (local_688._0_8_ - *(longlong *)(local_688._0_8_ + -8)) - 8U)) goto LAB_1402226c3;
    thunk_FUN_1402500f0();
  }
  cVar18 = FUN_140224780(uVar29);
  if (DAT_1403589f8 != (undefined8 *)0x0) {
    (**(code **)*DAT_1403589f8)(DAT_1403589f8,1);
  }
  DAT_1403589f8 = (undefined8 *)0x0;
  if ((((cVar15 == '\0') || (cVar16 == '\0')) || (cVar17 == '\0')) || (cVar18 == '\0')) {
    SteamAPI_Shutdown();
    if (0xf < uStack_690) {
      if ((0xfff < uStack_690 + 1) &&
         (0x1f < (local_6a8._0_8_ - *(longlong *)(local_6a8._0_8_ + -8)) - 8U)) {
LAB_1402226c3:
                    /* WARNING: Subroutine does not return */
        _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
      }
      thunk_FUN_1402500f0();
    }
  }
  else {
    if (0xf < uStack_690) {
      FUN_14006abd0(local_6a8,local_6a8._0_8_);
    }
    SetProcessDpiAwarenessContext(0xfffffffffffffffd);
    LVar13 = DAT_14030f278;
    uVar22 = DAT_14030f274;
    DVar21 = 0xcb0000;
    if (DAT_14032c938 != '\0') {
      DVar21 = 0x80000000;
    }
    DAT_14032c936 = DAT_14032c938;
    local_728.style = 3;
    local_728.cbSize = 0x50;
    iVar20 = 1;
    if (DAT_14032c938 != '\0') {
      iVar20 = 3;
    }
    local_728.lpfnWndProc = FUN_140222940;
    auVar11._8_8_ = 0;
    auVar11._0_8_ = DAT_1403589f0;
    local_728._16_16_ = auVar11 << 0x40;
    local_728.hIcon = (HICON)0x0;
    local_728.hCursor = (HCURSOR)0x0;
    local_728.hbrBackground = (HBRUSH)0x0;
    local_728.lpszMenuName = (LPCSTR)0x0;
    local_728.lpszClassName = (LPCSTR)0x0;
    local_728.hIconSm = (HICON)0x0;
    pHVar32 = LoadIconA(DAT_1403589f0,(LPCSTR)0x65);
    local_728.hIcon = pHVar32;
    local_728.hIconSm = LoadIconA(local_728.hInstance,(LPCSTR)0x65);
    local_728.lpszClassName = "XgACZWindow";
    pHVar33 = CreateSolidBrush(4);
    local_728.hbrBackground = pHVar33;
    AVar19 = RegisterClassExA(&local_728);
    if (AVar19 != 0) {
      auVar12._8_4_ = 0;
      auVar12._0_4_ = uVar22;
      auVar12._4_4_ = local_688.bottom;
      local_688._0_12_ = auVar12 << 0x40;
      local_688.bottom = LVar13;
      AdjustWindowRect(&local_688,DVar21,0);
      SystemParametersInfoA(0x30,0,local_6a8,0);
      nWidth = local_688.right - local_688.left;
      nHeight = local_688.bottom - local_688.top;
      iVar23 = ((local_6a8._8_4_ - nWidth) - local_6a8._0_4_) / 2;
      iVar24 = ((local_6a8._12_4_ - nHeight) - local_6a8._4_4_) / 2;
      iVar25 = FUN_140223440();
      Y = 0;
      if (0 < iVar24) {
        Y = iVar24;
      }
      lpWindowName = "ACE COMBAT ZERO THE BELKAN WAR";
      iVar24 = 0;
      if (0 < iVar23) {
        iVar24 = iVar23;
      }
      if (2 < iVar25) {
        lpWindowName = "ACE COMBAT THE BELKAN WAR";
      }
      DAT_1403589e8 =
           CreateWindowExA(0,"XgACZWindow",lpWindowName,DVar21,iVar24,Y,nWidth,nHeight,(HWND)0x0,
                           (HMENU)0x0,DAT_1403589f0,(LPVOID)0x0);
      if (DAT_1403589e8 != (HWND)0x0) {
        ShowWindow(DAT_1403589e8,iVar20);
        SetWindowPos(DAT_1403589e8,(HWND)0x1,0,0,0,0,0x23);
        SendMessageA(DAT_1403589e8,0x201,1,0);
        PostMessageA(DAT_1403589e8,0x201,1,0);
        puVar26 = operator_new(0x130);
        DAT_1403589d8 = puVar26;
        puVar26[1] = 0;
        puVar26[2] = 0;
        puVar26[3] = 0;
        *puVar26 = 0;
        puVar26[4] = 0;
        puVar26[5] = 0;
        puVar26[6] = 0;
        puVar26[7] = 0;
        puVar26[8] = 0;
        puVar26[9] = 0;
        puVar26[10] = 0;
        puVar26[0xb] = 0;
        puVar26[0xc] = 0;
        puVar26[0xd] = 0;
        *(undefined1 (*) [16])(puVar26 + 0xe) = (undefined1  [16])0x0;
        puVar26[0x10] = 0;
        puVar26[0x11] = &PTR_FUN_1402cf828;
        puVar26[0x12] = 0;
        puVar26[0x13] = 0;
        puVar26[0x14] = 0;
        *(undefined4 *)(puVar26 + 0x15) = 0;
        *(undefined1 (*) [16])((longlong)puVar26 + 0xac) = (undefined1  [16])0x0;
        *(undefined8 *)((longlong)puVar26 + 0xbc) = 0;
        *(undefined1 (*) [16])((longlong)puVar26 + 0xc4) = (undefined1  [16])0x0;
        *(undefined1 *)((longlong)puVar26 + 0xe4) = 0;
        pHVar14 = DAT_1403589e8;
        puVar26[0x1d] = 0x18;
        *(undefined4 *)(puVar26 + 0x1e) = 2;
        *(undefined1 (*) [16])((longlong)puVar26 + 0xf4) = (undefined1  [16])0x0;
        puVar26[0x21] = pHVar14;
        *(LONG *)((longlong)puVar26 + 0x11c) = LVar13;
        *(undefined4 *)(puVar26 + 0x24) = 0;
        puVar26[0x25] = 0;
        puVar26[0x22] = 0;
        *(undefined4 *)(puVar26 + 0x23) = uVar22;
        FUN_140225ff0();
        FUN_1402256f0(puVar26);
        FUN_140225bc0(DAT_1403589d8);
        DAT_1403589e0 = FUN_140218870(FUN_140221750,param_1[2],0);
        FUN_14021dee0(DAT_1403589e8);
        FUN_14021e040();
        local_6d8.hwnd = (HWND)0x0;
        local_6d8.message = 0;
        local_6d8._12_4_ = 0;
        local_6d8.wParam = 0;
        local_6d8.lParam = 0;
        local_6d8.time = 0;
        local_6d8.pt.x = 0;
        local_6d8.pt.y = 0;
        local_6d8._44_4_ = 0;
        iVar20 = GetMessageA(&local_6d8,(HWND)0x0,0,0);
        while (iVar20 != 0) {
          if (iVar20 != -1) {
            TranslateMessage(&local_6d8);
            DispatchMessageA(&local_6d8);
          }
          iVar20 = GetMessageA(&local_6d8,(HWND)0x0,0,0);
        }
        SteamAPI_Shutdown();
        return local_6d8.wParam & 0xffffffff;
      }
    }
    SteamAPI_Shutdown();
  }
  return 0xffffffff;
}

