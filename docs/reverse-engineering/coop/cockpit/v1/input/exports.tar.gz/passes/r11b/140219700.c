/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140219700; RVA 0x219700
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Removing unreachable block (ram,0x000140219985) */
/* WARNING: Removing unreachable block (ram,0x000140219988) */
/* WARNING: Removing unreachable block (ram,0x0001402199b0) */
/* WARNING: Removing unreachable block (ram,0x0001402199bc) */
/* WARNING: Removing unreachable block (ram,0x0001402199c7) */
/* WARNING: Removing unreachable block (ram,0x000140219a4f) */
/* WARNING: Removing unreachable block (ram,0x000140219a5b) */
/* WARNING: Removing unreachable block (ram,0x000140219a74) */
/* WARNING: Removing unreachable block (ram,0x000140219a91) */
/* WARNING: Removing unreachable block (ram,0x000140219aaa) */
/* WARNING: Removing unreachable block (ram,0x000140219aae) */
/* WARNING: Removing unreachable block (ram,0x000140219ac3) */
/* WARNING: Removing unreachable block (ram,0x000140219ae4) */
/* WARNING: Removing unreachable block (ram,0x000140219adc) */
/* WARNING: Removing unreachable block (ram,0x000140219ae8) */
/* WARNING: Removing unreachable block (ram,0x000140219b0a) */
/* WARNING: Removing unreachable block (ram,0x000140219b0d) */
/* WARNING: Removing unreachable block (ram,0x000140219b1d) */
/* WARNING: Removing unreachable block (ram,0x000140219b15) */
/* WARNING: Removing unreachable block (ram,0x000140219b25) */
/* WARNING: Removing unreachable block (ram,0x000140219b2e) */
/* WARNING: Removing unreachable block (ram,0x000140219b42) */
/* WARNING: Removing unreachable block (ram,0x000140219b48) */
/* WARNING: Removing unreachable block (ram,0x000140219cb6) */
/* WARNING: Removing unreachable block (ram,0x000140219b5f) */
/* WARNING: Removing unreachable block (ram,0x000140219b9a) */
/* WARNING: Removing unreachable block (ram,0x000140219b9c) */
/* WARNING: Removing unreachable block (ram,0x000140219bc2) */
/* WARNING: Removing unreachable block (ram,0x000140219c51) */
/* WARNING: Removing unreachable block (ram,0x0001402198fd) */
/* WARNING: Removing unreachable block (ram,0x000140219864) */
/* WARNING: Removing unreachable block (ram,0x0001402198b2) */
/* WARNING: Removing unreachable block (ram,0x0001402198e4) */
/* WARNING: Removing unreachable block (ram,0x00014021990a) */
/* WARNING: Removing unreachable block (ram,0x00014021992a) */
/* WARNING: Removing unreachable block (ram,0x000140219c10) */
/* WARNING: Removing unreachable block (ram,0x000140219938) */
/* WARNING: Removing unreachable block (ram,0x000140219979) */
/* WARNING: Removing unreachable block (ram,0x000140219c03) */
/* WARNING: Removing unreachable block (ram,0x000140219c66) */

void FUN_140219700(void)

{
  longlong *plVar1;
  HRESULT HVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  undefined1 auStackY_1b8 [32];
  longlong *local_148;
  undefined1 local_140 [16];
  undefined8 local_130;
  undefined1 local_128 [16];
  undefined8 local_118;
  undefined8 local_108;
  undefined8 local_100;
  ulonglong local_38;
  
  local_38 = DAT_140309040 ^ (ulonglong)auStackY_1b8;
  local_148 = (longlong *)0x0;
  lVar4 = 0;
  lVar5 = 0;
  local_140 = (undefined1  [16])0x0;
  local_130 = 0;
  Ordinal_8(local_140);
  Ordinal_2(L"Name");
  local_108 = Ordinal_2(L"Caption");
  local_100 = Ordinal_2(L"Descriptrion");
  local_118 = 0;
  local_128 = (undefined1  [16])0x0;
  Ordinal_8(local_128);
  lVar3 = Ordinal_2(L"\\\\.\\root\\cimv2");
  if (((lVar3 != 0) && (lVar4 = Ordinal_2(L"Win32_PNPEntity"), lVar4 != 0)) &&
     (lVar5 = Ordinal_2(L"DeviceID"), plVar1 = local_148, lVar5 != 0)) {
    if (local_148 != (longlong *)0x0) {
      local_148 = (longlong *)0x0;
      (**(code **)(*plVar1 + 0x10))();
    }
    HVar2 = CoCreateInstance((IID *)&DAT_1402cef88,(LPUNKNOWN)0x0,1,(IID *)&DAT_1402cef98,&local_148
                            );
    if ((-1 < HVar2) && (local_148 != (longlong *)0x0)) {
      (**(code **)(*local_148 + 0x18))(local_148,lVar3,0,0);
    }
  }
  Ordinal_9(local_140);
  if (lVar3 != 0) {
    Ordinal_6(lVar3);
  }
  if (lVar4 != 0) {
    Ordinal_6(lVar4);
  }
  if (lVar5 != 0) {
    Ordinal_6(lVar5);
  }
  plVar1 = local_148;
  if (local_148 != (longlong *)0x0) {
    local_148 = (longlong *)0x0;
    (**(code **)(*plVar1 + 0x10))();
  }
  return;
}

