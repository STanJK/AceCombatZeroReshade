/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021b300; RVA 0x21b300
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14021b300(char *param_1)

{
  char cVar1;
  undefined4 *puVar2;
  uint *puVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  longlong *plVar6;
  longlong *plVar7;
  int iVar8;
  int iVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  void *pvVar13;
  char *_Str1;
  undefined8 uVar14;
  char *pcVar15;
  uint uVar16;
  longlong lVar17;
  undefined1 *puVar18;
  longlong lVar19;
  undefined **ppuVar20;
  uint uVar21;
  bool bVar22;
  bool bVar23;
  undefined1 auStackY_348 [32];
  uint local_308;
  uint local_304;
  int local_300;
  uint local_2fc;
  int local_2f8 [4];
  undefined8 local_2e8;
  uint uStack_2e0;
  uint uStack_2dc;
  uint uStack_2d8;
  uint local_2c8;
  uint local_2c4;
  uint local_2c0 [2];
  undefined1 local_2b8 [16];
  undefined8 local_2a8;
  ulonglong uStack_2a0;
  undefined1 local_298 [576];
  undefined1 local_58 [16];
  undefined1 local_48;
  ulonglong local_38;
  
  local_38 = DAT_140309040 ^ (ulonglong)auStackY_348;
  if (*param_1 == '[') {
    param_1 = param_1 + 1;
    iVar8 = FUN_1402211c0(param_1,&DAT_1402cec74,&local_2c8);
    plVar7 = DAT_14033b1a0;
    local_2c8 = local_2c8 >> 0x10 | local_2c8 << 0x10;
    if (iVar8 == 1) {
      uStack_2e0 = 0;
      plVar10 = (longlong *)DAT_14033b1a0[1];
      cVar1 = *(char *)((longlong)plVar10 + 0x19);
      local_2e8 = plVar10;
      plVar12 = DAT_14033b1a0;
      while (plVar6 = plVar10, cVar1 == '\0') {
        if (local_2c8 <= *(uint *)(plVar6 + 4)) {
          plVar10 = plVar6;
          plVar12 = plVar6;
        }
        else {
          plVar10 = plVar6 + 2;
        }
        uStack_2e0 = (uint)(local_2c8 <= *(uint *)(plVar6 + 4));
        cVar1 = *(char *)(*plVar10 + 0x19);
        plVar10 = (longlong *)*plVar10;
        local_2e8 = plVar6;
      }
      if ((*(char *)((longlong)plVar12 + 0x19) != '\0') || (local_2c8 < *(uint *)(plVar12 + 4))) {
        if (DAT_14033b1a8 == 0x61861861861861) {
                    /* WARNING: Subroutine does not return */
          FUN_140183020();
        }
        puVar11 = operator_new(0x2a0);
        *(uint *)(puVar11 + 4) = local_2c8;
        FUN_1402777e0(puVar11 + 5,0,0x278);
        FUN_140220e80(puVar11 + 5);
        *puVar11 = plVar7;
        puVar11[1] = plVar7;
        puVar11[2] = plVar7;
        *(undefined2 *)(puVar11 + 3) = 0;
        plVar12 = (longlong *)FUN_140185940(&DAT_14033b1a0,&local_2e8,puVar11);
      }
      DAT_1437dfd18 = plVar12 + 5;
      if (DAT_1437dfd18 != (longlong *)0x0) {
        DAT_1437dfd20 = 0;
        return;
      }
    }
    else {
      DAT_1437dfd18 = (longlong *)0x0;
    }
    DAT_1437dfd20 = 0;
    iVar8 = strncmp(param_1,"KeyboardUI",10);
    if (iVar8 != 0) {
      iVar8 = strncmp(param_1,"KeyboardFlight",0xe);
      if (iVar8 == 0) {
        local_2b8._2_14_ = SUB1614((undefined1  [16])0x0,2);
        auVar5._14_2_ = 0;
        auVar5._0_14_ = local_2b8._2_14_;
        local_2b8 = auVar5 << 0x10;
        local_2a8 = _DAT_1402d2fd0;
        uStack_2a0 = _UNK_1402d2fd8;
        FUN_14021eb30(local_298);
        local_58 = (undefined1  [16])0x0;
        pvVar13 = operator_new(0x40);
        *(void **)pvVar13 = pvVar13;
        *(void **)((longlong)pvVar13 + 8) = pvVar13;
        *(void **)((longlong)pvVar13 + 0x10) = pvVar13;
        *(undefined2 *)((longlong)pvVar13 + 0x18) = 0x101;
        local_58._0_8_ = pvVar13;
        local_48 = 0;
        FUN_14021bd00(&DAT_14033b6c0,local_2b8);
        FUN_140219df0(local_2b8);
        DAT_1437dfd18 = (longlong *)&DAT_14033b6c0;
        DAT_1437dfd20 = 1;
        return;
      }
      return;
    }
    local_2b8._2_14_ = SUB1614((undefined1  [16])0x0,2);
    auVar4._14_2_ = 0;
    auVar4._0_14_ = local_2b8._2_14_;
    local_2b8 = auVar4 << 0x10;
    local_2a8 = _DAT_1402d2fd0;
    uStack_2a0 = _UNK_1402d2fd8;
    FUN_14021eb30(local_298);
    local_58 = (undefined1  [16])0x0;
    pvVar13 = operator_new(0x40);
    *(void **)pvVar13 = pvVar13;
    *(void **)((longlong)pvVar13 + 8) = pvVar13;
    *(void **)((longlong)pvVar13 + 0x10) = pvVar13;
    *(undefined2 *)((longlong)pvVar13 + 0x18) = 0x101;
    local_58._0_8_ = pvVar13;
    local_48 = 0;
    FUN_14021bd00(&DAT_14033b440,local_2b8);
    FUN_1402201f0(local_58,local_58);
    thunk_FUN_1402500f0(local_58._0_8_,0x40);
    lVar17 = 0x18;
    puVar18 = local_58;
    do {
      puVar18 = puVar18 + -0x18;
      FUN_14021f960(puVar18);
      lVar17 = lVar17 + -1;
    } while (lVar17 != 0);
    if (7 < uStack_2a0) {
      if ((0xfff < uStack_2a0 * 2 + 2) &&
         (0x1f < (local_2b8._0_8_ - *(longlong *)(local_2b8._0_8_ + -8)) - 8U)) {
                    /* WARNING: Subroutine does not return */
        _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
      }
      thunk_FUN_1402500f0();
    }
    DAT_1437dfd18 = (longlong *)&DAT_14033b440;
    DAT_1437dfd20 = 1;
    return;
  }
  if (DAT_1437dfd18 == (longlong *)0x0) {
    return;
  }
  _Str1 = (char *)FUN_140238b2c(param_1,0x3d);
  if (_Str1 == (char *)0x0) {
    return;
  }
  lVar17 = 4;
  iVar8 = strncmp(param_1,"Name",4);
  if (iVar8 == 0) {
    for (param_1 = param_1 + 4; param_1 < _Str1; param_1 = param_1 + 1) {
      if ((*param_1 != ' ') && (*param_1 != '\t')) {
        return;
      }
    }
    do {
      do {
        _Str1 = _Str1 + 1;
      } while (*_Str1 == ' ');
    } while (*_Str1 == '\t');
    lVar19 = -1;
    lVar17 = -1;
    do {
      lVar17 = lVar17 + 1;
    } while (_Str1[lVar17] != '\0');
    iVar8 = (int)lVar17 + -1;
    if (-1 < iVar8) {
      pcVar15 = _Str1 + iVar8;
      do {
        if ((*pcVar15 != ' ') && (*pcVar15 != '\t')) break;
        *pcVar15 = '\0';
        pcVar15 = pcVar15 + -1;
      } while (-1 < (longlong)pcVar15 - (longlong)_Str1);
    }
    lVar17 = -1;
    do {
      lVar17 = lVar17 + 1;
    } while (_Str1[lVar17] != '\0');
    iVar8 = MultiByteToWideChar(0xfde9,0,_Str1,(int)lVar17,(LPWSTR)local_2b8,0x100);
    if (iVar8 < 1) {
      return;
    }
    if (0x1ff < (ulonglong)((longlong)iVar8 * 2)) {
                    /* WARNING: Subroutine does not return */
      FUN_14022d904();
    }
    *(undefined2 *)(local_2b8 + (longlong)iVar8 * 2) = 0;
    do {
      lVar19 = lVar19 + 1;
    } while (*(short *)(local_2b8 + lVar19 * 2) != 0);
    FUN_14021f2c0(DAT_1437dfd18,local_2b8,lVar19);
    return;
  }
  iVar8 = strncmp(param_1,"FFB",3);
  if (iVar8 != 0) {
    iVar8 = strncmp(param_1,"SpecialMode",0xb);
    if (iVar8 == 0) {
      for (param_1 = param_1 + 0xc; param_1 < _Str1; param_1 = param_1 + 1) {
        if ((*param_1 != ' ') && (*param_1 != '\t')) {
          return;
        }
      }
      do {
        do {
          _Str1 = _Str1 + 1;
        } while (*_Str1 == ' ');
      } while (*_Str1 == '\t');
      iVar8 = strncmp(_Str1,"TM",2);
      if (iVar8 == 0) {
        *(undefined1 *)((longlong)DAT_1437dfd18 + 0x270) = 1;
        return;
      }
      return;
    }
    uVar21 = 0;
    ppuVar20 = &PTR_DAT_1402aa000;
    while (iVar8 = strncmp(param_1,*ppuVar20,(longlong)*(int *)(ppuVar20 + 1)), iVar8 != 0) {
      uVar21 = uVar21 + 1;
      ppuVar20 = ppuVar20 + 4;
      if (0x17 < uVar21) {
        return;
      }
    }
    lVar17 = (longlong)(int)uVar21;
    for (param_1 = param_1 + (int)(&DAT_1402aa008)[lVar17 * 8]; param_1 < _Str1;
        param_1 = param_1 + 1) {
      if ((*param_1 != ' ') && (*param_1 != '\t')) {
        return;
      }
    }
    do {
      do {
        pcVar15 = _Str1;
        _Str1 = pcVar15 + 1;
      } while (*_Str1 == ' ');
    } while (*_Str1 == '\t');
    uVar21 = 0;
    lVar19 = FUN_140238b2c(_Str1,0x2b);
    if (lVar19 != 0) {
      cVar1 = *_Str1;
      if (cVar1 == '!') {
        _Str1 = pcVar15 + 2;
      }
      local_308 = 0;
      if (DAT_1437dfd20 == '\0') {
        FUN_14021aea0(_Str1,&local_308,0);
        bVar22 = local_308 - 1 < 0x2f;
        bVar23 = local_308 - 1 == 0x2f;
      }
      else {
        for (; (*_Str1 == ' ' || (*_Str1 == '\t')); _Str1 = _Str1 + 1) {
        }
        iVar8 = FUN_1402211c0(_Str1,"0x%x%n",&local_308,&local_304);
        if (iVar8 != 1) {
          return;
        }
        bVar22 = local_308 - 1 < 0xfe;
        bVar23 = local_308 - 1 == 0xfe;
      }
      if (!bVar22 && !bVar23) {
        return;
      }
      _Str1 = (char *)(lVar19 + 1);
      iVar8 = -1;
      if (cVar1 != '!') {
        iVar8 = 1;
      }
      uVar21 = iVar8 * local_308;
    }
    if (DAT_1437dfd20 == '\0') {
      uVar14 = FUN_14021aea0(_Str1,&local_308,&local_304);
    }
    else {
      uVar14 = FUN_14021b000();
    }
    uVar16 = local_308;
    if (local_308 == 0) {
      return;
    }
    local_2c4 = 0;
    local_2c0[0] = 0;
    iVar8 = FUN_1402211c0(uVar14," : %d : %d ",&local_2c4,local_2c0);
    if (0xffff < local_2c4) {
      return;
    }
    if (0xffff < local_2c0[0]) {
      return;
    }
    if (local_304 == 2) {
      if (iVar8 != 2) {
        return;
      }
    }
    else {
      if (iVar8 == 2) {
        return;
      }
      if ((local_304 != 2) && (local_2c4 == 0)) {
        local_2c4 = 0xffff;
      }
    }
    if ((DAT_1437dfd20 != '\0') && (local_304 == 3)) {
      local_2c0[0] = uVar16;
      uVar16 = 0;
    }
    puVar3 = *(uint **)((longlong)DAT_1437dfd18 + (lVar17 * 3 + 5) * 8);
    lVar17 = (longlong)DAT_1437dfd18 + (lVar17 * 3 + 4) * 8;
    local_2e8 = (longlong *)CONCAT44(local_304,uVar16);
    if (puVar3 == *(uint **)(lVar17 + 0x10)) {
      uStack_2e0 = local_2c4;
      uStack_2dc = local_2c0[0];
      uStack_2d8 = uVar21;
      FUN_140220260(lVar17,puVar3,&local_2e8);
      return;
    }
    *puVar3 = uVar16;
    puVar3[1] = local_304;
    puVar3[2] = local_2c4;
    puVar3[3] = local_2c0[0];
    puVar3[4] = uVar21;
    *(longlong *)(lVar17 + 8) = *(longlong *)(lVar17 + 8) + 0x14;
    return;
  }
  for (param_1 = param_1 + 4; param_1 < _Str1; param_1 = param_1 + 1) {
    if ((*param_1 != ' ') && (*param_1 != '\t')) {
      return;
    }
  }
  do {
    do {
      _Str1 = _Str1 + 1;
    } while (*_Str1 == ' ');
  } while (*_Str1 == '\t');
  iVar8 = strncmp(_Str1,"Sine",4);
  if (iVar8 == 0) {
    iVar8 = 0;
  }
  else {
    lVar17 = 5;
    iVar8 = strncmp(_Str1,"Const",5);
    if (iVar8 == 0) {
      iVar8 = 1;
    }
    else {
      lVar17 = 6;
      iVar8 = strncmp(_Str1,"Spring",6);
      if (iVar8 != 0) {
        return;
      }
      iVar8 = 2;
    }
  }
  local_2fc = 0;
  local_2f8[0] = 0;
  local_300 = 0;
  local_304 = 0;
  local_308 = 0;
  iVar9 = FUN_1402211c0(_Str1 + lVar17," : %d : %d : %d : %d : %d",&local_2fc,local_2f8);
  if (iVar8 == 0) {
    bVar22 = iVar9 == 3;
  }
  else if (iVar8 == 1) {
    bVar22 = iVar9 == 2;
  }
  else {
    if (iVar8 != 2) goto LAB_14021b888;
    bVar22 = iVar9 == 5;
  }
  if (!bVar22) {
    return;
  }
LAB_14021b888:
  if ((((-1 < (int)local_2fc) && (local_2fc < 0x1d)) && ((local_2fc & 3) == 0)) &&
     (local_2f8[0] - 1U < 10000)) {
    if (iVar8 == 0) {
      if (4999 < local_300 - 1U) {
        return;
      }
    }
    else if ((iVar8 == 2) && (20000 < local_300 + 10000U)) {
      return;
    }
    if ((local_304 + 10000 < 0x4e21) && (local_308 < 0x2711)) {
      lVar17 = FUN_14021f100((longlong)DAT_1437dfd18 + 0x260,&local_2fc);
      if (iVar8 == 2) {
        puVar2 = *(undefined4 **)(lVar17 + 8);
        local_2e8 = (longlong *)CONCAT44(local_2f8[0],2);
        uStack_2e0 = local_300;
        uStack_2dc = local_304;
        uStack_2d8 = local_308;
        if (puVar2 == *(undefined4 **)(lVar17 + 0x10)) {
          FUN_140220260(lVar17,puVar2,&local_2e8);
        }
        else {
          *puVar2 = 2;
          puVar2[1] = local_2f8[0];
          puVar2[2] = local_300;
          puVar2[3] = local_304;
          puVar2[4] = local_308;
          *(longlong *)(lVar17 + 8) = *(longlong *)(lVar17 + 8) + 0x14;
        }
      }
      else {
        uStack_2e0 = local_300 * 1000;
        local_2e8 = (longlong *)CONCAT44(local_2f8[0],iVar8);
        uStack_2dc = 0;
        uStack_2d8 = 0;
        puVar11 = *(undefined8 **)(lVar17 + 8);
        if (puVar11 == *(undefined8 **)(lVar17 + 0x10)) {
          FUN_140220260(lVar17,puVar11,&local_2e8);
        }
        else {
          *puVar11 = local_2e8;
          puVar11[1] = (ulonglong)uStack_2e0;
          *(undefined4 *)(puVar11 + 2) = 0;
          *(longlong *)(lVar17 + 8) = *(longlong *)(lVar17 + 8) + 0x14;
        }
      }
    }
  }
  return;
}

