/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021a480; RVA 0x21a480
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_14021a480(byte *param_1,longlong param_2,longlong *param_3,undefined8 *param_4,
             undefined8 *param_5)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  undefined8 *puVar4;
  int *piVar5;
  undefined1 auVar6 [32];
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  short sVar14;
  int *piVar15;
  int iVar16;
  uint *puVar17;
  int *piVar18;
  uint uVar19;
  bool bVar20;
  byte bVar21;
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  float fVar24;
  undefined1 auVar25 [16];
  undefined8 unaff_XMM6_Qa;
  undefined8 unaff_XMM6_Qb;
  undefined8 unaff_XMM7_Qa;
  undefined8 unaff_XMM7_Qb;
  undefined8 unaff_XMM8_Qa;
  undefined8 unaff_XMM8_Qb;
  undefined8 unaff_XMM9_Qa;
  undefined8 unaff_XMM9_Qb;
  int aiStack_2cc [11];
  undefined8 uStack_2a0;
  undefined1 auStack_298 [32];
  uint local_278 [4];
  undefined8 local_268;
  undefined8 uStack_260;
  undefined8 uStack_258;
  undefined8 uStack_250;
  undefined8 local_248;
  undefined8 uStack_240;
  undefined8 uStack_238;
  undefined8 uStack_230;
  undefined1 local_228 [16];
  undefined1 local_218 [16];
  undefined1 local_208 [32];
  int local_1e8;
  int local_1e4;
  int local_1e0;
  undefined4 local_1dc;
  char local_1b8;
  char local_1b7;
  char local_1b6;
  char local_1b5;
  char local_1b4;
  char local_1b3;
  char local_1b2;
  char local_1b1;
  undefined1 local_f8 [32];
  undefined1 local_d8 [20];
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined1 local_b8 [32];
  ulonglong local_98;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  
  local_98 = DAT_140309040 ^ (ulonglong)auStack_298;
  if ((longlong *)*param_3 != (longlong *)0x0) {
    uStack_2a0 = 0x14021a4d3;
    (**(code **)(*(longlong *)*param_3 + 200))();
    uStack_2a0 = 0x14021a4e5;
    iVar8 = (**(code **)(*(longlong *)*param_3 + 0x48))((longlong *)*param_3,0x110,local_208);
    if (-1 < iVar8) {
LAB_14021a546:
      local_58 = unaff_XMM6_Qa;
      uStack_50 = unaff_XMM6_Qb;
      plVar11 = (longlong *)DAT_14033b1a0[1];
      local_68 = unaff_XMM7_Qa;
      uStack_60 = unaff_XMM7_Qb;
      local_78 = unaff_XMM8_Qa;
      uStack_70 = unaff_XMM8_Qb;
      local_88 = unaff_XMM9_Qa;
      uStack_80 = unaff_XMM9_Qb;
      cVar1 = *(char *)((longlong)plVar11 + 0x19);
      plVar12 = DAT_14033b1a0;
      while (cVar1 == '\0') {
        if (*(uint *)(plVar11 + 4) < *(uint *)(param_2 + 4)) {
          plVar11 = plVar11 + 2;
        }
        else {
          plVar12 = plVar11;
        }
        plVar11 = (longlong *)*plVar11;
        cVar1 = *(char *)((longlong)plVar11 + 0x19);
      }
      if ((*(char *)((longlong)plVar12 + 0x19) != '\0') ||
         (*(uint *)(param_2 + 4) < *(uint *)(plVar12 + 4))) {
        plVar12 = DAT_14033b1a0;
      }
      if (plVar12 == DAT_14033b1a0) {
        local_278[0] = 0;
        uStack_2a0 = 0x14021a5cc;
        plVar12 = (longlong *)FUN_14021ef40(plVar12,local_278);
      }
      else {
        plVar12 = plVar12 + 5;
      }
      local_218 = (undefined1  [16])0x0;
      if (local_1e8 != -1) {
        local_218[1] = local_1e8 - 0x8cbU < 0x34bb;
        local_218[0] = local_1e8 - 0x4f1bU < 0x34bb;
        local_218[2] = 0x57e4 < local_1e8 - 0x1a5eU;
        local_218._4_12_ = SUB1612((undefined1  [16])0x0,4);
        local_218[3] = local_1e8 - 0x2bf3U < 0x34bb;
      }
      auVar22 = local_218;
      if (local_1e4 != -1) {
        local_218[4] = local_1e4 - 0x4f1bU < 0x34bb;
        local_218[5] = local_1e4 - 0x8cbU < 0x34bb;
        local_218[6] = 0x57e4 < local_1e4 - 0x1a5eU;
        local_218._8_8_ = auVar22._8_8_;
        local_218[7] = local_1e4 - 0x2bf3U < 0x34bb;
      }
      auVar22 = local_218;
      if (local_1e0 != -1) {
        local_218[8] = local_1e0 - 0x4f1bU < 0x34bb;
        local_218[9] = local_1e0 - 0x8cbU < 0x34bb;
        local_218[10] = 0x57e4 < local_1e0 - 0x1a5eU;
        local_218._12_4_ = auVar22._12_4_;
        local_218[0xb] = local_1e0 - 0x2bf3U < 0x34bb;
      }
      if (local_1dc != -1) {
        local_218[0xc] = local_1dc - 0x4f1bU < 0x34bb;
        local_218[0xd] = local_1dc - 0x8cbU < 0x34bb;
        local_218[0xe] = 0x57e4 < local_1dc - 0x1a5eU;
        local_218[0xf] = local_1dc - 0x2bf3U < 0x34bb;
      }
      iVar8 = 0;
      local_f8 = SUB6432(ZEXT1664((undefined1  [16])0x0),0);
      _local_d8 = local_f8;
      local_b8 = local_f8;
      if (*(int *)(param_2 + 4) == 0x1ba0f0d) {
        bVar21 = local_1b8 < '\0';
        if (local_1b7 < '\0') {
          bVar21 = bVar21 | 2;
        }
        if (local_1b6 < '\0') {
          bVar21 = bVar21 | 4;
        }
        if (local_1b5 < '\0') {
          bVar21 = bVar21 | 8;
        }
        if (local_1b4 < '\0') {
          bVar21 = bVar21 | 0x10;
        }
        if (local_1b3 < '\0') {
          bVar21 = bVar21 | 0x20;
        }
        if (local_1b2 < '\0') {
          bVar21 = bVar21 | 0x40;
        }
        if (local_1b1 < '\0') {
          bVar21 = bVar21 | 0x80;
        }
        if (bVar21 < 0x81) {
          iVar8 = (uint)bVar21 << 8;
        }
        else {
          iVar8 = 0x8000 - (int)(((float)bVar21 - DAT_1402d277c) * DAT_1402d2e64);
        }
      }
      uVar19 = 0;
      puVar17 = (uint *)local_f8;
      piVar18 = &DAT_1402aa00c;
      plVar12 = plVar12 + 4;
      do {
        piVar5 = (int *)plVar12[1];
        for (piVar15 = (int *)*plVar12; piVar15 != piVar5; piVar15 = piVar15 + 5) {
          iVar16 = piVar15[4];
          if (iVar16 == 0) {
LAB_14021a82e:
            lVar13 = (longlong)*piVar15;
            if (piVar15[1] == 2) {
              iVar16 = iVar8;
              if (*piVar15 != 0x39) {
                iVar16 = aiStack_2cc[lVar13];
              }
              uVar2 = piVar15[2];
              uVar3 = piVar15[3];
              uVar10 = uVar3;
              if ((int)uVar2 <= (int)uVar3) {
                uVar10 = uVar2;
              }
              auVar22._0_4_ = (float)iVar16;
              auVar22._4_12_ = SUB1612(ZEXT816(0),4);
              auVar25._0_4_ = (float)(int)uVar10;
              auVar25._4_12_ = SUB1612(ZEXT816(0),4);
              auVar22 = vmaxss_avx(auVar22,auVar25);
              uVar10 = uVar2;
              if ((int)uVar2 <= (int)uVar3) {
                uVar10 = uVar3;
              }
              auVar23._0_4_ = (float)(int)uVar10;
              auVar23._4_12_ = SUB1612(ZEXT816(0),4);
              auVar22 = vminss_avx(auVar22,auVar23);
              fVar24 = (auVar22._0_4_ - auVar25._0_4_) / (auVar23._0_4_ - auVar25._0_4_);
              auVar22 = vpcmpgtd_avx(ZEXT416(uVar2),ZEXT416(uVar3));
              auVar22 = vblendvps_avx(ZEXT416((uint)fVar24),ZEXT416((uint)(DAT_1402d22d0 - fVar24)),
                                      auVar22);
              if (*piVar18 == 0) {
                auVar22 = vcmpss_avx(ZEXT416(DAT_1402d22c4),auVar22,1);
                auVar22 = vblendvps_avx(ZEXT816(0),ZEXT416((uint)DAT_1402d22d0),auVar22);
              }
            }
            else {
              if (piVar15[1] == 0) {
                bVar21 = *(byte *)((longlong)&local_1dc + lVar13 + 3) >> 7;
              }
              else {
                bVar21 = local_228[lVar13 + -0x11];
              }
              if (bVar21 == 0) goto LAB_14021a8f2;
              if (*piVar18 == 2) {
                auVar22 = ZEXT416((uint)((float)piVar15[2] * DAT_1402d1d60));
              }
              else {
                auVar22 = ZEXT416((uint)DAT_1402d22d0);
              }
            }
            auVar22 = vmaxss_avx(ZEXT416(*puVar17),auVar22);
            *puVar17 = auVar22._0_4_;
          }
          else {
            iVar9 = -iVar16;
            if (-1 < iVar16) {
              iVar9 = iVar16;
            }
            if (iVar9 < 0x21) {
              bVar21 = 0x80;
              if (iVar16 < 0) {
                bVar21 = 0;
              }
              bVar20 = (*(byte *)((longlong)&local_1dc + (longlong)iVar9 + 3) & 0x80) == bVar21;
            }
            else {
              bVar20 = local_228[(longlong)iVar9 + -0x11] ==
                       (char)-((char)~(byte)((uint)iVar16 >> 0x18) >> 7);
            }
            if (bVar20) goto LAB_14021a82e;
          }
LAB_14021a8f2:
        }
        uVar19 = uVar19 + 1;
        plVar12 = plVar12 + 3;
        piVar18 = piVar18 + 8;
        puVar17 = puVar17 + 1;
        if (0x17 < uVar19) {
          uStack_2a0 = 0x14021a956;
          FUN_14021a260(param_1,local_f8);
          puVar4 = (undefined8 *)param_4[1];
          param_4 = (undefined8 *)*param_4;
          uStack_260 = 0;
          uStack_258 = 0;
          uStack_250 = 0;
          local_268 = 0x50;
          local_248 = 0;
          uStack_240 = 0;
          uStack_238 = 0;
          uStack_230 = 0;
          local_228 = (undefined1  [16])0x0;
          auVar6 = _local_d8;
          for (; param_4 != puVar4; param_4 = param_4 + 1) {
            local_278[0] = 0;
            uStack_2a0 = 0x14021a999;
            _local_d8 = auVar6;
            (**(code **)(*(longlong *)*param_4 + 0x48))((longlong *)*param_4,local_278);
            uStack_258 = CONCAT44(uStack_258._4_4_,((uint)*param_1 * 10000) / 0xff);
            uStack_2a0 = 0x14021a9dd;
            (**(code **)(*(longlong *)*param_4 + 0x30))
                      ((longlong *)*param_4,&local_268,(~(local_278[0] & 0xff) & 1) << 0x1d | 4);
            auVar6 = _local_d8;
          }
          if (*(int *)(param_2 + 0x98) != 0) {
            uVar7 = local_218._12_4_;
            local_218._8_4_ = 0;
            sVar14 = (ushort)*param_1 * 0x101;
            local_218._0_4_ = 0xc;
            local_d8._0_12_ = ZEXT812(0);
            local_218._10_2_ = sVar14;
            local_218 = CONCAT412(uVar7,local_218._0_12_);
            local_218._8_2_ = sVar14;
            local_218._6_2_ = sVar14;
            local_218._4_2_ = sVar14;
            local_218._0_4_ = 0xc;
            local_f8._8_24_ = ZEXT824(0);
            local_f8._0_8_ = 0x1000000038;
            local_d8._12_8_ = local_218;
            uStack_c0 = auVar6._24_8_;
            uStack_c4 = 0xc;
            uStack_2a0 = 0x14021aa6a;
            tm_api_set_properties(*(int *)(param_2 + 0x98),0x3003000,local_f8);
          }
          param_1[0x2c] = 1;
          param_1[0x2d] = 0;
          param_1[0x2e] = 0;
          param_1[0x2f] = 0;
          param_1[4] = 0;
          param_1[5] = 0;
          param_1[6] = 0;
          param_1[7] = 0;
          return 1;
        }
      } while( true );
    }
    uStack_2a0 = 0x14021a4f2;
    iVar8 = (**(code **)(*(longlong *)*param_3 + 0x38))();
    if (-1 < iVar8) {
      uStack_2a0 = 0x14021a506;
      (**(code **)(*(longlong *)*param_3 + 200))();
      uStack_2a0 = 0x14021a518;
      iVar8 = (**(code **)(*(longlong *)*param_3 + 0x48))((longlong *)*param_3,0x110,local_208);
      if (-1 < iVar8) {
        puVar4 = (undefined8 *)param_5[1];
        for (param_5 = (undefined8 *)*param_5; param_5 != puVar4; param_5 = param_5 + 1) {
          uStack_2a0 = 0x14021a53d;
          (**(code **)(*(longlong *)*param_5 + 0x38))((longlong *)*param_5,1,0);
        }
        goto LAB_14021a546;
      }
    }
  }
  return 0;
}

