/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140188fb0; RVA 0x188fb0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140188fb0(undefined8 *param_1,byte param_2)

{
  float fVar1;
  ushort uVar2;
  float fVar3;
  float fVar4;
  bool bVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  char cVar11;
  uint uVar12;
  uint uVar13;
  int *piVar14;
  int *piVar15;
  longlong lVar16;
  ulonglong uVar17;
  byte bVar18;
  short *psVar19;
  byte bVar20;
  
  fVar10 = DAT_1402d28a4;
  fVar9 = DAT_1402d2690;
  fVar8 = DAT_1402d22d0;
  fVar7 = DAT_1402d2210;
  fVar6 = DAT_1402d2080;
  uVar17 = (ulonglong)param_2;
  if (*(char *)((longlong)param_1 + 0x95) != '\0') {
    psVar19 = (short *)((longlong)param_1 + 0x16);
    lVar16 = 3;
    *(undefined2 *)((longlong)param_1 + 0x92) = 0;
    do {
      piVar15 = *(int **)(psVar19 + -0xb);
      *(undefined2 *)((longlong)psVar19 + 7) = 0;
      if (piVar15 != (int *)0x0) {
        bVar18 = *(byte *)(psVar19 + 3);
        bVar5 = false;
        uVar2 = *(ushort *)(&DAT_1402917c0 + (ulonglong)bVar18 * 2);
        if ((uVar2 & 1) == 0) {
          if (bVar18 == 0) {
            fVar4 = fVar7;
            fVar3 = fVar6;
LAB_140189174:
            uVar12 = 0x78;
            uVar13 = 0x28;
          }
          else {
            if (bVar18 == 3) {
              fVar4 = fVar10;
              fVar3 = fVar9;
              goto LAB_140189174;
            }
            uVar13 = 0;
            uVar12 = 1;
            fVar4 = fVar8;
            fVar3 = 0.0;
          }
          fVar1 = *(float *)(psVar19 + -7);
          if (0.0 < fVar1) {
            if (fVar3 <= fVar1) {
              if (fVar1 < fVar4) {
                uVar13 = (uint)(byte)((char)uVar13 +
                                     (char)(int)(((float)(int)(uVar12 - uVar13) / (fVar4 - fVar3)) *
                                                (fVar1 - fVar3)));
              }
              else {
                uVar13 = uVar12;
              }
            }
          }
          else {
            uVar13 = 0;
          }
          psVar19[2] = psVar19[2] | 2;
          *(char *)(psVar19 + 4) = (char)uVar13;
        }
        else {
          *(char *)((longlong)psVar19 + 7) = (char)psVar19[-1];
          if (psVar19[1] == 1) {
            cVar11 = (char)(int)(((float)(int)*psVar19 / (float)*piVar15) *
                                (float)*(int *)(psVar19 + -3)) + *(char *)((longlong)piVar15 + 6);
          }
          else {
            cVar11 = *(char *)((longlong)piVar15 + 6);
          }
          *(char *)(psVar19 + 4) = cVar11;
          if (*piVar15 <= *(int *)(psVar19 + -3)) {
            piVar15 = piVar15 + (longlong)piVar15[3] * 4;
            *(int **)(psVar19 + -0xb) = piVar15;
            if (((uVar2 & 2) == 0) ||
               (((*(byte *)((longlong)piVar15 + 10) & 1) != 0 && ((*(byte *)(psVar19 + 2) & 1) == 0)
                ))) {
              piVar14 = piVar15 + 4;
            }
            else {
              piVar14 = piVar15 + (longlong)piVar15[3] * 4;
            }
            if (*piVar14 == -1) {
              bVar5 = true;
            }
            else {
              psVar19[-3] = 0;
              psVar19[-2] = 0;
              psVar19[-1] = (short)piVar15[1];
              *psVar19 = *(short *)((longlong)piVar14 + 6) - *(short *)((longlong)piVar15 + 6);
              psVar19[1] = (short)piVar15[2];
            }
          }
          if (bVar5) {
            psVar19[2] = psVar19[2] | 2;
          }
          else {
            *(int *)(psVar19 + -3) = *(int *)(psVar19 + -3) + 1;
            psVar19[2] = psVar19[2] & 0xfffe;
          }
        }
        cVar11 = (char)psVar19[3];
        if ((((cVar11 == '\x03') || (cVar11 == '\b')) || (cVar11 == '\t')) || (cVar11 == '\v')) {
          uVar13 = (int)((float)*(byte *)(psVar19 + 4) * *(float *)(psVar19 + -5)) & 0xff;
        }
        else {
          uVar13 = (uint)*(byte *)(psVar19 + 4);
        }
        *(char *)(psVar19 + 4) = (char)uVar13 + (char)(uVar13 / 0xff);
      }
      psVar19 = psVar19 + 0x10;
      lVar16 = lVar16 + -1;
    } while (lVar16 != 0);
    bVar18 = *(byte *)((longlong)param_1 + 0x1d);
    bVar20 = *(byte *)((longlong)param_1 + 0x1e);
    if (bVar18 == 0) {
      bVar18 = 0;
    }
    if (bVar20 == 0) {
      bVar20 = 0;
    }
    if ((*(byte *)((longlong)param_1 + 0x1a) & 2) != 0) {
      *(undefined1 *)((longlong)param_1 + 0x1c) = 0xff;
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      *(undefined4 *)(param_1 + 3) = 1;
    }
    if (bVar18 < *(byte *)((longlong)param_1 + 0x3d)) {
      bVar18 = *(byte *)((longlong)param_1 + 0x3d);
    }
    if (bVar20 < *(byte *)((longlong)param_1 + 0x3e)) {
      bVar20 = *(byte *)((longlong)param_1 + 0x3e);
    }
    if ((*(byte *)((longlong)param_1 + 0x3a) & 2) != 0) {
      *(undefined1 *)((longlong)param_1 + 0x3c) = 0xff;
      param_1[4] = 0;
      param_1[5] = 0;
      param_1[6] = 0;
      *(undefined4 *)(param_1 + 7) = 1;
    }
    if (bVar18 < *(byte *)((longlong)param_1 + 0x5d)) {
      bVar18 = *(byte *)((longlong)param_1 + 0x5d);
    }
    if (bVar20 < *(byte *)((longlong)param_1 + 0x5e)) {
      bVar20 = *(byte *)((longlong)param_1 + 0x5e);
    }
    if ((*(byte *)((longlong)param_1 + 0x5a) & 2) != 0) {
      *(undefined1 *)((longlong)param_1 + 0x5c) = 0xff;
      param_1[8] = 0;
      param_1[9] = 0;
      param_1[10] = 0;
      *(undefined4 *)(param_1 + 0xb) = 1;
    }
    lVar16 = DAT_14032c8f0 + uVar17 * 2;
    *(byte *)(uVar17 + 0x2b0 + lVar16) = bVar18;
    *(byte *)(uVar17 + 0x2b1 + lVar16) = bVar20;
  }
  return;
}

