/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021c9c0; RVA 0x21c9c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14021c9c0(longlong param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  
  puVar1 = *(undefined8 **)(param_1 + 0x28);
  for (puVar3 = *(undefined8 **)(param_1 + 0x20); puVar3 != puVar1; puVar3 = puVar3 + 1) {
    (**(code **)(*(longlong *)*puVar3 + 0x40))();
    (**(code **)(*(longlong *)*puVar3 + 0x58))();
  }
  FUN_14021eee0(param_1 + 0x20);
  puVar1 = *(undefined8 **)(param_1 + 0x40);
  for (puVar3 = *(undefined8 **)(param_1 + 0x38); puVar3 != puVar1; puVar3 = puVar3 + 1) {
    (**(code **)(*(longlong *)*puVar3 + 0x40))();
    (**(code **)(*(longlong *)*puVar3 + 0x58))();
  }
  FUN_14021eee0(param_1 + 0x38);
  if (*(longlong **)(param_1 + 0x10) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))();
  }
  plVar2 = *(longlong **)(param_1 + 0x10);
  if (plVar2 != (longlong *)0x0) {
    *(undefined8 *)(param_1 + 0x10) = 0;
    (**(code **)(*plVar2 + 0x10))();
  }
  if (*(longlong **)(param_1 + 0x18) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x18) + 0x40))();
  }
  plVar2 = *(longlong **)(param_1 + 0x18);
  if (plVar2 != (longlong *)0x0) {
    *(undefined8 *)(param_1 + 0x18) = 0;
    (**(code **)(*plVar2 + 0x10))();
  }
  FUN_14021f8b0(param_1 + 0x38);
  FUN_14021f8b0(param_1 + 0x20);
  plVar2 = *(longlong **)(param_1 + 0x18);
  if (plVar2 != (longlong *)0x0) {
    *(undefined8 *)(param_1 + 0x18) = 0;
    (**(code **)(*plVar2 + 0x10))();
  }
  plVar2 = *(longlong **)(param_1 + 0x10);
  if (plVar2 != (longlong *)0x0) {
    *(undefined8 *)(param_1 + 0x10) = 0;
    (**(code **)(*plVar2 + 0x10))();
  }
  return;
}

