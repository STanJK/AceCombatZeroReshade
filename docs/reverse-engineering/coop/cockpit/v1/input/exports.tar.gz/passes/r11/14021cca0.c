/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021cca0; RVA 0x21cca0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

longlong FUN_14021cca0(int *param_1)

{
  uint uVar1;
  undefined8 *puVar2;
  uint7 uVar3;
  int iVar4;
  uint *puVar5;
  ulonglong uVar6;
  
  if (*(longlong *)(param_1 + 2) != -1) {
    puVar2 = (undefined8 *)SteamInternal_ContextInit(&PTR_FUN_14031e578);
    uVar1 = (**(code **)(*(longlong *)*puVar2 + 0x138))
                      ((longlong *)*puVar2,*(undefined8 *)(param_1 + 2));
    if (uVar1 < 4) {
      iVar4 = 0;
      uVar6 = (DAT_14033b188 - DAT_14033b180 >> 5) * -0x3333333333333333;
      if (uVar6 != 0) {
        puVar5 = (uint *)(DAT_14033b180 + 0x90);
        do {
          if (*puVar5 == uVar1) {
            if ((iVar4 != -1) && (iVar4 != *param_1)) {
              *param_1 = iVar4;
            }
            break;
          }
          iVar4 = iVar4 + 1;
          puVar5 = puVar5 + 0x28;
        } while ((ulonglong)(longlong)iVar4 < uVar6);
      }
    }
  }
  iVar4 = *param_1;
  uVar3 = (uint7)(int3)((uint)iVar4 >> 8);
  if (iVar4 < 0) {
    return (ulonglong)uVar3 << 8;
  }
  return CONCAT71(uVar3,(ulonglong)(longlong)iVar4 <
                        (ulonglong)((DAT_14033b188 - DAT_14033b180 >> 5) * -0x3333333333333333));
}

