/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021aaa0; RVA 0x21aaa0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14021aaa0(longlong param_1,undefined8 *param_2,undefined8 *param_3)

{
  float *pfVar1;
  float fVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  float fVar6;
  uint uVar7;
  float fVar8;
  uint uVar9;
  longlong lVar10;
  int iVar11;
  uint uVar12;
  undefined8 uVar13;
  float *pfVar14;
  byte bVar15;
  int iVar16;
  int *piVar17;
  uint *puVar18;
  uint uVar19;
  int *piVar20;
  uint uVar21;
  undefined8 *puVar22;
  undefined1 auVar23 [16];
  float fVar24;
  undefined1 auVar25 [16];
  undefined1 auVar26 [16];
  undefined1 auVar27 [16];
  undefined8 unaff_XMM6_Qa;
  undefined8 unaff_XMM6_Qb;
  undefined8 unaff_XMM7_Qa;
  undefined8 unaff_XMM7_Qb;
  undefined8 unaff_XMM8_Qa;
  undefined8 unaff_XMM8_Qb;
  undefined8 unaff_XMM9_Qa;
  undefined8 unaff_XMM9_Qb;
  undefined1 auStack_228 [32];
  float local_208 [2];
  longlong local_200;
  undefined1 local_1f8 [16];
  undefined1 local_1e8 [32];
  undefined1 local_1c8 [32];
  undefined1 local_1a8 [32];
  byte local_188 [28];
  char local_16c;
  char local_150;
  char local_ec;
  char local_d0;
  ulonglong local_88;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  
  local_88 = DAT_140309040 ^ (ulonglong)auStack_228;
  local_1f8 = (undefined1  [16])0x0;
  local_200 = param_1;
  (**(code **)(*(longlong *)*param_2 + 200))();
  iVar11 = (**(code **)(*(longlong *)*param_2 + 0x48))((longlong *)*param_2,0x100,local_188);
  if (iVar11 < 0) {
    iVar11 = (**(code **)(*(longlong *)*param_2 + 0x38))();
    if (-1 < iVar11) {
      (**(code **)(*(longlong *)*param_2 + 200))();
      iVar11 = (**(code **)(*(longlong *)*param_2 + 0x48))((longlong *)*param_2,0x100,local_188);
      if (-1 < iVar11) goto LAB_14021ab33;
    }
    uVar13 = 0;
  }
  else {
LAB_14021ab33:
    local_48 = unaff_XMM6_Qa;
    uStack_40 = unaff_XMM6_Qb;
    local_58 = unaff_XMM7_Qa;
    uStack_50 = unaff_XMM7_Qb;
    local_68 = unaff_XMM8_Qa;
    uStack_60 = unaff_XMM8_Qb;
    local_78 = unaff_XMM9_Qa;
    uStack_70 = unaff_XMM9_Qb;
    if (DAT_14032c934 != '\0') {
      (**(code **)(*(longlong *)*param_3 + 200))();
      iVar11 = (**(code **)(*(longlong *)*param_3 + 0x48))((longlong *)*param_3,0x10,local_1f8);
      if (iVar11 < 0) {
        (**(code **)(*(longlong *)*param_3 + 0x38))();
        (**(code **)(*(longlong *)*param_3 + 200))();
        (**(code **)(*(longlong *)*param_3 + 0x48))((longlong *)*param_3,0x10,local_1f8);
      }
    }
    lVar10 = local_200;
    uVar9 = DAT_1402d3770;
    fVar8 = DAT_1402d2d64;
    uVar7 = DAT_1402d22d0;
    fVar6 = DAT_1402d1d60;
    if (((local_150 < '\0') || (local_d0 < '\0')) && ((local_16c < '\0' || (local_ec < '\0')))) {
      local_16c = '\0';
      local_ec = '\0';
    }
    uVar19 = 0;
    puVar22 = &DAT_14033b460;
    puVar18 = (uint *)local_1e8;
    local_1e8 = SUB6432(ZEXT1664((undefined1  [16])0x0),0);
    if (DAT_14032c932 != '\0') {
      puVar22 = &DAT_14033b6e0;
    }
    piVar20 = &DAT_1402aa00c;
    local_1c8 = local_1e8;
    local_1a8 = local_1e8;
    do {
      piVar5 = (int *)puVar22[1];
      for (piVar17 = (int *)*puVar22; piVar17 != piVar5; piVar17 = piVar17 + 5) {
        iVar11 = piVar17[4];
        if (iVar11 == 0) {
LAB_14021acda:
          if (piVar17[1] == 2) {
            iVar11 = *piVar17;
            uVar3 = piVar17[2];
            uVar4 = piVar17[3];
            iVar16 = 0x34;
            if (iVar11 < 0x34) {
              iVar16 = 0x31;
            }
            iVar16 = *(int *)(local_1f8 + (longlong)(iVar11 - iVar16) * 4);
            uVar21 = uVar4;
            uVar12 = uVar3;
            if ((int)uVar4 < (int)uVar3) {
              iVar16 = -iVar16;
              uVar21 = uVar3;
              uVar12 = uVar4;
            }
            auVar23._0_4_ = (float)iVar16;
            auVar23._4_12_ = SUB1612(ZEXT816(0),4);
            auVar27._0_4_ = (float)(int)uVar12;
            auVar27._4_12_ = SUB1612(ZEXT816(0),4);
            auVar23 = vmaxss_avx(auVar23,auVar27);
            auVar26._0_4_ = (float)(int)uVar21;
            auVar26._4_12_ = SUB1612(ZEXT816(0),4);
            auVar23 = vminss_avx(auVar23,auVar26);
            fVar24 = (auVar23._0_4_ - auVar27._0_4_) / (auVar26._0_4_ - auVar27._0_4_);
            auVar23 = ZEXT416((uint)fVar24);
            if (iVar11 - 0x34U < 3) {
              if ((int)uVar4 < (int)uVar3) {
                fVar24 = (float)((uint)fVar24 ^ uVar9);
              }
              pfVar1 = (float *)(&DAT_1437dfc38 + (longlong)iVar11 * 4);
              fVar2 = *pfVar1;
              *pfVar1 = fVar24 + fVar2;
              pfVar14 = local_208;
              if (fVar8 < fVar24 + fVar2) {
                pfVar14 = pfVar1;
              }
              local_208[0] = fVar8;
              auVar26 = vminss_avx(ZEXT416((uint)*pfVar14),ZEXT416(uVar7));
              auVar23 = vpcmpgtd_avx(ZEXT416(uVar3),ZEXT416(uVar4));
              auVar25._0_4_ = (uint)auVar26._0_4_ ^ uVar9;
              auVar25._4_4_ = auVar26._4_4_;
              auVar25._8_4_ = auVar26._8_4_;
              auVar25._12_4_ = auVar26._12_4_;
              auVar23 = vblendvps_avx(auVar26,auVar25,auVar23);
              *pfVar1 = auVar26._0_4_;
            }
          }
          else {
            if (piVar17[1] == 0) {
              bVar15 = local_1f8[(longlong)*piVar17 + 0xb];
            }
            else {
              bVar15 = local_188[piVar17[3]];
            }
            if (-1 < (char)bVar15) goto LAB_14021adee;
            if (*piVar20 == 2) {
              auVar23 = ZEXT416((uint)((float)piVar17[2] * fVar6));
            }
            else {
              auVar23 = ZEXT416(uVar7);
            }
          }
          auVar23 = vmaxss_avx(ZEXT416(*puVar18),auVar23);
          *puVar18 = auVar23._0_4_;
        }
        else {
          iVar16 = -iVar11;
          if (-1 < iVar11) {
            iVar16 = iVar11;
          }
          bVar15 = 0x80;
          if (iVar11 < 0) {
            bVar15 = 0;
          }
          if ((local_188[iVar16] & 0x80) == bVar15) goto LAB_14021acda;
          if (*piVar17 - 0x34U < 3) {
            *(undefined4 *)(&DAT_1437dfc38 + (longlong)*piVar17 * 4) = 0;
          }
        }
LAB_14021adee:
      }
      uVar19 = uVar19 + 1;
      puVar22 = puVar22 + 3;
      piVar20 = piVar20 + 8;
      puVar18 = puVar18 + 1;
    } while (uVar19 < 0x18);
    FUN_14021a260(local_200,local_1e8);
    *(undefined4 *)(lVar10 + 4) = 0;
    uVar13 = 1;
    *(undefined4 *)(lVar10 + 0x2c) = 1;
  }
  return uVar13;
}

