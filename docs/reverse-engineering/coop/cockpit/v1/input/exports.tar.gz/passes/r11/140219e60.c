/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140219e60; RVA 0x219e60
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140219e60(longlong param_1,longlong *param_2,longlong param_3,undefined8 *param_4)

{
  char cVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined8 *puVar5;
  bool bVar6;
  int iVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined *puVar10;
  int *piVar11;
  undefined1 auStack_118 [32];
  undefined8 local_f8;
  longlong *local_e8;
  undefined4 local_e0;
  int local_dc;
  longlong *local_d8;
  undefined8 local_d0;
  undefined4 local_c8;
  undefined4 local_c4;
  undefined4 local_c0;
  undefined4 local_bc;
  undefined4 local_b8;
  undefined4 local_b4;
  undefined4 local_b0;
  undefined4 local_ac;
  undefined4 *local_a8;
  undefined8 *local_a0;
  undefined8 local_98;
  undefined8 local_90;
  int *local_88;
  undefined8 local_80;
  undefined1 local_78 [16];
  undefined8 local_68;
  undefined1 local_60 [16];
  ulonglong local_50;
  
  plVar8 = DAT_14033b198;
  local_50 = DAT_140309040 ^ (ulonglong)auStack_118;
  plVar9 = (longlong *)*param_2;
  pcVar3 = *(code **)(*DAT_14033b198 + 0x18);
  if (plVar9 != (longlong *)0x0) {
    *param_2 = 0;
    (**(code **)(*plVar9 + 0x10))();
  }
  iVar7 = (*pcVar3)(plVar8,param_1 + 0x14,param_2,0);
  if (-1 < iVar7) {
    plVar8 = (longlong *)DAT_14033b1a0[1];
    cVar1 = *(char *)((longlong)plVar8 + 0x19);
    plVar9 = DAT_14033b1a0;
    while (cVar1 == '\0') {
      if (*(uint *)(plVar8 + 4) < *(uint *)(param_1 + 4)) {
        plVar8 = plVar8 + 2;
      }
      else {
        plVar9 = plVar8;
      }
      plVar8 = (longlong *)*plVar8;
      cVar1 = *(char *)((longlong)plVar8 + 0x19);
    }
    if ((*(char *)((longlong)plVar9 + 0x19) != '\0') ||
       (*(uint *)(param_1 + 4) < *(uint *)(plVar9 + 4))) {
      plVar9 = DAT_14033b1a0;
    }
    if (plVar9 == DAT_14033b1a0) {
      local_e8 = (longlong *)((ulonglong)local_e8 & 0xffffffff00000000);
      plVar9 = (longlong *)FUN_14021ef40(plVar9,&local_e8);
    }
    else {
      plVar9 = plVar9 + 5;
    }
    iVar7 = (**(code **)(*(longlong *)*param_2 + 0x58))((longlong *)*param_2,&DAT_14027bdd0);
    if ((-1 < iVar7) &&
       (((plVar9[0x4d] != 0 &&
         (iVar7 = (**(code **)(*(longlong *)*param_2 + 0x68))((longlong *)*param_2,DAT_1403589c8,9),
         -1 < iVar7)) ||
        (iVar7 = (**(code **)(*(longlong *)*param_2 + 0x68))((longlong *)*param_2,DAT_1403589c8,10),
        -1 < iVar7)))) {
      if (plVar9[0x4d] != 0) {
        local_dc = 0;
        local_68 = 0;
        local_a8 = &local_e0;
        local_a0 = &local_d0;
        local_e0 = 0;
        local_d0 = 0;
        local_90 = 0;
        local_88 = (int *)0x0;
        local_80 = 0;
        local_c8 = 0x50;
        local_c4 = 0x12;
        local_c0 = 0xffffffff;
        local_bc = 0;
        local_b8 = 10000;
        local_b4 = 0xffffffff;
        local_b0 = 0;
        local_ac = 1;
        local_98 = 0;
        local_60 = (undefined1  [16])0x0;
        local_78 = (undefined1  [16])0x0;
        local_d8 = *(longlong **)plVar9[0x4c];
        cVar1 = *(char *)((longlong)local_d8 + 0x19);
        while (cVar1 == '\0') {
          local_e0 = (undefined4)local_d8[4];
          bVar6 = false;
          piVar4 = (int *)local_d8[6];
          piVar11 = (int *)local_d8[5];
          if (piVar11 != piVar4) {
            do {
              iVar2 = *piVar11;
              local_e8 = (longlong *)0x0;
              if (iVar2 == 0) {
                if (!bVar6) {
                  local_60._12_4_ = piVar11[2];
                  local_60._0_4_ = piVar11[1];
                  local_88 = (int *)local_60;
                  puVar10 = &DAT_14027bdb0;
                  local_90 = CONCAT44(local_90._4_4_,0x10);
                  goto LAB_14021a0eb;
                }
              }
              else {
                if (iVar2 == 1) {
                  if (bVar6) goto LAB_14021a183;
                  local_dc = piVar11[1];
                  local_88 = &local_dc;
                  puVar10 = &DAT_14027bda0;
                  local_90 = CONCAT44(local_90._4_4_,4);
LAB_14021a0eb:
                  local_f8 = 0;
                  iVar7 = (**(code **)(*(longlong *)*param_2 + 0x90))
                                    ((longlong *)*param_2,puVar10,&local_c8,&local_e8);
                }
                else if (iVar2 == 2) {
                  local_78._8_4_ = piVar11[2];
                  local_78._12_4_ = piVar11[1];
                  local_78._4_4_ = piVar11[2];
                  local_78._0_4_ = piVar11[3];
                  local_68 = CONCAT44(piVar11[4],piVar11[1]);
                  local_88 = (int *)local_78;
                  puVar10 = &DAT_14027bdc0;
                  local_90 = CONCAT44(local_90._4_4_,0x18);
                  goto LAB_14021a0eb;
                }
                if (-1 < iVar7) {
                  if (*piVar11 == 2) {
                    puVar5 = (undefined8 *)param_4[1];
                    if (puVar5 == (undefined8 *)param_4[2]) {
                      FUN_14021fc20(param_4,puVar5,&local_e8);
                    }
                    else {
                      *puVar5 = local_e8;
                      if (local_e8 != (longlong *)0x0) {
                        (**(code **)(*local_e8 + 8))();
                      }
                      param_4[1] = param_4[1] + 8;
                    }
                  }
                  else {
                    puVar5 = *(undefined8 **)(param_3 + 8);
                    if (puVar5 == *(undefined8 **)(param_3 + 0x10)) {
                      FUN_14021fc20(param_3,puVar5,&local_e8);
                    }
                    else {
                      *puVar5 = local_e8;
                      if (local_e8 != (longlong *)0x0) {
                        (**(code **)(*local_e8 + 8))();
                      }
                      *(longlong *)(param_3 + 8) = *(longlong *)(param_3 + 8) + 8;
                    }
                    bVar6 = true;
                  }
                }
              }
LAB_14021a183:
              piVar11 = piVar11 + 5;
            } while (piVar11 != piVar4);
          }
          plVar9 = (longlong *)local_d8[2];
          if (*(char *)((longlong)plVar9 + 0x19) == '\0') {
            cVar1 = *(char *)(*plVar9 + 0x19);
            local_d8 = plVar9;
            plVar9 = (longlong *)*plVar9;
            while (cVar1 == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x19);
              local_d8 = plVar9;
              plVar9 = (longlong *)*plVar9;
            }
          }
          else {
            cVar1 = *(char *)(local_d8[1] + 0x19);
            plVar8 = (longlong *)local_d8[1];
            plVar9 = local_d8;
            while ((local_d8 = plVar8, cVar1 == '\0' && (plVar9 == (longlong *)local_d8[2]))) {
              cVar1 = *(char *)(local_d8[1] + 0x19);
              plVar8 = (longlong *)local_d8[1];
              plVar9 = local_d8;
            }
          }
          cVar1 = *(char *)((longlong)local_d8 + 0x19);
        }
      }
      (**(code **)(*(longlong *)*param_2 + 0x38))();
      puVar5 = (undefined8 *)param_4[1];
      for (param_4 = (undefined8 *)*param_4; param_4 != puVar5; param_4 = param_4 + 1) {
        (**(code **)(*(longlong *)*param_4 + 0x38))((longlong *)*param_4,1,0);
      }
      return 1;
    }
  }
  return 0;
}

