/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021c340; RVA 0x21c340
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14021c340(void)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  undefined4 local_res8 [2];
  
  FUN_14021bef0();
  cVar2 = *(char *)(DAT_14033b1a0[1] + 0x19);
  plVar1 = (longlong *)DAT_14033b1a0[1];
  plVar8 = DAT_14033b1a0;
  while (plVar4 = plVar1, cVar2 == '\0') {
    plVar1 = (longlong *)*plVar4;
    plVar8 = plVar4;
    cVar2 = *(char *)(*plVar4 + 0x19);
  }
  if ((*(char *)((longlong)plVar8 + 0x19) != '\0') || ((int)plVar8[4] != 0)) {
    plVar8 = DAT_14033b1a0;
  }
  if (plVar8 == DAT_14033b1a0) {
    local_res8[0] = 0;
    puVar6 = (undefined8 *)FUN_14021ef40(plVar4,local_res8);
    if ((undefined8 **)puVar6 != &DAT_14033b1c0) {
      puVar9 = &DAT_14033b1c0;
      if (7 < DAT_14033b1d8) {
        puVar9 = DAT_14033b1c0;
      }
      FUN_14021f2c0(puVar6,puVar9,DAT_14033b1d0);
    }
    lVar10 = 0x18;
    plVar8 = puVar6 + 4;
    do {
      plVar1 = (longlong *)(((longlong)&DAT_14033b1c0 - (longlong)puVar6) + (longlong)plVar8);
      if (plVar8 != plVar1) {
        lVar3 = *plVar1;
        FUN_14021f750(plVar8,lVar3,
                      (*(longlong *)
                        (((longlong)&DAT_14033b1c8 - (longlong)puVar6) + (longlong)plVar8) - lVar3
                      >> 2) * -0x3333333333333333);
      }
      plVar8 = plVar8 + 3;
      lVar10 = lVar10 + -1;
    } while (lVar10 != 0);
    plVar8 = puVar6 + 0x4c;
    if (plVar8 != &DAT_14033b420) {
      lVar10 = *plVar8;
      FUN_1402201f0(plVar8,plVar8,*(undefined8 *)(lVar10 + 8));
      *(longlong *)(lVar10 + 8) = lVar10;
      *(longlong *)lVar10 = lVar10;
      *(longlong *)(lVar10 + 0x10) = lVar10;
      puVar6[0x4d] = 0;
      uVar7 = FUN_140220840(plVar8,*(undefined8 *)(DAT_14033b420 + 8),*plVar8);
      *(undefined8 *)(*plVar8 + 8) = uVar7;
      plVar1 = (longlong *)*plVar8;
      puVar6[0x4d] = DAT_14033b428;
      plVar4 = (longlong *)plVar1[1];
      if (*(char *)((longlong)plVar4 + 0x19) == '\0') {
        cVar2 = *(char *)(*plVar4 + 0x19);
        plVar5 = (longlong *)*plVar4;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar5 + 0x19);
          plVar4 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
        *plVar1 = (longlong)plVar4;
        lVar10 = *(longlong *)(*plVar8 + 8);
        lVar3 = *(longlong *)(lVar10 + 0x10);
        cVar2 = *(char *)(lVar3 + 0x19);
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*(longlong *)(lVar3 + 0x10) + 0x19);
          lVar10 = lVar3;
          lVar3 = *(longlong *)(lVar3 + 0x10);
        }
        *(longlong *)(*plVar8 + 0x10) = lVar10;
      }
      else {
        *plVar1 = (longlong)plVar1;
        *(longlong *)(*plVar8 + 0x10) = *plVar8;
      }
    }
    *(undefined1 *)(puVar6 + 0x4e) = DAT_14033b430;
  }
  return;
}

