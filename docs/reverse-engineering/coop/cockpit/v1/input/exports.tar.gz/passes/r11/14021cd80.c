/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14021cd80; RVA 0x21cd80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14021cd80(void)

{
  int *piVar1;
  char cVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  int *piVar6;
  undefined8 *puVar7;
  HMODULE hModule;
  longlong *plVar8;
  INT_PTR IVar9;
  longlong *plVar10;
  longlong *plVar11;
  uint uVar12;
  int *piVar13;
  undefined1 auStackY_128 [32];
  undefined4 local_f8 [2];
  undefined1 local_f0 [16];
  undefined4 local_d8;
  undefined1 local_d4 [16];
  undefined1 local_c4 [16];
  undefined4 local_b4;
  undefined8 local_b0;
  undefined1 local_a8 [16];
  undefined8 local_98;
  undefined8 uStack_90;
  undefined1 local_88 [16];
  undefined8 local_78;
  undefined8 uStack_70;
  undefined1 local_68 [16];
  undefined8 local_58;
  undefined8 uStack_50;
  undefined4 local_48;
  undefined8 local_44;
  undefined1 local_3c;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  ulonglong local_18;
  
  local_18 = DAT_140309040 ^ (ulonglong)auStackY_128;
  if (DAT_1437dfd21 == '\0') {
    DAT_1437dfd21 = '\x01';
    puVar7 = (undefined8 *)SteamInternal_ContextInit(&PTR_FUN_14031e578);
    (*(code *)**(undefined8 **)*puVar7)((undefined8 *)*puVar7,0);
    puVar7 = (undefined8 *)SteamInternal_ContextInit(&PTR_FUN_14031e578);
    (**(code **)(*(longlong *)*puVar7 + 0x18))();
    FUN_14021c340();
    hModule = LoadLibraryA("XInput1_4.dll");
    if (hModule != (HMODULE)0x0) {
      DAT_1403589d0 = GetProcAddress(hModule,(LPCSTR)0x6c);
    }
    FUN_140219700();
    plVar10 = DAT_14033b198;
    if (DAT_14033b198 != (longlong *)0x0) {
      DAT_14033b198 = (longlong *)0x0;
      (**(code **)(*plVar10 + 0x10))();
    }
    CoCreateInstance((IID *)&DAT_14027bcd0,(LPUNKNOWN)0x0,1,(IID *)&DAT_14027bce0,&DAT_14033b198);
    (**(code **)(*DAT_14033b198 + 0x38))(DAT_14033b198,DAT_1403589f0,0x800);
    (**(code **)(*DAT_14033b198 + 0x20))(DAT_14033b198,4,&LAB_14021d490,0);
    piVar6 = DAT_14033b188;
    if (DAT_14033b180 != DAT_14033b188) {
      piVar13 = DAT_14033b180 + 0x27;
      plVar10 = DAT_14033b1a0;
      do {
        plVar8 = (longlong *)plVar10[1];
        cVar2 = *(char *)((longlong)plVar8 + 0x19);
        plVar11 = plVar10;
        while (cVar2 == '\0') {
          if (*(uint *)(plVar8 + 4) < (uint)piVar13[-0x26]) {
            plVar8 = plVar8 + 2;
          }
          else {
            plVar11 = plVar8;
          }
          plVar8 = (longlong *)*plVar8;
          cVar2 = *(char *)((longlong)plVar8 + 0x19);
        }
        if ((*(char *)((longlong)plVar11 + 0x19) != '\0') ||
           ((uint)piVar13[-0x26] < *(uint *)(plVar11 + 4))) {
          plVar11 = plVar10;
        }
        if ((plVar11 != plVar10) && ((char)plVar11[0x53] != '\0')) {
          *(undefined1 *)piVar13 = 1;
          DAT_14032c935 = '\x01';
          plVar10 = DAT_14033b1a0;
        }
        piVar1 = piVar13 + 1;
        piVar13 = piVar13 + 0x28;
      } while (piVar1 != piVar6);
    }
    if (DAT_14032c935 != '\0') {
      local_f0._0_12_ = ZEXT412(0);
      local_f0._0_4_ = 0xc;
      tm_api_init(0x800,local_f0);
    }
    if (DAT_1403589d0 != (FARPROC)0x0) {
      uVar12 = 0;
      do {
        local_f0 = (undefined1  [16])0x0;
        Ordinal_2(uVar12,local_f0);
        local_38 = 0;
        uStack_30 = 0;
        uStack_28 = 0;
        uStack_20 = 0;
        IVar9 = (*DAT_1403589d0)(1,(ulonglong)uVar12,0,&local_38);
        if ((int)IVar9 == 0) {
          plVar10 = (longlong *)DAT_14033b170[1];
          cVar2 = *(char *)((longlong)plVar10 + 0x19);
          plVar8 = DAT_14033b170;
          while (cVar2 == '\0') {
            if (*(uint *)((longlong)plVar10 + 0x1c) < uStack_28._4_4_) {
              plVar10 = plVar10 + 2;
            }
            else {
              plVar8 = plVar10;
            }
            plVar10 = (longlong *)*plVar10;
            cVar2 = *(char *)((longlong)plVar10 + 0x19);
          }
          if ((*(char *)((longlong)plVar8 + 0x19) != '\0') ||
             (uStack_28._4_4_ < *(uint *)((longlong)plVar8 + 0x1c))) {
            plVar8 = DAT_14033b170;
          }
          piVar6 = DAT_14033b180;
          if (plVar8 != DAT_14033b170) {
            for (; piVar6 != DAT_14033b188; piVar6 = piVar6 + 0x28) {
              if (((*piVar6 == 1) && (piVar6[0x24] == -1)) && (piVar6[1] == uStack_28._4_4_)) {
                piVar6[0x24] = uVar12;
                local_f8[0] = 0;
                Ordinal_3(uVar12,local_f8);
                break;
              }
            }
          }
        }
        uVar12 = uVar12 + 1;
      } while (uVar12 < 4);
    }
    FUN_140219cc0();
    local_c4 = (undefined1  [16])0x0;
    local_b0 = 0;
    local_a8._2_14_ = SUB1614((undefined1  [16])0x0,2);
    auVar3._14_2_ = 0;
    auVar3._0_14_ = local_a8._2_14_;
    local_a8 = auVar3 << 0x10;
    local_88._2_14_ = SUB1614((undefined1  [16])0x0,2);
    auVar4._14_2_ = 0;
    auVar4._0_14_ = local_88._2_14_;
    local_88 = auVar4 << 0x10;
    local_68._2_14_ = SUB1614((undefined1  [16])0x0,2);
    auVar5._14_2_ = 0;
    auVar5._0_14_ = local_68._2_14_;
    local_68 = auVar5 << 0x10;
    local_44 = 0;
    local_98 = _DAT_1402d2fd0;
    uStack_90 = _UNK_1402d2fd8;
    local_78 = _DAT_1402d2fd0;
    uStack_70 = _UNK_1402d2fd8;
    local_58 = _DAT_1402d2fd0;
    uStack_50 = _UNK_1402d2fd8;
    local_d8 = 3;
    local_d4 = (undefined1  [16])0x0;
    local_b4 = 0;
    local_48 = 0xffffffff;
    local_3c = 0;
    if (DAT_14033b188 == DAT_14033b190) {
      FUN_140220420(DAT_14033b188,DAT_14033b188,&local_d8);
    }
    else {
      FUN_1402208f0(DAT_14033b188,&local_d8);
      DAT_14033b188 = DAT_14033b188 + 0x28;
    }
    FUN_1402216b0(local_68);
    FUN_1402216b0(local_88);
    FUN_1402216b0(local_a8);
  }
  return;
}

