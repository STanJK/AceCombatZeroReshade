/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140188d80; RVA 0x188d80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140188d80(longlong param_1,byte param_2,byte param_3,undefined4 param_4)

{
  byte bVar1;
  ushort uVar2;
  undefined2 uVar3;
  int iVar4;
  longlong lVar5;
  int iVar6;
  longlong lVar7;
  
  if (*(char *)(param_1 + 0x95) != '\0') {
    switch(param_3) {
    case 0:
    case 1:
    case 4:
    case 5:
      *(undefined1 *)((ulonglong)param_2 * 3 + DAT_14032c8f0 + 0x2b2) = 1;
      break;
    case 2:
    case 3:
    case 7:
    case 8:
    case 9:
    case 10:
    case 0xb:
      *(undefined1 *)((ulonglong)param_2 * 3 + DAT_14032c8f0 + 0x2b2) = 0xff;
      break;
    case 6:
      *(undefined1 *)((ulonglong)param_2 * 3 + DAT_14032c8f0 + 0x2b2) = 3;
      break;
    case 0xf:
      *(undefined1 *)((ulonglong)param_2 * 3 + DAT_14032c8f0 + 0x2b2) = 2;
    }
    if (param_3 < 0xc) {
      lVar7 = 0xffffffff;
      iVar6 = 0;
      lVar5 = param_1;
      do {
        bVar1 = *(byte *)(lVar5 + 0x1c);
        if (bVar1 == param_3) {
          *(ushort *)(lVar5 + 0x1a) = *(ushort *)(lVar5 + 0x1a) | 1;
          if ((bVar1 == 3) || (bVar1 != 8)) {
            *(undefined4 *)(lVar5 + 0xc) = 0x3f800000;
            return;
          }
          return;
        }
        iVar4 = iVar6;
        if (bVar1 != 0xff) {
          iVar4 = (int)lVar7;
        }
        iVar6 = iVar6 + 1;
        lVar5 = lVar5 + 0x20;
        lVar7 = (longlong)iVar4;
      } while (iVar6 < 3);
      if (iVar4 != -1) {
        lVar7 = lVar7 * 0x20;
        uVar2 = *(ushort *)(&DAT_1402917c0 + (ulonglong)param_3 * 2);
        *(byte *)(lVar7 + 0x1c + param_1) = param_3;
        if ((uVar2 & 1) == 0) {
          if (((int)(uint)param_3 < *(int *)(param_1 + 0x60)) &&
             (iVar6 = *(int *)(*(longlong *)(param_1 + 0x70) + (ulonglong)param_3 * 4), iVar6 != 0))
          {
            lVar5 = (longlong)iVar6 + *(longlong *)(param_1 + 0x68);
          }
          else {
            lVar5 = 0;
          }
          *(longlong *)(lVar7 + param_1) = lVar5;
          *(undefined8 *)(lVar7 + 0x10 + param_1) = 0;
          uVar3 = *(undefined2 *)(lVar5 + 8);
        }
        else {
          if (((int)(uint)param_3 < *(int *)(param_1 + 0x60)) &&
             (iVar6 = *(int *)(*(longlong *)(param_1 + 0x70) + (longlong)(int)(uint)param_3 * 4),
             iVar6 != 0)) {
            lVar5 = (longlong)iVar6 + *(longlong *)(param_1 + 0x68);
          }
          else {
            lVar5 = 0;
          }
          *(longlong *)(lVar7 + param_1) = lVar5;
          *(undefined4 *)(lVar7 + 0x10 + param_1) = 0;
          *(undefined2 *)(lVar7 + 0x14 + param_1) = *(undefined2 *)(lVar5 + 4);
          *(short *)(lVar7 + 0x16 + param_1) = *(short *)(lVar5 + 0x16) - *(short *)(lVar5 + 6);
          uVar3 = *(undefined2 *)(lVar5 + 8);
          param_4 = 0;
        }
        *(undefined2 *)(lVar7 + 0x18 + param_1) = uVar3;
        *(undefined2 *)(lVar7 + 0x1a + param_1) = 0;
        *(undefined4 *)(lVar7 + 8 + param_1) = param_4;
        *(undefined4 *)(lVar7 + 0xc + param_1) = 0x3f800000;
        return;
      }
    }
  }
  return;
}

