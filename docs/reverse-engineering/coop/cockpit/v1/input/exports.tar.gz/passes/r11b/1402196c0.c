/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1402196c0; RVA 0x2196c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1402196c0(undefined8 *param_1)

{
  undefined8 uVar1;
  undefined4 uVar2;
  
  uVar2 = SteamAPI_GetHSteamUser();
  uVar1 = SteamInternal_FindOrCreateUserInterface(uVar2,"SteamInput006");
  *param_1 = uVar1;
  return;
}

