/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14022c040; RVA 0x22c040
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14022c040(longlong param_1,HWND param_2)

{
  SHORT SVar1;
  int extraout_EAX;
  uint uVar2;
  HWND pHVar3;
  LRESULT LVar4;
  longlong *plVar5;
  longlong lVar6;
  int iVar7;
  ushort uVar8;
  uint uVar9;
  undefined1 auStack_c8 [48];
  undefined2 local_98 [4];
  undefined8 local_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  ushort local_70;
  undefined2 local_68;
  undefined8 local_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined2 local_40;
  ulonglong local_38;
  
  local_38 = DAT_140309040 ^ (ulonglong)auStack_c8;
  SteamAPI_RunCallbacks();
  FUN_14022b2f0(param_1,0);
  DAT_14032c930 = 1;
  local_98[0] = 0;
  local_68 = 0;
  DAT_14032c931 = DAT_1437d9b28;
  local_90 = 0;
  uStack_88 = 0;
  uStack_80 = 0;
  uStack_78 = 0;
  local_70 = 0;
  local_60 = 0;
  uStack_58 = 0;
  uStack_50 = 0;
  uStack_48 = 0;
  local_40 = 0;
  FUN_14021d4c0(local_98);
  uVar8 = (local_70 ^ _DAT_1437dfd44) & local_70;
  _DAT_1437dfd44 = local_70;
  if ((uVar8 & 0x40f9) == 0) {
    return;
  }
  pHVar3 = GetFocus();
  uVar9 = 0;
  plVar5 = (longlong *)(param_1 + 0x30);
  lVar6 = 0;
  do {
    if ((HWND)*plVar5 == pHVar3) {
      uVar2 = uVar9;
      if (((int)uVar9 < 4) && (LVar4 = SendMessageA(pHVar3,0x157,0,0), (int)LVar4 != 0)) {
        LVar4 = SendMessageA(pHVar3,0x147,0,0);
        extraout_EAX = (int)LVar4;
        iVar7 = extraout_EAX;
        if ((uVar8 & 0x4009) == 0) {
          if ((uVar8 & 0x40) == 0) {
            if (((uVar8 & 0x10) != 0) && (iVar7 = extraout_EAX + -1, iVar7 < 0)) {
              iVar7 = 0;
            }
          }
          else {
            iVar7 = extraout_EAX + 1;
          }
        }
        else {
          SendMessageA(pHVar3,0x14f,0,0);
        }
        SendMessageA(pHVar3,0x14e,(longlong)iVar7,0);
        SendMessageA(param_2,0x111,(ulonglong)(uVar9 & 0xffff) | 0x10000,(LPARAM)pHVar3);
        return;
      }
      break;
    }
    uVar9 = uVar9 + 1;
    lVar6 = lVar6 + 1;
    plVar5 = plVar5 + 1;
    uVar2 = 4;
  } while (lVar6 < 4);
  if ((uVar8 & 0x4008) != 0) {
    SVar1 = GetKeyState(0x1b);
    if (SVar1 < 0) {
      return;
    }
    if ((int)uVar2 < 4) {
      SendMessageA(pHVar3,0x14f,1,0);
      return;
    }
    PostMessageA(pHVar3,0xf5,0,0);
    return;
  }
  if ((uVar8 & 1) != 0) {
    SVar1 = GetKeyState(0x10);
    uVar8 = uVar8 | (SVar1 >> 0xf & 0xffd0U) + 0x40;
  }
  if ((uVar8 & 0x40) == 0) {
    if ((uVar8 & 0x10) == 0) {
      if ((uVar8 & 0xa0) != 0) {
        if ((int)uVar2 < 2) {
          uVar2 = uVar2 + 2;
        }
        else {
          if (uVar2 == 4) {
            pHVar3 = *(HWND *)(param_1 + 0x38);
            goto LAB_14022c278;
          }
          uVar2 = uVar2 - 2;
        }
      }
      goto LAB_14022c256;
    }
    uVar2 = uVar2 - 1;
    if (-1 < (int)uVar2) goto LAB_14022c256;
  }
  else {
    uVar9 = uVar2 + 1;
    uVar2 = 0;
    if ((int)uVar9 < 5) {
      uVar2 = uVar9;
    }
LAB_14022c256:
    if ((int)uVar2 < 4) {
      pHVar3 = *(HWND *)(param_1 + 0x30 + (longlong)(int)uVar2 * 8);
      goto LAB_14022c278;
    }
  }
  pHVar3 = *(HWND *)(param_1 + 0x70);
LAB_14022c278:
  SetFocus(pHVar3);
  return;
}

