/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140219cc0; RVA 0x219cc0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140219cc0(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined1 auStack_b8 [32];
  undefined8 local_98 [16];
  ulonglong local_18;
  
  local_18 = DAT_140309040 ^ (ulonglong)auStack_b8;
  puVar4 = (undefined8 *)SteamInternal_ContextInit(&PTR_FUN_14031e578);
  (**(code **)(*(longlong *)*puVar4 + 0x18))((longlong *)*puVar4,1);
  puVar4 = (undefined8 *)SteamInternal_ContextInit(&PTR_FUN_14031e578);
  iVar2 = (**(code **)(*(longlong *)*puVar4 + 0x30))((longlong *)*puVar4,local_98);
  if (0 < iVar2) {
    lVar5 = 0;
    do {
      puVar4 = (undefined8 *)SteamInternal_ContextInit(&PTR_FUN_14031e578);
      iVar3 = (**(code **)(*(longlong *)*puVar4 + 0x138))((longlong *)*puVar4,local_98[lVar5]);
      piVar1 = DAT_14033b180;
      if (-1 < iVar3) {
        for (; piVar1 != DAT_14033b188; piVar1 = piVar1 + 0x28) {
          if ((piVar1[0x24] == iVar3) && ((*piVar1 == 1 || (*piVar1 == 2)))) {
            *piVar1 = 2;
            puVar4 = (undefined8 *)SteamInternal_ContextInit(&PTR_FUN_14031e578);
            iVar3 = (**(code **)(*(longlong *)*puVar4 + 0x128))((longlong *)*puVar4,local_98[lVar5])
            ;
            piVar1[0x25] = iVar3;
            *(undefined8 *)(piVar1 + 10) = local_98[lVar5];
            break;
          }
        }
      }
      lVar5 = lVar5 + 1;
    } while (lVar5 < iVar2);
  }
  return;
}

