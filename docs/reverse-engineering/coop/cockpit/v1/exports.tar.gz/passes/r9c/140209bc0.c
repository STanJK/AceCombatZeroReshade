/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140209bc0; RVA 0x209bc0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

longlong * FUN_140209bc0(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *local_res8;
  undefined1 local_18 [16];
  
  uVar1 = FUN_140209990();
  lVar2 = FUN_1402128e0(param_1,local_18,param_2,uVar1);
  lVar2 = *(longlong *)(lVar2 + 8);
  if ((lVar2 != 0) && (lVar2 != *(longlong *)(param_1 + 8))) {
    return *(longlong **)(lVar2 + 0x2a0);
  }
  local_res8 = (longlong *)0x0;
  (**(code **)(**(longlong **)(DAT_14033da48 + 8) + 0x50))
            (*(longlong **)(DAT_14033da48 + 8),param_2,&DAT_1402ce310,&local_res8);
  plVar3 = (longlong *)FUN_140211820(param_1,local_18,param_2);
  plVar4 = local_res8;
  lVar2 = *plVar3;
  if (*(longlong **)(lVar2 + 0x2a0) != local_res8) {
    if (local_res8 != (longlong *)0x0) {
      (**(code **)(*local_res8 + 8))(local_res8);
    }
    plVar3 = *(longlong **)(lVar2 + 0x2a0);
    *(longlong **)(lVar2 + 0x2a0) = plVar4;
    if (plVar3 != (longlong *)0x0) {
      (**(code **)(*plVar3 + 0x10))();
    }
    plVar4 = local_res8;
  }
  if (plVar4 != (longlong *)0x0) {
    local_res8 = (longlong *)0x0;
    (**(code **)(*plVar4 + 0x10))(plVar4);
  }
  return plVar4;
}

