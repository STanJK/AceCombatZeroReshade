/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140192920; RVA 0x192920
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Removing unreachable block (ram,0x0001401930fd) */
/* WARNING: Removing unreachable block (ram,0x000140192d2a) */
/* WARNING: Removing unreachable block (ram,0x000140192c9e) */
/* WARNING: Removing unreachable block (ram,0x000140192b4d) */
/* WARNING: Removing unreachable block (ram,0x000140192ce1) */
/* WARNING: Removing unreachable block (ram,0x000140192d69) */
/* WARNING: Removing unreachable block (ram,0x00014019314d) */

void FUN_140192920(longlong param_1,float param_2,float param_3,undefined8 param_4,float param_5)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  ulonglong uVar8;
  int iVar9;
  longlong lVar10;
  int iVar11;
  int *piVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  undefined1 auVar16 [16];
  undefined1 in_ZMM3 [64];
  float fVar17;
  undefined1 auVar18 [64];
  float fVar19;
  undefined1 auVar20 [64];
  
  uVar8 = *(ulonglong *)(param_1 + 200);
  auVar16 = in_ZMM3._0_16_;
  auVar20 = ZEXT1664(auVar16);
  if ((((byte)uVar8 & 7) == 6) && (*(int *)(param_1 + 0x714) == 0)) {
    *(float *)(param_1 + 0x718) = param_2;
    *(float *)(param_1 + 0x71c) = param_3;
    *(undefined8 *)(param_1 + 0x728) = *(undefined8 *)(param_1 + 0xe0);
    *(undefined8 *)(param_1 + 0x730) = *(undefined8 *)(param_1 + 0xd8);
    *(undefined4 *)(param_1 + 0x714) = 1;
  }
  else {
    if ((*(ulonglong *)(param_1 + 0x198) & 1) == 0) {
      uVar8 = *(ulonglong *)(param_1 + 0x1a0);
    }
    lVar10 = 0x1a0;
    if ((*(ulonglong *)(param_1 + 0x198) & 1) != 0) {
      lVar10 = 200;
    }
    iVar11 = 1;
    fVar19 = 0.0;
    fVar17 = 0.0;
    auVar18 = ZEXT864(0);
    iVar9 = 1;
    if (((uint)uVar8 & 0x110) == 0x110) {
      fVar19 = 0.0;
      lVar6 = FUN_140191040(param_1,*(undefined8 *)
                                     (param_1 + 200 + ((ulonglong)((uint)(uVar8 >> 9) & 1) | 6) * 8)
                            ,0);
      fVar17 = auVar18._0_4_;
      auVar16 = auVar20._0_16_;
      if (lVar6 != 0) {
        iVar11 = *(int *)(lVar6 + 0x14);
        if ((*(int *)(lVar6 + 0x28) == DAT_14030cab8) ||
           (iVar9 = *(int *)(lVar6 + 0x18), *(int *)(lVar6 + 0x28) == DAT_14030cabc)) {
          lVar6 = FUN_140189320();
          auVar16 = auVar20._0_16_;
          iVar11 = DAT_1403566c0;
          if (*(char *)(lVar6 + 0x28) != '\0') {
            iVar11 = 0x200;
          }
          fVar17 = ((float)(iVar11 + -0x200) * DAT_1402d2168) / (float)iVar11;
          iVar9 = DAT_1403566c4;
        }
      }
    }
    fVar13 = DAT_1402d1ed4;
    auVar16 = vminss_avx(auVar16,ZEXT416(DAT_1402d2c08));
    *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x10 + *(longlong *)(param_1 + 0x6f8)) =
         (float)*(byte *)(param_1 + 0xd0) * DAT_1402d1ed4;
    *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x14 + *(longlong *)(param_1 + 0x6f8)) =
         (float)*(byte *)(param_1 + 0xd1) * fVar13;
    *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x18 + *(longlong *)(param_1 + 0x6f8)) =
         (float)*(byte *)(param_1 + 0xd2) * fVar13;
    *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x1c + *(longlong *)(param_1 + 0x6f8)) =
         (float)*(byte *)(param_1 + 0xd3) * fVar13;
    fVar13 = DAT_1402d22d0;
    fVar14 = DAT_1402d1e98;
    *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x30 + *(longlong *)(param_1 + 0x6f8)) =
         (float)*(byte *)(param_1 + 0x2b0) * DAT_1402d1e98;
    *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x34 + *(longlong *)(param_1 + 0x6f8)) =
         (float)*(byte *)(param_1 + 0x2b1) * fVar14;
    *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x38 + *(longlong *)(param_1 + 0x6f8)) =
         (float)*(byte *)(param_1 + 0x2b2) * fVar14;
    *(undefined4 *)
     ((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x3c + *(longlong *)(param_1 + 0x6f8)) =
         0x3f800000;
    if ((*(byte *)(lVar10 + param_1) & 0x20) == 0) {
      fVar14 = fVar13;
    }
    else {
      fVar14 = fVar14 * param_5;
    }
    *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x2c + *(longlong *)(param_1 + 0x6f8)) =
         fVar14;
    fVar14 = DAT_1402d1fbc;
    fVar15 = *(float *)(param_1 + 0xd4);
    if (*(float *)(param_1 + 0xd4) == fVar19) {
      fVar15 = fVar13;
    }
    piVar12 = (int *)(param_1 + 0x708);
    if ((*(byte *)(param_1 + 200) & 7) == 6) {
      if ((*(uint *)(lVar10 + param_1) >> 8 & 1) == 0) {
        fVar13 = fVar13 / fVar15;
        fVar15 = fVar13 * *(float *)(param_1 + 0x730);
        fVar17 = fVar13 * *(float *)(param_1 + 0xd8);
        fVar19 = fVar13 * *(float *)(param_1 + 0x734);
        fVar13 = fVar13 * *(float *)(param_1 + 0xdc);
      }
      else {
        fVar15 = (fVar13 / (float)iVar11) *
                 (float)((uint)*(undefined8 *)(param_1 + 0x728) & 0x3fff) * DAT_1402d1fbc + fVar17;
        fVar17 = (fVar13 / (float)iVar11) *
                 (float)((uint)*(undefined8 *)(param_1 + 0xe0) & 0x3fff) * DAT_1402d1fbc + fVar17;
        fVar19 = (float)((uint)((ulonglong)*(undefined8 *)(param_1 + 0x728) >> 0x10) & 0x3fff) *
                 DAT_1402d1fbc * (fVar13 / (float)iVar9);
        fVar13 = (float)((uint)((ulonglong)*(undefined8 *)(param_1 + 0xe0) >> 0x10) & 0x3fff) *
                 DAT_1402d1fbc * (fVar13 / (float)iVar9);
      }
      if (*(int *)(param_1 + 0x70c) != 0) {
        *(undefined2 *)(*(longlong *)(param_1 + 0x700) + (longlong)*(int *)(param_1 + 0x70c) * 2) =
             0xffff;
        *(int *)(param_1 + 0x70c) = *(int *)(param_1 + 0x70c) + 1;
        *(undefined1 *)(param_1 + 0x710) = 1;
      }
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + *(longlong *)(param_1 + 0x6f8)) =
           fVar14 * *(float *)(param_1 + 0x718);
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 4 + *(longlong *)(param_1 + 0x6f8)) =
           fVar14 * *(float *)(param_1 + 0x71c);
      *(int *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 8 + *(longlong *)(param_1 + 0x6f8)) =
           auVar16._0_4_;
      *(undefined4 *)
       ((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0xc + *(longlong *)(param_1 + 0x6f8)) =
           0x3f800000;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x20 + *(longlong *)(param_1 + 0x6f8))
           = fVar15;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x24 + *(longlong *)(param_1 + 0x6f8))
           = fVar19;
      *(undefined2 *)(*(longlong *)(param_1 + 0x700) + (longlong)*(int *)(param_1 + 0x70c) * 2) =
           *(undefined2 *)(param_1 + 0x708);
      *(int *)(param_1 + 0x70c) = *(int *)(param_1 + 0x70c) + 1;
      iVar11 = *(int *)(param_1 + 0x708);
      lVar10 = *(longlong *)(param_1 + 0x6f8);
      *(int *)(param_1 + 0x708) = iVar11 + 1;
      lVar7 = (longlong)iVar11 * 0x40;
      lVar6 = ((longlong)iVar11 + 1) * 0x40;
      puVar1 = (undefined8 *)(lVar7 + lVar10);
      uVar3 = puVar1[1];
      uVar4 = puVar1[2];
      uVar5 = puVar1[3];
      puVar2 = (undefined8 *)(lVar6 + lVar10);
      *puVar2 = *puVar1;
      puVar2[1] = uVar3;
      puVar2[2] = uVar4;
      puVar2[3] = uVar5;
      puVar1 = (undefined8 *)(lVar7 + 0x20 + lVar10);
      uVar3 = puVar1[1];
      uVar4 = puVar1[2];
      uVar5 = puVar1[3];
      puVar2 = (undefined8 *)(lVar6 + 0x20 + lVar10);
      *puVar2 = *puVar1;
      puVar2[1] = uVar3;
      puVar2[2] = uVar4;
      puVar2[3] = uVar5;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + *(longlong *)(param_1 + 0x6f8)) =
           param_2 * fVar14;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x20 + *(longlong *)(param_1 + 0x6f8))
           = fVar17;
      *(undefined2 *)(*(longlong *)(param_1 + 0x700) + (longlong)*(int *)(param_1 + 0x70c) * 2) =
           *(undefined2 *)(param_1 + 0x708);
      iVar11 = *(int *)(param_1 + 0x708);
      *(int *)(param_1 + 0x70c) = *(int *)(param_1 + 0x70c) + 1;
      lVar10 = *(longlong *)(param_1 + 0x6f8);
      *(int *)(param_1 + 0x708) = iVar11 + 1;
      lVar7 = (longlong)iVar11 * 0x40;
      lVar6 = ((longlong)iVar11 + 1) * 0x40;
      puVar2 = (undefined8 *)(lVar7 + -0x40 + lVar10);
      uVar3 = puVar2[1];
      uVar4 = puVar2[2];
      uVar5 = puVar2[3];
      puVar1 = (undefined8 *)(lVar6 + lVar10);
      *puVar1 = *puVar2;
      puVar1[1] = uVar3;
      puVar1[2] = uVar4;
      puVar1[3] = uVar5;
      puVar1 = (undefined8 *)(lVar7 + -0x20 + lVar10);
      uVar3 = puVar1[1];
      uVar4 = puVar1[2];
      uVar5 = puVar1[3];
      puVar2 = (undefined8 *)(lVar6 + 0x20 + lVar10);
      *puVar2 = *puVar1;
      puVar2[1] = uVar3;
      puVar2[2] = uVar4;
      puVar2[3] = uVar5;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 4 + *(longlong *)(param_1 + 0x6f8)) =
           param_3 * fVar14;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x24 + *(longlong *)(param_1 + 0x6f8))
           = fVar13;
      *(undefined2 *)(*(longlong *)(param_1 + 0x700) + (longlong)*(int *)(param_1 + 0x70c) * 2) =
           *(undefined2 *)(param_1 + 0x708);
      *(int *)(param_1 + 0x70c) = *(int *)(param_1 + 0x70c) + 1;
      iVar11 = *(int *)(param_1 + 0x708);
      lVar10 = *(longlong *)(param_1 + 0x6f8);
      *(int *)(param_1 + 0x708) = iVar11 + 1;
      lVar6 = ((longlong)iVar11 + 1) * 0x40;
      lVar7 = (longlong)iVar11 * 0x40;
      puVar1 = (undefined8 *)(lVar7 + lVar10);
      uVar3 = puVar1[1];
      uVar4 = puVar1[2];
      uVar5 = puVar1[3];
      puVar2 = (undefined8 *)(lVar6 + lVar10);
      *puVar2 = *puVar1;
      puVar2[1] = uVar3;
      puVar2[2] = uVar4;
      puVar2[3] = uVar5;
      puVar1 = (undefined8 *)(lVar7 + 0x20 + lVar10);
      uVar3 = puVar1[1];
      uVar4 = puVar1[2];
      uVar5 = puVar1[3];
      puVar2 = (undefined8 *)(lVar6 + 0x20 + lVar10);
      *puVar2 = *puVar1;
      puVar2[1] = uVar3;
      puVar2[2] = uVar4;
      puVar2[3] = uVar5;
      *(undefined4 *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + *(longlong *)(param_1 + 0x6f8)) =
           *(undefined4 *)
            (((longlong)*(int *)(param_1 + 0x708) + -2) * 0x40 + *(longlong *)(param_1 + 0x6f8));
      *(undefined4 *)
       ((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x20 + *(longlong *)(param_1 + 0x6f8)) =
           *(undefined4 *)
            ((longlong)*(int *)(param_1 + 0x708) * 0x40 + -0x60 + *(longlong *)(param_1 + 0x6f8));
      *(undefined2 *)(*(longlong *)(param_1 + 0x700) + (longlong)*(int *)(param_1 + 0x70c) * 2) =
           *(undefined2 *)(param_1 + 0x708);
      *(int *)(param_1 + 0x70c) = *(int *)(param_1 + 0x70c) + 1;
      *(int *)(param_1 + 0x708) = *(int *)(param_1 + 0x708) + 1;
      *(undefined4 *)(param_1 + 0x714) = 0;
    }
    else {
      param_3 = param_3 * DAT_1402d1fbc;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + *(longlong *)(param_1 + 0x6f8)) =
           param_2 * DAT_1402d1fbc;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 4 + *(longlong *)(param_1 + 0x6f8)) =
           param_3;
      *(int *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 8 + *(longlong *)(param_1 + 0x6f8)) =
           auVar16._0_4_;
      *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0xc + *(longlong *)(param_1 + 0x6f8))
           = fVar15;
      lVar6 = (longlong)*(int *)(param_1 + 0x708) * 0x40;
      if ((*(uint *)(lVar10 + param_1) >> 8 & 1) == 0) {
        *(float *)(lVar6 + 0x20 + *(longlong *)(param_1 + 0x6f8)) =
             (fVar13 / fVar15) * *(float *)(param_1 + 0xd8);
        *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x24 +
                  *(longlong *)(param_1 + 0x6f8)) = (fVar13 / fVar15) * *(float *)(param_1 + 0xdc);
      }
      else {
        *(float *)(lVar6 + 0x20 + *(longlong *)(param_1 + 0x6f8)) =
             ((float)(*(uint *)(param_1 + 0xe0) & 0x3fff) * fVar14) / (float)iVar11 + fVar17;
        *(float *)((longlong)*(int *)(param_1 + 0x708) * 0x40 + 0x24 +
                  *(longlong *)(param_1 + 0x6f8)) =
             ((float)(*(uint *)(param_1 + 0xe0) >> 0x10 & 0x3fff) * fVar14) / (float)iVar9;
      }
      *(undefined2 *)(*(longlong *)(param_1 + 0x700) + (longlong)*(int *)(param_1 + 0x70c) * 2) =
           *(undefined2 *)piVar12;
      *(int *)(param_1 + 0x70c) = *(int *)(param_1 + 0x70c) + 1;
      *piVar12 = *piVar12 + 1;
    }
  }
  return;
}

