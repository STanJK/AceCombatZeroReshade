/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140191a00; RVA 0x191a00
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140191a00(longlong *param_1,uint param_2,int param_3,int param_4,int param_5,void *param_6,
                  int param_7,undefined4 param_8)

{
  char cVar1;
  uint uVar2;
  undefined8 *puVar3;
  ulonglong *puVar4;
  longlong lVar5;
  int iVar6;
  int iVar7;
  longlong lVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  uint *puVar19;
  uint uVar20;
  ulonglong *puVar21;
  bool bVar22;
  undefined4 local_res8;
  uint local_res10 [2];
  int local_res18;
  int local_res20;
  ulonglong local_138;
  undefined4 local_130;
  longlong *local_128;
  longlong lStack_120;
  longlong *local_118;
  longlong *local_110;
  longlong local_108;
  int local_100;
  uint local_f8;
  uint local_f4;
  uint local_f0 [2];
  longlong *local_e8;
  undefined8 uStack_e0;
  longlong *local_c8;
  uint uStack_c0;
  undefined4 uStack_bc;
  ulonglong local_b0;
  int local_a8;
  int iStack_a4;
  int iStack_a0;
  undefined4 uStack_9c;
  void *pvStack_98;
  int iStack_90;
  undefined4 uStack_8c;
  undefined1 local_88 [16];
  undefined1 local_78 [16];
  undefined1 local_68 [16];
  undefined1 local_58 [24];
  
  if (param_7 == 0x1b) {
    param_7 = 0x13;
  }
  else if (param_7 == 0x24) {
    param_7 = 0x14;
  }
  param_5 = param_5 << 4;
  local_res10[0] = param_2;
  local_res18 = param_3;
  local_res20 = param_4;
  iVar6 = FUN_140191720(param_3,param_4,param_5,param_7);
  plVar15 = (longlong *)
            (((((ulonglong)(param_2 >> 0x10 & 0xff) ^
               (((ulonglong)(byte)param_2 ^ 0xcbf29ce484222325) * 0x100000001b3 ^
               (ulonglong)(param_2 >> 8 & 0xff)) * 0x100000001b3) * 0x100000001b3 ^
              (ulonglong)(param_2 >> 0x18)) * 0x100000001b3 & param_1[7]) * 0x10 + param_1[4]);
  lVar8 = plVar15[1];
  if (lVar8 == param_1[2]) {
LAB_140191af7:
    lVar8 = 0;
  }
  else {
    uVar20 = *(uint *)(lVar8 + 0x10);
    while (param_2 != uVar20) {
      if (lVar8 == *plVar15) goto LAB_140191af7;
      lVar8 = *(longlong *)(lVar8 + 8);
      uVar20 = *(uint *)(lVar8 + 0x10);
    }
  }
  local_100 = iVar6;
  if (((((lVar8 != 0) && (lVar8 != param_1[2])) && (*(void **)(lVar8 + 0x28) == param_6)) &&
      ((*(int *)(lVar8 + 0x18) == param_3 && (*(int *)(lVar8 + 0x1c) == param_4)))) &&
     ((*(int *)(lVar8 + 0x20) == iVar6 &&
      ((*(int *)(lVar8 + 0x30) == param_7 &&
       (iVar7 = memcmp(param_6,(void *)((ulonglong)(param_2 << 8) + *param_1),(longlong)param_5),
       iVar7 == 0)))))) {
    return;
  }
  local_110 = (longlong *)0x0;
  local_108 = 0;
  plVar15 = operator_new(0x20);
  *plVar15 = (longlong)plVar15;
  plVar15[1] = (longlong)plVar15;
  plVar15[2] = (longlong)plVar15;
  *(undefined2 *)(plVar15 + 3) = 0x101;
  puVar12 = (undefined8 *)param_1[2];
  local_110 = plVar15;
  uVar20 = local_res10[0];
  for (puVar3 = (undefined8 *)*puVar12; puVar3 != puVar12; puVar3 = (undefined8 *)*puVar3) {
    uVar2 = *(uint *)(puVar3 + 2);
    if (uVar20 < *(int *)(puVar3 + 4) + uVar2) {
      if (uVar2 < iVar6 + uVar20) {
        local_c8 = (longlong *)plVar15[1];
        uStack_c0 = 0;
        plVar11 = plVar15;
        if (*(char *)((longlong)local_c8 + 0x19) == '\0') {
          plVar14 = local_c8;
          do {
            local_c8 = plVar14;
            bVar22 = uVar2 <= *(uint *)((longlong)local_c8 + 0x1c);
            if (bVar22) {
              plVar9 = local_c8;
              plVar11 = local_c8;
            }
            else {
              plVar9 = local_c8 + 2;
            }
            uStack_c0 = (uint)bVar22;
            plVar14 = (longlong *)*plVar9;
          } while (*(char *)(*plVar9 + 0x19) == '\0');
        }
        if (*(char *)((longlong)plVar11 + 0x19) == '\0') {
          if (*(uint *)((longlong)plVar11 + 0x1c) <= uVar2) goto LAB_140191c5c;
        }
        if (local_108 == 0x7ffffffffffffff) {
                    /* WARNING: Subroutine does not return */
          FUN_140183020();
        }
        puVar10 = operator_new(0x20);
        lStack_120 = CONCAT44(uStack_bc,uStack_c0);
        *(undefined4 *)((longlong)puVar10 + 0x1c) = *(undefined4 *)(puVar3 + 2);
        *puVar10 = plVar15;
        puVar10[1] = plVar15;
        puVar10[2] = plVar15;
        *(undefined2 *)(puVar10 + 3) = 0;
        local_128 = local_c8;
        FUN_140185940(&local_110,&local_128,puVar10);
        plVar15 = local_110;
        uVar20 = local_res10[0];
      }
    }
LAB_140191c5c:
  }
  local_118 = (longlong *)*plVar15;
  if (*(char *)((longlong)local_118 + 0x19) == '\0') {
LAB_140191c84:
    plVar15 = local_118;
    local_130 = *(uint *)((longlong)local_118 + 0x1c);
    uVar18 = (ulonglong)local_130;
    uVar17 = ((((ulonglong)(local_130 >> 8 & 0xff) ^
               (uVar18 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3) * 0x100000001b3 ^
              (ulonglong)(local_130 >> 0x10 & 0xff)) * 0x100000001b3 ^
             (ulonglong)(local_130 >> 0x18)) * 0x100000001b3 & param_1[0x17];
    lVar8 = *(longlong *)(param_1[0x14] + 8 + uVar17 * 0x10);
    if (lVar8 == param_1[0x12]) {
LAB_140191d11:
      lVar8 = 0;
    }
    else {
      uVar20 = *(uint *)(lVar8 + 0x10);
      while (local_130 != uVar20) {
        if (lVar8 == *(longlong *)(param_1[0x14] + uVar17 * 0x10)) goto LAB_140191d11;
        lVar8 = *(longlong *)(lVar8 + 8);
        uVar20 = *(uint *)(lVar8 + 0x10);
      }
    }
    local_b0 = uVar18;
    if ((lVar8 != 0) && (lVar8 != param_1[0x12])) {
      local_128 = (longlong *)0x0;
      lStack_120 = 0;
      local_128 = operator_new(0x28);
      *local_128 = (longlong)local_128;
      local_128[1] = (longlong)local_128;
      local_128[2] = (longlong)local_128;
      *(undefined2 *)(local_128 + 3) = 0x101;
      puVar4 = *(ulonglong **)(lVar8 + 0x20);
      for (puVar21 = *(ulonglong **)(lVar8 + 0x18); puVar21 != puVar4; puVar21 = puVar21 + 1) {
        local_138 = *puVar21;
        plVar11 = (longlong *)FUN_140196b10(param_1 + 9,local_78,&local_138);
        if (*(int *)(*(longlong *)(*plVar11 + 0x18) + 0x28) == -1) {
          FUN_1401965c0(&DAT_14033b060 + (longlong)DAT_14033b080 * 2,local_68,
                        *(longlong *)(*plVar11 + 0x18) + 0x10);
          uVar17 = ((((((((local_138 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                         local_138 >> 8 & 0xff) * 0x100000001b3 ^ local_138 >> 0x10 & 0xff) *
                        0x100000001b3 ^ local_138 >> 0x18 & 0xff) * 0x100000001b3 ^
                      local_138 >> 0x20 & 0xff) * 0x100000001b3 ^ local_138 >> 0x28 & 0xff) *
                     0x100000001b3 ^ local_138 >> 0x30 & 0xff) * 0x100000001b3 ^ local_138 >> 0x38)
                   * 0x100000001b3;
          puVar12 = (undefined8 *)(param_1[0xc] + (uVar17 & param_1[0xf]) * 0x10);
          plVar11 = (longlong *)puVar12[1];
          if (plVar11 == (longlong *)param_1[10]) {
LAB_140191e8c:
            plVar11 = (longlong *)0x0;
          }
          else if (local_138 != plVar11[2]) {
            do {
              if (plVar11 == (longlong *)*puVar12) goto LAB_140191e8c;
              plVar11 = (longlong *)plVar11[1];
            } while (local_138 != plVar11[2]);
          }
          if (plVar11 != (longlong *)0x0) {
            uVar17 = uVar17 & param_1[0xf];
            lVar8 = param_1[0xc];
            plVar9 = (longlong *)(lVar8 + 8 + uVar17 * 0x10);
            plVar13 = *(longlong **)(lVar8 + uVar17 * 0x10);
            plVar14 = (longlong *)(lVar8 + uVar17 * 0x10);
            if ((longlong *)*plVar9 == plVar11) {
              if (plVar13 == plVar11) {
                lVar8 = param_1[10];
                *plVar14 = lVar8;
                *plVar9 = lVar8;
              }
              else {
                *plVar9 = plVar11[1];
              }
            }
            else if (plVar13 == plVar11) {
              *plVar14 = *plVar11;
            }
            lVar8 = *plVar11;
            param_1[0xb] = param_1[0xb] + -1;
            *(longlong *)plVar11[1] = lVar8;
            *(longlong *)(lVar8 + 8) = plVar11[1];
            thunk_FUN_1402500f0(plVar11,0x20);
          }
          plVar11 = local_128;
          uVar20 = 0;
          local_e8 = (longlong *)local_128[1];
          plVar14 = local_128;
          if (*(char *)((longlong)local_e8 + 0x19) == '\0') {
            plVar9 = local_e8;
            do {
              local_e8 = plVar9;
              if (local_138 <= (ulonglong)local_e8[4]) {
                plVar13 = local_e8;
                plVar14 = local_e8;
              }
              else {
                plVar13 = local_e8 + 2;
              }
              uVar20 = (uint)(local_138 <= (ulonglong)local_e8[4]);
              plVar9 = (longlong *)*plVar13;
            } while (*(char *)(*plVar13 + 0x19) == '\0');
          }
          uStack_e0 = CONCAT44(uStack_bc,uVar20);
          if ((*(char *)((longlong)plVar14 + 0x19) != '\0') || (local_138 < (ulonglong)plVar14[4]))
          {
            if (lStack_120 == 0x666666666666666) {
                    /* WARNING: Subroutine does not return */
              FUN_140183020();
            }
            puVar12 = operator_new(0x28);
            puVar12[4] = local_138;
            *puVar12 = plVar11;
            puVar12[1] = plVar11;
            puVar12[2] = plVar11;
            *(undefined2 *)(puVar12 + 3) = 0;
            FUN_140185940(&local_128,&local_e8,puVar12);
          }
        }
      }
      local_e8 = (longlong *)*local_128;
      if (*(char *)((longlong)local_e8 + 0x19) == '\0') {
LAB_140191fd2:
        lVar8 = local_e8[4];
        puVar19 = &local_f8;
        local_f8 = (uint)lVar8 & 0x3fff;
        local_f4 = (uint)((ulonglong)lVar8 >> 0x20) & 0x3fff;
LAB_140192001:
        local_res8 = *puVar19;
        if (local_res8 != 0) {
          plVar15 = (longlong *)FUN_1401966e0(param_1 + 0x11,local_58,&local_res8);
          plVar15 = *(longlong **)(*plVar15 + 0x18);
          plVar11 = (longlong *)FUN_1401966e0(param_1 + 0x11,local_88,&local_res8);
          if (plVar15 != *(longlong **)(*plVar11 + 0x20)) {
            do {
              plVar11 = plVar15 + 1;
              if (*plVar15 == lVar8) {
                plVar14 = (longlong *)FUN_1401966e0(param_1 + 0x11,&local_a8,&local_res8);
                lVar5 = *plVar14;
                FUN_140277ba0(plVar15,plVar11,*(longlong *)(lVar5 + 0x20) - (longlong)plVar11);
                plVar15 = (longlong *)(lVar5 + 0x20);
                *plVar15 = *plVar15 + -8;
                plVar15 = (longlong *)FUN_1401966e0(param_1 + 0x11,&local_c8,&local_res8);
                if (*(longlong *)(*plVar15 + 0x20) == *(longlong *)(*plVar15 + 0x18)) {
                  uVar18 = (((((ulonglong)(local_res8 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3
                             ^ (ulonglong)local_res8._1_1_) * 0x100000001b3 ^
                            (ulonglong)local_res8._2_1_) * 0x100000001b3 ^
                           (ulonglong)local_res8._3_1_) * 0x100000001b3;
                  uVar17 = param_1[0x17] & uVar18;
                  plVar15 = *(longlong **)(param_1[0x14] + 8 + uVar17 * 0x10);
                  if (plVar15 == (longlong *)param_1[0x12]) goto LAB_140192191;
                  uVar20 = *(uint *)(plVar15 + 2);
                  goto joined_r0x000140192170;
                }
                break;
              }
              plVar14 = (longlong *)FUN_1401966e0(param_1 + 0x11,local_88,&local_res8);
              plVar15 = plVar11;
            } while (plVar11 != *(longlong **)(*plVar14 + 0x20));
          }
        }
        goto LAB_140192075;
      }
      goto LAB_14019226c;
    }
    goto LAB_1401922b1;
  }
LAB_1401923ff:
  FUN_140190400(param_1,uVar20,iVar6);
  FUN_140277ba0((ulonglong)(local_res10[0] << 8) + *param_1,param_6,(longlong)param_5);
  uStack_8c = param_8;
  pvStack_98 = param_6;
  local_a8 = param_3;
  iStack_a4 = param_4;
  iStack_a0 = iVar6;
  iStack_90 = param_7;
  plVar15 = (longlong *)FUN_140196fc0(param_1 + 1,&local_c8,local_res10);
  lVar8 = *plVar15;
  *(ulonglong *)(lVar8 + 0x18) = CONCAT44(iStack_a4,local_a8);
  *(ulonglong *)(lVar8 + 0x20) = CONCAT44(uStack_9c,iStack_a0);
  *(void **)(lVar8 + 0x28) = pvStack_98;
  *(ulonglong *)(lVar8 + 0x30) = CONCAT44(uStack_8c,iStack_90);
  cVar1 = *(char *)(local_110[1] + 0x19);
  plVar15 = (longlong *)local_110[1];
  while (cVar1 == '\0') {
    FUN_140197250(&local_110,&local_110,plVar15[2]);
    plVar11 = (longlong *)*plVar15;
    thunk_FUN_1402500f0(plVar15,0x20);
    plVar15 = plVar11;
    cVar1 = *(char *)((longlong)plVar11 + 0x19);
  }
  thunk_FUN_1402500f0(local_110,0x20);
  return;
joined_r0x000140192170:
  if (local_res8 == uVar20) goto LAB_140192193;
  if (plVar15 == *(longlong **)(param_1[0x14] + uVar17 * 0x10)) goto LAB_140192191;
  plVar15 = (longlong *)plVar15[1];
  uVar20 = *(uint *)(plVar15 + 2);
  goto joined_r0x000140192170;
LAB_140192191:
  plVar15 = (longlong *)0x0;
LAB_140192193:
  if (plVar15 != (longlong *)0x0) {
    lVar5 = param_1[0x14];
    uVar18 = param_1[0x17] & uVar18;
    plVar14 = (longlong *)(lVar5 + 8 + uVar18 * 0x10);
    plVar9 = *(longlong **)(lVar5 + uVar18 * 0x10);
    plVar11 = (longlong *)(lVar5 + uVar18 * 0x10);
    if ((longlong *)*plVar14 == plVar15) {
      if (plVar9 == plVar15) {
        lVar5 = param_1[0x12];
        *plVar11 = lVar5;
        *plVar14 = lVar5;
      }
      else {
        *plVar14 = plVar15[1];
      }
    }
    else if (plVar9 == plVar15) {
      *plVar11 = *plVar15;
    }
    lVar5 = *plVar15;
    param_1[0x13] = param_1[0x13] + -1;
    *(longlong *)plVar15[1] = lVar5;
    *(longlong *)(lVar5 + 8) = plVar15[1];
    FUN_14006cce0(plVar15 + 3);
    thunk_FUN_1402500f0(plVar15,0x30);
  }
LAB_140192075:
  puVar19 = puVar19 + 1;
  if (puVar19 == local_f0) goto code_r0x000140192087;
  goto LAB_140192001;
code_r0x000140192087:
  plVar15 = (longlong *)local_e8[2];
  if (*(char *)((longlong)plVar15 + 0x19) == '\0') {
    cVar1 = *(char *)(*plVar15 + 0x19);
    local_e8 = plVar15;
    plVar15 = (longlong *)*plVar15;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar15 + 0x19);
      local_e8 = plVar15;
      plVar15 = (longlong *)*plVar15;
    }
  }
  else {
    cVar1 = *(char *)(local_e8[1] + 0x19);
    plVar11 = (longlong *)local_e8[1];
    plVar15 = local_e8;
    while ((local_e8 = plVar11, cVar1 == '\0' && (plVar15 == (longlong *)local_e8[2]))) {
      cVar1 = *(char *)(local_e8[1] + 0x19);
      plVar11 = (longlong *)local_e8[1];
      plVar15 = local_e8;
    }
  }
  if (*(char *)((longlong)local_e8 + 0x19) != '\0') goto code_r0x00014019225e;
  goto LAB_140191fd2;
code_r0x00014019225e:
  plVar15 = local_118;
  uVar18 = local_b0;
LAB_14019226c:
  cVar1 = *(char *)(local_128[1] + 0x19);
  plVar11 = (longlong *)local_128[1];
  while (cVar1 == '\0') {
    FUN_14018ef40(&local_128,&local_128,plVar11[2]);
    plVar14 = (longlong *)*plVar11;
    thunk_FUN_1402500f0(plVar11,0x28);
    plVar11 = plVar14;
    cVar1 = *(char *)((longlong)plVar14 + 0x19);
  }
  thunk_FUN_1402500f0(local_128,0x28);
LAB_1401922b1:
  uVar17 = ((((uVar18 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (ulonglong)local_130._1_1_) *
             0x100000001b3 ^ (ulonglong)local_130._2_1_) * 0x100000001b3 ^
           (ulonglong)local_130._3_1_) * 0x100000001b3;
  uVar16 = param_1[7] & uVar17;
  plVar11 = *(longlong **)(param_1[4] + 8 + uVar16 * 0x10);
  if (plVar11 == (longlong *)param_1[2]) {
LAB_14019231e:
    plVar11 = (longlong *)0x0;
  }
  else {
    iVar6 = (int)plVar11[2];
    while ((int)uVar18 != iVar6) {
      if (plVar11 == *(longlong **)(param_1[4] + uVar16 * 0x10)) goto LAB_14019231e;
      plVar11 = (longlong *)plVar11[1];
      iVar6 = (int)plVar11[2];
    }
  }
  if (plVar11 != (longlong *)0x0) {
    lVar8 = param_1[4];
    uVar17 = param_1[7] & uVar17;
    plVar9 = (longlong *)(lVar8 + 8 + uVar17 * 0x10);
    plVar13 = *(longlong **)(lVar8 + uVar17 * 0x10);
    plVar14 = (longlong *)(lVar8 + uVar17 * 0x10);
    if ((longlong *)*plVar9 == plVar11) {
      if (plVar13 == plVar11) {
        lVar8 = param_1[2];
        *plVar14 = lVar8;
        *plVar9 = lVar8;
      }
      else {
        *plVar9 = plVar11[1];
      }
    }
    else if (plVar13 == plVar11) {
      *plVar14 = *plVar11;
    }
    lVar8 = *plVar11;
    param_1[3] = param_1[3] + -1;
    *(longlong *)plVar11[1] = lVar8;
    *(longlong *)(lVar8 + 8) = plVar11[1];
    thunk_FUN_1402500f0(plVar11,0x38);
  }
  local_118 = (longlong *)plVar15[2];
  if (*(char *)((longlong)local_118 + 0x19) == '\0') {
    cVar1 = *(char *)(*local_118 + 0x19);
    plVar15 = (longlong *)*local_118;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar15 + 0x19);
      local_118 = plVar15;
      plVar15 = (longlong *)*plVar15;
    }
  }
  else {
    cVar1 = *(char *)(plVar15[1] + 0x19);
    plVar11 = (longlong *)plVar15[1];
    while ((local_118 = plVar11, cVar1 == '\0' && (plVar15 == (longlong *)local_118[2]))) {
      cVar1 = *(char *)(local_118[1] + 0x19);
      plVar11 = (longlong *)local_118[1];
      plVar15 = local_118;
    }
  }
  if (*(char *)((longlong)local_118 + 0x19) != '\0') goto code_r0x0001401923ee;
  goto LAB_140191c84;
code_r0x0001401923ee:
  uVar20 = local_res10[0];
  param_3 = local_res18;
  param_4 = local_res20;
  iVar6 = local_100;
  goto LAB_1401923ff;
}

