/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140081e60; RVA 0x81e60
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_140081e60(longlong param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  float fVar5;
  
  *param_2 = 0x10000003;
  *(undefined4 *)(param_2 + 1) = 0;
  *(undefined4 *)(param_2 + 6) = 0;
  *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000003;
  *(undefined4 *)(param_2 + 2) = 2;
  *(undefined4 *)((longlong)param_2 + 0x14) = 0x10000000;
  param_2[3] = 0xe;
  *(undefined4 *)(param_2 + 4) = 0x310000a8;
  *(undefined4 *)((longlong)param_2 + 0x24) = 1;
  *(undefined4 *)(param_2 + 5) = 0x4f;
  *(undefined4 *)(param_2 + 7) = 0x4a;
  uVar3 = FUN_140083330(param_1 + 0x170,param_2 + 8);
  *(undefined4 *)(param_1 + 0x2d8) = *(undefined4 *)(*(longlong *)(param_1 + 0xd08) + 0x1c);
  *(undefined4 *)(param_1 + 0x2d0) = *(undefined4 *)(param_1 + 0xc90);
  *(undefined4 *)(param_1 + 0x2d4) = *(undefined4 *)(param_1 + 0xc94);
  *(longlong *)(param_1 + 0x268) = *(longlong *)(param_1 + 0xd08) + 0x18;
  *(longlong *)(param_1 + 0x270) = *(longlong *)(param_1 + 0xd08) + 0x28;
  *(undefined4 *)(param_1 + 0x2ac) = *(undefined4 *)(param_1 + 0xc98);
  *(undefined4 *)(param_1 + 0x2a8) = *(undefined4 *)(param_1 + 0xc9c);
  uVar3 = FUN_140203b30(param_1 + 0xb40,uVar3);
  puVar4 = (undefined8 *)
           FUN_140086520(param_1 + 0x250,uVar3,*(longlong *)(param_1 + 0xd08) + 0xf8,
                         *(longlong *)(param_1 + 0xd08) + 0xb8);
  if (*(char *)(param_1 + 0x7f1) == '\x01') {
    *(undefined4 *)(param_1 + 0x378) = *(undefined4 *)(*(longlong *)(param_1 + 0xd08) + 0x1c);
    *(undefined4 *)(param_1 + 0x370) = *(undefined4 *)(param_1 + 0x7cc);
    *(undefined4 *)(param_1 + 0x374) = *(undefined4 *)(param_1 + 2000);
    *(longlong *)(param_1 + 0x308) = *(longlong *)(param_1 + 0xd08) + 0x18;
    *(longlong *)(param_1 + 0x310) = *(longlong *)(param_1 + 0xd08) + 0x28;
    *(undefined4 *)(param_1 + 0x34c) = *(undefined4 *)(param_1 + 0x7d8);
    *(undefined4 *)(param_1 + 0x348) = *(undefined4 *)(param_1 + 0x7d4);
    uVar3 = FUN_140203b30(param_1 + 0xb40,puVar4);
    puVar4 = (undefined8 *)
             FUN_140086520(param_1 + 0x2f0,uVar3,*(longlong *)(param_1 + 0xd08) + 0xf8,
                           *(longlong *)(param_1 + 0xd08) + 0xb8);
  }
  fVar5 = 0.0;
  if (0.0 < *(float *)(param_1 + 0xccc)) {
    fVar5 = 0.0;
    uVar3 = FUN_140203b30(param_1 + 0xaf8,puVar4);
    *(undefined4 *)(param_1 + 0x3a0) = *(undefined4 *)(param_1 + 0xcc0);
    *(undefined4 *)(param_1 + 0x3a4) = *(undefined4 *)(param_1 + 0xcc4);
    *(undefined4 *)(param_1 + 0x39c) = *(undefined4 *)(param_1 + 0xcc8);
    *(undefined4 *)(param_1 + 0x398) = *(undefined4 *)(param_1 + 0xccc);
    puVar4 = (undefined8 *)
             FUN_14007db80(param_1 + 0x390,uVar3,*(longlong *)(param_1 + 0xd08) + 0xf8);
  }
  if ((*(int *)(param_1 + 0xcd0) != 0) && (fVar5 < *(float *)(param_1 + 0xcd4))) {
    uVar3 = FUN_140203b30(param_1 + 0xab0,puVar4);
    *(undefined4 *)(param_1 + 0x7b4) = *(undefined4 *)(param_1 + 0xcd0);
    *(undefined4 *)(param_1 + 0x7b8) = *(undefined4 *)(param_1 + 0xcd4);
    lVar2 = *(longlong *)(param_1 + 0xd08);
    uVar1 = *(undefined4 *)(lVar2 + 0x28c);
    *(undefined4 *)(param_1 + 0x7bc) = *(undefined4 *)(lVar2 + 0x288);
    *(undefined4 *)(param_1 + 0x7c0) = uVar1;
    puVar4 = (undefined8 *)FUN_140086170(param_1 + 0x3a8,uVar3,lVar2 + 0xf8);
  }
  *puVar4 = 0x10000002;
  *(undefined4 *)(puVar4 + 1) = 0;
  *(undefined4 *)((longlong)puVar4 + 0xc) = 0x50000002;
  *(undefined4 *)(puVar4 + 2) = 0x8001;
  *(undefined4 *)((longlong)puVar4 + 0x14) = 0x10000000;
  puVar4[3] = 0xe;
  puVar4[4] = 0x310000a8;
  *(undefined4 *)(puVar4 + 5) = 0x4f;
  *(undefined8 *)(param_1 + 0x938) = *(undefined8 *)(param_1 + 0xd08);
  *(undefined4 *)(param_1 + 0x940) = *(undefined4 *)(param_1 + 0xc90);
  *(undefined4 *)(param_1 + 0x944) = *(undefined4 *)(param_1 + 0xc94);
  if ((**(byte **)(param_1 + 0x7f8) & 4) == 0) {
    puVar4 = puVar4 + 6;
  }
  else {
    uVar3 = FUN_140203b30(param_1 + 0x8a0,puVar4 + 6);
    puVar4 = (undefined8 *)
             FUN_140073d10(param_1 + 0x7f8,*(undefined8 *)(*(longlong *)(param_1 + 0x938) + 0x280),
                           uVar3);
  }
  return puVar4;
}

