/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140202180; RVA 0x202180
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_140202180(longlong *param_1,int param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar2 = (longlong)(int)param_1[1] * 0x10 + *param_1;
  lVar3 = (longlong)param_2 * 0x10 + *param_1;
  if (*(undefined8 **)(DAT_14033acb8 + (ulonglong)(*(uint *)(lVar2 + 4) & 0x3fffffff) * 8) ==
      param_3) {
    return param_3;
  }
  uVar1 = *(undefined8 *)(DAT_14033acb8 + (ulonglong)(*(uint *)(lVar3 + 4) & 0x3fffffff) * 8);
  *param_3 = 0x20000000;
  FUN_140197b30(param_3,uVar1);
  param_3[1] = 0;
  *(undefined4 *)(lVar3 + 4) = *(undefined4 *)(lVar2 + 4);
  FUN_140197b30(lVar2,param_3 + 2);
  return param_3 + 2;
}

