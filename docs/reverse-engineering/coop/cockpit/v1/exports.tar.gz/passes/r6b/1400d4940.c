/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400d4940; RVA 0xd4940
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400d4940(longlong param_1,byte param_2)

{
  uint *puVar1;
  undefined8 *puVar2;
  byte *pbVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  longlong lVar9;
  char cVar10;
  int iVar11;
  undefined8 *puVar12;
  longlong lVar13;
  undefined8 in_stack_ffffffffffffffb8;
  undefined4 uVar14;
  undefined8 in_stack_ffffffffffffffc0;
  undefined4 uVar15;
  
  uVar14 = (undefined4)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20);
  uVar15 = (undefined4)((ulonglong)in_stack_ffffffffffffffc0 >> 0x20);
  iVar11 = 0;
  if (*(char *)(param_1 + 0xa87e4) != '\0') {
    lVar13 = 0;
    do {
      lVar9 = *(longlong *)(param_1 + 0xa8248);
      iVar11 = iVar11 + 1;
      pbVar3 = (byte *)(lVar13 + 0x1da7 + lVar9);
      *pbVar3 = *pbVar3 | 1;
      *(undefined8 *)(lVar13 + 0x1d78 + lVar9) = 0;
      lVar13 = lVar13 + 0x27a0;
    } while (iVar11 < (int)(uint)*(byte *)(param_1 + 0xa87e4));
  }
  if (param_2 == 0) {
    puVar1 = (uint *)(*(longlong *)(param_1 + 0x67158) + 0x50);
    *puVar1 = *puVar1 | 1;
    puVar1 = (uint *)(*(longlong *)(param_1 + 0x67158) + 0x50);
    *puVar1 = *puVar1 & 0xfffffffd;
  }
  else if (param_2 == 1) {
    puVar1 = (uint *)(*(longlong *)(param_1 + 0x67158) + 0x50);
    *puVar1 = *puVar1 & 0xfffffffe;
    puVar1 = (uint *)(*(longlong *)(param_1 + 0x67158) + 0x50);
    *puVar1 = *puVar1 | 2;
  }
  lVar13 = *(longlong *)(*(longlong *)(param_1 + 0xa8318) + 0x10);
  if (((((*(byte *)(param_1 + 0xa881d) < 3) && (lVar13 != 0)) &&
       (puVar12 = *(undefined8 **)(lVar13 + 0x2d8), puVar12 != (undefined8 *)0x0)) &&
      ((*(byte *)(lVar13 + 0x3c9) < *(byte *)*puVar12 &&
       (puVar2 = (undefined8 *)(puVar12[1] + (ulonglong)*(byte *)(lVar13 + 0x3c9) * 0x48),
       puVar2 != (undefined8 *)0x0)))) &&
     ((*(char *)*puVar2 == '\0' && (*(char *)(param_1 + 0xa8794) == '\x1c')))) {
    FUN_1400dfbc0(*(undefined8 *)(*(longlong *)(param_1 + 0x67158) + 0x270),
                  CONCAT71((int7)((ulonglong)puVar12 >> 8),1));
  }
  else {
    *(undefined1 *)(*(longlong *)(*(longlong *)(param_1 + 0x67158) + 0x270) + 0x10ca) = 0;
  }
  uVar8 = *(uint *)(lVar13 + 0x3a8);
  uVar4 = *(undefined4 *)(lVar13 + 0x364);
  uVar5 = *(undefined4 *)(lVar13 + 0x35c);
  puVar12 = *(undefined8 **)(*(longlong *)(param_1 + 0x67158) + 0x270);
  uVar6 = *(undefined4 *)(lVar13 + 0x360);
  uVar7 = *(undefined4 *)(lVar13 + 0x358);
  *(bool *)(puVar12 + 0x219) = (uVar8 >> 0x17 & 1) != 0;
  if ((uVar8 >> 0x17 & 1) != 0) {
    *(undefined4 *)((longlong)puVar12 + 0x1404) = uVar7;
    *(undefined4 *)(puVar12 + 0x281) = uVar6;
    *(undefined4 *)((longlong)puVar12 + 0x140c) = uVar5;
    *(undefined4 *)(puVar12 + 0x282) = uVar4;
  }
  lVar9 = *(longlong *)(*(longlong *)(param_1 + 0xa8318) + 0x10);
  if (((lVar9 == 0) || (puVar12 = *(undefined8 **)(lVar9 + 0x2d8), puVar12 == (undefined8 *)0x0)) ||
     ((*(byte *)*puVar12 <= *(byte *)(lVar9 + 0x3c9) ||
      (puVar2 = (undefined8 *)(puVar12[1] + (ulonglong)*(byte *)(lVar9 + 0x3c9) * 0x48),
      puVar2 == (undefined8 *)0x0)))) {
    cVar10 = -1;
  }
  else {
    cVar10 = *(char *)*puVar2;
  }
  FUN_1400ad6f0(*(undefined8 *)(*(longlong *)(param_1 + 0x67158) + 0x270),
                CONCAT71((int7)((ulonglong)puVar12 >> 8),cVar10 == '\x04'),
                *(undefined4 *)(lVar13 + 0x90),*(undefined4 *)(lVar13 + 0x98),
                CONCAT44(uVar14,*(undefined4 *)(lVar13 + 0xa0)),
                CONCAT44(uVar15,*(undefined4 *)(lVar13 + 0xa8)));
  (**(code **)(**(longlong **)(param_1 + 0x67158) + 0x68))
            (*(longlong **)(param_1 + 0x67158),param_2,*(undefined1 *)(param_1 + 0xa8796),
             (ulonglong)param_2 * 0x27a0 + *(longlong *)(param_1 + 0xa8248),param_1 + 0x697b8,
             param_1 + 0x69798,*(undefined4 *)(lVar13 + 0x348),*(undefined4 *)(lVar13 + 0x34c),
             *(undefined4 *)(lVar13 + 0x350),*(undefined4 *)(lVar13 + 0x354),
             (byte)((uint)*(undefined4 *)(param_1 + 0xa8790) >> 0x1f));
  FUN_1400d4180(param_1,param_2,*(undefined4 *)(*(longlong *)(param_1 + 0x67158) + 0x54));
  return;
}

