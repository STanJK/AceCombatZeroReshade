/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401fe9c0; RVA 0x1fe9c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401fe9c0(void)

{
  short sVar1;
  short sVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined4 uVar5;
  longlong lVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  byte bVar12;
  bool bVar13;
  undefined8 uVar14;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined4 local_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined4 local_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  
  lVar6 = DAT_14032c8b8;
  puVar10 = *(undefined8 **)(DAT_14032c8b8 + 0xc0);
  if (puVar10 != (undefined8 *)0x0) {
    *puVar10 = 0x70000001;
    FUN_140197b30(puVar10,0);
    *(undefined4 *)(puVar10 + 1) = 0;
    *(undefined4 *)((longlong)puVar10 + 0xc) = 0x50000001;
    puVar10[2] = 0x8000;
    puVar10[3] = 0;
    *(undefined8 **)(lVar6 + 0xc0) = puVar10 + 4;
  }
  puVar10 = *(undefined8 **)(lVar6 + 200);
  if (puVar10 != (undefined8 *)0x0) {
    *puVar10 = 0x70000001;
    FUN_140197b30(puVar10,0);
    puVar10[1] = 0;
    puVar10[2] = 0x8000;
    puVar10[3] = 0;
    *(undefined8 **)(lVar6 + 200) = puVar10 + 4;
  }
  uVar8 = *(uint *)(lVar6 + 0xd0);
  if ((uVar8 & 1) != 0) {
    if ((uVar8 & 2) != 0) {
      *(undefined2 *)(lVar6 + 0xe4) = *(undefined2 *)(lVar6 + 0xf0);
      *(undefined2 *)(lVar6 + 0xe6) = *(undefined2 *)(lVar6 + 0xf2);
      *(undefined2 *)(lVar6 + 0xe8) = *(undefined2 *)(lVar6 + 0xf4);
      *(undefined2 *)(lVar6 + 0xea) = *(undefined2 *)(lVar6 + 0xf6);
      *(undefined2 *)(lVar6 + 0xec) = *(undefined2 *)(lVar6 + 0xf8);
      *(undefined2 *)(lVar6 + 0xee) = *(undefined2 *)(lVar6 + 0xfa);
    }
    if ((uVar8 & 4) != 0) {
      *(undefined2 *)(lVar6 + 0xfc) = *(undefined2 *)(lVar6 + 0x104);
      *(undefined2 *)(lVar6 + 0xfe) = *(undefined2 *)(lVar6 + 0x106);
      *(undefined2 *)(lVar6 + 0x100) = *(undefined2 *)(lVar6 + 0x108);
      *(undefined2 *)(lVar6 + 0x102) = *(undefined2 *)(lVar6 + 0x10a);
    }
    uVar8 = uVar8 & 0xfffffffe | 0x20;
    *(uint *)(lVar6 + 0xd0) = uVar8;
  }
  if ((uVar8 & 2) != 0) {
    uVar8 = uVar8 & 0xfffffffd;
    *(undefined2 *)(lVar6 + 0xe4) = *(undefined2 *)(lVar6 + 0xf0);
    *(undefined2 *)(lVar6 + 0xe6) = *(undefined2 *)(lVar6 + 0xf2);
    *(undefined2 *)(lVar6 + 0xe8) = *(undefined2 *)(lVar6 + 0xf4);
    *(undefined2 *)(lVar6 + 0xea) = *(undefined2 *)(lVar6 + 0xf6);
    *(undefined2 *)(lVar6 + 0xec) = *(undefined2 *)(lVar6 + 0xf8);
    *(undefined2 *)(lVar6 + 0xee) = *(undefined2 *)(lVar6 + 0xfa);
    *(uint *)(lVar6 + 0xd0) = uVar8;
  }
  if ((uVar8 & 4) != 0) {
    uVar8 = uVar8 & 0xfffffffb;
    *(undefined2 *)(lVar6 + 0xfc) = *(undefined2 *)(lVar6 + 0x104);
    *(undefined2 *)(lVar6 + 0xfe) = *(undefined2 *)(lVar6 + 0x106);
    *(undefined2 *)(lVar6 + 0x100) = *(undefined2 *)(lVar6 + 0x108);
    *(undefined2 *)(lVar6 + 0x102) = *(undefined2 *)(lVar6 + 0x10a);
    *(uint *)(lVar6 + 0xd0) = uVar8;
  }
  if ((uVar8 & 0x10) != 0) {
    *(uint *)(lVar6 + 0xd0) = uVar8 & 0xffffffef;
  }
  puVar10 = *(undefined8 **)(lVar6 + (0x17 - (ulonglong)*(byte *)(lVar6 + 0xdf)) * 8);
  if ((*(byte *)(lVar6 + 0xd4) & 0x40) != 0) {
    *puVar10 = 0x1000000a;
    FUN_140197b30(puVar10,0);
    *(undefined4 *)(puVar10 + 1) = 0;
    puVar11 = puVar10 + 0x16;
    *(undefined4 *)((longlong)puVar10 + 0xc) = 0x5000000a;
    *(undefined4 *)(puVar10 + 2) = 9;
    *(undefined4 *)((longlong)puVar10 + 0x14) = 0x10000000;
    puVar10[3] = 0xe;
    *(undefined4 *)(puVar10 + 4) = 0;
    *(undefined4 *)(puVar10 + 5) = 0x4a;
    sVar1 = *(short *)(lVar6 + 0xe6);
    iVar7 = *(short *)(lVar6 + 0xe8) + 0x3f;
    sVar2 = *(short *)(lVar6 + 0xe4);
    *(undefined4 *)((longlong)puVar10 + 0x34) = 0;
    *(undefined4 *)(puVar10 + 7) = 0x4c;
    *(int *)(puVar10 + 6) =
         ((int)((iVar7 >> 0x1f & 0x3fU) + iVar7) >> 6 | (int)sVar1 << 8) << 0x10 |
         (int)((int)sVar2 + ((int)sVar2 >> 0x1f & 0x1fU)) >> 5;
    iVar9 = DAT_1403566cc + -1;
    iVar7 = DAT_1403566c8 + -1;
    *(undefined4 *)(puVar10 + 9) = 0x40;
    *(int *)(puVar10 + 8) = iVar7 * 0x10000;
    *(int *)((longlong)puVar10 + 0x44) = iVar9 * 0x10000;
    iVar7 = (*(short *)(lVar6 + 0xec) * DAT_1403566c8) / DAT_1403566c0;
    iVar9 = (((int)*(short *)(lVar6 + 0xee) + *(int *)(lVar6 + 0x1c)) * DAT_1403566cc) /
            DAT_1403566c4;
    *(undefined4 *)(lVar6 + 0x1c) = 0;
    *(int *)(puVar10 + 10) = (0x80 - iVar7) * 0x10;
    *(int *)((longlong)puVar10 + 0x54) = (0x100 - iVar9) * 0x10;
    *(undefined4 *)(puVar10 + 0xb) = 0x18;
    *(undefined4 *)(puVar10 + 0xc) = 0x1000000;
    *(undefined4 *)((longlong)puVar10 + 100) = 1;
    *(undefined4 *)(puVar10 + 0xd) = 0x4e;
    *(undefined4 *)(puVar10 + 0xe) = 0x30003;
    *(undefined4 *)(puVar10 + 0xf) = 0x47;
    puVar10[0x10] = 0x60;
    *(undefined4 *)(puVar10 + 0x11) = 0x14;
    sVar1 = *(short *)(lVar6 + 0x100);
    sVar2 = *(short *)(lVar6 + 0x102);
    *(undefined4 *)(puVar10 + 0x13) = 8;
    *(uint *)(puVar10 + 0x12) = (sVar1 + -1) * 0x4000 | 10;
    *(undefined4 *)(puVar10 + 0x14) = 1;
    *(int *)((longlong)puVar10 + 0x94) = sVar2 * 4 + -4;
    *(undefined4 *)(puVar10 + 0x15) = 0x1a;
    if ((*(uint *)(lVar6 + 0xd0) & 0x100) != 0) {
      *puVar11 = 0x10000002;
      FUN_140197b30(puVar11);
      *(undefined4 *)(puVar10 + 0x17) = 0;
      *(undefined4 *)((longlong)puVar10 + 0xbc) = 0x50000002;
      *(undefined4 *)(puVar10 + 0x18) = 1;
      *(undefined4 *)((longlong)puVar10 + 0xc4) = 0x10000000;
      puVar10[0x19] = 0xe;
      *(uint *)((longlong)puVar10 + 0xd4) = (uint)*(byte *)(lVar6 + 0x10f);
      *(undefined4 *)(puVar10 + 0x1a) = 100;
      *(undefined4 *)(puVar10 + 0x1b) = 0x42;
      puVar11 = puVar10 + 0x1c;
      if (DAT_14030f270 == 0) {
        uVar8 = *DAT_14033da48;
        plVar3 = *(longlong **)(DAT_14033da48 + 4);
        uVar4 = (ulonglong)((uVar8 - 1) + DAT_14033da48[0x3c]) % (ulonglong)DAT_14033da48[0x3c];
        local_78 = *(undefined8 *)(DAT_14033da48 + uVar4 * 2 + 0x12);
        local_68 = 0;
        uStack_60 = 0;
        uStack_58 = 0;
        uStack_50 = 0;
        local_70 = 0;
        local_48 = *(undefined8 *)(DAT_14033da48 + (ulonglong)uVar8 * 2 + 0x12);
        local_38 = 0;
        uStack_30 = 0;
        uStack_28 = 0;
        uStack_20 = 0;
        local_40 = 0;
        uStack_b0 = *(undefined8 *)(DAT_14033da48 + (ulonglong)uVar8 * 2 + 0x12);
        local_b8 = 0;
        uStack_a8 = 0x4ffffffff;
        uStack_a0 = 0x400;
        uStack_90 = *(undefined8 *)(DAT_14033da48 + uVar4 * 2 + 0x12);
        local_98 = 0;
        uStack_88 = 0xffffffff;
        uStack_80 = 0x800;
        (**(code **)(*plVar3 + 0xd0))(plVar3,2,&local_b8);
        (**(code **)(*plVar3 + 0x80))(plVar3,&local_48,0,0,0,&local_78,0);
        uStack_b0 = *(undefined8 *)(DAT_14033da48 + (ulonglong)*DAT_14033da48 * 2 + 0x12);
        local_b8 = 0;
        uStack_a8 = 0x400ffffffff;
        uStack_a0 = 4;
        uStack_90 = *(undefined8 *)
                     (DAT_14033da48 +
                     ((ulonglong)((DAT_14033da48[0x3c] - 1) + *DAT_14033da48) %
                     (ulonglong)DAT_14033da48[0x3c]) * 2 + 0x12);
        local_98 = 0;
        uStack_88 = 0x800ffffffff;
        uStack_80 = 0;
        (**(code **)(*plVar3 + 0xd0))(plVar3,2,&local_b8);
      }
    }
    *puVar11 = 0x10000003;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((longlong)puVar11 + 0xc) = 0x50000003;
    *(undefined4 *)(puVar11 + 2) = 1;
    *(undefined4 *)((longlong)puVar11 + 0x14) = 0x44000000;
    puVar11[3] = 0xf610;
    if ((*(uint *)(lVar6 + 0xd0) & 0x100) == 0) {
      *(undefined4 *)(puVar11 + 4) = 0x16;
    }
    else {
      *(undefined4 *)(puVar11 + 4) = 0x56;
      *(uint *)(lVar6 + 0xd0) = *(uint *)(lVar6 + 0xd0) & 0xfffffeff;
    }
    uVar5 = *(undefined4 *)(lVar6 + 0x10c);
    *(undefined4 *)((longlong)puVar11 + 0x2c) = 0x3f800000;
    *(undefined4 *)(puVar11 + 5) = uVar5;
    sVar1 = *(short *)(lVar6 + 0xfe);
    iVar7 = *(short *)(lVar6 + 0x100) + 0x3f;
    sVar2 = *(short *)(lVar6 + 0xfc);
    *(undefined4 *)((longlong)puVar11 + 0x34) = 6;
    *(uint *)(puVar11 + 6) =
         (((int)sVar1 | 0xa80U) << 6 | (int)(iVar7 + (iVar7 >> 0x1f & 0x3fU)) >> 6) << 0xe |
         (int)sVar2;
    puVar11[8] = 0x10000003;
    FUN_140197b30(puVar11 + 8,0);
    *(undefined4 *)(puVar11 + 9) = 0;
    *(undefined4 *)((longlong)puVar11 + 0x4c) = 0x50000003;
    *(undefined4 *)(puVar11 + 10) = 1;
    *(undefined4 *)((longlong)puVar11 + 0x54) = 0x44000000;
    puVar11[0xb] = 0x4242;
    puVar11[0xc] = 0;
    puVar11[0xd] = 0x10000800;
    *(undefined4 *)(puVar11 + 0xe) = 0x3f800000;
    *(undefined4 *)((longlong)puVar11 + 0x74) = 0x3f800000;
    iVar9 = DAT_1403566cc * 0x10;
    iVar7 = DAT_1403566c8 * 0x10;
    *(undefined4 *)((longlong)puVar11 + 0x7c) = 0;
    *(uint *)(puVar11 + 0xf) = (iVar9 + 0x1000) * 0x10000 | iVar7 + 0x800U;
    puVar10 = puVar11 + 0x10;
  }
  *puVar10 = 0x10000009;
  *(undefined4 *)(puVar10 + 1) = 0;
  *(undefined4 *)((longlong)puVar10 + 0xc) = 0x50000009;
  *(undefined4 *)(puVar10 + 2) = 0x8008;
  *(undefined4 *)((longlong)puVar10 + 0x14) = 0x10000000;
  puVar10[3] = 0xe;
  sVar1 = *(short *)(lVar6 + 0xfe);
  iVar7 = *(short *)(lVar6 + 0x100) + 0x3f;
  sVar2 = *(short *)(lVar6 + 0xfc);
  *(undefined4 *)((longlong)puVar10 + 0x24) = 0;
  *(undefined4 *)(puVar10 + 5) = 0x4c;
  *(int *)(puVar10 + 4) =
       ((int)((iVar7 >> 0x1f & 0x3fU) + iVar7) >> 6 | (int)sVar1 << 8) << 0x10 |
       (int)((int)sVar2 + ((int)sVar2 >> 0x1f & 0x1fU)) >> 5;
  sVar1 = *(short *)(lVar6 + 0x102);
  sVar2 = *(short *)(lVar6 + 0x100);
  *(undefined4 *)(puVar10 + 7) = 0x40;
  *(int *)(puVar10 + 6) = (sVar2 + -1) * 0x10000;
  puVar10[8] = 0;
  *(undefined4 *)(puVar10 + 9) = 0x18;
  *(undefined4 *)(puVar10 + 10) = 0x1000000;
  *(undefined4 *)((longlong)puVar10 + 0x54) = 1;
  *(undefined4 *)(puVar10 + 0xb) = 0x4e;
  *(undefined4 *)(puVar10 + 0xc) = 0x30003;
  *(undefined4 *)(puVar10 + 0xd) = 0x47;
  *(int *)((longlong)puVar10 + 0x34) = (sVar1 + -1) * 0x10000;
  sVar1 = *(short *)(lVar6 + 0x100);
  sVar2 = *(short *)(lVar6 + 0x102);
  *(undefined4 *)(puVar10 + 0xf) = 8;
  *(uint *)(puVar10 + 0xe) = (sVar1 + -1) * 0x4000 | 10;
  *(undefined4 *)(puVar10 + 0x10) = 0;
  *(int *)((longlong)puVar10 + 0x74) = sVar2 * 4 + -4;
  *(undefined4 *)(puVar10 + 0x11) = 0x49;
  *(undefined4 *)(puVar10 + 0x12) = 1;
  *(undefined4 *)(puVar10 + 0x13) = 0x1a;
  puVar10[0x14] = 0x70000000;
  puVar10[0x15] = 0;
  if ((*(uint *)(lVar6 + 0xd0) & 0x20) == 0) {
    uVar14 = FUN_14018f920((int)sVar2,
                           *(undefined8 *)(lVar6 + 0xa0 + (ulonglong)*(byte *)(lVar6 + 0xdf) * 8));
    FUN_14018f920(uVar14,*(undefined8 *)(lVar6 + (0x17 - (ulonglong)*(byte *)(lVar6 + 0xdf)) * 8));
  }
  else {
    *(uint *)(lVar6 + 0xd0) = *(uint *)(lVar6 + 0xd0) & 0xffffffdf;
  }
  bVar12 = 1 - *(char *)(lVar6 + 0xdf);
  bVar13 = DAT_14030f270 == 0;
  *(byte *)(lVar6 + 0xdf) = bVar12;
  *(undefined8 *)(lVar6 + 0xc0) = *(undefined8 *)(lVar6 + 0xa0 + (ulonglong)bVar12 * 8);
  *(undefined8 *)(lVar6 + 200) = *(undefined8 *)(lVar6 + 0xb0 + (ulonglong)bVar12 * 8);
  lVar6 = DAT_14031cf20;
  if (bVar13) {
    *(uint *)(DAT_14031cf20 + 0xa8) = *(uint *)(DAT_14031cf20 + 0xa8) ^ 1;
  }
  iVar7 = DAT_14030cac4;
  *(undefined8 *)(lVar6 + 0xac) = 0;
  if (iVar7 != -1) {
    FUN_14020e490();
  }
  DAT_14030cac4 = 0xffffffff;
  DAT_140326f84 = 0;
  if (DAT_14033ac60 != 0) {
    (**(code **)(*DAT_14033bcb8 + 8))();
    while (DAT_14033ac60 != 0) {
      (**(code **)(*DAT_14033bca8 + 0x10))(DAT_14033bca8,DAT_14033bcb8);
      (**(code **)(*DAT_14033bcb8 + 0x10))();
      (**(code **)(*DAT_14033bcb8 + 8))();
    }
    (**(code **)(*DAT_14033bcb8 + 0x10))();
  }
  if (DAT_140356728 != DAT_140356730) {
    DAT_140356730 = DAT_140356728;
  }
  FUN_14020c280();
  if (DAT_14032c93c == '\0') {
    FUN_14020b9c0();
    FUN_14018fa80();
  }
  return;
}

