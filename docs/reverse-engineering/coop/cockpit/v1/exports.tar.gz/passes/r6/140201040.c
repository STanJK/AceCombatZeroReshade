/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140201040; RVA 0x201040
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140201040(longlong param_1,undefined8 param_2)

{
  int iVar1;
  longlong *plVar2;
  
  iVar1 = *(int *)(param_1 + 0x48);
  *(int *)(param_1 + 0x48) = iVar1 + 1;
  *(undefined8 *)(param_1 + 0x10 + (longlong)iVar1 * 8) = param_2;
  plVar2 = *(longlong **)(param_1 + 8 + (longlong)*(int *)(param_1 + 0x48) * 8);
                    /* WARNING: Could not recover jumptable at 0x000140201062. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + 8))(plVar2,param_1);
  return;
}

