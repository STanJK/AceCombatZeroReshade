/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140201070; RVA 0x201070
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140201070(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  int iVar3;
  
  (**(code **)(**(longlong **)(param_1 + 8 + (longlong)*(int *)(param_1 + 0x48) * 8) + 0x10))();
  iVar1 = *(int *)(param_1 + 0x48);
  iVar3 = iVar1 + -1;
  *(int *)(param_1 + 0x48) = iVar3;
  if (iVar3 < 0) {
    return;
  }
  plVar2 = *(longlong **)(param_1 + (longlong)iVar1 * 8);
                    /* WARNING: Could not recover jumptable at 0x0001402010a5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + 0x18))(plVar2,param_1);
  return;
}

