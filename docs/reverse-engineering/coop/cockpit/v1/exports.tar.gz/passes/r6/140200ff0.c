/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140200ff0; RVA 0x200ff0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140200ff0(longlong param_1,undefined8 param_2)

{
  longlong *plVar1;
  
  (**(code **)(**(longlong **)(param_1 + 8 + (longlong)*(int *)(param_1 + 0x48) * 8) + 0x10))();
  *(undefined8 *)(param_1 + 8 + (longlong)*(int *)(param_1 + 0x48) * 8) = param_2;
  plVar1 = *(longlong **)(param_1 + 8 + (longlong)*(int *)(param_1 + 0x48) * 8);
                    /* WARNING: Could not recover jumptable at 0x000140201031. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 8))(plVar1,param_1);
  return;
}

