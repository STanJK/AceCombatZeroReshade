/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400bbe00; RVA 0xbbe00
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_1400bbe00(longlong param_1)

{
  byte bVar1;
  undefined8 uVar2;
  
  bVar1 = *(byte *)(param_1 + 0x25);
  if ((bVar1 & 1) != 0) {
    return 0;
  }
  if ((bVar1 & 2) != 0) {
    return 1;
  }
  if ((bVar1 & 4) != 0) {
    return 2;
  }
  if ((bVar1 & 8) != 0) {
    return 3;
  }
  uVar2 = 0xff;
  if ((bVar1 & 0x10) != 0) {
    uVar2 = 4;
  }
  return uVar2;
}

