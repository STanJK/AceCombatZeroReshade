/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400bbc50; RVA 0xbbc50
 * Ghidra-generated research pseudocode, inferred types, not original source. */

ulonglong FUN_1400bbc50(longlong param_1,char param_2,char param_3,char param_4,char param_5,
                       char param_6)

{
  byte bVar1;
  byte bVar2;
  ulonglong in_RAX;
  byte bVar3;
  short sVar4;
  ulonglong uVar5;
  
  uVar5 = 0;
  if ((*(byte *)(param_1 + 0x22) & 2) != 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  if ((((param_2 == '\0') && (param_3 == '\0')) && (param_4 == '\0')) && (param_5 == '\0')) {
    return 0;
  }
  bVar3 = *(byte *)(param_1 + 0x23);
  sVar4 = -1;
  if ((*(byte *)(param_1 + 0x22) & 1) == 0) {
    if ((bVar3 & 1) == 0) {
      *(byte *)(param_1 + 0x23) = bVar3 & 0xf9 | 1;
      *(ushort *)(param_1 + 0x20) =
           ((ushort)*(byte *)(param_1 + 0x24) + (ushort)*(byte *)(param_1 + 0x24) * 4) * 2;
      goto LAB_1400bbdc8;
    }
  }
  else {
    *(undefined2 *)(param_1 + 0x20) = 0;
    bVar3 = bVar3 & 0xf9 | 1;
  }
  bVar3 = bVar3 & 0xf;
  uVar5 = 1;
  if (param_2 == '\0') {
    if (param_3 == '\0') {
      if (param_4 == '\0') {
        if (param_5 != '\0') {
          bVar3 = bVar3 | 0x84;
          bVar2 = *(byte *)(param_1 + 0x25) & 0x9f;
          if (param_6 == '\0') {
            bVar2 = bVar2 | 0x20;
            sVar4 = 0xfc;
          }
          else {
            bVar2 = bVar2 | 0x40;
            sVar4 = 0xfd;
          }
          *(byte *)(param_1 + 0x25) = bVar2;
        }
      }
      else {
        bVar2 = *(byte *)(param_1 + 0x25);
        bVar3 = bVar3 | 0x40;
        if ((bVar2 & 4) == 0) {
          bVar1 = 0x10;
          if ((bVar2 & 8) == 0) {
            bVar1 = 4;
          }
          *(byte *)(param_1 + 0x25) = bVar2 & 0xe0 | bVar1;
          sVar4 = 0xfb;
        }
        else {
          *(byte *)(param_1 + 0x25) = bVar2 & 0xe0 | 8;
          sVar4 = 0xfb;
        }
      }
    }
    else {
      *(byte *)(param_1 + 0x25) = *(byte *)(param_1 + 0x25) & 0xe2;
      sVar4 = 0xfb;
      *(byte *)(param_1 + 0x25) = *(byte *)(param_1 + 0x25) | 2;
      bVar3 = bVar3 | 0x20;
    }
  }
  else {
    *(byte *)(param_1 + 0x25) = *(byte *)(param_1 + 0x25) & 0xe1;
    sVar4 = 0xfb;
    *(byte *)(param_1 + 0x25) = *(byte *)(param_1 + 0x25) | 1;
    bVar3 = bVar3 | 0x10;
  }
  *(ushort *)(param_1 + 0x20) = (ushort)*(byte *)(param_1 + 0x24);
  *(byte *)(param_1 + 0x23) = bVar3 | 2;
  if (sVar4 == -1) {
    return 1;
  }
LAB_1400bbdc8:
  FUN_1401c56d0();
  FUN_1401c6150();
  return uVar5;
}

