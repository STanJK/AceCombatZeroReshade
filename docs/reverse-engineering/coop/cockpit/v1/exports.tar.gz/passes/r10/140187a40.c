/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140187a40; RVA 0x187a40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

uchar FUN_140187a40(ulonglong context_or_unused,uchar logical_slot,uchar action)

{
  longlong lVar1;
  byte bVar2;
  char cVar3;
  longlong lVar4;
  ulonglong uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  longlong lVar10;
  
  uVar5 = (ulonglong)logical_slot;
  if (*(char *)(uVar5 + 0x2b6 + context_or_unused) == -1) {
    return '\0';
  }
  lVar4 = *(longlong *)(context_or_unused + uVar5 * 8);
  lVar10 = ((longlong)*(char *)(lVar4 + 0x2e) + uVar5 * 4) * 0x2a;
  lVar1 = lVar10 + (ulonglong)action;
  bVar2 = *(byte *)(lVar1 + 0x160 + context_or_unused);
  if (bVar2 == 1) {
    cVar3 = *(char *)(lVar1 + 0x10 + context_or_unused);
    if (cVar3 == -1) {
      return '\0';
    }
    uVar8 = (int)cVar3 >> 0x1f & 0x1f;
    uVar6 = (int)cVar3 + uVar8;
    uVar6 = *(uint *)(lVar4 + 0x38 + (longlong)((int)uVar6 >> 5) * 4) >>
            ((uVar6 & 0x1f) - uVar8 & 0x1f);
  }
  else {
    cVar3 = *(char *)(lVar10 + (ulonglong)action + 0x161 + context_or_unused);
    if (cVar3 == '\x01') {
      iVar9 = 0;
      if (bVar2 == 0) {
        return '\x01';
      }
      while( true ) {
        cVar3 = *(char *)((int)((uint)action + iVar9) + lVar10 + 0x10 + context_or_unused);
        uVar6 = (uint)cVar3;
        if (cVar3 == -1) {
          return '\0';
        }
        uVar8 = uVar6 & 0x1f;
        if ((int)uVar6 < 0) {
          uVar6 = uVar6 + 0x1f;
          uVar8 = uVar8 - 0x20;
        }
        if ((*(uint *)(lVar4 + 0x38 + (longlong)((int)uVar6 >> 5) * 4) >> (uVar8 & 0x1f) & 1) == 0)
        break;
        iVar9 = iVar9 + 1;
        if ((int)(uint)bVar2 <= iVar9) {
          return '\x01';
        }
      }
      return '\0';
    }
    uVar6 = (uint)bVar2;
    if (cVar3 == '\x02') {
      iVar9 = 0;
      if (uVar6 == 0) {
        return '\0';
      }
      while( true ) {
        cVar3 = *(char *)((int)((uint)action + iVar9) + lVar10 + 0x10 + context_or_unused);
        uVar8 = (uint)cVar3;
        if (cVar3 == -1) {
          return '\0';
        }
        uVar7 = uVar8 & 0x1f;
        if ((int)uVar8 < 0) {
          uVar8 = uVar8 + 0x1f;
          uVar7 = uVar7 - 0x20;
        }
        if ((*(uint *)(lVar4 + 0x38 + (longlong)((int)uVar8 >> 5) * 4) >> (uVar7 & 0x1f) & 1) != 0)
        break;
        iVar9 = iVar9 + 1;
        if ((int)uVar6 <= iVar9) {
          return '\0';
        }
      }
      return '\x01';
    }
    if (cVar3 != '\x03') {
      return '\0';
    }
    iVar9 = 1;
    if (1 < uVar6) {
      do {
        cVar3 = *(char *)((int)((uint)action + iVar9) + lVar10 + 0x10 + context_or_unused);
        uVar8 = (uint)cVar3;
        if (cVar3 == -1) {
          return '\0';
        }
        uVar7 = uVar8 & 0x1f;
        if ((int)uVar8 < 0) {
          uVar8 = uVar8 + 0x1f;
          uVar7 = uVar7 - 0x20;
        }
        if ((*(uint *)(lVar4 + 0x38 + (longlong)((int)uVar8 >> 5) * 4) >> (uVar7 & 0x1f) & 1) != 0)
        {
          return '\0';
        }
        iVar9 = iVar9 + 1;
      } while (iVar9 < (int)uVar6);
    }
    cVar3 = *(char *)(lVar1 + 0x10 + context_or_unused);
    if (cVar3 == -1) {
      return '\0';
    }
    uVar8 = (int)cVar3 >> 0x1f & 0x1f;
    uVar6 = (int)cVar3 + uVar8;
    uVar6 = *(uint *)(lVar4 + 0x38 + (longlong)((int)uVar6 >> 5) * 4) >>
            ((uVar6 & 0x1f) - uVar8 & 0x1f);
  }
  if ((uVar6 & 1) == 0) {
    return '\0';
  }
  return '\x01';
}

