/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401b8c40; RVA 0x1b8c40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1401b8c40(longlong param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  uint *puVar3;
  byte *pbVar4;
  ushort *puVar5;
  undefined8 uVar6;
  undefined1 uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong lVar10;
  uint uVar11;
  int iVar12;
  longlong *plVar13;
  longlong lVar14;
  int iVar15;
  longlong lVar16;
  longlong unaff_GS_OFFSET;
  
  *(uint *)(param_1 + 0xa8790) = *(uint *)(param_1 + 0xa8790) | 4;
  uVar11 = 0;
  if (*(char *)(param_1 + 0xa87e4) != '\0') {
    do {
      lVar10 = *(longlong *)(param_1 + 0xa8248);
      lVar16 = (ulonglong)uVar11 * 0x27a0;
      *(undefined4 *)(lVar10 + 0x70 + lVar16) = *(undefined4 *)(lVar10 + 0x20d0 + lVar16);
      *(undefined4 *)(lVar10 + 0x74 + lVar16) = *(undefined4 *)(lVar10 + 0x20d4 + lVar16);
      *(undefined4 *)(lVar10 + 0x78 + lVar16) = *(undefined4 *)(lVar10 + 0x20d8 + lVar16);
      *(undefined4 *)(lVar10 + 0x7c + lVar16) = *(undefined4 *)(lVar10 + 0x20dc + lVar16);
      *(undefined4 *)(lVar10 + 0x80 + lVar16) = *(undefined4 *)(lVar10 + 0x20e0 + lVar16);
      *(undefined4 *)(lVar10 + 0x84 + lVar16) = *(undefined4 *)(lVar10 + 0x20e4 + lVar16);
      *(undefined4 *)(lVar10 + 0x88 + lVar16) = *(undefined4 *)(lVar10 + 0x20e8 + lVar16);
      *(undefined4 *)(lVar10 + 0x8c + lVar16) = *(undefined4 *)(lVar10 + 0x20ec + lVar16);
      FUN_1401b5680(lVar10 + 0x1430 + lVar16,lVar10 + 0x2100 + lVar16);
      FUN_1401b6130(lVar10 + 0xc08 + lVar16,lVar10 + 0x2538 + lVar16);
      puVar1 = (undefined8 *)(lVar10 + 0x2680 + lVar16);
      uVar9 = puVar1[1];
      uVar6 = *(undefined8 *)(lVar10 + 0x2690 + lVar16);
      uVar8 = *(undefined4 *)(lVar10 + 0x2718 + lVar16);
      *(undefined1 *)(lVar10 + 0x2094 + lVar16) = *(undefined1 *)(lVar10 + 0x271c + lVar16);
      *(undefined1 *)(lVar10 + 0x272c + lVar16) = *(undefined1 *)(lVar10 + 0x271d + lVar16);
      *(undefined1 *)(lVar10 + 0x272d + lVar16) = *(undefined1 *)(lVar10 + 0x271e + lVar16);
      *(undefined1 *)(lVar10 + 0x272e + lVar16) = *(undefined1 *)(lVar10 + 0x271f + lVar16);
      *(undefined1 *)(lVar10 + 0x2099 + lVar16) = *(undefined1 *)(lVar10 + 0x2723 + lVar16);
      *(undefined1 *)(lVar10 + 0x209a + lVar16) = *(undefined1 *)(lVar10 + 0x2724 + lVar16);
      *(undefined1 *)(lVar10 + 0x209c + lVar16) = *(undefined1 *)(lVar10 + 0x2721 + lVar16);
      uVar7 = *(undefined1 *)(lVar10 + 0x2722 + lVar16);
      puVar2 = (undefined8 *)(lVar10 + 0x1f08 + lVar16);
      *puVar2 = *puVar1;
      puVar2[1] = uVar9;
      puVar1 = (undefined8 *)(lVar10 + 0x2698 + lVar16);
      uVar9 = puVar1[1];
      *(undefined1 *)(lVar10 + 0x209d + lVar16) = uVar7;
      *(undefined8 *)(lVar10 + 0x1f18 + lVar16) = uVar6;
      uVar6 = *(undefined8 *)(lVar10 + 0x26a8 + lVar16);
      puVar2 = (undefined8 *)(lVar10 + 0x1f20 + lVar16);
      *puVar2 = *puVar1;
      puVar2[1] = uVar9;
      *(undefined4 *)(lVar10 + 0x2058 + lVar16) = uVar8;
      *(undefined8 *)(lVar10 + 0x1f30 + lVar16) = uVar6;
      puVar1 = (undefined8 *)(lVar10 + 0x26b0 + lVar16);
      uVar9 = puVar1[1];
      uVar6 = *(undefined8 *)(lVar10 + 0x26c0 + lVar16);
      puVar2 = (undefined8 *)(lVar10 + 0x1f38 + lVar16);
      *puVar2 = *puVar1;
      puVar2[1] = uVar9;
      *(undefined8 *)(lVar10 + 0x1f48 + lVar16) = uVar6;
      puVar1 = (undefined8 *)(lVar10 + 0x26c8 + lVar16);
      uVar6 = puVar1[1];
      puVar2 = (undefined8 *)(lVar10 + 0x1f50 + lVar16);
      *puVar2 = *puVar1;
      puVar2[1] = uVar6;
      *(undefined8 *)(lVar10 + 0x1f60 + lVar16) = *(undefined8 *)(lVar10 + 0x26d8 + lVar16);
      puVar1 = (undefined8 *)(lVar10 + 0x26e0 + lVar16);
      uVar6 = puVar1[1];
      puVar2 = (undefined8 *)(lVar10 + 0x1f68 + lVar16);
      *puVar2 = *puVar1;
      puVar2[1] = uVar6;
      *(undefined8 *)(lVar10 + 0x1f78 + lVar16) = *(undefined8 *)(lVar10 + 0x26f0 + lVar16);
      puVar1 = (undefined8 *)(lVar10 + 0x26f8 + lVar16);
      uVar6 = puVar1[1];
      puVar2 = (undefined8 *)(lVar10 + 0x1f80 + lVar16);
      *puVar2 = *puVar1;
      puVar2[1] = uVar6;
      *(undefined8 *)(lVar10 + 0x1f90 + lVar16) = *(undefined8 *)(lVar10 + 0x2708 + lVar16);
      *(undefined4 *)(lVar10 + 0x1640 + lVar16) = *(undefined4 *)(lVar10 + 10000 + lVar16);
      *(undefined4 *)(lVar10 + 0x1848 + lVar16) = *(undefined4 *)(lVar10 + 0x2714 + lVar16);
      *(undefined4 *)(lVar10 + 0x1818 + lVar16) = *(undefined4 *)(lVar10 + 0x20f0 + lVar16);
      *(undefined4 *)(lVar10 + 0x181c + lVar16) = *(undefined4 *)(lVar10 + 0x20f4 + lVar16);
      *(undefined4 *)(lVar10 + 0x1820 + lVar16) = *(undefined4 *)(lVar10 + 0x20f8 + lVar16);
      *(undefined4 *)(lVar10 + 0x1824 + lVar16) = *(undefined4 *)(lVar10 + 0x20fc + lVar16);
      lVar10 = *(longlong *)(param_1 + 0xa8248);
      uVar7 = *(undefined1 *)(lVar10 + 0x271c + lVar16);
      *(undefined1 *)(lVar10 + 0x2094 + lVar16) = uVar7;
      *(undefined1 *)(lVar10 + 0x1da6 + lVar16) = uVar7;
      puVar3 = (uint *)(*(longlong *)(param_1 + 0xa8248) + 0x2058 + lVar16);
      *puVar3 = *puVar3 & 0xffffffef;
      lVar10 = *(longlong *)(param_1 + 0xa8248);
      pbVar4 = (byte *)(lVar10 + 0x1863 + lVar16);
      *pbVar4 = *pbVar4 & 0xfe;
      *(undefined4 *)(lVar10 + 0x185c + lVar16) = 0;
      lVar10 = *(longlong *)(param_1 + 0xa8248);
      pbVar4 = (byte *)(lVar10 + 0x1da7 + lVar16);
      *pbVar4 = *pbVar4 & 0xfe;
      *(undefined8 *)(lVar10 + 0x1d78 + lVar16) = 0;
      puVar3 = (uint *)(*(longlong *)(param_1 + 0xa8248) + 0x2058 + lVar16);
      *puVar3 = *puVar3 & 0xffffffdf;
      puVar3 = (uint *)(*(longlong *)(param_1 + 0xa8248) + 0x2058 + lVar16);
      *puVar3 = *puVar3 & 0xffefffff;
      lVar10 = *(longlong *)(param_1 + 0xa8248);
      puVar3 = (uint *)(lVar10 + 0x2058 + lVar16);
      *puVar3 = *puVar3 | 2;
      puVar5 = (ushort *)(lVar10 + 0x1c20 + lVar16);
      *puVar5 = *puVar5 | 0x40;
      FUN_1401040c0(*(longlong *)(param_1 + 0xa8248) + lVar16,uVar11 & 0xff,param_1 + 0x6a130);
      uVar11 = uVar11 + 1;
    } while (uVar11 < *(byte *)(param_1 + 0xa87e4));
  }
  iVar15 = 0;
  if (*(char *)(param_1 + 0x697ec) != '\0') {
    lVar10 = *(longlong *)(param_1 + 0x697b8);
    lVar16 = 0;
    do {
      iVar12 = 0;
      *(undefined4 *)(*(longlong *)(lVar10 + lVar16) + 0x120) =
           *(undefined4 *)(*(longlong *)(lVar10 + lVar16) + 0x16c);
      lVar10 = *(longlong *)(param_1 + 0x697b8);
      if (0 < *(int *)(*(longlong *)(lVar10 + lVar16) + 0x118)) {
        do {
          FUN_140119610((longlong)iVar12 * 0x520 +
                        *(longlong *)(*(longlong *)(lVar16 + lVar10) + 0x110));
          lVar10 = *(longlong *)(param_1 + 0x697b8);
          iVar12 = iVar12 + 1;
        } while (iVar12 < *(int *)(*(longlong *)(lVar10 + lVar16) + 0x118));
      }
      iVar15 = iVar15 + 1;
      lVar16 = lVar16 + 8;
    } while (iVar15 < (int)(uint)*(byte *)(param_1 + 0x697ec));
  }
  _DAT_140326f90 = _DAT_140326f90 & 0xfffe;
  *(longlong *)(param_1 + 0x67120) = param_1 + 0x240;
  FUN_140277ba0(param_1 + 0x6a288,param_1 + 0x6a830,0x580);
  *(undefined4 *)(param_1 + 0x6a808) = *(undefined4 *)(param_1 + 0x6adb0);
  *(undefined4 *)(param_1 + 0x6a80c) = *(undefined4 *)(param_1 + 0x6adb4);
  *(undefined4 *)(param_1 + 0x6a810) = *(undefined4 *)(param_1 + 0x6adb8);
  *(undefined4 *)(param_1 + 0x6a814) = *(undefined4 *)(param_1 + 0x6adbc);
  *(undefined4 *)(param_1 + 0x6a818) = *(undefined4 *)(param_1 + 0x6adc0);
  *(undefined4 *)(param_1 + 0x6a820) = *(undefined4 *)(param_1 + 0x6adc8);
  *(undefined2 *)(param_1 + 0x6a824) = *(undefined2 *)(param_1 + 0x6adcc);
  FUN_140277ba0(param_1 + 0x6ae08,param_1 + 0x6b530,0x700);
  *(undefined4 *)(param_1 + 0x6b508) = *(undefined4 *)(param_1 + 0x6bc30);
  *(undefined8 *)(param_1 + 0x6b514) = 0xffffffffffffffff;
  *(undefined2 *)(param_1 + 0x6b51c) = 0xffff;
  *(undefined4 *)(param_1 + 0x6b510) = 0;
  (*(code *)**(undefined8 **)(param_1 + 0x819a0))(param_1 + 0x819a0);
  (*(code *)**(undefined8 **)(param_1 + 0x82870))();
  FUN_140277ba0(param_1 + 0x6bc40,param_1 + 0x89ed0,0x1e280);
  *(undefined1 *)(param_1 + 0x89ec0) = *(undefined1 *)(param_1 + 0xa8150);
  lVar10 = **(longlong **)(unaff_GS_OFFSET + 0x58);
  if (*(int *)(lVar10 + 4) < DAT_1437dad18) {
    FUN_14022d540(&DAT_1437dad18);
    if (DAT_1437dad18 == -1) {
      _DAT_1437daef0 = 0;
      _DAT_1437daee0 = _DAT_1402d3500;
      uRam00000001437daee8 = _UNK_1402d3508;
      DAT_1437daef4 = 0;
      _Init_thread_footer(&DAT_1437dad18);
    }
  }
  if (*(int *)(lVar10 + 4) < DAT_1437daf04) {
    FUN_14022d540(&DAT_1437daf04);
    if (DAT_1437daf04 == -1) {
      FUN_1401c93c0();
      _Init_thread_footer(&DAT_1437daf04);
    }
  }
  FUN_1401cb090(&DAT_1437daf20);
  if (*(int *)(lVar10 + 4) < DAT_1437daf04) {
    FUN_14022d540(&DAT_1437daf04);
    if (DAT_1437daf04 == -1) {
      FUN_1401c93c0();
      _Init_thread_footer(&DAT_1437daf04);
    }
  }
  DAT_1437dece0 = DAT_1437dece0 | 1;
  plVar13 = *(longlong **)(param_1 + 0x697b8);
  if (plVar13 != plVar13 + *(byte *)(param_1 + 0x697ec)) {
    do {
      lVar16 = *plVar13;
      iVar15 = 0;
      if (0 < *(int *)(lVar16 + 0x118)) {
        do {
          FUN_140115a70((longlong)iVar15 * 0x520 + *(longlong *)(lVar16 + 0x110));
          iVar15 = iVar15 + 1;
        } while (iVar15 < *(int *)(lVar16 + 0x118));
      }
      plVar13 = plVar13 + 1;
    } while (plVar13 !=
             (longlong *)
             (*(longlong *)(param_1 + 0x697b8) + (ulonglong)*(byte *)(param_1 + 0x697ec) * 8));
  }
  uVar11 = 0;
  if (*(char *)(param_1 + 0xa87e4) != '\0') {
    do {
      lVar14 = (ulonglong)uVar11 * 0x27a0;
      FUN_14010e220(*(longlong *)(param_1 + 0xa8248) + lVar14,0);
      puVar3 = (uint *)(*(longlong *)(param_1 + 0xa8248) + 0x2058 + lVar14);
      *puVar3 = *puVar3 | 0x200;
      (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0xa8248) + 0x1fa8 + lVar14) + 8))();
      FUN_1400b95a0(*(longlong *)(param_1 + 0xa8248) + 0x1868 + lVar14);
      lVar16 = *(longlong *)(param_1 + 0xa8248);
      *(undefined4 *)(lVar16 + 0x2084 + lVar14) = 0;
      (**(code **)**(undefined8 **)(lVar16 + 0x1fa8 + lVar14))();
      uVar11 = uVar11 + 1;
    } while (uVar11 < *(byte *)(param_1 + 0xa87e4));
  }
  lVar16 = *(longlong *)(*(longlong *)(param_1 + 0xa8318) + 0x10);
  *(uint *)(lVar16 + 0x3c4) = (uint)*(byte *)(lVar16 + 0x3d1);
  if (((*(longlong *)(param_1 + 0x67138) != 0) && (*(byte *)(param_1 + 0xa8829) < 2)) &&
     (lVar16 = (longlong)(char)*(byte *)(param_1 + 0xa8829) * 0xd10 +
               *(longlong *)(param_1 + 0x67138), lVar16 != 0)) {
    lVar14 = FUN_140019ef0();
    *(undefined4 *)(lVar16 + 0xc80) = *(undefined4 *)(lVar14 + 0x1c);
  }
  if (*(int *)(lVar10 + 4) < DAT_1437daf04) {
    FUN_14022d540(&DAT_1437daf04);
    if (DAT_1437daf04 == -1) {
      FUN_1401c93c0();
      _Init_thread_footer(&DAT_1437daf04);
    }
  }
  FUN_1401cb010(&DAT_1437daf20,param_1 + 0x671c8);
  return;
}

