/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400d03a0; RVA 0xd03a0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_1400d03a0(longlong param_1)

{
  undefined1 auVar1 [32];
  undefined1 uVar2;
  byte bVar3;
  longlong *plVar4;
  code *pcVar5;
  undefined1 auVar6 [16];
  int iVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  ulonglong context_or_unused;
  longlong lVar11;
  longlong lVar12;
  undefined8 uVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  undefined1 auVar17 [16];
  float fVar18;
  undefined1 auVar19 [16];
  undefined4 uVar20;
  undefined4 uVar21;
  undefined1 auVar22 [64];
  undefined1 auVar23 [64];
  float fVar24;
  
  uVar13 = 0;
  lVar10 = *(longlong *)(param_1 + 0xa8248);
  if ((*(uint *)(param_1 + 0xa87c0) == 0) || ((*(uint *)(param_1 + 0xa87c0) & 1) == 0)) {
    FUN_140189320();
  }
  lVar8 = FUN_140189320();
  auVar17 = vpcmpeqd_avx(ZEXT416((uint)*(byte *)(lVar8 + 0x28)),SUB6416(ZEXT464(0),0));
  auVar17 = vblendvps_avx(ZEXT416(DAT_1402d2940),ZEXT416(DAT_1402d2950),auVar17);
  auVar23 = ZEXT1664(auVar17);
  uVar21 = auVar17._0_4_;
  auVar17 = vpcmpeqd_avx(ZEXT416((uint)*(byte *)(lVar8 + 0x28)),SUB6416(ZEXT464(0),0));
  auVar17 = vblendvps_avx(ZEXT416(DAT_1402d2928),ZEXT416(DAT_1402d293c),auVar17);
  auVar22 = ZEXT1664(auVar17);
  if (*(char *)(param_1 + 0xa87d8) == '\0') {
    *(uint *)(lVar10 + 0x2058) = *(uint *)(lVar10 + 0x2058) | 0x10;
    FUN_1400c5070(lVar10,1);
    uVar21 = auVar23._0_4_;
    *(undefined2 *)(*(longlong *)(*(longlong *)(lVar10 + 0x1fc0) + 0x66ee0) + 0x336d4) = 1;
  }
  else {
    if (*(char *)(param_1 + 0xa87d9) != '\0') {
      *(char *)(param_1 + 0xa87d9) = '\0';
      *(uint *)(lVar10 + 0x2058) = *(uint *)(lVar10 + 0x2058) & 0xffffffef;
      FUN_1400c5070(lVar10,2);
      uVar21 = auVar23._0_4_;
    }
    *(undefined2 *)(*(longlong *)(*(longlong *)(lVar10 + 0x1fc0) + 0x66ee0) + 0x336d4) = 2;
  }
  *(undefined4 *)(lVar10 + 0x1640) = 0;
  *(byte *)(lVar10 + 0x1863) = *(byte *)(lVar10 + 0x1863) | 1;
  *(undefined4 *)(lVar10 + 0x185c) = 0;
  *(undefined8 *)(lVar10 + 0x1d78) = 0;
  *(byte *)(lVar10 + 0x1da7) = *(byte *)(lVar10 + 0x1da7) | 1;
  *(uint *)(lVar10 + 0x2058) = *(uint *)(lVar10 + 0x2058) | 0x20;
  uVar20 = auVar22._0_4_;
  *(undefined4 *)(lVar10 + 0x1d64) = uVar20;
  *(undefined4 *)(lVar10 + 0x1d68) = uVar21;
  *(undefined4 *)(lVar10 + 0x1d6c) = uVar20;
  *(undefined4 *)(lVar10 + 0x1bd0) = uVar20;
  *(uint *)(param_1 + 0xa8790) = *(uint *)(param_1 + 0xa8790) & 0xfffffffb;
  FUN_140080620((longlong)*(char *)(param_1 + 0xa8829) * 0xd10 + *(longlong *)(param_1 + 0x67138));
  FUN_14007b080((longlong)*(char *)(param_1 + 0xa8829) * 0x1c8 + *(longlong *)(param_1 + 0x67140));
  *(uint *)(lVar10 + 0x2058) = *(uint *)(lVar10 + 0x2058) & 0xfffffffd;
  *(ushort *)(lVar10 + 0x1c20) = *(ushort *)(lVar10 + 0x1c20) & 0xffbf;
  lVar8 = FUN_140189320();
  if (*(char *)(lVar8 + 0x32) != '\0') {
    FUN_1400781c0(param_1 + 0x69598 + (longlong)*(char *)(param_1 + 0xa8829) * 0x18,
                  param_1 + 0x68f72,param_1 + 0x240);
  }
  FUN_140036fe0(*(undefined8 *)(param_1 + 0x67120));
  context_or_unused = param_1 + 0x697b8;
  FUN_140136540(context_or_unused,param_1 + 0xa87a0,*(undefined1 *)(param_1 + 0xa87e0));
  if (*(char *)(param_1 + 0xa87d8) == '\0') {
    lVar8 = param_1 + 0x69850;
    if (*(int *)(param_1 + 0xa87d0) == 0) {
      DAT_1437da3b0 = *(float *)(param_1 + 0x69880);
      DAT_1437da3b4 = *(float *)(param_1 + 0x69884);
      DAT_1437da3b8 = *(float *)(param_1 + 0x69888);
      _DAT_1437da3bc = *(undefined4 *)(param_1 + 0x6988c);
      fVar18 = *(float *)(param_1 + 0x69890);
      fVar24 = *(float *)(param_1 + 0x69894);
      uVar21 = *(undefined4 *)(param_1 + 0x69898);
      _DAT_1437da3ac = *(undefined4 *)(param_1 + 0x6989c);
      _DAT_1437da3a0 = fVar18;
      _DAT_1437da3a4 = fVar24;
      _DAT_1437da3a8 = uVar21;
      fVar14 = FUN_140187ec0(context_or_unused,'\0','\x1b');
      fVar15 = FUN_140187ec0(context_or_unused,'\0','\x19');
      fVar24 = (fVar15 - fVar14) * DAT_1402d1ff8 + fVar24;
      _DAT_1437da3a4 = fVar24;
      fVar14 = FUN_140187ec0(context_or_unused,'\0','\x1d');
      fVar15 = FUN_140187ec0(context_or_unused,'\0','\x1f');
      fVar18 = (fVar15 - fVar14) * DAT_1402d1ff8 + fVar18;
      _DAT_1437da3a0 = fVar18;
      *(undefined4 *)(param_1 + 0x6989c) = 0;
      *(float *)(param_1 + 0x69890) = fVar18;
      *(float *)(param_1 + 0x69894) = fVar24;
      *(undefined4 *)(param_1 + 0x69898) = uVar21;
      fVar18 = FUN_140187ec0(context_or_unused,'\0','\x16');
      fVar24 = FUN_140187ec0(context_or_unused,'\0','\x15');
      fVar18 = (fVar24 - fVar18) * DAT_1402d2508;
      uVar21 = 0;
      fVar24 = 0.0;
      if ((char)DAT_14032c8c0[0x10] == -1) {
        fVar14 = 0.0;
      }
      else {
        lVar10 = *DAT_14032c8c0;
        lVar12 = (longlong)*(char *)(lVar10 + 0x2e) * 0x1b;
        fVar14 = (float)*(byte *)((ulonglong)*(byte *)(lVar12 + 0x1a + (longlong)DAT_14032c8c0) +
                                 lVar10) * DAT_1402d1f94;
        bVar3 = *(byte *)((ulonglong)*(byte *)(lVar12 + 0x1b + (longlong)DAT_14032c8c0) + lVar10);
        context_or_unused = (ulonglong)bVar3;
        fVar24 = (float)bVar3 * DAT_1402d1f94;
      }
      fVar14 = fVar14 - fVar24;
      fVar15 = DAT_1402d2508;
      fVar24 = FUN_140187ec0(context_or_unused,'\0','\x13');
      fVar16 = FUN_140187ec0(context_or_unused,'\0','\x14');
      fVar15 = (fVar16 - fVar24) * fVar15;
      auVar1 = *(undefined1 (*) [32])(param_1 + 0x698a0);
      auVar19 = auVar1._0_16_;
      auVar17 = vshufps_avx(auVar19,auVar19,0x55);
      auVar6 = vshufps_avx(auVar19,auVar19,0xaa);
      auVar19 = vshufps_avx(auVar19,auVar19,0xff);
      DAT_1437da3b0 =
           auVar6._0_4_ * fVar15 + fVar18 * auVar1._0_4_ + auVar17._0_4_ * fVar14 + auVar19._0_4_ +
           DAT_1437da3b0;
      auVar19 = auVar1._16_16_;
      auVar17 = vshufps_avx(auVar19,auVar19,0x55);
      auVar6 = vshufps_avx(auVar19,auVar19,0xaa);
      auVar19 = vshufps_avx(auVar19,auVar19,0xff);
      fVar24 = fVar15 * auVar6._0_4_ + auVar1._16_4_ * fVar18 + auVar17._0_4_ * fVar14 +
               auVar19._0_4_ + DAT_1437da3b4;
      auVar19 = SUB3216(*(undefined1 (*) [32])(param_1 + 0x698c0),0);
      auVar17 = vshufps_avx(auVar19,auVar19,0x55);
      auVar6 = vshufps_avx(auVar19,auVar19,0xaa);
      auVar19 = vshufps_avx(auVar19,auVar19,0xff);
      fVar18 = fVar15 * auVar6._0_4_ +
               fVar14 * auVar17._0_4_ + SUB324(*(undefined1 (*) [32])(param_1 + 0x698c0),0) * fVar18
               + auVar19._0_4_ + DAT_1437da3b8;
      DAT_1437da3b4 = fVar24;
      DAT_1437da3b8 = fVar18;
      _DAT_1437da3c8 = uVar21;
      _DAT_1437da3cc = uVar21;
      _DAT_1437da3d0 = uVar21;
      *(float *)(param_1 + 0x69880) = DAT_1437da3b0;
      *(float *)(param_1 + 0x69884) = fVar24;
      *(float *)(param_1 + 0x69888) = fVar18;
      *(undefined4 *)(param_1 + 0x6988c) = 0x3f800000;
    }
    else {
      FUN_140014960(lVar8,*(undefined8 *)(param_1 + 0xa8240));
      *(undefined4 *)(param_1 + 0x6985c) = 0x40a00000;
      lVar12 = *(longlong *)(param_1 + 0xa87c8);
      if (lVar12 != 0) {
        lVar11 = *(longlong *)(*(longlong *)(lVar12 + 0x3c8) + 0x48);
        if ((lVar11 != 0) && (lVar11 = lVar11 + 0x90, lVar9 = lVar11, lVar11 != 0)) {
          do {
            iVar7 = strcmp("#cam_lens##",(char *)(lVar9 + 0x9c));
            if (iVar7 == 0) {
              fVar18 = *(float *)(lVar9 + 0x90);
              lVar9 = FUN_140189320();
              if (*(char *)(lVar9 + 0x28) != '\0') {
                fVar18 = fVar18 * DAT_1402d2254;
              }
              *(float *)(param_1 + 0x69858) = fVar18;
              uVar21 = auVar22._0_4_;
              *(undefined4 *)(lVar10 + 0x1d64) = uVar21;
              *(float *)(lVar10 + 0x1d68) = fVar18;
              *(undefined4 *)(lVar10 + 0x1d6c) = uVar21;
              *(undefined4 *)(lVar10 + 0x1bd0) = uVar21;
              break;
            }
            lVar9 = *(longlong *)(lVar9 + 0xf0);
          } while (lVar9 != 0);
          do {
            iVar7 = strcmp("#dtl_x#dtl_y#dtl_z",(char *)(lVar11 + 0x9c));
            if (iVar7 == 0) {
              fVar18 = *(float *)(lVar11 + 0x98);
              fVar24 = *(float *)(lVar11 + 0x94);
              *(float *)(lVar12 + 600) = fVar18 + *(float *)(lVar12 + 600);
              *(float *)(lVar12 + 0x260) = fVar18 + *(float *)(lVar12 + 0x260);
              *(float *)(lVar12 + 0x25c) = fVar24 + *(float *)(lVar12 + 0x25c);
              break;
            }
            lVar11 = *(longlong *)(lVar11 + 0xf0);
          } while (lVar11 != 0);
        }
        uVar21 = *(undefined4 *)(lVar12 + 0x260);
        uVar20 = *(undefined4 *)(lVar12 + 600);
        *(undefined4 *)(param_1 + 0x69884) = *(undefined4 *)(lVar12 + 0x25c);
        *(undefined4 *)(param_1 + 0x69888) = uVar21;
        *(undefined4 *)(param_1 + 0x69880) = uVar20;
        *(undefined4 *)(param_1 + 0x6988c) = 0x3f800000;
        uVar21 = *(undefined4 *)(lVar12 + 0x270);
        uVar20 = *(undefined4 *)(lVar12 + 0x268);
        *(undefined4 *)(param_1 + 0x69894) = *(undefined4 *)(lVar12 + 0x26c);
        *(undefined4 *)(param_1 + 0x69898) = uVar21;
        *(undefined4 *)(param_1 + 0x69890) = uVar20;
        *(undefined4 *)(param_1 + 0x6989c) = 0;
      }
    }
    FUN_1401fbec0(lVar8);
    if (*(int *)(param_1 + 0x67230) < 4) {
      *(longlong *)(param_1 + 0x671f0 + (longlong)*(int *)(param_1 + 0x67230) * 8) = lVar8;
      *(longlong *)(param_1 + 0x67210 + (longlong)*(int *)(param_1 + 0x67230) * 8) = lVar8;
      *(undefined4 *)(param_1 + 0x67234 + (longlong)*(int *)(param_1 + 0x67230) * 4) = 0;
      *(int *)(param_1 + 0x67230) = *(int *)(param_1 + 0x67230) + 1;
    }
  }
  else {
    if (*(char *)(param_1 + 0xa87d9) != '\0') {
      *(uint *)(lVar10 + 0x2058) = *(uint *)(lVar10 + 0x2058) & 0xffffffef;
      FUN_1400c5070(lVar10,2);
    }
    uVar2 = *(undefined1 *)(lVar10 + 0x1862);
    *(undefined1 *)(lVar10 + 0x1862) = 3;
    FUN_140106f30(lVar10);
    *(undefined1 *)(lVar10 + 0x1862) = uVar2;
    lVar8 = lVar10 + 0x10b0;
    FUN_1401fbec0(lVar8);
    lVar12 = lVar10 + 0x1270;
    FUN_1401fbec0(lVar12);
    FUN_1401fbec0(lVar8);
    FUN_1401fbec0(lVar12);
    if (*(int *)(param_1 + 0x67230) < 4) {
      *(longlong *)(param_1 + 0x671f0 + (longlong)*(int *)(param_1 + 0x67230) * 8) = lVar8;
      *(longlong *)(param_1 + 0x67210 + (longlong)*(int *)(param_1 + 0x67230) * 8) = lVar12;
      *(undefined4 *)(param_1 + 0x67234 + (longlong)*(int *)(param_1 + 0x67230) * 4) = 0;
      *(int *)(param_1 + 0x67230) = *(int *)(param_1 + 0x67230) + 1;
    }
    auVar17 = *(undefined1 (*) [16])(lVar10 + 0x10e0);
    *(int *)(param_1 + 0x69880) = auVar17._0_4_;
    uVar21 = vextractps_avx(auVar17,1);
    *(undefined4 *)(param_1 + 0x69884) = uVar21;
    uVar21 = vextractps_avx(auVar17,2);
    *(undefined4 *)(param_1 + 0x69888) = uVar21;
    uVar21 = vextractps_avx(auVar17,3);
    *(undefined4 *)(param_1 + 0x6988c) = uVar21;
    auVar17 = *(undefined1 (*) [16])(lVar10 + 0x10f0);
    *(int *)(param_1 + 0x69890) = auVar17._0_4_;
    uVar21 = vextractps_avx(auVar17,1);
    *(undefined4 *)(param_1 + 0x69894) = uVar21;
    uVar21 = vextractps_avx(auVar17,2);
    *(undefined4 *)(param_1 + 0x69898) = uVar21;
    uVar21 = vextractps_avx(auVar17,3);
    *(undefined4 *)(param_1 + 0x6989c) = uVar21;
    *(int *)(param_1 + 0x69858) = auVar22._0_4_;
    FUN_1401fbec0();
  }
  if (((*(int *)(param_1 + 0xa87d0) < 1) && (*(int *)(param_1 + 0xa87c0) != 0)) ||
     (*(char *)(param_1 + 0xa87db) != '\0')) {
    *(undefined1 *)(param_1 + 0xa87da) = 0;
    uVar13 = 1;
  }
  if (*(char *)(param_1 + 0xa87da) == '\0') {
    *(int *)(param_1 + 0xa87c0) = *(int *)(param_1 + 0xa87c0) + 1;
  }
  plVar4 = *(longlong **)(param_1 + 0xa8760);
  if (plVar4 != (longlong *)0x0) {
    pcVar5 = *(code **)(*plVar4 + 0x10);
    lVar10 = FUN_140189320();
    auVar17._0_4_ = (float)*(int *)(lVar10 + 0xc);
    auVar17._4_12_ = SUB1612(ZEXT816(0),4);
    (*pcVar5)(plVar4,auVar17._0_8_);
  }
  return uVar13;
}

