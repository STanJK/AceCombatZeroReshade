/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140197b30; RVA 0x197b30
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140197b30(longlong param_1,longlong param_2)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong *plVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  
  plVar3 = DAT_14033acc0;
  if (param_2 != 0) {
    lVar4 = (longlong)DAT_14033acc0 - (longlong)DAT_14033acb8 >> 3;
    if (DAT_14033acc0 == DAT_14033acc8) {
      if (lVar4 == 0x1fffffffffffffff) {
                    /* WARNING: Subroutine does not return */
        FUN_140185860();
      }
      uVar2 = (longlong)DAT_14033acc8 - (longlong)DAT_14033acb8 >> 3;
      if (0x1fffffffffffffff - (uVar2 >> 1) < uVar2) {
        uVar5 = 0x1fffffffffffffff;
      }
      else {
        uVar2 = (uVar2 >> 1) + uVar2;
        uVar5 = lVar4 + 1U;
        if (lVar4 + 1U <= uVar2) {
          uVar5 = uVar2;
        }
        if (0x1fffffffffffffff < uVar5) {
                    /* WARNING: Subroutine does not return */
          FUN_14006a4f0();
        }
      }
      lVar1 = FUN_14006ac30(uVar5 * 8);
      *(longlong *)(lVar1 + lVar4 * 8) = param_2;
      if (plVar3 == DAT_14033acc0) {
        lVar6 = (longlong)DAT_14033acc0 - (longlong)DAT_14033acb8;
        plVar3 = DAT_14033acb8;
      }
      else {
        FUN_140277ba0(lVar1,DAT_14033acb8,(longlong)plVar3 - (longlong)DAT_14033acb8);
        lVar1 = lVar1 + 8 + lVar4 * 8;
        lVar6 = (longlong)DAT_14033acc0 - (longlong)plVar3;
      }
      FUN_140277ba0(lVar1,plVar3,lVar6);
      FUN_140197c80();
    }
    else {
      *DAT_14033acc0 = param_2;
      DAT_14033acc0 = DAT_14033acc0 + 1;
    }
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) & 0xc0000000;
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | (uint)lVar4 | 0x40000000;
  }
  return;
}

