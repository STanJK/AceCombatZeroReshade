/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140201120; RVA 0x201120
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_140201120(longlong *param_1,int param_2)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  if (((*(int *)((longlong)param_1 + 0xc) != -1) || (param_2 < 0)) || ((int)param_1[1] <= param_2))
  {
    return 0;
  }
  *(int *)((longlong)param_1 + 0xc) = param_2;
  lVar1 = param_1[3];
  puVar2 = *(undefined8 **)((longlong)param_2 * 0x20 + 8 + *param_1);
  if (*(char *)(lVar1 + 0x21) == '\0') {
    *(undefined1 *)(lVar1 + 0x21) = 1;
    uVar3 = *(undefined8 *)(lVar1 + 0x10);
  }
  else {
    uVar3 = 0;
  }
  *puVar2 = 0x20000000;
  FUN_140197b30(puVar2,uVar3);
  puVar2[1] = 0;
  return uVar3;
}

