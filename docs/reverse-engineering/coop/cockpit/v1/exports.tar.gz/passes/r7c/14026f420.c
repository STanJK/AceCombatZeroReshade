/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14026f420; RVA 0x26f420
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14026f420(undefined8 param_1)

{
  undefined4 in_EAX;
  int iVar1;
  ulonglong uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  float fVar11;
  uint uVar12;
  float in_XMM0_Dc;
  uint uVar13;
  float in_XMM0_Dd;
  uint uVar14;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  uint uVar18;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  undefined1 auVar24 [16];
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  undefined1 auVar33 [16];
  undefined1 auVar34 [16];
  uint uVar35;
  uint uVar37;
  uint uVar38;
  uint uVar39;
  undefined1 auVar36 [16];
  float fVar40;
  float fVar41;
  float fVar44;
  float fVar45;
  float fVar46;
  float fVar47;
  undefined1 auVar42 [16];
  undefined1 auVar43 [16];
  float fVar48;
  float fVar52;
  float fVar53;
  undefined1 auVar49 [16];
  undefined1 auVar50 [16];
  undefined1 auVar51 [16];
  float fVar54;
  float fVar55;
  float fVar56;
  float fVar58;
  float fVar59;
  float fVar60;
  float fVar61;
  float fVar63;
  ulonglong uVar62;
  undefined1 auVar57 [16];
  float fVar64;
  uint uVar65;
  float fVar66;
  uint uVar69;
  float fVar70;
  uint uVar71;
  float fVar72;
  float fVar73;
  uint uVar74;
  undefined1 auVar67 [16];
  undefined1 auVar68 [16];
  float fVar75;
  float fVar76;
  float fVar77;
  float fVar78;
  float fVar81;
  float fVar82;
  float fVar83;
  undefined1 auVar79 [16];
  undefined1 auVar80 [16];
  float fVar84;
  float fVar85;
  undefined1 auVar86 [16];
  undefined1 auVar87 [16];
  undefined1 auVar88 [16];
  uint uVar89;
  float fVar91;
  float fVar97;
  float fVar98;
  undefined1 auVar92 [16];
  undefined1 auVar93 [16];
  uint uVar90;
  undefined1 auVar94 [16];
  undefined1 auVar95 [16];
  undefined1 auVar96 [16];
  float fVar99;
  float local_140 [16];
  uint local_100 [58];
  
  fVar11 = (float)((ulonglong)param_1 >> 0x20);
  local_140[0] = (float)param_1;
  uVar3 = 0;
  fVar40 = (float)((uint)local_140[0] & _DAT_14380c000);
  fVar44 = (float)((uint)fVar11 & _UNK_14380c004);
  fVar46 = (float)((uint)in_XMM0_Dc & _UNK_14380c008);
  fVar47 = (float)((uint)in_XMM0_Dd & _UNK_14380c00c);
  fVar25 = _DAT_14380c480 * fVar40 + _DAT_14380c4c0;
  fVar27 = _UNK_14380c484 * fVar44 + _UNK_14380c4c4;
  fVar29 = _UNK_14380c488 * fVar46 + _UNK_14380c4c8;
  fVar31 = _UNK_14380c48c * fVar47 + _UNK_14380c4cc;
  fVar26 = fVar25 - _DAT_14380c4c0;
  fVar28 = fVar27 - _UNK_14380c4c4;
  fVar30 = fVar29 - _UNK_14380c4c8;
  fVar32 = fVar31 - _UNK_14380c4cc;
  fVar55 = (((fVar40 - _DAT_14380c1c0 * fVar26) - _DAT_14380c200 * fVar26) - _DAT_14380c240 * fVar26
           ) - _DAT_14380c280 * fVar26;
  fVar58 = (((fVar44 - _UNK_14380c1c4 * fVar28) - _UNK_14380c204 * fVar28) - _UNK_14380c244 * fVar28
           ) - _UNK_14380c284 * fVar28;
  fVar60 = (((fVar46 - _UNK_14380c1c8 * fVar30) - _UNK_14380c208 * fVar30) - _UNK_14380c248 * fVar30
           ) - _UNK_14380c288 * fVar30;
  fVar63 = (((fVar47 - _UNK_14380c1cc * fVar32) - _UNK_14380c20c * fVar32) - _UNK_14380c24c * fVar32
           ) - _UNK_14380c28c * fVar32;
  fVar26 = fVar55 * fVar55;
  fVar28 = fVar58 * fVar58;
  fVar30 = fVar60 * fVar60;
  fVar32 = fVar63 * fVar63;
  fVar55 = (float)((uint)fVar55 ^ (int)fVar25 << 0x1f);
  fVar58 = (float)((uint)fVar58 ^ (int)fVar27 << 0x1f);
  fVar60 = (float)((uint)fVar60 ^ (int)fVar29 << 0x1f);
  fVar63 = (float)((uint)fVar63 ^ (int)fVar31 << 0x1f);
  uVar4 = -(uint)(_DAT_14380c040 < fVar40);
  uVar5 = -(uint)(_UNK_14380c044 < fVar44);
  uVar6 = -(uint)(_UNK_14380c048 < fVar46);
  uVar7 = -(uint)(_UNK_14380c04c < fVar47);
  auVar87._4_4_ = uVar5;
  auVar87._0_4_ = uVar4;
  auVar87._8_4_ = uVar6;
  auVar87._12_4_ = uVar7;
  iVar1 = movmskps(in_EAX,auVar87);
  local_100[0] = (uint)(fVar55 + fVar26 * (((_DAT_14380c440 * fVar26 + _DAT_14380c400) * fVar26 +
                                           _DAT_14380c3c0) * fVar26 + _DAT_14380c380) * fVar55) ^
                 ~_DAT_14380c000 & (uint)local_140[0];
  local_100[1] = (uint)(fVar58 + fVar28 * (((_UNK_14380c444 * fVar28 + _UNK_14380c404) * fVar28 +
                                           _UNK_14380c3c4) * fVar28 + _UNK_14380c384) * fVar58) ^
                 ~_UNK_14380c004 & (uint)fVar11;
  local_100[2] = (uint)(fVar60 + fVar30 * (((_UNK_14380c448 * fVar30 + _UNK_14380c408) * fVar30 +
                                           _UNK_14380c3c8) * fVar30 + _UNK_14380c388) * fVar60) ^
                 ~_UNK_14380c008 & (uint)in_XMM0_Dc;
  local_100[3] = (uint)(fVar63 + fVar32 * (((_UNK_14380c44c * fVar32 + _UNK_14380c40c) * fVar32 +
                                           _UNK_14380c3cc) * fVar32 + _UNK_14380c38c) * fVar63) ^
                 ~_UNK_14380c00c & (uint)in_XMM0_Dd;
  if (iVar1 != 0) {
    auVar42._4_4_ = -(uint)((float)((uint)fVar44 & (uint)_UNK_14380c084) == _UNK_14380c084);
    auVar42._0_4_ = -(uint)((float)((uint)fVar40 & (uint)_DAT_14380c080) == _DAT_14380c080);
    auVar42._8_4_ = -(uint)((float)((uint)fVar46 & (uint)_UNK_14380c088) == _UNK_14380c088);
    auVar42._12_4_ = -(uint)((float)((uint)fVar47 & (uint)_UNK_14380c08c) == _UNK_14380c08c);
    uVar35 = (((uint)local_140[0] & 0x7f800000) >> 0x17) * 0xc;
    uVar37 = (((uint)fVar11 & 0x7f800000) >> 0x17) * 0xc;
    uVar38 = (((uint)in_XMM0_Dc & 0x7f800000) >> 0x17) * 0xc;
    uVar39 = (((uint)in_XMM0_Dd & 0x7f800000) >> 0x17) * 0xc;
    uVar3 = movmskps(0,auVar42);
    auVar43._4_4_ = *(uint *)(&DAT_14380a400 + uVar37);
    auVar43._0_4_ = *(uint *)(&DAT_14380a400 + uVar35);
    auVar43._12_4_ = *(uint *)(&DAT_14380a400 + uVar39);
    auVar43._8_4_ = *(uint *)(&DAT_14380a400 + uVar38);
    auVar24._4_4_ = *(uint *)(&DAT_14380a408 + uVar37);
    auVar24._0_4_ = *(uint *)(&DAT_14380a408 + uVar35);
    auVar24._12_4_ = *(uint *)(&DAT_14380a408 + uVar39);
    auVar24._8_4_ = *(uint *)(&DAT_14380a408 + uVar38);
    auVar36._8_4_ = 0xffff;
    auVar36._0_8_ = 0xffff0000ffff;
    auVar36._12_4_ = 0xffff;
    auVar86._0_4_ = ((uint)local_140[0] & 0x7fffff) + 0x800000;
    auVar86._4_4_ = ((uint)fVar11 & 0x7fffff) + 0x800000;
    auVar86._8_4_ = ((uint)in_XMM0_Dc & 0x7fffff) + 0x800000;
    auVar86._12_4_ = ((uint)in_XMM0_Dd & 0x7fffff) + 0x800000;
    auVar43 = auVar43 & auVar36;
    auVar87 = auVar86 & auVar36;
    uVar62 = auVar87._8_8_;
    uVar65 = auVar86._0_4_ >> 0x10;
    uVar69 = auVar86._4_4_ >> 0x10;
    uVar71 = auVar86._8_4_ >> 0x10;
    uVar74 = auVar86._12_4_ >> 0x10;
    uVar89 = auVar87._0_4_;
    auVar92._0_8_ = (ulonglong)uVar89 * (ulonglong)auVar43._0_4_;
    auVar92._8_8_ = (uVar62 & 0xffffffff) * (ulonglong)auVar43._8_4_;
    auVar49._4_4_ = *(uint *)(&DAT_14380a404 + uVar37);
    auVar49._0_4_ = *(uint *)(&DAT_14380a404 + uVar35);
    auVar93._0_8_ = (auVar87._0_8_ >> 0x20) * (auVar43._0_8_ >> 0x20) << 0x20;
    auVar93._8_8_ = (uVar62 >> 0x20) * (auVar43._8_8_ >> 0x20) << 0x20;
    auVar49._12_4_ = *(uint *)(&DAT_14380a404 + uVar39);
    auVar49._8_4_ = *(uint *)(&DAT_14380a404 + uVar38);
    auVar49 = auVar49 & auVar36;
    uVar8 = *(uint *)(&DAT_14380a404 + uVar35) >> 0x10;
    uVar12 = *(uint *)(&DAT_14380a404 + uVar37) >> 0x10;
    uVar13 = *(uint *)(&DAT_14380a404 + uVar38) >> 0x10;
    uVar14 = *(uint *)(&DAT_14380a404 + uVar39) >> 0x10;
    auVar93 = auVar92 & _DAT_14380a000 | auVar93;
    uVar2 = auVar49._8_8_;
    auVar33._0_8_ = (ulonglong)uVar89 * (ulonglong)uVar8;
    auVar33._8_8_ = (uVar62 & 0xffffffff) * (ulonglong)uVar13;
    uVar90 = auVar87._4_4_;
    auVar16._0_8_ = (ulonglong)uVar90 * (ulonglong)auVar49._4_4_ << 0x20;
    auVar16._8_8_ = (uVar62 >> 0x20) * (uVar2 >> 0x20) << 0x20;
    auVar15._0_8_ = (ulonglong)uVar89 * (ulonglong)auVar49._0_4_;
    auVar15._8_8_ = (uVar62 & 0xffffffff) * (ulonglong)auVar49._8_4_;
    auVar50._0_8_ = (ulonglong)auVar49._0_4_ * (ulonglong)uVar65;
    auVar50._8_8_ = (uVar2 & 0xffffffff) * (ulonglong)uVar71;
    auVar24 = auVar24 & auVar36;
    auVar16 = auVar15 & _DAT_14380a000 | auVar16;
    auVar94._0_8_ = (ulonglong)uVar65 * (ulonglong)auVar24._0_4_;
    auVar94._8_8_ = (ulonglong)uVar71 * (ulonglong)auVar24._8_4_;
    uVar18 = *(uint *)(&DAT_14380a408 + uVar35) >> 0x10;
    uVar21 = *(uint *)(&DAT_14380a408 + uVar37) >> 0x10;
    uVar22 = *(uint *)(&DAT_14380a408 + uVar38) >> 0x10;
    uVar23 = *(uint *)(&DAT_14380a408 + uVar39) >> 0x10;
    auVar9._0_8_ = (auVar24._0_8_ >> 0x20) * (ulonglong)uVar69 << 0x20;
    auVar9._8_8_ = (auVar24._8_8_ >> 0x20) * (ulonglong)uVar74 << 0x20;
    auVar9 = auVar94 & _DAT_14380a000 | auVar9;
    auVar34._0_8_ = (ulonglong)uVar90 * (ulonglong)uVar12 << 0x20;
    auVar34._8_8_ = (uVar62 >> 0x20) * (ulonglong)uVar14 << 0x20;
    auVar79._0_8_ = (ulonglong)uVar65 * (ulonglong)uVar18;
    auVar79._8_8_ = (ulonglong)uVar71 * (ulonglong)uVar22;
    auVar34 = auVar33 & _DAT_14380a000 | auVar34;
    auVar19._0_8_ = (ulonglong)uVar18 * (ulonglong)uVar89;
    auVar19._8_8_ = (ulonglong)uVar22 * (ulonglong)auVar87._8_4_;
    auVar20._0_8_ = (ulonglong)uVar21 * (ulonglong)uVar90 << 0x20;
    auVar20._8_8_ = (ulonglong)uVar23 * (uVar62 >> 0x20) << 0x20;
    auVar80._0_8_ = (ulonglong)uVar69 * (ulonglong)uVar21 << 0x20;
    auVar80._8_8_ = (ulonglong)uVar74 * (ulonglong)uVar23 << 0x20;
    auVar20 = auVar19 & _DAT_14380a000 | auVar20;
    auVar80 = auVar79 & _DAT_14380a000 | auVar80;
    auVar51._0_8_ = (ulonglong)auVar49._4_4_ * (ulonglong)uVar69 << 0x20;
    auVar51._8_8_ = (uVar2 >> 0x20) * (ulonglong)uVar74 << 0x20;
    auVar94 = auVar16 & auVar36;
    auVar51 = auVar50 & _DAT_14380a000 | auVar51;
    auVar87 = auVar34 & auVar36;
    auVar10._0_4_ = (auVar9._0_4_ >> 0x10) + auVar94._0_4_ + auVar80._0_4_ + (auVar20._0_4_ >> 0x10)
    ;
    auVar10._4_4_ = (auVar9._4_4_ >> 0x10) + auVar94._4_4_ + auVar80._4_4_ + (auVar20._4_4_ >> 0x10)
    ;
    auVar10._8_4_ = (auVar9._8_4_ >> 0x10) + auVar94._8_4_ + auVar80._8_4_ + (auVar20._8_4_ >> 0x10)
    ;
    auVar10._12_4_ =
         (auVar9._12_4_ >> 0x10) + auVar94._12_4_ + auVar80._12_4_ + (auVar20._12_4_ >> 0x10);
    auVar95._0_8_ = (ulonglong)uVar8 * (ulonglong)uVar65;
    auVar95._8_8_ = (ulonglong)uVar13 * (ulonglong)uVar71;
    auVar67._0_8_ = (ulonglong)uVar65 * (ulonglong)auVar43._0_4_;
    auVar67._8_8_ = (ulonglong)uVar71 * (ulonglong)auVar43._8_4_;
    auVar96._0_8_ = (ulonglong)uVar12 * (ulonglong)uVar69 << 0x20;
    auVar96._8_8_ = (ulonglong)uVar14 * (ulonglong)uVar74 << 0x20;
    auVar96 = auVar95 & _DAT_14380a000 | auVar96;
    uVar18 = (auVar10._0_4_ >> 0x10) + auVar87._0_4_ + auVar51._0_4_ + (auVar16._0_4_ >> 0x10);
    uVar21 = (auVar10._4_4_ >> 0x10) + auVar87._4_4_ + auVar51._4_4_ + (auVar16._4_4_ >> 0x10);
    uVar22 = (auVar10._8_4_ >> 0x10) + auVar87._8_4_ + auVar51._8_4_ + (auVar16._8_4_ >> 0x10);
    uVar23 = (auVar10._12_4_ >> 0x10) + auVar87._12_4_ + auVar51._12_4_ + (auVar16._12_4_ >> 0x10);
    auVar88._0_8_ = (ulonglong)uVar89 * (ulonglong)(*(uint *)(&DAT_14380a400 + uVar35) >> 0x10);
    auVar88._8_8_ = (uVar62 & 0xffffffff) * (ulonglong)(*(uint *)(&DAT_14380a400 + uVar38) >> 0x10);
    auVar87 = auVar93 & auVar36;
    auVar57._0_8_ =
         (ulonglong)uVar90 * (ulonglong)(*(uint *)(&DAT_14380a400 + uVar37) >> 0x10) << 0x20;
    auVar57._8_8_ =
         (uVar62 >> 0x20) * (ulonglong)(*(uint *)(&DAT_14380a400 + uVar39) >> 0x10) << 0x20;
    auVar68._0_8_ = (ulonglong)uVar69 * (auVar43._0_8_ >> 0x20) << 0x20;
    auVar68._8_8_ = (ulonglong)uVar74 * (auVar43._8_8_ >> 0x20) << 0x20;
    auVar17._0_4_ = (uVar18 >> 0x10) + auVar87._0_4_ + auVar96._0_4_ + (auVar34._0_4_ >> 0x10);
    auVar17._4_4_ = (uVar21 >> 0x10) + auVar87._4_4_ + auVar96._4_4_ + (auVar34._4_4_ >> 0x10);
    auVar17._8_4_ = (uVar22 >> 0x10) + auVar87._8_4_ + auVar96._8_4_ + (auVar34._8_4_ >> 0x10);
    auVar17._12_4_ = (uVar23 >> 0x10) + auVar87._12_4_ + auVar96._12_4_ + (auVar34._12_4_ >> 0x10);
    auVar68 = auVar67 & _DAT_14380a000 | auVar68;
    auVar16 = (auVar88 & _DAT_14380a000 | auVar57) & auVar36;
    auVar87 = auVar17 & auVar36;
    auVar10 = auVar10 & auVar36;
    uVar8 = ((auVar17._0_4_ >> 0x10) + auVar16._0_4_ + auVar68._0_4_ + (auVar93._0_4_ >> 0x10)) *
            0x10000 + auVar87._0_4_;
    uVar12 = ((auVar17._4_4_ >> 0x10) + auVar16._4_4_ + auVar68._4_4_ + (auVar93._4_4_ >> 0x10)) *
             0x10000 + auVar87._4_4_;
    uVar13 = ((auVar17._8_4_ >> 0x10) + auVar16._8_4_ + auVar68._8_4_ + (auVar93._8_4_ >> 0x10)) *
             0x10000 + auVar87._8_4_;
    uVar14 = ((auVar17._12_4_ >> 0x10) + auVar16._12_4_ + auVar68._12_4_ + (auVar93._12_4_ >> 0x10))
             * 0x10000 + auVar87._12_4_;
    uVar35 = uVar18 * 0x10000 + auVar10._0_4_;
    uVar37 = uVar21 * 0x10000 + auVar10._4_4_;
    uVar38 = uVar22 * 0x10000 + auVar10._8_4_;
    uVar39 = uVar23 * 0x10000 + auVar10._12_4_;
    uVar18 = (uint)local_140[0] & 0x80000000;
    uVar21 = (uint)fVar11 & 0x80000000;
    uVar22 = (uint)in_XMM0_Dc & 0x80000000;
    uVar23 = (uint)in_XMM0_Dd & 0x80000000;
    fVar25 = (float)(uVar8 >> 9 | uVar18 ^ 0x3f800000);
    fVar27 = (float)(uVar12 >> 9 | uVar21 ^ 0x3f800000);
    fVar29 = (float)(uVar13 >> 9 | uVar22 ^ 0x3f800000);
    fVar31 = (float)(uVar14 >> 9 | uVar23 ^ 0x3f800000);
    fVar26 = fVar25 + 49152.0;
    fVar28 = fVar27 + 49152.0;
    fVar30 = fVar29 + 49152.0;
    fVar32 = fVar31 + 49152.0;
    fVar40 = (float)((uVar8 & 0x1ff) << 0xe | uVar35 >> 0x12 | uVar18 ^ 0x34000000) -
             (float)(uVar18 ^ 0x34000000);
    fVar44 = (float)((uVar12 & 0x1ff) << 0xe | uVar37 >> 0x12 | uVar21 ^ 0x34000000) -
             (float)(uVar21 ^ 0x34000000);
    fVar46 = (float)((uVar13 & 0x1ff) << 0xe | uVar38 >> 0x12 | uVar22 ^ 0x34000000) -
             (float)(uVar22 ^ 0x34000000);
    fVar47 = (float)((uVar14 & 0x1ff) << 0xe | uVar39 >> 0x12 | uVar23 ^ 0x34000000) -
             (float)(uVar23 ^ 0x34000000);
    fVar25 = fVar25 - (fVar26 - 49152.0);
    fVar27 = fVar27 - (fVar28 - 49152.0);
    fVar29 = fVar29 - (fVar30 - 49152.0);
    fVar31 = fVar31 - (fVar32 - 49152.0);
    fVar58 = fVar25 + fVar40;
    fVar60 = fVar27 + fVar44;
    fVar72 = fVar29 + fVar46;
    fVar75 = fVar31 + fVar47;
    fVar77 = (float)((uint)fVar58 & 0xfffff000);
    fVar82 = (float)((uint)fVar72 & 0xfffff000);
    fVar84 = (float)((uint)fVar75 & 0xfffff000);
    fVar55 = (float)((uint)fVar60 & 0xfffff000) * 6.283203;
    fVar63 = fVar60 - (float)((uint)fVar60 & 0xfffff000);
    fVar41 = (fVar58 - fVar77) * 6.283203 + fVar77 * -1.781782e-05 +
             (((float)((uVar35 & 0x3ffff) << 5 | uVar18 ^ 0x28800000) - (float)(uVar18 ^ 0x28800000)
              ) + fVar40 + (fVar25 - fVar58)) * 6.2831855 + (fVar58 - fVar77) * -1.781782e-05;
    fVar45 = fVar63 * 6.283203 + (float)((uint)fVar60 & 0xfffff000) * -1.781782e-05 +
             (((float)((uVar37 & 0x3ffff) << 5 | uVar21 ^ 0x28800000) - (float)(uVar21 ^ 0x28800000)
              ) + fVar44 + (fVar27 - fVar60)) * 6.2831855 + fVar63 * -1.781782e-05;
    fVar72 = (fVar72 - fVar82) * 6.283203 + fVar82 * -1.781782e-05 +
             (((float)((uVar38 & 0x3ffff) << 5 | uVar22 ^ 0x28800000) - (float)(uVar22 ^ 0x28800000)
              ) + fVar46 + (fVar29 - fVar72)) * 6.2831855 + (fVar72 - fVar82) * -1.781782e-05;
    fVar75 = (fVar75 - fVar84) * 6.283203 + fVar84 * -1.781782e-05 +
             (((float)((uVar39 & 0x3ffff) << 5 | uVar23 ^ 0x28800000) - (float)(uVar23 ^ 0x28800000)
              ) + fVar47 + (fVar31 - fVar75)) * 6.2831855 + (fVar75 - fVar84) * -1.781782e-05;
    uVar18 = ((uint)fVar26 & 0xff) << 4;
    uVar21 = ((uint)fVar28 & 0xff) << 4;
    uVar22 = ((uint)fVar30 & 0xff) << 4;
    uVar23 = ((uint)fVar32 & 0xff) << 4;
    fVar32 = fVar41 + fVar77 * 6.283203;
    fVar27 = fVar45 + fVar55;
    fVar31 = fVar72 + fVar82 * 6.283203;
    fVar44 = fVar75 + fVar84 * 6.283203;
    uVar8 = -(uint)(9.536743e-07 < ABS(local_140[0]));
    uVar12 = -(uint)(9.536743e-07 < ABS(fVar11));
    uVar13 = -(uint)(9.536743e-07 < ABS(in_XMM0_Dc));
    uVar14 = -(uint)(9.536743e-07 < ABS(in_XMM0_Dd));
    fVar66 = (float)(-(uint)(ABS(local_140[0]) <= 9.536743e-07) & (uint)local_140[0] |
                    (uint)fVar32 & uVar8);
    fVar70 = (float)(-(uint)(ABS(fVar11) <= 9.536743e-07) & (uint)fVar11 | (uint)fVar27 & uVar12);
    fVar73 = (float)(-(uint)(ABS(in_XMM0_Dc) <= 9.536743e-07) & (uint)in_XMM0_Dc |
                    (uint)fVar31 & uVar13);
    fVar76 = (float)(-(uint)(ABS(in_XMM0_Dd) <= 9.536743e-07) & (uint)in_XMM0_Dd |
                    (uint)fVar44 & uVar14);
    fVar11 = *(float *)(&DAT_14380b004 + uVar18);
    fVar26 = *(float *)(&DAT_14380b004 + uVar21);
    fVar91 = fVar66 * *(float *)(&DAT_14380b00c + uVar18);
    fVar97 = fVar70 * *(float *)(&DAT_14380b00c + uVar21);
    fVar98 = fVar73 * *(float *)(&DAT_14380b00c + uVar22);
    fVar99 = fVar76 * *(float *)(&DAT_14380b00c + uVar23);
    fVar56 = fVar66 * fVar66;
    fVar59 = fVar70 * fVar70;
    fVar61 = fVar73 * fVar73;
    fVar64 = fVar76 * fVar76;
    fVar25 = fVar66 * *(float *)(&DAT_14380b000 + uVar18);
    fVar29 = fVar70 * *(float *)(&DAT_14380b000 + uVar21);
    fVar40 = fVar73 * *(float *)(&DAT_14380b000 + uVar22);
    fVar46 = fVar76 * *(float *)(&DAT_14380b000 + uVar23);
    fVar28 = *(float *)(&DAT_14380b004 + uVar23);
    fVar30 = *(float *)(&DAT_14380b004 + uVar22);
    fVar48 = fVar11 + fVar91;
    fVar52 = fVar26 + fVar97;
    fVar53 = fVar30 + fVar98;
    fVar54 = fVar28 + fVar99;
    fVar78 = fVar48 + fVar25;
    fVar81 = fVar52 + fVar29;
    fVar83 = fVar53 + fVar40;
    fVar85 = fVar54 + fVar46;
    fVar47 = (*(float *)(&DAT_14380b000 + uVar18) + *(float *)(&DAT_14380b00c + uVar18)) -
             fVar66 * fVar11;
    fVar58 = (*(float *)(&DAT_14380b000 + uVar21) + *(float *)(&DAT_14380b00c + uVar21)) -
             fVar70 * fVar26;
    fVar60 = (*(float *)(&DAT_14380b000 + uVar22) + *(float *)(&DAT_14380b00c + uVar22)) -
             fVar73 * fVar30;
    fVar63 = (*(float *)(&DAT_14380b000 + uVar23) + *(float *)(&DAT_14380b00c + uVar23)) -
             fVar76 * fVar28;
    local_100[0] = ~uVar4 & local_100[0] |
                   (uint)(fVar78 + *(float *)(&DAT_14380b008 + uVar18) +
                                   (float)(uVar8 & (uint)(fVar41 + (fVar77 * 6.283203 - fVar32))) *
                                   fVar47 + fVar11 * fVar56 * (_DAT_14380c180 * fVar56 +
                                                              _DAT_14380c140) +
                                   fVar91 + (fVar11 - fVar48) + fVar25 + (fVar48 - fVar78) +
                                   (_DAT_14380c100 * fVar56 + _DAT_14380c0c0) * fVar56 * fVar66 *
                                   fVar47) & uVar4;
    local_100[1] = ~uVar5 & local_100[1] |
                   (uint)(fVar81 + *(float *)(&DAT_14380b008 + uVar21) +
                                   (float)(uVar12 & (uint)(fVar45 + (fVar55 - fVar27))) * fVar58 +
                                   fVar26 * fVar59 * (_UNK_14380c184 * fVar59 + _UNK_14380c144) +
                                   fVar97 + (fVar26 - fVar52) + fVar29 + (fVar52 - fVar81) +
                                   (_UNK_14380c104 * fVar59 + _UNK_14380c0c4) * fVar59 * fVar70 *
                                   fVar58) & uVar5;
    local_100[2] = ~uVar6 & local_100[2] |
                   (uint)(fVar83 + *(float *)(&DAT_14380b008 + uVar22) +
                                   (float)(uVar13 & (uint)(fVar72 + (fVar82 * 6.283203 - fVar31))) *
                                   fVar60 + fVar30 * fVar61 * (_UNK_14380c188 * fVar61 +
                                                              _UNK_14380c148) +
                                   fVar98 + (fVar30 - fVar53) + fVar40 + (fVar53 - fVar83) +
                                   (_UNK_14380c108 * fVar61 + _UNK_14380c0c8) * fVar61 * fVar73 *
                                   fVar60) & uVar6;
    local_100[3] = ~uVar7 & local_100[3] |
                   (uint)(fVar85 + *(float *)(&DAT_14380b008 + uVar23) +
                                   (float)(uVar14 & (uint)(fVar75 + (fVar84 * 6.283203 - fVar44))) *
                                   fVar63 + fVar28 * fVar64 * (_UNK_14380c18c * fVar64 +
                                                              _UNK_14380c14c) +
                                   fVar99 + (fVar28 - fVar54) + fVar46 + (fVar54 - fVar85) +
                                   (_UNK_14380c10c * fVar64 + _UNK_14380c0cc) * fVar64 * fVar76 *
                                   fVar63) & uVar7;
  }
  if (uVar3 != 0) {
    uVar2 = 0;
    do {
      if ((uVar3 >> ((uint)uVar2 & 0x1f) & 1) != 0) {
        FUN_1402716e0(local_140 + uVar2,local_100 + uVar2);
      }
      uVar4 = (uint)uVar2 + 1;
      uVar2 = (ulonglong)uVar4;
    } while ((int)uVar4 < 4);
  }
  return;
}

