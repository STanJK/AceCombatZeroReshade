/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14026fd60; RVA 0x26fd60
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_14026fd60(undefined8 param_1)

{
  undefined4 in_EAX;
  int iVar1;
  uint uVar2;
  ulonglong uVar3;
  uint uVar4;
  float fVar5;
  float in_XMM0_Dc;
  float in_XMM0_Dd;
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  float fVar23;
  float fVar24;
  float fVar26;
  uint uVar27;
  float fVar28;
  float fVar29;
  uint uVar30;
  float fVar31;
  float fVar32;
  uint uVar33;
  undefined1 auVar25 [16];
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar40;
  float fVar41;
  float fVar42;
  float fVar43;
  float fVar44;
  float fVar45;
  float fVar46;
  undefined1 auVar38 [16];
  undefined1 auVar39 [16];
  float fVar47;
  float fVar48;
  float fVar49;
  float fVar52;
  float fVar53;
  undefined1 auVar50 [16];
  undefined1 auVar51 [16];
  float fVar54;
  undefined1 auVar55 [16];
  float fVar58;
  undefined1 auVar56 [16];
  undefined1 auVar57 [16];
  float fVar59;
  float fVar60;
  uint uVar61;
  float fVar64;
  uint uVar65;
  float fVar66;
  uint uVar67;
  undefined1 auVar62 [16];
  undefined1 auVar63 [16];
  float fVar68;
  uint uVar69;
  uint uVar70;
  float fVar71;
  uint uVar74;
  float fVar75;
  uint uVar76;
  float fVar77;
  undefined1 auVar72 [16];
  undefined1 auVar73 [16];
  uint uVar78;
  float fVar79;
  float local_140 [16];
  undefined1 local_100 [14] [16];
  
  fVar5 = (float)((ulonglong)param_1 >> 0x20);
  local_140[0] = (float)param_1;
  uVar4 = 0;
  fVar23 = (float)((uint)local_140[0] & _DAT_14380c000);
  fVar26 = (float)((uint)fVar5 & _UNK_14380c004);
  fVar29 = (float)((uint)in_XMM0_Dc & _UNK_14380c008);
  fVar32 = (float)((uint)in_XMM0_Dd & _UNK_14380c00c);
  fVar11 = _DAT_14380c480 * fVar23 + _DAT_14380c4c0;
  fVar13 = _UNK_14380c484 * fVar26 + _UNK_14380c4c4;
  fVar15 = _UNK_14380c488 * fVar29 + _UNK_14380c4c8;
  fVar17 = _UNK_14380c48c * fVar32 + _UNK_14380c4cc;
  fVar12 = fVar11 - _DAT_14380c4c0;
  fVar14 = fVar13 - _UNK_14380c4c4;
  fVar16 = fVar15 - _UNK_14380c4c8;
  fVar18 = fVar17 - _UNK_14380c4cc;
  auVar6._4_4_ = -(uint)(_UNK_14380c044 < fVar26);
  auVar6._0_4_ = -(uint)(_DAT_14380c040 < fVar23);
  auVar6._8_4_ = -(uint)(_UNK_14380c048 < fVar29);
  auVar6._12_4_ = -(uint)(_UNK_14380c04c < fVar32);
  iVar1 = movmskps(in_EAX,auVar6);
  fVar35 = (((fVar23 - _DAT_14380c1c0 * fVar12) - _DAT_14380c200 * fVar12) - _DAT_14380c240 * fVar12
           ) - _DAT_14380c280 * fVar12;
  fVar40 = (((fVar26 - _UNK_14380c1c4 * fVar14) - _UNK_14380c204 * fVar14) - _UNK_14380c244 * fVar14
           ) - _UNK_14380c284 * fVar14;
  fVar43 = (((fVar29 - _UNK_14380c1c8 * fVar16) - _UNK_14380c208 * fVar16) - _UNK_14380c248 * fVar16
           ) - _UNK_14380c288 * fVar16;
  fVar46 = (((fVar32 - _UNK_14380c1cc * fVar18) - _UNK_14380c20c * fVar18) - _UNK_14380c24c * fVar18
           ) - _UNK_14380c28c * fVar18;
  fVar12 = fVar35 * fVar35;
  fVar14 = fVar40 * fVar40;
  fVar16 = fVar43 * fVar43;
  fVar18 = fVar46 * fVar46;
  fVar35 = (float)((uint)fVar35 ^ (int)fVar11 << 0x1f);
  fVar40 = (float)((uint)fVar40 ^ (int)fVar13 << 0x1f);
  fVar43 = (float)((uint)fVar43 ^ (int)fVar15 << 0x1f);
  fVar46 = (float)((uint)fVar46 ^ (int)fVar17 << 0x1f);
  local_100[0]._0_4_ =
       (uint)(fVar35 + fVar12 * (((_DAT_14380c440 * fVar12 + _DAT_14380c400) * fVar12 +
                                 _DAT_14380c3c0) * fVar12 + _DAT_14380c380) * fVar35) ^
       ~_DAT_14380c000 & (uint)local_140[0];
  local_100[0]._4_4_ =
       (uint)(fVar40 + fVar14 * (((_UNK_14380c444 * fVar14 + _UNK_14380c404) * fVar14 +
                                 _UNK_14380c3c4) * fVar14 + _UNK_14380c384) * fVar40) ^
       ~_UNK_14380c004 & (uint)fVar5;
  local_100[0]._8_4_ =
       (uint)(fVar43 + fVar16 * (((_UNK_14380c448 * fVar16 + _UNK_14380c408) * fVar16 +
                                 _UNK_14380c3c8) * fVar16 + _UNK_14380c388) * fVar43) ^
       ~_UNK_14380c008 & (uint)in_XMM0_Dc;
  local_100[0]._12_4_ =
       (uint)(fVar46 + fVar18 * (((_UNK_14380c44c * fVar18 + _UNK_14380c40c) * fVar18 +
                                 _UNK_14380c3cc) * fVar18 + _UNK_14380c38c) * fVar46) ^
       ~_UNK_14380c00c & (uint)in_XMM0_Dd;
  if (iVar1 != 0) {
    auVar25._4_4_ = -(uint)((float)((uint)fVar26 & (uint)_UNK_14380c084) == _UNK_14380c084);
    auVar25._0_4_ = -(uint)((float)((uint)fVar23 & (uint)_DAT_14380c080) == _DAT_14380c080);
    auVar25._8_4_ = -(uint)((float)((uint)fVar29 & (uint)_UNK_14380c088) == _UNK_14380c088);
    auVar25._12_4_ = -(uint)((float)((uint)fVar32 & (uint)_UNK_14380c08c) == _UNK_14380c08c);
    uVar4 = movmskps(0,auVar25);
    uVar2 = (((uint)local_140[0] & 0x7f800000) >> 0x17) * 0xc;
    uVar27 = (((uint)fVar5 & 0x7f800000) >> 0x17) * 0xc;
    uVar30 = (((uint)in_XMM0_Dc & 0x7f800000) >> 0x17) * 0xc;
    uVar33 = (((uint)in_XMM0_Dd & 0x7f800000) >> 0x17) * 0xc;
    auVar73._4_4_ = *(uint *)(&DAT_14380a408 + uVar27);
    auVar73._0_4_ = *(uint *)(&DAT_14380a408 + uVar2);
    auVar73._12_4_ = *(uint *)(&DAT_14380a408 + uVar33);
    auVar73._8_4_ = *(uint *)(&DAT_14380a408 + uVar30);
    auVar50._12_4_ = *(uint *)(&DAT_14380a404 + uVar33);
    auVar50._8_4_ = *(uint *)(&DAT_14380a404 + uVar30);
    auVar50._4_4_ = *(uint *)(&DAT_14380a404 + uVar27);
    auVar50._0_4_ = *(uint *)(&DAT_14380a404 + uVar2);
    auVar56._4_4_ = *(uint *)(&DAT_14380a400 + uVar27);
    auVar56._0_4_ = *(uint *)(&DAT_14380a400 + uVar2);
    auVar56._12_4_ = *(uint *)(&DAT_14380a400 + uVar33);
    auVar56._8_4_ = *(uint *)(&DAT_14380a400 + uVar30);
    auVar55._0_4_ = *(uint *)(&DAT_14380a408 + uVar2) >> 0x10;
    auVar55._4_4_ = *(uint *)(&DAT_14380a408 + uVar27) >> 0x10;
    auVar55._8_4_ = *(uint *)(&DAT_14380a408 + uVar30) >> 0x10;
    auVar55._12_4_ = *(uint *)(&DAT_14380a408 + uVar33) >> 0x10;
    auVar63._0_4_ = *(uint *)(&DAT_14380a404 + uVar2) >> 0x10;
    auVar63._4_4_ = *(uint *)(&DAT_14380a404 + uVar27) >> 0x10;
    auVar63._8_4_ = *(uint *)(&DAT_14380a404 + uVar30) >> 0x10;
    auVar63._12_4_ = *(uint *)(&DAT_14380a404 + uVar33) >> 0x10;
    auVar57._0_4_ = *(uint *)(&DAT_14380a400 + uVar2) >> 0x10;
    auVar57._4_4_ = *(uint *)(&DAT_14380a400 + uVar27) >> 0x10;
    auVar57._8_4_ = *(uint *)(&DAT_14380a400 + uVar30) >> 0x10;
    auVar57._12_4_ = *(uint *)(&DAT_14380a400 + uVar33) >> 0x10;
    auVar62._0_4_ = ((uint)local_140[0] & 0x7fffff) + 0x800000;
    auVar62._4_4_ = ((uint)fVar5 & 0x7fffff) + 0x800000;
    auVar62._8_4_ = ((uint)in_XMM0_Dc & 0x7fffff) + 0x800000;
    auVar62._12_4_ = ((uint)in_XMM0_Dd & 0x7fffff) + 0x800000;
    auVar7._8_4_ = 0xffff;
    auVar7._0_8_ = 0xffff0000ffff;
    auVar7._12_4_ = 0xffff;
    auVar22._0_4_ = auVar62._0_4_ >> 0x10;
    auVar22._4_4_ = auVar62._4_4_ >> 0x10;
    auVar22._8_4_ = auVar62._8_4_ >> 0x10;
    auVar22._12_4_ = auVar62._12_4_ >> 0x10;
    auVar62 = auVar62 & auVar7;
    auVar21 = pmulld(auVar62,auVar50 & auVar7);
    auVar6 = pmulld(auVar22,auVar55);
    auVar72 = pmulld(auVar55,auVar62);
    auVar55 = auVar21 & auVar7;
    auVar38 = pmulld(auVar73 & auVar7,auVar22);
    auVar25 = pmulld(auVar62,auVar63);
    auVar51 = pmulld(auVar50 & auVar7,auVar22);
    auVar39._0_4_ = (auVar38._0_4_ >> 0x10) + auVar55._0_4_ + auVar6._0_4_ + (auVar72._0_4_ >> 0x10)
    ;
    auVar39._4_4_ = (auVar38._4_4_ >> 0x10) + auVar55._4_4_ + auVar6._4_4_ + (auVar72._4_4_ >> 0x10)
    ;
    auVar39._8_4_ = (auVar38._8_4_ >> 0x10) + auVar55._8_4_ + auVar6._8_4_ + (auVar72._8_4_ >> 0x10)
    ;
    auVar39._12_4_ =
         (auVar38._12_4_ >> 0x10) + auVar55._12_4_ + auVar6._12_4_ + (auVar72._12_4_ >> 0x10);
    auVar73 = auVar25 & auVar7;
    auVar38 = pmulld(auVar62,auVar56 & auVar7);
    auVar6 = pmulld(auVar63,auVar22);
    uVar2 = (auVar39._0_4_ >> 0x10) + auVar73._0_4_ + auVar51._0_4_ + (auVar21._0_4_ >> 0x10);
    uVar27 = (auVar39._4_4_ >> 0x10) + auVar73._4_4_ + auVar51._4_4_ + (auVar21._4_4_ >> 0x10);
    uVar30 = (auVar39._8_4_ >> 0x10) + auVar73._8_4_ + auVar51._8_4_ + (auVar21._8_4_ >> 0x10);
    uVar33 = (auVar39._12_4_ >> 0x10) + auVar73._12_4_ + auVar51._12_4_ + (auVar21._12_4_ >> 0x10);
    auVar21 = auVar38 & auVar7;
    auVar63 = pmulld(auVar62,auVar57);
    auVar51._0_4_ = (uVar2 >> 0x10) + auVar21._0_4_ + auVar6._0_4_ + (auVar25._0_4_ >> 0x10);
    auVar51._4_4_ = (uVar27 >> 0x10) + auVar21._4_4_ + auVar6._4_4_ + (auVar25._4_4_ >> 0x10);
    auVar51._8_4_ = (uVar30 >> 0x10) + auVar21._8_4_ + auVar6._8_4_ + (auVar25._8_4_ >> 0x10);
    auVar51._12_4_ = (uVar33 >> 0x10) + auVar21._12_4_ + auVar6._12_4_ + (auVar25._12_4_ >> 0x10);
    auVar6 = pmulld(auVar22,auVar56 & auVar7);
    auVar63 = auVar63 & auVar7;
    auVar22 = auVar51 & auVar7;
    auVar39 = auVar39 & auVar7;
    uVar70 = ((auVar51._0_4_ >> 0x10) + auVar63._0_4_ + auVar6._0_4_ + (auVar38._0_4_ >> 0x10)) *
             0x10000 + auVar22._0_4_;
    uVar74 = ((auVar51._4_4_ >> 0x10) + auVar63._4_4_ + auVar6._4_4_ + (auVar38._4_4_ >> 0x10)) *
             0x10000 + auVar22._4_4_;
    uVar76 = ((auVar51._8_4_ >> 0x10) + auVar63._8_4_ + auVar6._8_4_ + (auVar38._8_4_ >> 0x10)) *
             0x10000 + auVar22._8_4_;
    uVar78 = ((auVar51._12_4_ >> 0x10) + auVar63._12_4_ + auVar6._12_4_ + (auVar38._12_4_ >> 0x10))
             * 0x10000 + auVar22._12_4_;
    uVar2 = uVar2 * 0x10000 + auVar39._0_4_;
    uVar27 = uVar27 * 0x10000 + auVar39._4_4_;
    uVar30 = uVar30 * 0x10000 + auVar39._8_4_;
    uVar33 = uVar33 * 0x10000 + auVar39._12_4_;
    uVar61 = (uint)local_140[0] & 0x80000000;
    uVar65 = (uint)fVar5 & 0x80000000;
    uVar67 = (uint)in_XMM0_Dc & 0x80000000;
    uVar69 = (uint)in_XMM0_Dd & 0x80000000;
    fVar43 = (float)(uVar70 >> 9 | uVar61 ^ 0x3f800000);
    fVar46 = (float)(uVar74 >> 9 | uVar65 ^ 0x3f800000);
    fVar58 = (float)(uVar76 >> 9 | uVar67 ^ 0x3f800000);
    fVar59 = (float)(uVar78 >> 9 | uVar69 ^ 0x3f800000);
    fVar60 = fVar43 + 49152.0;
    fVar64 = fVar46 + 49152.0;
    fVar66 = fVar58 + 49152.0;
    fVar68 = fVar59 + 49152.0;
    fVar15 = (float)((uVar70 & 0x1ff) << 0xe | uVar2 >> 0x12 | uVar61 ^ 0x34000000) -
             (float)(uVar61 ^ 0x34000000);
    fVar17 = (float)((uVar74 & 0x1ff) << 0xe | uVar27 >> 0x12 | uVar65 ^ 0x34000000) -
             (float)(uVar65 ^ 0x34000000);
    fVar35 = (float)((uVar76 & 0x1ff) << 0xe | uVar30 >> 0x12 | uVar67 ^ 0x34000000) -
             (float)(uVar67 ^ 0x34000000);
    fVar40 = (float)((uVar78 & 0x1ff) << 0xe | uVar33 >> 0x12 | uVar69 ^ 0x34000000) -
             (float)(uVar69 ^ 0x34000000);
    fVar43 = fVar43 - (fVar60 - 49152.0);
    fVar46 = fVar46 - (fVar64 - 49152.0);
    fVar58 = fVar58 - (fVar66 - 49152.0);
    fVar59 = fVar59 - (fVar68 - 49152.0);
    fVar12 = fVar43 + fVar15;
    fVar14 = fVar46 + fVar17;
    fVar11 = fVar58 + fVar35;
    fVar13 = fVar59 + fVar40;
    fVar8 = (float)((uint)fVar12 & 0xfffff000);
    fVar9 = (float)((uint)fVar11 & 0xfffff000);
    fVar10 = (float)((uint)fVar13 & 0xfffff000);
    fVar16 = fVar14 - (float)((uint)fVar14 & 0xfffff000);
    fVar18 = (float)((uint)fVar14 & 0xfffff000) * 6.283203;
    fVar36 = (fVar12 - fVar8) * 6.283203 + fVar8 * -1.781782e-05 +
             (((float)((uVar2 & 0x3ffff) << 5 | uVar61 ^ 0x28800000) - (float)(uVar61 ^ 0x28800000))
             + fVar15 + (fVar43 - fVar12)) * 6.2831855 + (fVar12 - fVar8) * -1.781782e-05;
    fVar41 = fVar16 * 6.283203 + (float)((uint)fVar14 & 0xfffff000) * -1.781782e-05 +
             (((float)((uVar27 & 0x3ffff) << 5 | uVar65 ^ 0x28800000) - (float)(uVar65 ^ 0x28800000)
              ) + fVar17 + (fVar46 - fVar14)) * 6.2831855 + fVar16 * -1.781782e-05;
    fVar44 = (fVar11 - fVar9) * 6.283203 + fVar9 * -1.781782e-05 +
             (((float)((uVar30 & 0x3ffff) << 5 | uVar67 ^ 0x28800000) - (float)(uVar67 ^ 0x28800000)
              ) + fVar35 + (fVar58 - fVar11)) * 6.2831855 + (fVar11 - fVar9) * -1.781782e-05;
    fVar47 = (fVar13 - fVar10) * 6.283203 + fVar10 * -1.781782e-05 +
             (((float)((uVar33 & 0x3ffff) << 5 | uVar69 ^ 0x28800000) - (float)(uVar69 ^ 0x28800000)
              ) + fVar40 + (fVar59 - fVar13)) * 6.2831855 + (fVar13 - fVar10) * -1.781782e-05;
    fVar71 = fVar36 + fVar8 * 6.283203;
    fVar75 = fVar41 + fVar18;
    fVar77 = fVar44 + fVar9 * 6.283203;
    fVar79 = fVar47 + fVar10 * 6.283203;
    uVar2 = -(uint)(9.536743e-07 < ABS(local_140[0]));
    uVar27 = -(uint)(9.536743e-07 < ABS(fVar5));
    uVar30 = -(uint)(9.536743e-07 < ABS(in_XMM0_Dc));
    uVar33 = -(uint)(9.536743e-07 < ABS(in_XMM0_Dd));
    fVar24 = (float)(-(uint)(ABS(local_140[0]) <= 9.536743e-07) & (uint)local_140[0] |
                    (uint)fVar71 & uVar2);
    fVar28 = (float)(-(uint)(ABS(fVar5) <= 9.536743e-07) & (uint)fVar5 | (uint)fVar75 & uVar27);
    fVar31 = (float)(-(uint)(ABS(in_XMM0_Dc) <= 9.536743e-07) & (uint)in_XMM0_Dc |
                    (uint)fVar77 & uVar30);
    fVar34 = (float)(-(uint)(ABS(in_XMM0_Dd) <= 9.536743e-07) & (uint)in_XMM0_Dd |
                    (uint)fVar79 & uVar33);
    uVar61 = ((uint)fVar60 & 0xff) << 4;
    uVar65 = ((uint)fVar64 & 0xff) << 4;
    uVar67 = ((uint)fVar66 & 0xff) << 4;
    uVar69 = ((uint)fVar68 & 0xff) << 4;
    fVar66 = fVar24 * fVar24;
    fVar68 = fVar28 * fVar28;
    fVar19 = fVar31 * fVar31;
    fVar20 = fVar34 * fVar34;
    fVar5 = *(float *)(&DAT_14380b004 + uVar61);
    fVar12 = *(float *)(&DAT_14380b004 + uVar67);
    fVar14 = *(float *)(&DAT_14380b004 + uVar65);
    fVar16 = *(float *)(&DAT_14380b004 + uVar69);
    fVar11 = fVar24 * *(float *)(&DAT_14380b00c + uVar61);
    fVar13 = fVar28 * *(float *)(&DAT_14380b00c + uVar65);
    fVar15 = fVar31 * *(float *)(&DAT_14380b00c + uVar67);
    fVar17 = fVar34 * *(float *)(&DAT_14380b00c + uVar69);
    fVar37 = fVar5 + fVar11;
    fVar42 = fVar14 + fVar13;
    fVar45 = fVar12 + fVar15;
    fVar48 = fVar16 + fVar17;
    fVar49 = fVar24 * *(float *)(&DAT_14380b000 + uVar61);
    fVar52 = fVar28 * *(float *)(&DAT_14380b000 + uVar65);
    fVar53 = fVar31 * *(float *)(&DAT_14380b000 + uVar67);
    fVar54 = fVar34 * *(float *)(&DAT_14380b000 + uVar69);
    fVar35 = fVar37 + fVar49;
    fVar40 = fVar42 + fVar52;
    fVar43 = fVar45 + fVar53;
    fVar46 = fVar48 + fVar54;
    fVar58 = (*(float *)(&DAT_14380b000 + uVar61) + *(float *)(&DAT_14380b00c + uVar61)) -
             fVar24 * fVar5;
    fVar59 = (*(float *)(&DAT_14380b000 + uVar65) + *(float *)(&DAT_14380b00c + uVar65)) -
             fVar28 * fVar14;
    fVar60 = (*(float *)(&DAT_14380b000 + uVar67) + *(float *)(&DAT_14380b00c + uVar67)) -
             fVar31 * fVar12;
    fVar64 = (*(float *)(&DAT_14380b000 + uVar69) + *(float *)(&DAT_14380b00c + uVar69)) -
             fVar34 * fVar16;
    auVar21._0_4_ =
         fVar35 + *(float *)(&DAT_14380b008 + uVar61) +
                  (float)(uVar2 & (uint)(fVar36 + (fVar8 * 6.283203 - fVar71))) * fVar58 +
                  fVar5 * fVar66 * (_DAT_14380c180 * fVar66 + _DAT_14380c140) +
                  fVar11 + (fVar5 - fVar37) + fVar49 + (fVar37 - fVar35) +
                  (_DAT_14380c100 * fVar66 + _DAT_14380c0c0) * fVar66 * fVar24 * fVar58;
    auVar21._4_4_ =
         fVar40 + *(float *)(&DAT_14380b008 + uVar65) +
                  (float)(uVar27 & (uint)(fVar41 + (fVar18 - fVar75))) * fVar59 +
                  fVar14 * fVar68 * (_UNK_14380c184 * fVar68 + _UNK_14380c144) +
                  fVar13 + (fVar14 - fVar42) + fVar52 + (fVar42 - fVar40) +
                  (_UNK_14380c104 * fVar68 + _UNK_14380c0c4) * fVar68 * fVar28 * fVar59;
    auVar21._8_4_ =
         fVar43 + *(float *)(&DAT_14380b008 + uVar67) +
                  (float)(uVar30 & (uint)(fVar44 + (fVar9 * 6.283203 - fVar77))) * fVar60 +
                  fVar12 * fVar19 * (_UNK_14380c188 * fVar19 + _UNK_14380c148) +
                  fVar15 + (fVar12 - fVar45) + fVar53 + (fVar45 - fVar43) +
                  (_UNK_14380c108 * fVar19 + _UNK_14380c0c8) * fVar19 * fVar31 * fVar60;
    auVar21._12_4_ =
         fVar46 + *(float *)(&DAT_14380b008 + uVar69) +
                  (float)(uVar33 & (uint)(fVar47 + (fVar10 * 6.283203 - fVar79))) * fVar64 +
                  fVar16 * fVar20 * (_UNK_14380c18c * fVar20 + _UNK_14380c14c) +
                  fVar17 + (fVar16 - fVar48) + fVar54 + (fVar48 - fVar46) +
                  (_UNK_14380c10c * fVar20 + _UNK_14380c0cc) * fVar20 * fVar34 * fVar64;
    auVar38._4_4_ = -(uint)(_UNK_14380c044 < fVar26);
    auVar38._0_4_ = -(uint)(_DAT_14380c040 < fVar23);
    auVar38._8_4_ = -(uint)(_UNK_14380c048 < fVar29);
    auVar38._12_4_ = -(uint)(_UNK_14380c04c < fVar32);
    local_100[0] = blendvps(local_100[0],auVar21,auVar38);
  }
  if (uVar4 != 0) {
    uVar3 = 0;
    do {
      if ((uVar4 >> ((uint)uVar3 & 0x1f) & 1) != 0) {
        FUN_1402716e0(local_140 + uVar3,local_100[0] + uVar3 * 4);
      }
      uVar2 = (uint)uVar3 + 1;
      uVar3 = (ulonglong)uVar2;
    } while ((int)uVar2 < 4);
  }
  return local_100[0]._0_8_;
}

