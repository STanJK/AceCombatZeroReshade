/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14026f390; RVA 0x26f390
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_14026f390(undefined8 param_1)

{
  undefined4 in_EAX;
  int iVar1;
  uint uVar2;
  ulonglong uVar3;
  uint uVar4;
  float fVar6;
  undefined8 uVar5;
  float in_XMM0_Dc;
  float in_XMM0_Dd;
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  float fVar24;
  float fVar25;
  float fVar27;
  uint uVar28;
  float fVar29;
  float fVar30;
  uint uVar31;
  float fVar32;
  float fVar33;
  uint uVar34;
  undefined1 auVar26 [16];
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  float fVar41;
  float fVar42;
  float fVar43;
  float fVar44;
  float fVar45;
  float fVar46;
  float fVar47;
  undefined1 auVar39 [16];
  undefined1 auVar40 [16];
  float fVar48;
  float fVar49;
  float fVar50;
  float fVar53;
  float fVar54;
  undefined1 auVar51 [16];
  undefined1 auVar52 [16];
  float fVar55;
  undefined1 auVar56 [16];
  float fVar59;
  undefined1 auVar57 [16];
  undefined1 auVar58 [16];
  float fVar60;
  float fVar61;
  uint uVar62;
  float fVar65;
  uint uVar66;
  float fVar67;
  uint uVar68;
  undefined1 auVar63 [16];
  undefined1 auVar64 [16];
  float fVar69;
  uint uVar70;
  uint uVar71;
  float fVar72;
  uint uVar75;
  float fVar76;
  uint uVar77;
  float fVar78;
  undefined1 auVar73 [16];
  undefined1 auVar74 [16];
  uint uVar79;
  float fVar80;
  float afStack_140 [16];
  undefined1 aauStack_100 [14] [16];
  
  fVar6 = (float)((ulonglong)param_1 >> 0x20);
  afStack_140[0] = (float)param_1;
  if (DAT_140309090 < 2) {
    uVar5 = FUN_14026f420();
    return uVar5;
  }
  uVar4 = 0;
  fVar24 = (float)((uint)afStack_140[0] & _DAT_14380c000);
  fVar27 = (float)((uint)fVar6 & _UNK_14380c004);
  fVar30 = (float)((uint)in_XMM0_Dc & _UNK_14380c008);
  fVar33 = (float)((uint)in_XMM0_Dd & _UNK_14380c00c);
  fVar12 = _DAT_14380c480 * fVar24 + _DAT_14380c4c0;
  fVar14 = _UNK_14380c484 * fVar27 + _UNK_14380c4c4;
  fVar16 = _UNK_14380c488 * fVar30 + _UNK_14380c4c8;
  fVar18 = _UNK_14380c48c * fVar33 + _UNK_14380c4cc;
  fVar13 = fVar12 - _DAT_14380c4c0;
  fVar15 = fVar14 - _UNK_14380c4c4;
  fVar17 = fVar16 - _UNK_14380c4c8;
  fVar19 = fVar18 - _UNK_14380c4cc;
  auVar7._4_4_ = -(uint)(_UNK_14380c044 < fVar27);
  auVar7._0_4_ = -(uint)(_DAT_14380c040 < fVar24);
  auVar7._8_4_ = -(uint)(_UNK_14380c048 < fVar30);
  auVar7._12_4_ = -(uint)(_UNK_14380c04c < fVar33);
  iVar1 = movmskps(in_EAX,auVar7);
  fVar36 = (((fVar24 - _DAT_14380c1c0 * fVar13) - _DAT_14380c200 * fVar13) - _DAT_14380c240 * fVar13
           ) - _DAT_14380c280 * fVar13;
  fVar41 = (((fVar27 - _UNK_14380c1c4 * fVar15) - _UNK_14380c204 * fVar15) - _UNK_14380c244 * fVar15
           ) - _UNK_14380c284 * fVar15;
  fVar44 = (((fVar30 - _UNK_14380c1c8 * fVar17) - _UNK_14380c208 * fVar17) - _UNK_14380c248 * fVar17
           ) - _UNK_14380c288 * fVar17;
  fVar47 = (((fVar33 - _UNK_14380c1cc * fVar19) - _UNK_14380c20c * fVar19) - _UNK_14380c24c * fVar19
           ) - _UNK_14380c28c * fVar19;
  fVar13 = fVar36 * fVar36;
  fVar15 = fVar41 * fVar41;
  fVar17 = fVar44 * fVar44;
  fVar19 = fVar47 * fVar47;
  fVar36 = (float)((uint)fVar36 ^ (int)fVar12 << 0x1f);
  fVar41 = (float)((uint)fVar41 ^ (int)fVar14 << 0x1f);
  fVar44 = (float)((uint)fVar44 ^ (int)fVar16 << 0x1f);
  fVar47 = (float)((uint)fVar47 ^ (int)fVar18 << 0x1f);
  aauStack_100[0]._0_4_ =
       (uint)(fVar36 + fVar13 * (((_DAT_14380c440 * fVar13 + _DAT_14380c400) * fVar13 +
                                 _DAT_14380c3c0) * fVar13 + _DAT_14380c380) * fVar36) ^
       ~_DAT_14380c000 & (uint)afStack_140[0];
  aauStack_100[0]._4_4_ =
       (uint)(fVar41 + fVar15 * (((_UNK_14380c444 * fVar15 + _UNK_14380c404) * fVar15 +
                                 _UNK_14380c3c4) * fVar15 + _UNK_14380c384) * fVar41) ^
       ~_UNK_14380c004 & (uint)fVar6;
  aauStack_100[0]._8_4_ =
       (uint)(fVar44 + fVar17 * (((_UNK_14380c448 * fVar17 + _UNK_14380c408) * fVar17 +
                                 _UNK_14380c3c8) * fVar17 + _UNK_14380c388) * fVar44) ^
       ~_UNK_14380c008 & (uint)in_XMM0_Dc;
  aauStack_100[0]._12_4_ =
       (uint)(fVar47 + fVar19 * (((_UNK_14380c44c * fVar19 + _UNK_14380c40c) * fVar19 +
                                 _UNK_14380c3cc) * fVar19 + _UNK_14380c38c) * fVar47) ^
       ~_UNK_14380c00c & (uint)in_XMM0_Dd;
  if (iVar1 != 0) {
    auVar26._4_4_ = -(uint)((float)((uint)fVar27 & (uint)_UNK_14380c084) == _UNK_14380c084);
    auVar26._0_4_ = -(uint)((float)((uint)fVar24 & (uint)_DAT_14380c080) == _DAT_14380c080);
    auVar26._8_4_ = -(uint)((float)((uint)fVar30 & (uint)_UNK_14380c088) == _UNK_14380c088);
    auVar26._12_4_ = -(uint)((float)((uint)fVar33 & (uint)_UNK_14380c08c) == _UNK_14380c08c);
    uVar4 = movmskps(0,auVar26);
    uVar2 = (((uint)afStack_140[0] & 0x7f800000) >> 0x17) * 0xc;
    uVar28 = (((uint)fVar6 & 0x7f800000) >> 0x17) * 0xc;
    uVar31 = (((uint)in_XMM0_Dc & 0x7f800000) >> 0x17) * 0xc;
    uVar34 = (((uint)in_XMM0_Dd & 0x7f800000) >> 0x17) * 0xc;
    auVar74._4_4_ = *(uint *)(&DAT_14380a408 + uVar28);
    auVar74._0_4_ = *(uint *)(&DAT_14380a408 + uVar2);
    auVar74._12_4_ = *(uint *)(&DAT_14380a408 + uVar34);
    auVar74._8_4_ = *(uint *)(&DAT_14380a408 + uVar31);
    auVar51._12_4_ = *(uint *)(&DAT_14380a404 + uVar34);
    auVar51._8_4_ = *(uint *)(&DAT_14380a404 + uVar31);
    auVar51._4_4_ = *(uint *)(&DAT_14380a404 + uVar28);
    auVar51._0_4_ = *(uint *)(&DAT_14380a404 + uVar2);
    auVar57._4_4_ = *(uint *)(&DAT_14380a400 + uVar28);
    auVar57._0_4_ = *(uint *)(&DAT_14380a400 + uVar2);
    auVar57._12_4_ = *(uint *)(&DAT_14380a400 + uVar34);
    auVar57._8_4_ = *(uint *)(&DAT_14380a400 + uVar31);
    auVar56._0_4_ = *(uint *)(&DAT_14380a408 + uVar2) >> 0x10;
    auVar56._4_4_ = *(uint *)(&DAT_14380a408 + uVar28) >> 0x10;
    auVar56._8_4_ = *(uint *)(&DAT_14380a408 + uVar31) >> 0x10;
    auVar56._12_4_ = *(uint *)(&DAT_14380a408 + uVar34) >> 0x10;
    auVar64._0_4_ = *(uint *)(&DAT_14380a404 + uVar2) >> 0x10;
    auVar64._4_4_ = *(uint *)(&DAT_14380a404 + uVar28) >> 0x10;
    auVar64._8_4_ = *(uint *)(&DAT_14380a404 + uVar31) >> 0x10;
    auVar64._12_4_ = *(uint *)(&DAT_14380a404 + uVar34) >> 0x10;
    auVar58._0_4_ = *(uint *)(&DAT_14380a400 + uVar2) >> 0x10;
    auVar58._4_4_ = *(uint *)(&DAT_14380a400 + uVar28) >> 0x10;
    auVar58._8_4_ = *(uint *)(&DAT_14380a400 + uVar31) >> 0x10;
    auVar58._12_4_ = *(uint *)(&DAT_14380a400 + uVar34) >> 0x10;
    auVar63._0_4_ = ((uint)afStack_140[0] & 0x7fffff) + 0x800000;
    auVar63._4_4_ = ((uint)fVar6 & 0x7fffff) + 0x800000;
    auVar63._8_4_ = ((uint)in_XMM0_Dc & 0x7fffff) + 0x800000;
    auVar63._12_4_ = ((uint)in_XMM0_Dd & 0x7fffff) + 0x800000;
    auVar8._8_4_ = 0xffff;
    auVar8._0_8_ = 0xffff0000ffff;
    auVar8._12_4_ = 0xffff;
    auVar23._0_4_ = auVar63._0_4_ >> 0x10;
    auVar23._4_4_ = auVar63._4_4_ >> 0x10;
    auVar23._8_4_ = auVar63._8_4_ >> 0x10;
    auVar23._12_4_ = auVar63._12_4_ >> 0x10;
    auVar63 = auVar63 & auVar8;
    auVar22 = pmulld(auVar63,auVar51 & auVar8);
    auVar7 = pmulld(auVar23,auVar56);
    auVar73 = pmulld(auVar56,auVar63);
    auVar56 = auVar22 & auVar8;
    auVar39 = pmulld(auVar74 & auVar8,auVar23);
    auVar26 = pmulld(auVar63,auVar64);
    auVar52 = pmulld(auVar51 & auVar8,auVar23);
    auVar40._0_4_ = (auVar39._0_4_ >> 0x10) + auVar56._0_4_ + auVar7._0_4_ + (auVar73._0_4_ >> 0x10)
    ;
    auVar40._4_4_ = (auVar39._4_4_ >> 0x10) + auVar56._4_4_ + auVar7._4_4_ + (auVar73._4_4_ >> 0x10)
    ;
    auVar40._8_4_ = (auVar39._8_4_ >> 0x10) + auVar56._8_4_ + auVar7._8_4_ + (auVar73._8_4_ >> 0x10)
    ;
    auVar40._12_4_ =
         (auVar39._12_4_ >> 0x10) + auVar56._12_4_ + auVar7._12_4_ + (auVar73._12_4_ >> 0x10);
    auVar74 = auVar26 & auVar8;
    auVar39 = pmulld(auVar63,auVar57 & auVar8);
    auVar7 = pmulld(auVar64,auVar23);
    uVar2 = (auVar40._0_4_ >> 0x10) + auVar74._0_4_ + auVar52._0_4_ + (auVar22._0_4_ >> 0x10);
    uVar28 = (auVar40._4_4_ >> 0x10) + auVar74._4_4_ + auVar52._4_4_ + (auVar22._4_4_ >> 0x10);
    uVar31 = (auVar40._8_4_ >> 0x10) + auVar74._8_4_ + auVar52._8_4_ + (auVar22._8_4_ >> 0x10);
    uVar34 = (auVar40._12_4_ >> 0x10) + auVar74._12_4_ + auVar52._12_4_ + (auVar22._12_4_ >> 0x10);
    auVar22 = auVar39 & auVar8;
    auVar64 = pmulld(auVar63,auVar58);
    auVar52._0_4_ = (uVar2 >> 0x10) + auVar22._0_4_ + auVar7._0_4_ + (auVar26._0_4_ >> 0x10);
    auVar52._4_4_ = (uVar28 >> 0x10) + auVar22._4_4_ + auVar7._4_4_ + (auVar26._4_4_ >> 0x10);
    auVar52._8_4_ = (uVar31 >> 0x10) + auVar22._8_4_ + auVar7._8_4_ + (auVar26._8_4_ >> 0x10);
    auVar52._12_4_ = (uVar34 >> 0x10) + auVar22._12_4_ + auVar7._12_4_ + (auVar26._12_4_ >> 0x10);
    auVar7 = pmulld(auVar23,auVar57 & auVar8);
    auVar64 = auVar64 & auVar8;
    auVar23 = auVar52 & auVar8;
    auVar40 = auVar40 & auVar8;
    uVar71 = ((auVar52._0_4_ >> 0x10) + auVar64._0_4_ + auVar7._0_4_ + (auVar39._0_4_ >> 0x10)) *
             0x10000 + auVar23._0_4_;
    uVar75 = ((auVar52._4_4_ >> 0x10) + auVar64._4_4_ + auVar7._4_4_ + (auVar39._4_4_ >> 0x10)) *
             0x10000 + auVar23._4_4_;
    uVar77 = ((auVar52._8_4_ >> 0x10) + auVar64._8_4_ + auVar7._8_4_ + (auVar39._8_4_ >> 0x10)) *
             0x10000 + auVar23._8_4_;
    uVar79 = ((auVar52._12_4_ >> 0x10) + auVar64._12_4_ + auVar7._12_4_ + (auVar39._12_4_ >> 0x10))
             * 0x10000 + auVar23._12_4_;
    uVar2 = uVar2 * 0x10000 + auVar40._0_4_;
    uVar28 = uVar28 * 0x10000 + auVar40._4_4_;
    uVar31 = uVar31 * 0x10000 + auVar40._8_4_;
    uVar34 = uVar34 * 0x10000 + auVar40._12_4_;
    uVar62 = (uint)afStack_140[0] & 0x80000000;
    uVar66 = (uint)fVar6 & 0x80000000;
    uVar68 = (uint)in_XMM0_Dc & 0x80000000;
    uVar70 = (uint)in_XMM0_Dd & 0x80000000;
    fVar44 = (float)(uVar71 >> 9 | uVar62 ^ 0x3f800000);
    fVar47 = (float)(uVar75 >> 9 | uVar66 ^ 0x3f800000);
    fVar59 = (float)(uVar77 >> 9 | uVar68 ^ 0x3f800000);
    fVar60 = (float)(uVar79 >> 9 | uVar70 ^ 0x3f800000);
    fVar61 = fVar44 + 49152.0;
    fVar65 = fVar47 + 49152.0;
    fVar67 = fVar59 + 49152.0;
    fVar69 = fVar60 + 49152.0;
    fVar16 = (float)((uVar71 & 0x1ff) << 0xe | uVar2 >> 0x12 | uVar62 ^ 0x34000000) -
             (float)(uVar62 ^ 0x34000000);
    fVar18 = (float)((uVar75 & 0x1ff) << 0xe | uVar28 >> 0x12 | uVar66 ^ 0x34000000) -
             (float)(uVar66 ^ 0x34000000);
    fVar36 = (float)((uVar77 & 0x1ff) << 0xe | uVar31 >> 0x12 | uVar68 ^ 0x34000000) -
             (float)(uVar68 ^ 0x34000000);
    fVar41 = (float)((uVar79 & 0x1ff) << 0xe | uVar34 >> 0x12 | uVar70 ^ 0x34000000) -
             (float)(uVar70 ^ 0x34000000);
    fVar44 = fVar44 - (fVar61 - 49152.0);
    fVar47 = fVar47 - (fVar65 - 49152.0);
    fVar59 = fVar59 - (fVar67 - 49152.0);
    fVar60 = fVar60 - (fVar69 - 49152.0);
    fVar13 = fVar44 + fVar16;
    fVar15 = fVar47 + fVar18;
    fVar12 = fVar59 + fVar36;
    fVar14 = fVar60 + fVar41;
    fVar9 = (float)((uint)fVar13 & 0xfffff000);
    fVar10 = (float)((uint)fVar12 & 0xfffff000);
    fVar11 = (float)((uint)fVar14 & 0xfffff000);
    fVar17 = fVar15 - (float)((uint)fVar15 & 0xfffff000);
    fVar19 = (float)((uint)fVar15 & 0xfffff000) * 6.283203;
    fVar37 = (fVar13 - fVar9) * 6.283203 + fVar9 * -1.781782e-05 +
             (((float)((uVar2 & 0x3ffff) << 5 | uVar62 ^ 0x28800000) - (float)(uVar62 ^ 0x28800000))
             + fVar16 + (fVar44 - fVar13)) * 6.2831855 + (fVar13 - fVar9) * -1.781782e-05;
    fVar42 = fVar17 * 6.283203 + (float)((uint)fVar15 & 0xfffff000) * -1.781782e-05 +
             (((float)((uVar28 & 0x3ffff) << 5 | uVar66 ^ 0x28800000) - (float)(uVar66 ^ 0x28800000)
              ) + fVar18 + (fVar47 - fVar15)) * 6.2831855 + fVar17 * -1.781782e-05;
    fVar45 = (fVar12 - fVar10) * 6.283203 + fVar10 * -1.781782e-05 +
             (((float)((uVar31 & 0x3ffff) << 5 | uVar68 ^ 0x28800000) - (float)(uVar68 ^ 0x28800000)
              ) + fVar36 + (fVar59 - fVar12)) * 6.2831855 + (fVar12 - fVar10) * -1.781782e-05;
    fVar48 = (fVar14 - fVar11) * 6.283203 + fVar11 * -1.781782e-05 +
             (((float)((uVar34 & 0x3ffff) << 5 | uVar70 ^ 0x28800000) - (float)(uVar70 ^ 0x28800000)
              ) + fVar41 + (fVar60 - fVar14)) * 6.2831855 + (fVar14 - fVar11) * -1.781782e-05;
    fVar72 = fVar37 + fVar9 * 6.283203;
    fVar76 = fVar42 + fVar19;
    fVar78 = fVar45 + fVar10 * 6.283203;
    fVar80 = fVar48 + fVar11 * 6.283203;
    uVar2 = -(uint)(9.536743e-07 < ABS(afStack_140[0]));
    uVar28 = -(uint)(9.536743e-07 < ABS(fVar6));
    uVar31 = -(uint)(9.536743e-07 < ABS(in_XMM0_Dc));
    uVar34 = -(uint)(9.536743e-07 < ABS(in_XMM0_Dd));
    fVar25 = (float)(-(uint)(ABS(afStack_140[0]) <= 9.536743e-07) & (uint)afStack_140[0] |
                    (uint)fVar72 & uVar2);
    fVar29 = (float)(-(uint)(ABS(fVar6) <= 9.536743e-07) & (uint)fVar6 | (uint)fVar76 & uVar28);
    fVar32 = (float)(-(uint)(ABS(in_XMM0_Dc) <= 9.536743e-07) & (uint)in_XMM0_Dc |
                    (uint)fVar78 & uVar31);
    fVar35 = (float)(-(uint)(ABS(in_XMM0_Dd) <= 9.536743e-07) & (uint)in_XMM0_Dd |
                    (uint)fVar80 & uVar34);
    uVar62 = ((uint)fVar61 & 0xff) << 4;
    uVar66 = ((uint)fVar65 & 0xff) << 4;
    uVar68 = ((uint)fVar67 & 0xff) << 4;
    uVar70 = ((uint)fVar69 & 0xff) << 4;
    fVar67 = fVar25 * fVar25;
    fVar69 = fVar29 * fVar29;
    fVar20 = fVar32 * fVar32;
    fVar21 = fVar35 * fVar35;
    fVar6 = *(float *)(&DAT_14380b004 + uVar62);
    fVar13 = *(float *)(&DAT_14380b004 + uVar68);
    fVar15 = *(float *)(&DAT_14380b004 + uVar66);
    fVar17 = *(float *)(&DAT_14380b004 + uVar70);
    fVar12 = fVar25 * *(float *)(&DAT_14380b00c + uVar62);
    fVar14 = fVar29 * *(float *)(&DAT_14380b00c + uVar66);
    fVar16 = fVar32 * *(float *)(&DAT_14380b00c + uVar68);
    fVar18 = fVar35 * *(float *)(&DAT_14380b00c + uVar70);
    fVar38 = fVar6 + fVar12;
    fVar43 = fVar15 + fVar14;
    fVar46 = fVar13 + fVar16;
    fVar49 = fVar17 + fVar18;
    fVar50 = fVar25 * *(float *)(&DAT_14380b000 + uVar62);
    fVar53 = fVar29 * *(float *)(&DAT_14380b000 + uVar66);
    fVar54 = fVar32 * *(float *)(&DAT_14380b000 + uVar68);
    fVar55 = fVar35 * *(float *)(&DAT_14380b000 + uVar70);
    fVar36 = fVar38 + fVar50;
    fVar41 = fVar43 + fVar53;
    fVar44 = fVar46 + fVar54;
    fVar47 = fVar49 + fVar55;
    fVar59 = (*(float *)(&DAT_14380b000 + uVar62) + *(float *)(&DAT_14380b00c + uVar62)) -
             fVar25 * fVar6;
    fVar60 = (*(float *)(&DAT_14380b000 + uVar66) + *(float *)(&DAT_14380b00c + uVar66)) -
             fVar29 * fVar15;
    fVar61 = (*(float *)(&DAT_14380b000 + uVar68) + *(float *)(&DAT_14380b00c + uVar68)) -
             fVar32 * fVar13;
    fVar65 = (*(float *)(&DAT_14380b000 + uVar70) + *(float *)(&DAT_14380b00c + uVar70)) -
             fVar35 * fVar17;
    auVar22._0_4_ =
         fVar36 + *(float *)(&DAT_14380b008 + uVar62) +
                  (float)(uVar2 & (uint)(fVar37 + (fVar9 * 6.283203 - fVar72))) * fVar59 +
                  fVar6 * fVar67 * (_DAT_14380c180 * fVar67 + _DAT_14380c140) +
                  fVar12 + (fVar6 - fVar38) + fVar50 + (fVar38 - fVar36) +
                  (_DAT_14380c100 * fVar67 + _DAT_14380c0c0) * fVar67 * fVar25 * fVar59;
    auVar22._4_4_ =
         fVar41 + *(float *)(&DAT_14380b008 + uVar66) +
                  (float)(uVar28 & (uint)(fVar42 + (fVar19 - fVar76))) * fVar60 +
                  fVar15 * fVar69 * (_UNK_14380c184 * fVar69 + _UNK_14380c144) +
                  fVar14 + (fVar15 - fVar43) + fVar53 + (fVar43 - fVar41) +
                  (_UNK_14380c104 * fVar69 + _UNK_14380c0c4) * fVar69 * fVar29 * fVar60;
    auVar22._8_4_ =
         fVar44 + *(float *)(&DAT_14380b008 + uVar68) +
                  (float)(uVar31 & (uint)(fVar45 + (fVar10 * 6.283203 - fVar78))) * fVar61 +
                  fVar13 * fVar20 * (_UNK_14380c188 * fVar20 + _UNK_14380c148) +
                  fVar16 + (fVar13 - fVar46) + fVar54 + (fVar46 - fVar44) +
                  (_UNK_14380c108 * fVar20 + _UNK_14380c0c8) * fVar20 * fVar32 * fVar61;
    auVar22._12_4_ =
         fVar47 + *(float *)(&DAT_14380b008 + uVar70) +
                  (float)(uVar34 & (uint)(fVar48 + (fVar11 * 6.283203 - fVar80))) * fVar65 +
                  fVar17 * fVar21 * (_UNK_14380c18c * fVar21 + _UNK_14380c14c) +
                  fVar18 + (fVar17 - fVar49) + fVar55 + (fVar49 - fVar47) +
                  (_UNK_14380c10c * fVar21 + _UNK_14380c0cc) * fVar21 * fVar35 * fVar65;
    auVar39._4_4_ = -(uint)(_UNK_14380c044 < fVar27);
    auVar39._0_4_ = -(uint)(_DAT_14380c040 < fVar24);
    auVar39._8_4_ = -(uint)(_UNK_14380c048 < fVar30);
    auVar39._12_4_ = -(uint)(_UNK_14380c04c < fVar33);
    aauStack_100[0] = blendvps(aauStack_100[0],auVar22,auVar39);
  }
  if (uVar4 != 0) {
    uVar3 = 0;
    do {
      if ((uVar4 >> ((uint)uVar3 & 0x1f) & 1) != 0) {
        FUN_1402716e0(afStack_140 + uVar3,aauStack_100[0] + uVar3 * 4);
      }
      uVar2 = (uint)uVar3 + 1;
      uVar3 = (ulonglong)uVar2;
    } while ((int)uVar2 < 4);
  }
  return aauStack_100[0]._0_8_;
}

