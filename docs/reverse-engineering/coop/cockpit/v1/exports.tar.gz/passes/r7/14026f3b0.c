/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14026f3b0; RVA 0x26f3b0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14026f3b0(uint param_1)

{
  undefined1 auVar1 [16];
  float fVar2;
  
  fVar2 = (float)(param_1 & (uint)DAT_1402d42e0);
  if (_DAT_1402d4310 <= fVar2) {
    auVar1._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar1._0_4_ = fVar2 + _DAT_1402d4320;
    FUN_14026f390(param_1,auVar1._0_8_);
    return;
  }
  return;
}

