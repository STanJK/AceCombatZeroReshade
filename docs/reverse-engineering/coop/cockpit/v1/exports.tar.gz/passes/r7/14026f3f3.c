/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14026f3f3; RVA 0x26f3f3
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14026f3f3(float param_1)

{
  FUN_14026f390(param_1 + _DAT_1402d4330);
  return;
}

