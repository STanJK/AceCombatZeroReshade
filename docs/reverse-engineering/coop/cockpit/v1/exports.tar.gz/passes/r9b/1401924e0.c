/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401924e0; RVA 0x1924e0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

longlong *
FUN_1401924e0(longlong param_1,longlong *param_2,int param_3,int param_4,ulonglong *param_5)

{
  int iVar1;
  ulonglong uVar2;
  ulonglong *puVar3;
  undefined1 auVar4 [16];
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  void *pvVar8;
  longlong *plVar9;
  ulonglong uVar10;
  undefined4 *puVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  ulonglong uVar16;
  uint uVar17;
  undefined1 auStackY_c8 [32];
  int local_98 [2];
  ulonglong local_90;
  longlong local_88;
  longlong local_80;
  undefined1 local_78 [16];
  undefined1 local_68 [16];
  undefined8 local_58;
  ulonglong local_50;
  ulonglong local_48;
  
  local_48 = DAT_140309040 ^ (ulonglong)auStackY_c8;
  if (param_3 == 3) {
    if ((param_4 != 0) && (param_4 != 3)) {
      return param_2;
    }
  }
  else if ((param_4 != 3) || (param_3 != 0)) {
    return param_2;
  }
  if (param_3 == 3) {
    uVar13 = ((uint)(*param_5 >> 4) & 0x3ff) + 1;
    uVar16 = (ulonglong)((uint)(*param_5 >> 0xe) & 0x3ff);
  }
  else {
    uVar13 = 0x1000;
    uVar16 = 0;
  }
  if (param_4 == 3) {
    uVar12 = ((uint)(*param_5 >> 0x18) & 0x3ff) + 1;
    uVar17 = (uint)(*param_5 >> 0x22) & 0x3ff;
  }
  else {
    uVar12 = 0x1000;
    uVar17 = 0;
  }
  local_80 = param_1 + 0x48;
  local_90 = ((((ulonglong)uVar13 + 0x200) * 0x100 + uVar16) * 0x4000 +
              (longlong)*(int *)((longlong)param_2 + 0x24) << 0x20) + (ulonglong)(uVar17 << 0xe) +
             (ulonglong)(uVar12 << 0x14) + (longlong)(int)param_2[4];
  uVar10 = (((((((local_90 >> 8 & 0xff ^ (local_90 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3) *
                 0x100000001b3 ^ local_90 >> 0x10 & 0xff) * 0x100000001b3 ^ local_90 >> 0x18 & 0xff)
               * 0x100000001b3 ^ local_90 >> 0x20 & 0xff) * 0x100000001b3 ^ local_90 >> 0x28 & 0xff)
             * 0x100000001b3 ^ local_90 >> 0x30 & 0xff) * 0x100000001b3 ^ local_90 >> 0x38) *
           0x100000001b3 & *(ulonglong *)(param_1 + 0x78);
  lVar6 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 8 + uVar10 * 0x10);
  if (lVar6 == *(longlong *)(param_1 + 0x50)) {
LAB_1401926bc:
    lVar6 = 0;
  }
  else {
    uVar2 = *(ulonglong *)(lVar6 + 0x10);
    while (local_90 != uVar2) {
      if (lVar6 == *(longlong *)(*(longlong *)(param_1 + 0x60) + uVar10 * 0x10)) goto LAB_1401926bc;
      lVar6 = *(longlong *)(lVar6 + 8);
      uVar2 = *(ulonglong *)(lVar6 + 0x10);
    }
  }
  if ((lVar6 == 0) || (lVar6 == *(longlong *)(param_1 + 0x50))) {
    local_98[0] = (int)param_2[3];
    iVar1 = *(int *)((longlong)param_2 + 0x14);
    local_58 = 0;
    local_50 = 0xf;
    local_68._1_15_ = SUB1615((undefined1  [16])0x0,1);
    auVar4[0xf] = 0;
    auVar4._0_15_ = local_68._1_15_;
    local_68 = auVar4 << 8;
    local_88 = param_1;
    plVar7 = (longlong *)FUN_14020daa0(iVar1,local_98[0],1);
    if ((plVar7 != (longlong *)0x0) && (plVar7[1] == 0)) {
      pvVar8 = operator_new((longlong)*(int *)(*plVar7 + 8));
      plVar7[1] = (longlong)pvVar8;
    }
    puVar11 = (undefined4 *)plVar7[1];
    FUN_140190400(local_88);
    uVar15 = 0;
    if (0 < local_98[0]) {
      do {
        lVar6 = param_2[1];
        uVar10 = 0;
        if (0 < iVar1) {
          do {
            uVar2 = uVar10 % (ulonglong)uVar13;
            uVar14 = (int)uVar10 + 1;
            uVar10 = (ulonglong)uVar14;
            *puVar11 = *(undefined4 *)
                        (lVar6 + ((longlong)(int)((uVar15 % uVar12 + uVar17) * iVar1) + uVar16) * 4
                        + (longlong)(int)uVar2 * 4);
            puVar11 = puVar11 + 1;
          } while ((int)uVar14 < iVar1);
        }
        uVar15 = uVar15 + 1;
      } while ((int)uVar15 < local_98[0]);
    }
    FUN_14020dcf0(plVar7);
    plVar9 = (longlong *)FUN_140196b10(local_80,local_78,&local_90);
    lVar5 = local_88;
    *(longlong **)(*plVar9 + 0x18) = plVar7;
    local_98[0] = (int)param_2[4];
    plVar9 = (longlong *)FUN_140196900(local_88 + 0x88,local_78,local_98);
    lVar6 = *plVar9;
    puVar3 = *(ulonglong **)(lVar6 + 0x20);
    if (puVar3 == *(ulonglong **)(lVar6 + 0x28)) {
      FUN_1401972b0(lVar6 + 0x18,puVar3,&local_90);
    }
    else {
      *puVar3 = local_90;
      *(longlong *)(lVar6 + 0x20) = *(longlong *)(lVar6 + 0x20) + 8;
    }
    local_98[0] = *(int *)((longlong)param_2 + 0x24);
    plVar9 = (longlong *)FUN_140196900(lVar5 + 0x88,local_78);
    lVar6 = *plVar9;
    if (*(ulonglong **)(lVar6 + 0x20) == *(ulonglong **)(lVar6 + 0x28)) {
      FUN_1401972b0();
    }
    else {
      **(ulonglong **)(lVar6 + 0x20) = local_90;
      *(longlong *)(lVar6 + 0x20) = *(longlong *)(lVar6 + 0x20) + 8;
    }
    if (0xf < local_50) {
      if ((0xfff < local_50 + 1) &&
         (0x1f < (local_68._0_8_ - *(longlong *)(local_68._0_8_ + -8)) - 8U)) {
                    /* WARNING: Subroutine does not return */
        _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
      }
      thunk_FUN_1402500f0();
    }
  }
  else {
    plVar7 = *(longlong **)(lVar6 + 0x18);
  }
  return plVar7;
}

