/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140195dc0; RVA 0x195dc0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140195dc0(longlong param_1)

{
  size_t sVar1;
  int iVar2;
  longlong lVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  undefined8 *_Buf1;
  longlong lVar7;
  longlong unaff_GS_OFFSET;
  ulonglong in_stack_ffffffffffffff68;
  undefined4 uVar8;
  ulonglong in_stack_ffffffffffffff78;
  undefined4 *local_38;
  undefined4 *local_30;
  undefined4 *local_28;
  
  uVar6 = *(ulonglong *)(param_1 + 0x78) & 0xa8c7f832281a39c5;
  lVar3 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 8 + uVar6 * 0x10);
  if (lVar3 == *(longlong *)(param_1 + 0x50)) {
LAB_140195e1d:
    lVar3 = 0;
  }
  else {
    lVar7 = *(longlong *)(lVar3 + 0x10);
    while (lVar7 != 0) {
      if (lVar3 == *(longlong *)(*(longlong *)(param_1 + 0x60) + uVar6 * 0x10)) goto LAB_140195e1d;
      lVar3 = *(longlong *)(lVar3 + 8);
      lVar7 = *(longlong *)(lVar3 + 0x10);
    }
  }
  lVar7 = *(longlong *)(param_1 + 0x50);
  if (lVar3 != 0) {
    lVar7 = lVar3;
  }
  uVar6 = in_stack_ffffffffffffff68 & 0xffffffff00000000;
  FUN_14020f8e0(**(undefined8 **)(lVar7 + 0x18),3,*(undefined8 *)(param_1 + 0x6f8),
                *(undefined4 *)(param_1 + 0x708),uVar6,DAT_1402d2d64,
                in_stack_ffffffffffffff78 & 0xffffffffffffff00,*(undefined4 *)(param_1 + 0x73c),
                *(uint *)(param_1 + 0x740) ^ DAT_1402d3770,*(undefined4 *)(param_1 + 0x744),
                *(undefined4 *)(param_1 + 0x748),0,&DAT_14031e088,0,0);
  if (DAT_14030cac0 == -1) {
    uVar6 = CONCAT71((int7)(uVar6 >> 8),1);
    DAT_14030cac0 = FUN_14020cde0(1);
  }
  FUN_14020e000(DAT_14030cac0);
  if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dab94) &&
     (FUN_14022d540(&DAT_1437dab94), DAT_1437dab94 == -1)) {
    DAT_14031efc0._0_4_ = DAT_1402c40f8;
    DAT_14031efc0._4_2_ = DAT_1402c40fc;
    atexit(FUN_1402796e0);
    _Init_thread_footer(&DAT_1437dab94);
  }
  sVar1 = DAT_14031efd0;
  puVar5 = &DAT_14031efc0;
  if (0xf < DAT_14031efd8) {
    puVar5 = (undefined8 *)
             CONCAT26(DAT_14031efc0._6_2_,CONCAT24(DAT_14031efc0._4_2_,(undefined4)DAT_14031efc0));
  }
  _Buf1 = &DAT_14031e0f0;
  if (0xf < DAT_14031e108) {
    _Buf1 = DAT_14031e0f0;
  }
  if ((DAT_14031e100 != DAT_14031efd0) ||
     ((DAT_14031e100 != 0 && (iVar2 = memcmp(_Buf1,puVar5,DAT_14031e100), iVar2 != 0)))) {
    puVar5 = &DAT_14031efc0;
    if (0xf < DAT_14031efd8) {
      puVar5 = (undefined8 *)
               CONCAT26(DAT_14031efc0._6_2_,CONCAT24(DAT_14031efc0._4_2_,(undefined4)DAT_14031efc0))
      ;
    }
    FUN_140212710(&DAT_14031e0f0,puVar5,sVar1);
    if (DAT_14031efd0 != 0) {
      FUN_14020f590(0);
      DAT_14031e110 = 1;
    }
  }
  uVar6 = uVar6 & 0xffffffffffffff00;
  FUN_14020ef50(0x14,0,1,0,uVar6);
  uVar8 = (undefined4)(uVar6 >> 0x20);
  DAT_14031e3a8 = 0;
  if (((DAT_14031e0e8 != 3) || (DAT_14031e3ac != '\0')) || (DAT_14031e3b0 != 0)) {
    DAT_14031e110 = 1;
    DAT_14031e0e8 = 3;
    DAT_14031e3ac = '\0';
    DAT_14031e3b0 = 0;
    _DAT_14031e308 = 0;
    DAT_14031e314 = 0;
  }
  puVar4 = operator_new(0x40);
  local_28 = puVar4 + 0x10;
  local_30 = puVar4 + 0x10;
  *(undefined8 *)(puVar4 + 1) = 0;
  *(undefined8 *)(puVar4 + 3) = 0;
  *(undefined8 *)(puVar4 + 5) = 0;
  puVar4[7] = 0;
  *(undefined8 *)(puVar4 + 8) = 0;
  *(undefined8 *)(puVar4 + 10) = 0;
  *(undefined8 *)(puVar4 + 0xc) = 0;
  *(undefined8 *)(puVar4 + 0xe) = 0;
  *puVar4 = 0;
  local_38 = puVar4;
  puVar5 = (undefined8 *)FUN_140191040(param_1,0x3ec0,1);
  *(undefined8 *)(puVar4 + 4) = *puVar5;
  puVar4[6] = 0;
  puVar4[8] = 0;
  puVar5 = (undefined8 *)FUN_140191040(param_1,0x3ee0);
  *(undefined8 *)(puVar4 + 0xc) = *puVar5;
  puVar4[0xe] = 1;
  FUN_140210380(0,0,0,0,CONCAT44(uVar8,1),5,&local_38);
  if (local_38 != (undefined4 *)0x0) {
    if ((0xfff < ((longlong)local_28 - (longlong)local_38 & 0xffffffffffffffe0U)) &&
       (0x1f < (ulonglong)((longlong)local_38 + (-8 - *(longlong *)(local_38 + -2))))) {
                    /* WARNING: Subroutine does not return */
      _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
    }
    thunk_FUN_1402500f0();
  }
  FUN_14020e490(DAT_14030cac0);
  DAT_140326f84 = 1;
  return;
}

