/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140191040; RVA 0x191040
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

longlong * FUN_140191040(longlong param_1,ulonglong param_2,char param_3)

{
  int iVar1;
  ulonglong uVar2;
  ulonglong *puVar3;
  uint uVar4;
  longlong lVar5;
  longlong *plVar6;
  void *pvVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 *puVar10;
  longlong lVar11;
  ulonglong uVar12;
  uint uVar14;
  uint uVar13;
  ulonglong uVar15;
  uint uVar16;
  undefined4 uVar17;
  longlong unaff_GS_OFFSET;
  undefined1 auStackY_b8 [32];
  ulonglong local_88;
  uint local_80 [2];
  undefined8 local_78;
  undefined1 local_70 [16];
  undefined1 local_60 [8];
  longlong *plStack_58;
  longlong lStack_50;
  ulonglong uStack_48;
  ulonglong local_40;
  
  local_40 = DAT_140309040 ^ (ulonglong)auStackY_b8;
  uVar4 = (uint)param_2;
  if ((uVar4 & 0x3f00000) == 0x1000000) {
    return *(longlong **)(&DAT_14033bc50 + (ulonglong)((uint)((longlong)param_2 >> 10) & 0xf) * 8);
  }
  uVar14 = (uint)(param_2 >> 0x25);
  uVar13 = uVar14 & 0x3fff;
  uVar15 = (ulonglong)uVar13;
  uVar16 = uVar4 & 0x3fff;
  local_88 = CONCAT44(uVar14,uVar4) & 0x3fff00003fff;
  uVar12 = (((local_88 >> 8 & 0xff ^ (param_2 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3) *
             0x8a97b0004e7feab ^ local_88 >> 0x20 & 0xff) * 0x100000001b3 ^ local_88 >> 0x28) *
           0x8a97b0004e7feab & *(ulonglong *)(param_1 + 0x78);
  lVar11 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 8 + uVar12 * 0x10);
  if (lVar11 == *(longlong *)(param_1 + 0x50)) {
LAB_140191170:
    lVar11 = 0;
  }
  else {
    uVar2 = *(ulonglong *)(lVar11 + 0x10);
    while (local_88 != uVar2) {
      if (lVar11 == *(longlong *)(*(longlong *)(param_1 + 0x60) + uVar12 * 0x10))
      goto LAB_140191170;
      lVar11 = *(longlong *)(lVar11 + 8);
      uVar2 = *(ulonglong *)(lVar11 + 0x10);
    }
  }
  local_78 = uVar15;
  if (((lVar11 != 0) && (lVar11 != *(longlong *)(param_1 + 0x50))) &&
     (*(longlong *)(lVar11 + 0x18) != 0)) {
    if ((param_3 != '\0') && (iVar1 = *(int *)(*(longlong *)(lVar11 + 0x18) + 0x28), iVar1 != -1)) {
      FUN_14020e550(iVar1,0,0);
    }
    return *(longlong **)(lVar11 + 0x18);
  }
  if ((ulonglong)uVar16 == 0) {
    return (longlong *)0x0;
  }
  if (*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dab9c) {
    FUN_14022d540(&DAT_1437dab9c);
    if (DAT_1437dab9c == -1) {
      atexit(FUN_1402793e0);
      _Init_thread_footer(&DAT_1437dab9c);
    }
  }
  uVar17 = 0;
  if ((param_2 & 0x3f00000) != 0) {
    lVar11 = *(longlong *)(param_1 + 0x10);
    uVar12 = ((uVar15 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (ulonglong)(uVar13 >> 8)) *
             0x8a97b0004e7feab & *(ulonglong *)(param_1 + 0x38);
    lVar9 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 8 + uVar12 * 0x10);
    if (lVar9 == lVar11) {
LAB_14019125d:
      lVar9 = 0;
    }
    else {
      uVar4 = *(uint *)(lVar9 + 0x10);
      while (uVar13 != uVar4) {
        if (lVar9 == *(longlong *)(*(longlong *)(param_1 + 0x20) + uVar12 * 0x10))
        goto LAB_14019125d;
        lVar9 = *(longlong *)(lVar9 + 8);
        uVar4 = *(uint *)(lVar9 + 0x10);
      }
    }
    lVar5 = lVar11;
    if (lVar9 != 0) {
      lVar5 = lVar9;
    }
    if (lVar5 == lVar11) {
      puVar10 = &DAT_14031ef80;
      if (0xf < DAT_14031ef98) {
        puVar10 = DAT_14031ef80;
      }
      local_60[4] = s_NoPal__1402c4244[4];
      local_60[5] = s_NoPal__1402c4244[5];
      local_60[0] = s_NoPal__1402c4244[0];
      local_60[1] = s_NoPal__1402c4244[1];
      local_60[2] = s_NoPal__1402c4244[2];
      local_60[3] = s_NoPal__1402c4244[3];
      lStack_50 = 6;
      uStack_48 = 0xf;
      stack0xffffffffffffffa7 = SUB169((undefined1  [16])0x0,7);
      local_60[6] = 0;
      plVar6 = (longlong *)FUN_140197430(local_60,puVar10);
      lVar11 = *plVar6;
      uVar12 = plVar6[3];
      plVar6[2] = 0;
      plVar6[3] = 0xf;
      *(undefined1 *)plVar6 = 0;
      if (0xf < uVar12) {
        if ((0xfff < uVar12 + 1) && (0x1f < (lVar11 - *(longlong *)(lVar11 + -8)) - 8U))
        goto LAB_1401916eb;
        thunk_FUN_1402500f0();
      }
      if (uStack_48 < 0x10) {
        return (longlong *)0x0;
      }
      if ((0xfff < uStack_48 + 1) &&
         (0x1f < ((longlong)local_60 - *(longlong *)((longlong)local_60 + -8)) - 8U)) {
LAB_1401916eb:
                    /* WARNING: Subroutine does not return */
        _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
      }
      goto LAB_1401914c8;
    }
    uVar17 = 0x100;
    if (*(int *)(lVar5 + 0x1c) == 2) {
      uVar17 = 0x10;
    }
  }
  uVar12 = (((ulonglong)uVar16 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
           (ulonglong)(uVar16 >> 8)) * 0x8a97b0004e7feab & *(ulonglong *)(param_1 + 0x38);
  lVar11 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 8 + uVar12 * 0x10);
  if (lVar11 == *(longlong *)(param_1 + 0x10)) {
LAB_1401913d0:
    lVar11 = 0;
  }
  else {
    uVar4 = *(uint *)(lVar11 + 0x10);
    while (uVar16 != uVar4) {
      if (lVar11 == *(longlong *)(*(longlong *)(param_1 + 0x20) + uVar12 * 0x10))
      goto LAB_1401913d0;
      lVar11 = *(longlong *)(lVar11 + 8);
      uVar4 = *(uint *)(lVar11 + 0x10);
    }
  }
  if (lVar11 == 0) {
    lVar11 = *(longlong *)(param_1 + 0x10);
  }
  if (lVar11 != *(longlong *)(param_1 + 0x10)) {
    plVar6 = (longlong *)
             FUN_14020daa0(*(undefined4 *)(lVar11 + 0x18),*(undefined4 *)(lVar11 + 0x1c),1,0x1c);
    if (plVar6 == (longlong *)0x0) {
      return (longlong *)0x0;
    }
    if (plVar6[1] == 0) {
      pvVar7 = operator_new((longlong)*(int *)(*plVar6 + 8));
      plVar6[1] = (longlong)pvVar7;
    }
    *(uint *)(plVar6 + 4) = uVar16;
    *(uint *)((longlong)plVar6 + 0x24) = uVar13;
    *(undefined4 *)(plVar6 + 7) = *(undefined4 *)(lVar11 + 0x34);
    plVar8 = (longlong *)FUN_140196b10(param_1 + 0x48,local_70,&local_88);
    *(longlong **)(*plVar8 + 0x18) = plVar6;
    local_80[0] = uVar16;
    plVar8 = (longlong *)FUN_140196900(param_1 + 0x88,local_70,local_80);
    lVar9 = *plVar8;
    puVar3 = *(ulonglong **)(lVar9 + 0x20);
    if (puVar3 == *(ulonglong **)(lVar9 + 0x28)) {
      FUN_1401972b0(lVar9 + 0x18,puVar3,&local_88);
    }
    else {
      *puVar3 = local_88;
      *(longlong *)(lVar9 + 0x20) = *(longlong *)(lVar9 + 0x20) + 8;
    }
    if (local_78 != 0) {
      local_78 = CONCAT44(local_78._4_4_,uVar14) & 0xffffffff00003fff;
      plVar8 = (longlong *)FUN_140196900(param_1 + 0x88,local_60,&local_78);
      lVar9 = *plVar8;
      puVar3 = *(ulonglong **)(lVar9 + 0x20);
      if (puVar3 == *(ulonglong **)(lVar9 + 0x28)) {
        FUN_1401972b0(lVar9 + 0x18,puVar3,&local_88);
      }
      else {
        *puVar3 = local_88;
        *(longlong *)(lVar9 + 0x20) = *(longlong *)(lVar9 + 0x20) + 8;
      }
    }
    lVar11 = *(longlong *)(lVar11 + 0x18);
    (**(code **)(*DAT_14033bcb8 + 8))();
    lVar9 = DAT_14033ac58;
    uStack_48 = CONCAT44(uStack_48._4_4_,uVar17);
    lStack_50 = lVar11;
    local_60 = (undefined1  [8])param_2;
    plStack_58 = plVar6;
    if (DAT_14033ac60 == 0x555555555555555) {
                    /* WARNING: Subroutine does not return */
      FUN_14022d41c("list too long");
    }
    plVar8 = operator_new(0x30);
    plVar8[2] = (longlong)local_60;
    plVar8[3] = (longlong)plStack_58;
    plVar8[4] = lStack_50;
    plVar8[5] = uStack_48;
    DAT_14033ac60 = DAT_14033ac60 + 1;
    puVar10 = *(undefined8 **)(lVar9 + 8);
    plVar8[1] = (longlong)puVar10;
    *plVar8 = lVar9;
    *(longlong **)(lVar9 + 8) = plVar8;
    *puVar10 = plVar8;
    (**(code **)(*DAT_14033bcb8 + 0x10))();
    (**(code **)(*DAT_14033bcb0 + 8))();
    (**(code **)(*DAT_14033bca0 + 8))();
    (**(code **)(*DAT_14033bcb0 + 0x10))();
    return plVar6;
  }
  puVar10 = &DAT_14031ef80;
  if (0xf < DAT_14031ef98) {
    puVar10 = DAT_14031ef80;
  }
  local_60[4] = s_NoTex__1402c4288[4];
  local_60[5] = s_NoTex__1402c4288[5];
  local_60[0] = s_NoTex__1402c4288[0];
  local_60[1] = s_NoTex__1402c4288[1];
  local_60[2] = s_NoTex__1402c4288[2];
  local_60[3] = s_NoTex__1402c4288[3];
  lStack_50 = 6;
  uStack_48 = 0xf;
  stack0xffffffffffffffa7 = SUB169((undefined1  [16])0x0,7);
  local_60[6] = 0;
  plVar6 = (longlong *)FUN_140197430(local_60,puVar10);
  lVar11 = *plVar6;
  uVar12 = plVar6[3];
  plVar6[2] = 0;
  plVar6[3] = 0xf;
  *(undefined1 *)plVar6 = 0;
  if (0xf < uVar12) {
    if ((0xfff < uVar12 + 1) && (0x1f < (lVar11 - *(longlong *)(lVar11 + -8)) - 8U))
    goto LAB_140191703;
    thunk_FUN_1402500f0();
  }
  if (uStack_48 < 0x10) {
    return (longlong *)0x0;
  }
  if ((uStack_48 + 1 < 0x1000) ||
     (((longlong)local_60 - *(longlong *)((longlong)local_60 + -8)) - 8U < 0x20)) {
LAB_1401914c8:
    thunk_FUN_1402500f0();
    return (longlong *)0x0;
  }
LAB_140191703:
                    /* WARNING: Subroutine does not return */
  _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
}

