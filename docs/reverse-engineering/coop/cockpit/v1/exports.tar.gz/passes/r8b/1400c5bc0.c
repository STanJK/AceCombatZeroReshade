/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400c5bc0; RVA 0xc5bc0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

ulonglong FUN_1400c5bc0(longlong param_1)

{
  byte *pbVar1;
  undefined8 *puVar2;
  byte *pbVar3;
  
  pbVar3 = *(byte **)(param_1 + 0x10);
  if ((pbVar3 != (byte *)0x0) &&
     (puVar2 = *(undefined8 **)(pbVar3 + 0x2d8), puVar2 != (undefined8 *)0x0)) {
    pbVar1 = pbVar3 + 0x3c9;
    pbVar3 = (byte *)*puVar2;
    if ((*pbVar1 < *pbVar3) &&
       (puVar2 = (undefined8 *)(puVar2[1] + (ulonglong)*pbVar1 * 0x48), pbVar3 = (byte *)0x0,
       puVar2 != (undefined8 *)0x0)) {
      return (ulonglong)*(byte *)*puVar2;
    }
  }
  return CONCAT71((int7)((ulonglong)pbVar3 >> 8),0xff);
}

