/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140077c50; RVA 0x77c50
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_140077c50(longlong *param_1,undefined8 *param_2)

{
  longlong *plVar1;
  float fVar2;
  char cVar3;
  longlong *plVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  int iVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  float fVar12;
  
  plVar1 = param_1 + 3;
  *(longlong **)(param_1[1] + 0x168) = plVar1;
  if (*(int *)(param_1[2] + 0x38) != 0) {
    *(longlong **)(param_1[2] + 0x130) = plVar1;
  }
  lVar10 = param_1[1];
  iVar8 = 0;
  *(undefined4 *)(lVar10 + 0x160) = 0x47800000;
  *(undefined4 *)(lVar10 + 0x164) = 0x47400000;
  *plVar1 = (longlong)param_2;
  *(undefined4 *)(param_1 + 4) = 0x20;
  do {
    puVar6 = param_2 + 2;
    *param_2 = 0x20000000;
    FUN_140197b30(param_2,puVar6);
    param_2[1] = 0;
    iVar8 = iVar8 + 1;
    param_2 = puVar6;
  } while (iVar8 < (int)param_1[4] + 1);
  uVar5 = FUN_1400791f0(*param_1,puVar6);
  uVar5 = FUN_14007b140(param_1[1],uVar5);
  puVar6 = (undefined8 *)FUN_140202180(plVar1,0,uVar5);
  if (*(int *)(param_1[2] + 0x38) != 0) {
    uVar5 = FUN_1400791f0(*param_1,puVar6);
    puVar6 = (undefined8 *)FUN_140079310(*param_1,uVar5);
    plVar4 = (longlong *)param_1[1];
    *puVar6 = 0x10000001;
    FUN_140197b30(puVar6,0);
    fVar12 = DAT_1402d1e68;
    *(undefined4 *)(puVar6 + 1) = 0;
    *(undefined4 *)((longlong)puVar6 + 0xc) = 0x6c014021;
    *(float *)(puVar6 + 2) =
         *(float *)(plVar4[3] + 0x290) * *(float *)((longlong)plVar4 + 0x164) * fVar12;
    *(float *)((longlong)puVar6 + 0x14) =
         *(float *)(plVar4[3] + 0x290) * *(float *)(plVar4 + 0x2c) * fVar12;
    fVar12 = *(float *)(*plVar4 + 4) * *(float *)(plVar4[3] + 0x290) * fVar12;
    *(float *)(puVar6 + 3) = fVar12;
    fVar2 = *(float *)(plVar4[3] + 0x29c);
    if (fVar2 < fVar12) {
      *(float *)(puVar6 + 3) = fVar2;
      fVar12 = fVar2;
    }
    fVar12 = DAT_1402d22d0 / fVar12;
    puVar6[4] = 0x10000005;
    *(float *)((longlong)puVar6 + 0x1c) = fVar12;
    FUN_140197b30(puVar6 + 4,0);
    *(undefined4 *)(puVar6 + 5) = 0;
    *(undefined4 *)((longlong)puVar6 + 0x2c) = 0x6c01401a;
    puVar6[6] = plVar4[0x16];
    *(undefined4 *)(puVar6 + 7) = 7;
    puVar6[8] = 0;
    *(undefined4 *)(puVar6 + 9) = 0;
    *(undefined4 *)((longlong)puVar6 + 0x4c) = 0x6c03401e;
    *(undefined4 *)(puVar6 + 10) = 0x5f001;
    *(undefined4 *)(puVar6 + 0xb) = 0x48;
    *(undefined4 *)(puVar6 + 0xc) = 0x54000;
    *(undefined4 *)(puVar6 + 0xd) = 0x48;
    *(undefined4 *)(puVar6 + 0xe) = 0x53001;
    *(undefined4 *)(puVar6 + 0xf) = 0x48;
    puVar6 = (undefined8 *)FUN_140203b30(plVar4 + 0x16,puVar6 + 0x10);
    *puVar6 = 0x10000006;
    FUN_140197b30(puVar6,0);
    *(undefined4 *)(puVar6 + 1) = 0;
    *(undefined4 *)((longlong)puVar6 + 0xc) = 0x50000006;
    *(undefined4 *)(puVar6 + 2) = 0x8005;
    *(undefined4 *)((longlong)puVar6 + 0x14) = 0x10000000;
    puVar6[3] = 0xe;
    *(undefined4 *)(puVar6 + 4) = 0x42;
    *(undefined4 *)((longlong)puVar6 + 0x24) = 0x80;
    *(undefined4 *)(puVar6 + 5) = 0x43;
    puVar6[6] = 0x60;
    *(undefined4 *)(puVar6 + 7) = 0x15;
    puVar6[8] = 0;
    *(undefined4 *)(puVar6 + 9) = 9;
    *(undefined4 *)(puVar6 + 10) = 0;
    *(undefined4 *)(puVar6 + 0xb) = 0x4b;
    *(undefined4 *)(puVar6 + 0xd) = 0x3f;
    uVar5 = FUN_14007f9f0(param_1[2],puVar6 + 0xe);
    puVar6 = (undefined8 *)FUN_140202180(plVar1,0x1a,uVar5);
  }
  FUN_14007b490(param_1[1]);
  if (*(int *)(param_1[2] + 0x38) == 0) {
    iVar8 = *(byte *)(*param_1 + 0x372) - 6;
    lVar10 = 0;
    do {
      iVar7 = *(byte *)(*param_1 + 0x371) - 6;
      lVar9 = 0;
      lVar11 = lVar10;
      do {
        cVar3 = *(char *)(*param_1 + 0x2c8 + lVar11);
        if (cVar3 != '\x04') {
          puVar6 = (undefined8 *)FUN_14007c2c0(param_1[1],puVar6,iVar7,iVar8,cVar3);
        }
        lVar9 = lVar9 + 1;
        iVar7 = iVar7 + 1;
        lVar11 = lVar11 + 1;
      } while (lVar9 < 0xd);
      lVar10 = lVar10 + 0xd;
      iVar8 = iVar8 + 1;
    } while (lVar10 < 0xa9);
  }
  else {
    lVar10 = 0;
    iVar8 = *(byte *)(*param_1 + 0x372) - 6;
    do {
      lVar9 = 0;
      iVar7 = *(byte *)(*param_1 + 0x371) - 6;
      lVar11 = lVar10;
      do {
        cVar3 = *(char *)(*param_1 + 0x2c8 + lVar11);
        if (cVar3 != '\x04') {
          uVar5 = FUN_14007c2c0(param_1[1],puVar6,iVar7,iVar8,cVar3);
          puVar6 = (undefined8 *)FUN_14007f840(param_1[2],uVar5,iVar7,iVar8,cVar3);
        }
        lVar9 = lVar9 + 1;
        iVar7 = iVar7 + 1;
        lVar11 = lVar11 + 1;
      } while (lVar9 < 0xd);
      lVar10 = lVar10 + 0xd;
      iVar8 = iVar8 + 1;
    } while (lVar10 < 0xa9);
  }
  lVar10 = param_1[1];
  iVar8 = 2;
  if (1 < *(int *)(lVar10 + 0x170) + 1) {
    do {
      *puVar6 = 0x10000002;
      *(undefined4 *)(puVar6 + 1) = 0;
      *(undefined4 *)((longlong)puVar6 + 0xc) = 0x50000002;
      *(undefined4 *)(puVar6 + 2) = 0x8001;
      *(undefined4 *)((longlong)puVar6 + 0x14) = 0x10000000;
      puVar6[3] = 0xe;
      *(undefined4 *)(puVar6 + 5) = 0x3f;
      puVar6 = (undefined8 *)FUN_140202180(*(undefined8 *)(lVar10 + 0x168),iVar8,puVar6 + 6);
      iVar8 = iVar8 + 2;
    } while (iVar8 <= *(int *)(lVar10 + 0x170) + 1);
  }
  puVar6[1] = 0;
  puVar6[2] = 0x60000000;
  puVar6[3] = 0;
  *puVar6 = 0x20000000;
  FUN_140197b30(puVar6,puVar6 + 4);
  puVar6[4] = 0x50000000;
  FUN_140197b30(puVar6 + 4,puVar6 + 2);
  puVar6[5] = 0;
  puVar6[6] = 0x10000003;
  *(undefined4 *)(puVar6 + 7) = 0x11000000;
  *(undefined4 *)((longlong)puVar6 + 0x3c) = 0x50000003;
  *(undefined4 *)(puVar6 + 8) = 0x8002;
  *(undefined4 *)((longlong)puVar6 + 0x44) = 0x10000000;
  puVar6[9] = 0xe;
  *(undefined4 *)(puVar6 + 10) = 0;
  *(undefined4 *)(puVar6 + 0xb) = 0x4b;
  *(undefined4 *)(puVar6 + 0xc) = 0;
  *(undefined4 *)(puVar6 + 0xd) = 0x4a;
  puVar6 = (undefined8 *)FUN_140202180(param_1 + 3,0x19,puVar6 + 0xe);
  if (*(int *)(param_1[2] + 0x38) != 0) {
    *puVar6 = 0x10000002;
    FUN_140197b30(puVar6,0);
    *(undefined4 *)(puVar6 + 1) = 0x11000000;
    *(undefined4 *)((longlong)puVar6 + 0xc) = 0x50000002;
    *(undefined4 *)(puVar6 + 2) = 0x8001;
    *(undefined4 *)((longlong)puVar6 + 0x14) = 0x10000000;
    puVar6[3] = 0xe;
    *(undefined4 *)(puVar6 + 4) = 0;
    *(undefined4 *)(puVar6 + 5) = 0x4a;
    puVar6 = (undefined8 *)FUN_140202180(param_1 + 3,0x1f,puVar6 + 6);
  }
  if (*(int *)(param_1[2] + 0x38) != 0) {
    FUN_14007f380();
  }
  return puVar6;
}

