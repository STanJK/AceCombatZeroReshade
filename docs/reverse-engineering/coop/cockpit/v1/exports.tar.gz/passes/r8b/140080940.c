/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140080940; RVA 0x80940
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140080940(longlong param_1)

{
  float *pfVar1;
  float *pfVar2;
  undefined4 uVar3;
  uint uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  longlong lVar10;
  float *pfVar11;
  undefined8 uVar12;
  float fVar13;
  float fVar14;
  undefined1 auVar15 [64];
  undefined1 auVar16 [64];
  float fVar17;
  undefined8 uVar18;
  undefined1 auVar19 [64];
  undefined1 auVar20 [64];
  
  pfVar2 = *(float **)(param_1 + 8);
  pfVar1 = (float *)(param_1 + 0x10);
  fVar17 = *(float *)(param_1 + 0xc80);
  auVar15 = ZEXT464((uint)fVar17);
  *(float *)(param_1 + 0xc88) = fVar17 * (pfVar2[0x28] - *pfVar2) + *pfVar2;
  *(float *)(param_1 + 0xc8c) = fVar17 * (pfVar2[0x29] - pfVar2[1]) + pfVar2[1];
  pfVar2 = *(float **)(param_1 + 0xaa0);
  pfVar11 = *(float **)(param_1 + 0xaa8);
  *pfVar1 = fVar17 * (*pfVar11 - *pfVar2) + *pfVar2;
  *(float *)(param_1 + 0x14) = fVar17 * (pfVar11[1] - pfVar2[1]) + pfVar2[1];
  *(float *)(param_1 + 0x98) = fVar17 * (pfVar11[0x22] - pfVar2[0x22]) + pfVar2[0x22];
  *(float *)(param_1 + 0x9c) = fVar17 * (pfVar11[0x23] - pfVar2[0x23]) + pfVar2[0x23];
  *(float *)(param_1 + 0xa0) = fVar17 * (pfVar11[0x24] - pfVar2[0x24]) + pfVar2[0x24];
  *(float *)(param_1 + 0xa4) = fVar17 * (pfVar11[0x25] - pfVar2[0x25]) + pfVar2[0x25];
  *(float *)(param_1 + 0xa8) = fVar17 * (pfVar11[0x26] - pfVar2[0x26]) + pfVar2[0x26];
  *(float *)(param_1 + 0xac) = fVar17 * (pfVar11[0x27] - pfVar2[0x27]) + pfVar2[0x27];
  *(float *)(param_1 + 0xb0) = fVar17 * (pfVar11[0x28] - pfVar2[0x28]) + pfVar2[0x28];
  *(float *)(param_1 + 0xb4) = fVar17 * (pfVar11[0x29] - pfVar2[0x29]) + pfVar2[0x29];
  *(float *)(param_1 + 0xb8) = fVar17 * (pfVar11[0x2a] - pfVar2[0x2a]) + pfVar2[0x2a];
  *(float *)(param_1 + 0xbc) = fVar17 * (pfVar11[0x2b] - pfVar2[0x2b]) + pfVar2[0x2b];
  uVar8 = *(ulonglong *)(pfVar11 + 4);
  uVar9 = *(ulonglong *)(pfVar11 + 6);
  uVar5 = *(ulonglong *)(pfVar2 + 4);
  uVar6 = *(ulonglong *)(pfVar2 + 6);
  uVar3 = FUN_140022d10(uVar5 & 0xffffffff,uVar8 & 0xffffffff,fVar17);
  *(undefined4 *)(param_1 + 0x20) = uVar3;
  uVar3 = FUN_140022d10(uVar5 >> 0x20,uVar8 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  uVar3 = FUN_140022d10(uVar6 & 0xffffffff,uVar9 & 0xffffffff,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x28) = uVar3;
  uVar3 = FUN_140022d10(uVar6 >> 0x20,uVar9 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x2c) = uVar3;
  uVar8 = *(ulonglong *)(pfVar11 + 8);
  uVar9 = *(ulonglong *)(pfVar11 + 10);
  uVar5 = *(ulonglong *)(pfVar2 + 8);
  uVar6 = *(ulonglong *)(pfVar2 + 10);
  auVar15 = ZEXT464(*(uint *)(param_1 + 0xc80));
  uVar3 = FUN_140022d10(uVar5 & 0xffffffff,uVar8 & 0xffffffff,*(uint *)(param_1 + 0xc80));
  *(undefined4 *)(param_1 + 0x30) = uVar3;
  uVar3 = FUN_140022d10(uVar5 >> 0x20,uVar8 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x34) = uVar3;
  uVar3 = FUN_140022d10(uVar6 & 0xffffffff,uVar9 & 0xffffffff,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x38) = uVar3;
  uVar3 = FUN_140022d10(uVar6 >> 0x20,uVar9 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x3c) = uVar3;
  uVar8 = *(ulonglong *)(pfVar11 + 0xc);
  uVar9 = *(ulonglong *)(pfVar11 + 0xe);
  uVar5 = *(ulonglong *)(pfVar2 + 0xc);
  uVar6 = *(ulonglong *)(pfVar2 + 0xe);
  auVar15 = ZEXT464(*(uint *)(param_1 + 0xc80));
  uVar3 = FUN_140022d10(uVar5 & 0xffffffff,uVar8 & 0xffffffff,*(uint *)(param_1 + 0xc80));
  *(undefined4 *)(param_1 + 0x40) = uVar3;
  uVar3 = FUN_140022d10(uVar5 >> 0x20,uVar8 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x44) = uVar3;
  uVar3 = FUN_140022d10(uVar6 & 0xffffffff,uVar9 & 0xffffffff,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x48) = uVar3;
  uVar3 = FUN_140022d10(uVar6 >> 0x20,uVar9 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x4c) = uVar3;
  uVar8 = *(ulonglong *)(pfVar11 + 0x10);
  uVar9 = *(ulonglong *)(pfVar11 + 0x12);
  uVar5 = *(ulonglong *)(pfVar2 + 0x10);
  uVar6 = *(ulonglong *)(pfVar2 + 0x12);
  auVar15 = ZEXT464(*(uint *)(param_1 + 0xc80));
  uVar3 = FUN_140022d10(uVar5 & 0xffffffff,uVar8 & 0xffffffff,*(uint *)(param_1 + 0xc80));
  *(undefined4 *)(param_1 + 0x50) = uVar3;
  uVar3 = FUN_140022d10(uVar5 >> 0x20,uVar8 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x54) = uVar3;
  uVar3 = FUN_140022d10(uVar6 & 0xffffffff,uVar9 & 0xffffffff,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x58) = uVar3;
  uVar3 = FUN_140022d10(uVar6 >> 0x20,uVar9 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x5c) = uVar3;
  uVar8 = *(ulonglong *)(pfVar11 + 0x14);
  uVar9 = *(ulonglong *)(pfVar11 + 0x16);
  uVar5 = *(ulonglong *)(pfVar2 + 0x14);
  uVar6 = *(ulonglong *)(pfVar2 + 0x16);
  auVar15 = ZEXT464(*(uint *)(param_1 + 0xc80));
  uVar3 = FUN_140022d10(uVar5 & 0xffffffff,uVar8 & 0xffffffff,*(uint *)(param_1 + 0xc80));
  *(undefined4 *)(param_1 + 0x60) = uVar3;
  uVar3 = FUN_140022d10(uVar5 >> 0x20,uVar8 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 100) = uVar3;
  uVar3 = FUN_140022d10(uVar6 & 0xffffffff,uVar9 & 0xffffffff,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x68) = uVar3;
  uVar3 = FUN_140022d10(uVar6 >> 0x20,uVar9 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x6c) = uVar3;
  uVar8 = *(ulonglong *)(pfVar11 + 0x18);
  uVar9 = *(ulonglong *)(pfVar11 + 0x1a);
  uVar5 = *(ulonglong *)(pfVar2 + 0x18);
  uVar6 = *(ulonglong *)(pfVar2 + 0x1a);
  auVar15 = ZEXT464(*(uint *)(param_1 + 0xc80));
  uVar3 = FUN_140022d10(uVar5 & 0xffffffff,uVar8 & 0xffffffff,*(uint *)(param_1 + 0xc80));
  *(undefined4 *)(param_1 + 0x70) = uVar3;
  uVar3 = FUN_140022d10(uVar5 >> 0x20,uVar8 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x74) = uVar3;
  uVar3 = FUN_140022d10(uVar6 & 0xffffffff,uVar9 & 0xffffffff,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x78) = uVar3;
  uVar3 = FUN_140022d10(uVar6 >> 0x20,uVar9 >> 0x20,auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x7c) = uVar3;
  lVar7 = *(longlong *)(param_1 + 0xaa8);
  lVar10 = *(longlong *)(param_1 + 0xaa0);
  auVar15 = ZEXT464(*(uint *)(param_1 + 0xc80));
  uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x78),*(undefined4 *)(lVar7 + 0x78),
                        *(uint *)(param_1 + 0xc80));
  *(undefined4 *)(param_1 + 0x88) = uVar3;
  uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x7c),*(undefined4 *)(lVar7 + 0x7c),auVar15._0_8_);
  *(undefined4 *)(param_1 + 0x8c) = uVar3;
  uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x80),*(undefined4 *)(lVar7 + 0x80),auVar15._0_8_);
  lVar7 = *(longlong *)(param_1 + 0xd08);
  lVar10 = *(longlong *)(param_1 + 8);
  *(undefined4 *)(param_1 + 0x90) = uVar3;
  *(float **)(param_1 + 0xd00) = pfVar1;
  fVar17 = *(float *)(lVar7 + 0x1c);
  fVar13 = *pfVar1;
  fVar14 = auVar15._0_4_;
  uVar12 = auVar15._0_8_;
  if (fVar13 < fVar17) {
    if (fVar17 < *(float *)(param_1 + 0x14)) {
      fVar13 = (fVar17 - fVar13) / (*(float *)(param_1 + 0x14) - fVar13);
      auVar16 = ZEXT464((uint)fVar13);
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xa8) - *(float *)(lVar10 + 8)) +
               *(float *)(lVar10 + 8);
      fVar17 = fVar13 * ((fVar14 * (*(float *)(lVar10 + 0xd8) - *(float *)(lVar10 + 0x38)) +
                         *(float *)(lVar10 + 0x38)) - fVar17) + fVar17;
      auVar20 = ZEXT464((uint)fVar17);
      *(float *)(param_1 + 0xc90) = fVar17;
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xac) - *(float *)(lVar10 + 0xc)) +
               *(float *)(lVar10 + 0xc);
      fVar17 = fVar13 * ((fVar14 * (*(float *)(lVar10 + 0xdc) - *(float *)(lVar10 + 0x3c)) +
                         *(float *)(lVar10 + 0x3c)) - fVar17) + fVar17;
      auVar19 = ZEXT464((uint)fVar17);
      *(float *)(param_1 + 0xc94) = fVar17;
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xb0) - *(float *)(lVar10 + 0x10)) +
               *(float *)(lVar10 + 0x10);
      *(float *)(param_1 + 0xc98) =
           fVar13 * ((fVar14 * (*(float *)(lVar10 + 0xe0) - *(float *)(lVar10 + 0x40)) +
                     *(float *)(lVar10 + 0x40)) - fVar17) + fVar17;
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xb4) - *(float *)(lVar10 + 0x14)) +
               *(float *)(lVar10 + 0x14);
      *(float *)(param_1 + 0xc9c) =
           fVar13 * ((fVar14 * (*(float *)(lVar10 + 0xe4) - *(float *)(lVar10 + 0x44)) +
                     *(float *)(lVar10 + 0x44)) - fVar17) + fVar17;
      uVar4 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x48),*(undefined4 *)(lVar10 + 0xe8),uVar12);
      uVar8 = (ulonglong)uVar4;
      uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x18),*(undefined4 *)(lVar10 + 0xb8),
                            auVar15._0_8_,uVar8);
      uVar3 = FUN_140022d10(uVar3,uVar8 & 0xffffffff,auVar16._0_8_);
      *(undefined4 *)(param_1 + 0xca0) = uVar3;
      fVar14 = auVar15._0_4_;
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xbc) - *(float *)(lVar10 + 0x1c)) +
               *(float *)(lVar10 + 0x1c);
      fVar13 = auVar16._0_4_;
      *(float *)(param_1 + 0xca4) =
           fVar13 * ((fVar14 * (*(float *)(lVar10 + 0xec) - *(float *)(lVar10 + 0x4c)) +
                     *(float *)(lVar10 + 0x4c)) - fVar17) + fVar17;
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xc0) - *(float *)(lVar10 + 0x20)) +
               *(float *)(lVar10 + 0x20);
      *(float *)(param_1 + 0xca8) =
           fVar13 * ((fVar14 * (*(float *)(lVar10 + 0xf4) - *(float *)(lVar10 + 0x54)) +
                     *(float *)(lVar10 + 0x54)) - fVar17) + fVar17;
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xc4) - *(float *)(lVar10 + 0x24)) +
               *(float *)(lVar10 + 0x24);
      *(float *)(param_1 + 0xcac) =
           fVar13 * ((fVar14 * (*(float *)(lVar10 + 0xf8) - *(float *)(lVar10 + 0x58)) +
                     *(float *)(lVar10 + 0x58)) - fVar17) + fVar17;
      fVar17 = fVar14 * (*(float *)(lVar10 + 200) - *(float *)(lVar10 + 0x28)) +
               *(float *)(lVar10 + 0x28);
      *(float *)(param_1 + 0xcb0) =
           fVar13 * ((fVar14 * (*(float *)(lVar10 + 0xfc) - *(float *)(lVar10 + 0x5c)) +
                     *(float *)(lVar10 + 0x5c)) - fVar17) + fVar17;
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xcc) - *(float *)(lVar10 + 0x2c)) +
               *(float *)(lVar10 + 0x2c);
      *(float *)(param_1 + 0xcb4) =
           fVar13 * ((fVar14 * (*(float *)(lVar10 + 0x100) - *(float *)(lVar10 + 0x60)) +
                     *(float *)(lVar10 + 0x60)) - fVar17) + fVar17;
      uVar4 = FUN_140022d10(*(undefined4 *)(lVar10 + 100),*(undefined4 *)(lVar10 + 0x104),
                            auVar15._0_8_);
      uVar8 = (ulonglong)uVar4;
      uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x30),*(undefined4 *)(lVar10 + 0xd0),
                            auVar15._0_8_,uVar8);
      uVar3 = FUN_140022d10(uVar3,uVar8 & 0xffffffff,auVar16._0_8_);
      *(undefined4 *)(param_1 + 0xcb8) = uVar3;
      uVar4 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x68),*(undefined4 *)(lVar10 + 0x108),
                            auVar15._0_8_);
      uVar8 = (ulonglong)uVar4;
      uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x34),*(undefined4 *)(lVar10 + 0xd4),
                            auVar15._0_8_,uVar8);
      uVar3 = FUN_140022d10(uVar3,uVar8 & 0xffffffff,auVar16._0_8_);
      uVar18 = auVar20._0_8_;
      uVar12 = auVar19._0_8_;
      *(undefined4 *)(param_1 + 0xcbc) = uVar3;
      fVar13 = auVar15._0_4_;
      fVar17 = fVar13 * (*(float *)(lVar10 + 0x138) - *(float *)(lVar10 + 0x98)) +
               *(float *)(lVar10 + 0x98);
      fVar17 = auVar16._0_4_ *
               ((fVar13 * (*(float *)(lVar10 + 0x13c) - *(float *)(lVar10 + 0x9c)) +
                *(float *)(lVar10 + 0x9c)) - fVar17) + fVar17;
    }
    else {
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xd8) - *(float *)(lVar10 + 0x38)) +
               *(float *)(lVar10 + 0x38);
      auVar19 = ZEXT464((uint)fVar17);
      *(float *)(param_1 + 0xc90) = fVar17;
      fVar17 = fVar14 * (*(float *)(lVar10 + 0xdc) - *(float *)(lVar10 + 0x3c)) +
               *(float *)(lVar10 + 0x3c);
      auVar16 = ZEXT464((uint)fVar17);
      *(float *)(param_1 + 0xc94) = fVar17;
      *(float *)(param_1 + 0xc98) =
           fVar14 * (*(float *)(lVar10 + 0xe0) - *(float *)(lVar10 + 0x40)) +
           *(float *)(lVar10 + 0x40);
      *(float *)(param_1 + 0xc9c) =
           fVar14 * (*(float *)(lVar10 + 0xe4) - *(float *)(lVar10 + 0x44)) +
           *(float *)(lVar10 + 0x44);
      uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x48),*(undefined4 *)(lVar10 + 0xe8),uVar12);
      *(undefined4 *)(param_1 + 0xca0) = uVar3;
      fVar17 = auVar15._0_4_;
      *(float *)(param_1 + 0xca4) =
           fVar17 * (*(float *)(lVar10 + 0xec) - *(float *)(lVar10 + 0x4c)) +
           *(float *)(lVar10 + 0x4c);
      *(float *)(param_1 + 0xca8) =
           fVar17 * (*(float *)(lVar10 + 0xf4) - *(float *)(lVar10 + 0x54)) +
           *(float *)(lVar10 + 0x54);
      *(float *)(param_1 + 0xcac) =
           fVar17 * (*(float *)(lVar10 + 0xf8) - *(float *)(lVar10 + 0x58)) +
           *(float *)(lVar10 + 0x58);
      *(float *)(param_1 + 0xcb0) =
           fVar17 * (*(float *)(lVar10 + 0xfc) - *(float *)(lVar10 + 0x5c)) +
           *(float *)(lVar10 + 0x5c);
      *(float *)(param_1 + 0xcb4) =
           fVar17 * (*(float *)(lVar10 + 0x100) - *(float *)(lVar10 + 0x60)) +
           *(float *)(lVar10 + 0x60);
      uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 100),*(undefined4 *)(lVar10 + 0x104),
                            auVar15._0_8_);
      *(undefined4 *)(param_1 + 0xcb8) = uVar3;
      uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x68),*(undefined4 *)(lVar10 + 0x108),
                            auVar15._0_8_);
      uVar18 = auVar19._0_8_;
      uVar12 = auVar16._0_8_;
      *(undefined4 *)(param_1 + 0xcbc) = uVar3;
      fVar13 = auVar15._0_4_;
      fVar17 = fVar13 * (*(float *)(lVar10 + 0x13c) - *(float *)(lVar10 + 0x9c)) +
               *(float *)(lVar10 + 0x9c);
    }
  }
  else {
    fVar17 = fVar14 * (*(float *)(lVar10 + 0xa8) - *(float *)(lVar10 + 8)) + *(float *)(lVar10 + 8);
    auVar19 = ZEXT464((uint)fVar17);
    *(float *)(param_1 + 0xc90) = fVar17;
    fVar17 = fVar14 * (*(float *)(lVar10 + 0xac) - *(float *)(lVar10 + 0xc)) +
             *(float *)(lVar10 + 0xc);
    auVar16 = ZEXT464((uint)fVar17);
    *(float *)(param_1 + 0xc94) = fVar17;
    *(float *)(param_1 + 0xc98) =
         fVar14 * (*(float *)(lVar10 + 0xb0) - *(float *)(lVar10 + 0x10)) +
         *(float *)(lVar10 + 0x10);
    *(float *)(param_1 + 0xc9c) =
         fVar14 * (*(float *)(lVar10 + 0xb4) - *(float *)(lVar10 + 0x14)) +
         *(float *)(lVar10 + 0x14);
    uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x18),*(undefined4 *)(lVar10 + 0xb8),uVar12);
    *(undefined4 *)(param_1 + 0xca0) = uVar3;
    fVar17 = auVar15._0_4_;
    *(float *)(param_1 + 0xca4) =
         fVar17 * (*(float *)(lVar10 + 0xbc) - *(float *)(lVar10 + 0x1c)) +
         *(float *)(lVar10 + 0x1c);
    *(float *)(param_1 + 0xca8) =
         fVar17 * (*(float *)(lVar10 + 0xc0) - *(float *)(lVar10 + 0x20)) +
         *(float *)(lVar10 + 0x20);
    *(float *)(param_1 + 0xcac) =
         fVar17 * (*(float *)(lVar10 + 0xc4) - *(float *)(lVar10 + 0x24)) +
         *(float *)(lVar10 + 0x24);
    *(float *)(param_1 + 0xcb0) =
         fVar17 * (*(float *)(lVar10 + 200) - *(float *)(lVar10 + 0x28)) + *(float *)(lVar10 + 0x28)
    ;
    *(float *)(param_1 + 0xcb4) =
         fVar17 * (*(float *)(lVar10 + 0xcc) - *(float *)(lVar10 + 0x2c)) +
         *(float *)(lVar10 + 0x2c);
    uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x30),*(undefined4 *)(lVar10 + 0xd0),
                          auVar15._0_8_);
    *(undefined4 *)(param_1 + 0xcb8) = uVar3;
    uVar3 = FUN_140022d10(*(undefined4 *)(lVar10 + 0x34),*(undefined4 *)(lVar10 + 0xd4),
                          auVar15._0_8_);
    uVar18 = auVar19._0_8_;
    uVar12 = auVar16._0_8_;
    *(undefined4 *)(param_1 + 0xcbc) = uVar3;
    fVar13 = auVar15._0_4_;
    fVar17 = fVar13 * (*(float *)(lVar10 + 0x138) - *(float *)(lVar10 + 0x98)) +
             *(float *)(lVar10 + 0x98);
  }
  *(float *)(param_1 + 0xcf0) = fVar17;
  *(float *)(param_1 + 0xcc0) =
       fVar13 * (*(float *)(lVar10 + 0x10c) - *(float *)(lVar10 + 0x6c)) + *(float *)(lVar10 + 0x6c)
  ;
  *(float *)(param_1 + 0xcc4) =
       fVar13 * (*(float *)(lVar10 + 0x110) - *(float *)(lVar10 + 0x70)) + *(float *)(lVar10 + 0x70)
  ;
  *(float *)(param_1 + 0xcc8) =
       fVar13 * (*(float *)(lVar10 + 0x114) - *(float *)(lVar10 + 0x74)) + *(float *)(lVar10 + 0x74)
  ;
  *(float *)(param_1 + 0xccc) =
       fVar13 * (*(float *)(lVar10 + 0x118) - *(float *)(lVar10 + 0x78)) + *(float *)(lVar10 + 0x78)
  ;
  *(int *)(param_1 + 0xcd0) =
       (int)(longlong)((float)(*(int *)(lVar10 + 0x11c) - *(int *)(lVar10 + 0x7c)) * fVar13) +
       *(int *)(lVar10 + 0x7c);
  *(float *)(param_1 + 0xcd4) =
       fVar13 * (*(float *)(lVar10 + 0x120) - *(float *)(lVar10 + 0x80)) + *(float *)(lVar10 + 0x80)
  ;
  *(float **)(param_1 + 0x1f8) = pfVar1;
  FUN_140079080(lVar7,0,uVar18,uVar12);
  FUN_140079080(*(undefined8 *)(param_1 + 0xd08),1,*(undefined4 *)(param_1 + 0xcb0),
                *(undefined4 *)(param_1 + 0xcb4));
  fVar17 = DAT_1402d1e98;
  uVar4 = *(uint *)(param_1 + 0xca0);
  lVar7 = *(longlong *)(param_1 + 0xd08);
  *(float *)(lVar7 + 0x1f8) = (float)(uVar4 & 0xff) * DAT_1402d1e98;
  *(undefined4 *)(lVar7 + 0x204) = 0x3f800000;
  *(float *)(lVar7 + 0x1fc) = (float)(uVar4 >> 8 & 0xff) * fVar17;
  *(float *)(lVar7 + 0x200) = (float)(uVar4 >> 0x10 & 0xff) * fVar17;
  uVar4 = *(uint *)(param_1 + 0xcb8);
  lVar7 = *(longlong *)(param_1 + 0xd08);
  *(float *)(lVar7 + 0x208) = (float)(uVar4 & 0xff) * fVar17;
  *(float *)(lVar7 + 0x20c) = (float)(uVar4 >> 8 & 0xff) * fVar17;
  *(undefined4 *)(lVar7 + 0x214) = 0x3f800000;
  *(float *)(lVar7 + 0x210) = (float)(uVar4 >> 0x10 & 0xff) * fVar17;
  uVar4 = *(uint *)(param_1 + 0xcbc);
  lVar7 = *(longlong *)(param_1 + 0xd08);
  *(undefined4 *)(lVar7 + 0x234) = 0x3f800000;
  *(float *)(lVar7 + 0x228) = (float)(uVar4 & 0xff) * fVar17;
  *(float *)(lVar7 + 0x22c) = (float)(uVar4 >> 8 & 0xff) * fVar17;
  *(float *)(lVar7 + 0x230) = (float)(uVar4 >> 0x10 & 0xff) * fVar17;
  return;
}

