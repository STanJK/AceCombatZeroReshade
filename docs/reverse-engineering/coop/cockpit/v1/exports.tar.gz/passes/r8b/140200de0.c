/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140200de0; RVA 0x200de0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

ulonglong FUN_140200de0(longlong *param_1,uint param_2,uint param_3)

{
  ulonglong uVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong *plVar6;
  longlong lVar7;
  ulonglong uVar8;
  int iVar9;
  int iVar10;
  ulonglong uVar11;
  int iVar12;
  ulonglong uVar13;
  int local_res10;
  
  if ((param_2 != 0) && ((char)param_1[5] != '\0')) {
    iVar2 = (int)param_1[3];
    local_res10 = 0;
    if (0 < iVar2) {
      plVar3 = (longlong *)param_1[2];
      lVar7 = 0;
      plVar6 = plVar3 + 1;
      do {
        if (*plVar6 == 0) {
          if (local_res10 == -1) {
            return 0;
          }
          uVar13 = 0xf000000000000000;
          iVar9 = 0;
          iVar12 = -1;
          plVar6 = plVar3;
          do {
            if (plVar6[1] != 0) {
              uVar11 = (ulonglong)param_3 + plVar6[1] + -1 + *plVar6;
              uVar11 = uVar11 - uVar11 % (ulonglong)param_3;
              uVar1 = uVar11 + param_2;
              if (uVar1 <= (ulonglong)*(uint *)(param_1 + 1) + *param_1) {
                iVar10 = 0;
                lVar7 = 0;
                do {
                  lVar4 = *(longlong *)(lVar7 + 8 + (longlong)plVar3);
                  if (lVar4 != 0) {
                    uVar5 = *(ulonglong *)(lVar7 + (longlong)plVar3);
                    uVar8 = lVar4 + uVar5;
                    if (((((uVar5 <= uVar11) && (uVar11 < uVar8)) ||
                         ((uVar5 < uVar1 && (uVar1 <= uVar8)))) ||
                        ((uVar11 <= uVar5 && (uVar5 < uVar1)))) ||
                       ((uVar11 < uVar8 && (uVar8 <= uVar1)))) goto LAB_140200efa;
                  }
                  iVar10 = iVar10 + 1;
                  lVar7 = lVar7 + 0x18;
                } while (iVar10 < iVar2);
                if (uVar11 < uVar13) {
                  uVar13 = uVar11;
                  iVar12 = iVar9;
                }
              }
            }
LAB_140200efa:
            iVar9 = iVar9 + 1;
            plVar6 = plVar6 + 3;
            if (iVar2 <= iVar9) {
              lVar7 = (longlong)local_res10;
              if (iVar12 == -1) {
                return 0;
              }
              plVar3[lVar7 * 3] = uVar13;
              plVar3[lVar7 * 3 + 1] = (ulonglong)param_2;
              *(char *)(plVar3 + lVar7 * 3 + 2) = (char)param_1[5];
              return uVar13;
            }
          } while( true );
        }
        local_res10 = local_res10 + 1;
        lVar7 = lVar7 + 1;
        plVar6 = plVar6 + 3;
      } while (lVar7 < iVar2);
    }
  }
  return 0;
}

