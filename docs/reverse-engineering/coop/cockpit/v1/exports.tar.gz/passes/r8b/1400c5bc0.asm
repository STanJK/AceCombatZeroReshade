0x1400c5bc0  MOV RAX,qword ptr [RCX + 0x10]
0x1400c5bc4  TEST RAX,RAX
0x1400c5bc7  JZ 0x1400c5bfb
0x1400c5bc9  MOV RDX,qword ptr [RAX + 0x2d8]
0x1400c5bd0  TEST RDX,RDX
0x1400c5bd3  JZ 0x1400c5bfb
0x1400c5bd5  MOVZX ECX,byte ptr [RAX + 0x3c9]
0x1400c5bdc  MOV RAX,qword ptr [RDX]
0x1400c5bdf  CMP CL,byte ptr [RAX]
0x1400c5be1  JNC 0x1400c5bfb
0x1400c5be3  MOV RAX,qword ptr [RDX + 0x8]
0x1400c5be7  LEA RCX,[RCX + RCX*0x8]
0x1400c5beb  LEA RAX,[RAX + RCX*0x8]
0x1400c5bef  TEST RAX,RAX
0x1400c5bf2  JZ 0x1400c5bfb
0x1400c5bf4  MOV RAX,qword ptr [RAX]
0x1400c5bf7  MOVZX EAX,byte ptr [RAX]
0x1400c5bfa  RET
0x1400c5bfb  MOV AL,0xff
0x1400c5bfd  RET
