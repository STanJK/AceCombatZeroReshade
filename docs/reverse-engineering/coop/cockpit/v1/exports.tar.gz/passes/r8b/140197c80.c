/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140197c80; RVA 0x197c80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140197c80(undefined8 param_1,longlong param_2,longlong param_3,longlong param_4)

{
  if (DAT_14033acb8 != 0) {
    if (0xfff < (DAT_14033acc8 - DAT_14033acb8 & 0xfffffffffffffff8U)) {
      if (0x1f < (DAT_14033acb8 - *(longlong *)(DAT_14033acb8 + -8)) - 8U) {
                    /* WARNING: Subroutine does not return */
        _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
      }
    }
    thunk_FUN_1402500f0();
  }
  DAT_14033acb8 = param_2;
  DAT_14033acc0 = param_2 + param_3 * 8;
  DAT_14033acc8 = param_2 + param_4 * 8;
  return;
}

