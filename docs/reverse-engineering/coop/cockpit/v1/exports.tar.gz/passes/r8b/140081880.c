/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140081880; RVA 0x81880
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140081880(longlong *param_1,longlong *param_2,undefined8 param_3)

{
  undefined4 uVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  longlong lVar5;
  float fVar6;
  float fVar7;
  undefined8 uVar8;
  undefined8 *puVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined8 *puVar12;
  int local_res8;
  undefined4 local_resc;
  
  lVar5 = param_1[0x1a1];
  uVar1 = *(undefined4 *)(lVar5 + 0x30);
  uVar4 = *(undefined4 *)(lVar5 + 0x28);
  *(undefined4 *)((longlong)param_1 + 0x20c) = *(undefined4 *)(lVar5 + 0x2c);
  *(undefined4 *)(param_1 + 0x42) = uVar1;
  *(undefined4 *)(param_1 + 0x41) = uVar4;
  lVar5 = param_1[0x1a1];
  *(undefined4 *)((longlong)param_1 + 0x214) = *(undefined4 *)(lVar5 + 0x1c);
  *(undefined4 *)((longlong)param_1 + 0x21c) = *(undefined4 *)((longlong)param_1 + 0xc9c);
  *(undefined4 *)(param_1 + 0x43) = *(undefined4 *)((longlong)param_1 + 0xc94);
  uVar1 = *(undefined4 *)(lVar5 + 0x2a0);
  *(undefined4 *)((longlong)param_1 + 0x204) = *(undefined4 *)(lVar5 + 0x29c);
  *(undefined4 *)(param_1 + 0x40) = uVar1;
  FUN_140082a80(param_1 + 0x2e,lVar5 + 0x178,lVar5 + 0x138);
  lVar5 = param_1[0x1a1];
  uVar1 = *(undefined4 *)(lVar5 + 0x288);
  *(undefined4 *)((longlong)param_1 + 0x2a4) = *(undefined4 *)(lVar5 + 0x28c);
  *(undefined4 *)(param_1 + 0x54) = uVar1;
  if (*(char *)((longlong)param_1 + 0x7f1) == '\x01') {
    uVar1 = *(undefined4 *)(lVar5 + 0x288);
    *(undefined4 *)((longlong)param_1 + 0x344) = *(undefined4 *)(lVar5 + 0x28c);
    *(undefined4 *)(param_1 + 0x68) = uVar1;
    *(int *)((longlong)param_1 + 0x38c) = (int)param_1[0xf9];
  }
  uVar10 = *(undefined8 *)(lVar5 + 0x280);
  uVar11 = 0;
  if (*(int *)((longlong)param_2 + 0xc) == -1) {
    if ((int)param_2[1] < 2) {
      uVar8 = 0;
    }
    else {
      lVar5 = param_2[3];
      *(undefined4 *)((longlong)param_2 + 0xc) = 1;
      puVar9 = *(undefined8 **)(*param_2 + 0x28);
      if (*(char *)(lVar5 + 0x21) == '\0') {
        *(undefined1 *)(lVar5 + 0x21) = 1;
        uVar8 = *(undefined8 *)(lVar5 + 0x10);
      }
      else {
        uVar8 = 0;
      }
      *puVar9 = 0x20000000;
      FUN_140197b30(puVar9,uVar8);
      puVar9[1] = 0;
    }
  }
  else {
    uVar8 = 0;
  }
  uVar8 = FUN_1401fc350(uVar10,uVar8);
  puVar9 = (undefined8 *)FUN_140081e60(param_1,uVar8);
  if (*(int *)((longlong)param_2 + 0xc) != -1) {
    *(undefined8 **)((longlong)*(int *)((longlong)param_2 + 0xc) * 0x20 + 8 + *param_2) = puVar9;
    uVar8 = *(undefined8 *)((longlong)*(int *)((longlong)param_2 + 0xc) * 0x20 + 0x10 + *param_2);
    *puVar9 = 0x20000000;
    FUN_140197b30(puVar9,uVar8);
    puVar9[1] = 0;
    lVar5 = param_2[3];
    *(undefined4 *)((longlong)param_2 + 0xc) = 0xffffffff;
    if (*(char *)(lVar5 + 0x21) != '\0') {
      *(undefined1 *)(lVar5 + 0x21) = 0;
      *(undefined8 **)(lVar5 + 0x10) = puVar9 + 2;
    }
  }
  if (*(int *)((longlong)param_2 + 0xc) == -1) {
    if ((int)param_2[1] < 4) {
      uVar8 = 0;
    }
    else {
      lVar5 = param_2[3];
      *(undefined4 *)((longlong)param_2 + 0xc) = 3;
      puVar9 = *(undefined8 **)(*param_2 + 0x68);
      if (*(char *)(lVar5 + 0x21) == '\0') {
        *(undefined1 *)(lVar5 + 0x21) = 1;
        uVar8 = *(undefined8 *)(lVar5 + 0x10);
      }
      else {
        uVar8 = 0;
      }
      *puVar9 = 0x20000000;
      FUN_140197b30(puVar9,uVar8);
      puVar9[1] = 0;
    }
  }
  else {
    uVar8 = 0;
  }
  uVar8 = FUN_1401fc350(uVar10,uVar8);
  puVar9 = (undefined8 *)FUN_1400821c0(param_1,uVar8);
  if (*(int *)((longlong)param_2 + 0xc) != -1) {
    *(undefined8 **)((longlong)*(int *)((longlong)param_2 + 0xc) * 0x20 + 8 + *param_2) = puVar9;
    uVar8 = *(undefined8 *)((longlong)*(int *)((longlong)param_2 + 0xc) * 0x20 + 0x10 + *param_2);
    *puVar9 = 0x20000000;
    FUN_140197b30(puVar9,uVar8);
    puVar9[1] = 0;
    lVar5 = param_2[3];
    *(undefined4 *)((longlong)param_2 + 0xc) = 0xffffffff;
    if (*(char *)(lVar5 + 0x21) != '\0') {
      *(undefined1 *)(lVar5 + 0x21) = 0;
      *(undefined8 **)(lVar5 + 0x10) = puVar9 + 2;
    }
  }
  FUN_1400823e0(param_1,param_2,param_3);
  if ((*(int *)(*param_1 + 0x14) != 0) && (0.0 < *(float *)(param_1 + 0x19e))) {
    if (*(int *)((longlong)param_2 + 0xc) == -1) {
      if ((int)param_2[1] < 10) {
        puVar12 = (undefined8 *)0x0;
      }
      else {
        lVar5 = param_2[3];
        *(undefined4 *)((longlong)param_2 + 0xc) = 9;
        puVar9 = *(undefined8 **)(*param_2 + 0x128);
        if (*(char *)(lVar5 + 0x21) == '\0') {
          *(undefined1 *)(lVar5 + 0x21) = 1;
          puVar12 = *(undefined8 **)(lVar5 + 0x10);
        }
        else {
          puVar12 = (undefined8 *)0x0;
        }
        *puVar9 = 0x20000000;
        FUN_140197b30(puVar9,puVar12);
        puVar9[1] = 0;
      }
    }
    else {
      puVar12 = (undefined8 *)0x0;
    }
    if (*(int *)(*param_1 + 0x14) != 0) {
      local_resc = (undefined4)param_1[0x19e];
      local_res8 = *(int *)(*param_1 + 0x14);
      puVar12 = (undefined8 *)
                FUN_140069700(&local_res8,puVar12,0,DAT_1403566c8,DAT_1403566cc,0x140,0);
    }
    if (*(int *)((longlong)param_2 + 0xc) != -1) {
      *(undefined8 **)((longlong)*(int *)((longlong)param_2 + 0xc) * 0x20 + 8 + *param_2) = puVar12;
      uVar8 = *(undefined8 *)((longlong)*(int *)((longlong)param_2 + 0xc) * 0x20 + 0x10 + *param_2);
      *puVar12 = 0x20000000;
      FUN_140197b30(puVar12,uVar8);
      puVar12[1] = 0;
      lVar5 = param_2[3];
      *(undefined4 *)((longlong)param_2 + 0xc) = 0xffffffff;
      if (*(char *)(lVar5 + 0x21) != '\0') {
        *(undefined1 *)(lVar5 + 0x21) = 0;
        *(undefined8 **)(lVar5 + 0x10) = puVar12 + 2;
      }
    }
  }
  if (*(int *)((longlong)param_2 + 0xc) == -1) {
    if ((int)param_2[1] < 0xb) {
      uVar8 = 0;
    }
    else {
      lVar5 = param_2[3];
      *(undefined4 *)((longlong)param_2 + 0xc) = 10;
      puVar9 = *(undefined8 **)(*param_2 + 0x148);
      if (*(char *)(lVar5 + 0x21) == '\0') {
        *(undefined1 *)(lVar5 + 0x21) = 1;
        uVar8 = *(undefined8 *)(lVar5 + 0x10);
      }
      else {
        uVar8 = 0;
      }
      *puVar9 = 0x20000000;
      FUN_140197b30(puVar9,uVar8);
      puVar9[1] = 0;
    }
  }
  else {
    uVar8 = 0;
  }
  puVar9 = (undefined8 *)FUN_140089350(param_1 + 0x4a,uVar8,uVar10);
  if (*(char *)((longlong)param_1 + 0x7f1) == '\x01') {
    puVar9 = (undefined8 *)FUN_140089350(param_1 + 0x5e,puVar9,uVar10);
  }
  if (*(int *)((longlong)param_2 + 0xc) != -1) {
    *(undefined8 **)((longlong)*(int *)((longlong)param_2 + 0xc) * 0x20 + 8 + *param_2) = puVar9;
    uVar10 = *(undefined8 *)((longlong)*(int *)((longlong)param_2 + 0xc) * 0x20 + 0x10 + *param_2);
    *puVar9 = 0x20000000;
    FUN_140197b30(puVar9,uVar10);
    puVar9[1] = 0;
    lVar5 = param_2[3];
    *(undefined4 *)((longlong)param_2 + 0xc) = 0xffffffff;
    if (*(char *)(lVar5 + 0x21) != '\0') {
      *(undefined1 *)(lVar5 + 0x21) = 0;
      *(undefined8 **)(lVar5 + 0x10) = puVar9 + 2;
    }
  }
  if ((*(int *)((longlong)param_2 + 0xc) == -1) && (0xc < (int)param_2[1])) {
    lVar5 = param_2[3];
    *(undefined4 *)((longlong)param_2 + 0xc) = 0xc;
    puVar9 = *(undefined8 **)(*param_2 + 0x188);
    if (*(char *)(lVar5 + 0x21) == '\0') {
      *(undefined1 *)(lVar5 + 0x21) = 1;
      uVar11 = *(undefined8 *)(lVar5 + 0x10);
    }
    else {
      uVar11 = 0;
    }
    *puVar9 = 0x20000000;
    FUN_140197b30(puVar9,uVar11);
    puVar9[1] = 0;
  }
  uVar10 = FUN_1400825c0(param_1,uVar11);
  FUN_1402011a0(param_2,uVar10);
  fVar7 = DAT_1402d2a04;
  lVar5 = param_1[0x1a1];
  fVar2 = *(float *)(param_1 + 0x5d);
  fVar3 = *(float *)((longlong)param_1 + 0x2e4);
  fVar6 = *(float *)(lVar5 + 0x18) + *(float *)(param_1 + 0x5c) + DAT_1402d2a04;
  *(float *)(lVar5 + 0x2a8) =
       (*(float *)(lVar5 + 0x18) + *(float *)((longlong)param_1 + 0x2dc)) - DAT_1402d2a04;
  *(float *)(lVar5 + 0x2ac) = fVar6;
  *(float *)(lVar5 + 0x2b4) = fVar2 + *(float *)(lVar5 + 0x20) + fVar7;
  *(float *)(lVar5 + 0x2b0) = (fVar3 + *(float *)(lVar5 + 0x20)) - fVar7;
  return;
}

