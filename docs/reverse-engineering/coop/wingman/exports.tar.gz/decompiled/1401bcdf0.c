/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401bcdf0; RVA 0x1bcdf0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401bcdf0(longlong *param_1)

{
  int *piVar1;
  byte *pbVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  int iVar7;
  char cVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined *puVar11;
  
  lVar5 = param_1[3];
  puVar11 = &DAT_140316e78;
  if (DAT_14031cf18 == '\0') {
    puVar11 = &DAT_140310ec0;
  }
  piVar1 = (int *)(puVar11 + (longlong)(int)param_1[7] * 4 + 0x24c);
  lVar6 = *(longlong *)(lVar5 + 0x368 + (longlong)*piVar1 * 0x18);
  *(uint *)(param_1 + 5) =
       (uint)*(byte *)(lVar6 + 7) + (uint)(byte)(&DAT_1402a9b58)[*(byte *)(lVar6 + 4)] * 10;
  cVar3 = puVar11[(longlong)*piVar1 * 3 + 0x1e0];
  *(char *)((longlong)param_1 + 0x34) = cVar3;
  lVar6 = *(longlong *)(lVar5 + 0x368 + (longlong)*piVar1 * 0x18);
  *(uint *)((longlong)param_1 + 0x2c) =
       (uint)*(byte *)(lVar6 + 8) + (uint)(byte)(&DAT_1402a9b58)[*(byte *)(lVar6 + 5)] * 10;
  cVar8 = puVar11[(longlong)*piVar1 * 3 + 0x1e1];
  *(char *)((longlong)param_1 + 0x35) = cVar8;
  lVar5 = *(longlong *)(lVar5 + 0x368 + (longlong)*piVar1 * 0x18);
  *(uint *)(param_1 + 6) =
       (uint)*(byte *)(lVar5 + 9) + (uint)(byte)(&DAT_1402a9b58)[*(byte *)(lVar5 + 6)] * 10;
  *(undefined *)((longlong)param_1 + 0x36) = puVar11[(longlong)*piVar1 * 3 + 0x1e2];
  if ((int)param_1[4] == 1) {
    *(undefined2 *)((longlong)param_1 + 0x34) = 0x101;
    cVar8 = '\x01';
    *(undefined1 *)((longlong)param_1 + 0x36) = 1;
LAB_1401bcf00:
    *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
    uVar9 = 1;
  }
  else {
    uVar9 = 0;
    if (cVar3 != '\0') goto LAB_1401bcf00;
  }
  uVar10 = uVar9;
  if (cVar8 != '\0') {
    uVar10 = (ulonglong)((int)uVar9 + 1);
    *(undefined4 *)((longlong)param_1 + uVar9 * 4 + 0x3c) = 1;
  }
  uVar9 = uVar10;
  if (*(char *)((longlong)param_1 + 0x36) != '\0') {
    uVar9 = (ulonglong)((int)uVar10 + 1);
    *(undefined4 *)((longlong)param_1 + uVar10 * 4 + 0x3c) = 2;
  }
  iVar7 = (int)uVar9;
  *(int *)(param_1 + 9) = iVar7;
  if ((int)param_1[1] == -1) {
    iVar4 = *(int *)(puVar11 + (longlong)(int)param_1[7] * 4 + 0x25c);
    if ((((iVar4 < 0) || (2 < iVar4)) ||
        (puVar11[(longlong)iVar4 + (longlong)*(int *)((longlong)param_1 + 0x4c) * 3 + 0x1e0] == '\0'
        )) && ((int)param_1[4] != 1)) {
      iVar7 = (**(code **)(*param_1 + 0x20))(param_1);
    }
    else {
      if ((iVar4 != 0) && (iVar7 != 1)) {
        if (iVar7 == 3) {
          if ((-1 < iVar4) && (iVar7 = (**(code **)(*param_1 + 0x20))(param_1), iVar4 < iVar7)) {
            *(int *)(param_1 + 1) = iVar4;
          }
        }
        else {
          iVar7 = (**(code **)(*param_1 + 0x20))(param_1);
          if (1 < iVar7) {
            *(undefined4 *)(param_1 + 1) = 1;
          }
        }
        goto LAB_1401bcfcf;
      }
      iVar7 = (**(code **)(*param_1 + 0x20))(param_1);
    }
    if (0 < iVar7) {
      *(undefined4 *)(param_1 + 1) = 0;
    }
  }
LAB_1401bcfcf:
  pbVar2 = (byte *)((longlong)((int)param_1[4] * 2) + 0x26cd + param_1[2]);
  *pbVar2 = *pbVar2 & 0xfd;
                    /* WARNING: Could not recover jumptable at 0x0001401bcffd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x10))(param_1);
  return;
}

