0x1400faa80  MOV qword ptr [RSP + 0x10],RBX
0x1400faa85  PUSH RSI
0x1400faa86  SUB RSP,0x20
0x1400faa8a  MOV R11,qword ptr [RDX]
0x1400faa8d  XOR ESI,ESI
0x1400faa8f  MOV RAX,qword ptr [RCX + 0x2f8]
0x1400faa96  MOV R8,RCX
0x1400faa99  MOV R9D,ESI
0x1400faa9c  MOV RDX,qword ptr [RAX]
0x1400faa9f  MOV RAX,qword ptr [RDX]
0x1400faaa2  MOV RDX,qword ptr [RAX + 0x110]
0x1400faaa9  MOV RBX,qword ptr [RDX + 0x1b8]
0x1400faab0  OR dword ptr [RBX + 0x2058],0x1000
0x1400faaba  OR word ptr [RBX + 0x1c20],0x1
0x1400faac2  MOVZX EAX,byte ptr [R11 + 0xb6]
0x1400faaca  CMP AL,0xff
0x1400faacc  JZ 0x1400faafe
0x1400faace  MOV EDX,EAX
0x1400faad0  MOV RAX,qword ptr [RCX + 0x2f8]
0x1400faad7  MOV RCX,qword ptr [RAX]
0x1400faada  LEA RAX,[RCX + RDX*0x8]
0x1400faade  MOVZX ECX,byte ptr [R11 + 0xb7]
0x1400faae6  CMP CL,0xff
0x1400faae9  JZ 0x1400fab06
0x1400faaeb  IMUL R9,RCX,0x520
0x1400faaf2  MOV RCX,qword ptr [RAX]
0x1400faaf5  ADD R9,qword ptr [RCX + 0x110]
0x1400faafc  JMP 0x1400fab06
0x1400faafe  MOV RAX,qword ptr [0x00000000]
0x1400fab06  TEST RAX,RAX
0x1400fab09  JZ 0x1400fac47
0x1400fab0f  TEST R9,R9
0x1400fab12  JZ 0x1400fac47
0x1400fab18  MOV R10D,dword ptr [R8 + 0x3a8]
0x1400fab1f  MOV EDX,dword ptr [R8 + 0x37c]
0x1400fab26  OR R10D,0x10020
0x1400fab2d  MOV qword ptr [RSP + 0x30],RDI
0x1400fab32  MOVZX EDI,byte ptr [R8 + 0x3d1]
0x1400fab3a  VXORPS XMM1,XMM1,XMM1
0x1400fab3e  VCVTSI2SS XMM1,XMM1,EDI
0x1400fab42  MOV dword ptr [R8 + 0x3a8],R10D
0x1400fab49  VMULSS XMM0,XMM1,dword ptr [R11 + 0x98]
0x1400fab52  VCVTTSS2SI EAX,XMM0
0x1400fab56  MOVZX ECX,AX
0x1400fab59  CMP EDX,ECX
0x1400fab5b  JGE 0x1400fabb5
0x1400fab5d  TEST R10B,0x4
0x1400fab61  JNZ 0x1400fab6c
0x1400fab63  INC EDX
0x1400fab65  MOV dword ptr [R8 + 0x37c],EDX
0x1400fab6c  CMP EDX,EDI
0x1400fab6e  JGE 0x1400fab91
0x1400fab70  VXORPS XMM0,XMM0,XMM0
0x1400fab74  VCVTSI2SS XMM0,XMM0,EDX
0x1400fab78  VDIVSS XMM2,XMM0,XMM1
0x1400fab7c  VMOVSS XMM1,dword ptr [0x1402d22d0]
0x1400fab84  VSUBSS XMM0,XMM1,XMM2
0x1400fab88  VMOVSS dword ptr [R8 + 0x3a0],XMM0
0x1400fab91  XOR EDX,EDX
0x1400fab93  MOV RCX,R8
0x1400fab96  CALL 0x140101ec0
0x1400fab9b  OR dword ptr [RBX + 0x2058],0x2000000
0x1400faba5  MOV RDI,qword ptr [RSP + 0x30]
0x1400fabaa  MOV RBX,qword ptr [RSP + 0x38]
0x1400fabaf  ADD RSP,0x20
0x1400fabb3  POP RSI
0x1400fabb4  RET
0x1400fabb5  MOV RAX,qword ptr [R8 + 0x2f8]
0x1400fabbc  AND R10D,0xfffffff7
0x1400fabc0  MOV dword ptr [R8 + 0x3a8],R10D
0x1400fabc7  MOV RCX,qword ptr [RAX]
0x1400fabca  MOV RAX,qword ptr [RCX]
0x1400fabcd  MOV RCX,qword ptr [RAX + 0x110]
0x1400fabd4  MOV RAX,qword ptr [RCX + 0x1b8]
0x1400fabdb  AND dword ptr [RAX + 0x2058],0xffffffef
0x1400fabe2  AND byte ptr [RBX + 0x1863],0xfe
0x1400fabe9  MOV dword ptr [RBX + 0x185c],ESI
0x1400fabef  AND byte ptr [RBX + 0x1da7],0xfe
0x1400fabf6  MOV qword ptr [RBX + 0x1d78],RSI
0x1400fabfd  MOV ECX,dword ptr [RBX + 0x2058]
0x1400fac03  BT ECX,0xd
0x1400fac07  JNC 0x1400fac1a
0x1400fac09  MOVZX EAX,byte ptr [RBX + 0x2095]
0x1400fac10  BTR ECX,0xd
0x1400fac14  MOV byte ptr [RBX + 0x2096],AL
0x1400fac1a  BTR ECX,0x19
0x1400fac1e  MOV dword ptr [RBX + 0x2058],ECX
0x1400fac24  MOV RDI,qword ptr [RSP + 0x30]
0x1400fac29  MOV dword ptr [R8 + 0x37c],ESI
0x1400fac30  MOV byte ptr [R8 + 0x3cc],0x17
0x1400fac38  MOV byte ptr [R8 + 0x3e6],0x1
0x1400fac40  MOV dword ptr [R8 + 0x3a0],ESI
0x1400fac47  MOV RBX,qword ptr [RSP + 0x38]
0x1400fac4c  ADD RSP,0x20
0x1400fac50  POP RSI
0x1400fac51  RET
