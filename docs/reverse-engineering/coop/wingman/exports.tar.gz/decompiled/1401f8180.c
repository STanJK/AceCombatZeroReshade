/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401f8180; RVA 0x1f8180
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1401f8180(char *param_1)

{
  float fVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined4 local_18;
  
  if ((param_1[1] == '\0') && (*param_1 == '\0')) {
    *(float *)(param_1 + 4) = *(float *)(param_1 + 4) + DAT_1402d22d0;
    if (*(longlong **)(param_1 + 0x1d0) != (longlong *)0x0) {
      (**(code **)(**(longlong **)(param_1 + 0x1d0) + 0x20))();
    }
    iVar3 = *(int *)(param_1 + 0x1fc);
    fVar1 = *(float *)(param_1 + 0x200);
    if ((float)iVar3 <= fVar1) {
      do {
        *(float *)(param_1 + 0x200) = fVar1 - (float)iVar3;
        param_1[0x1f8] = -1;
        param_1[0x1f9] = -1;
        param_1[0x1fa] = -1;
        param_1[0x1fb] = -1;
        local_78 = _DAT_14030f080;
        uStack_70 = uRam000000014030f088;
        uStack_68 = uRam000000014030f090;
        uStack_60 = uRam000000014030f098;
        local_58 = _DAT_14030f0a0;
        uStack_50 = uRam000000014030f0a8;
        uStack_48 = uRam000000014030f0b0;
        uStack_40 = uRam000000014030f0b8;
        local_38 = _DAT_14030f060;
        uStack_30 = uRam000000014030f068;
        uStack_28 = uRam000000014030f070;
        uStack_20 = uRam000000014030f078;
        local_18 = 0;
        FUN_1401f9970(*(undefined8 *)(param_1 + 0x1e0),&local_78);
        if (*(int *)(param_1 + 0x1f8) == -1) {
          param_1[0x1f0] = '\0';
          param_1[0x1f1] = '\0';
          param_1[0x1f2] = '\0';
          param_1[499] = '\0';
          param_1[500] = '\0';
          param_1[0x1f5] = '\0';
          param_1[0x1f6] = '\0';
          param_1[0x1f7] = '\0';
        }
        else {
          lVar4 = (**(code **)(**(longlong **)(param_1 + 0x1b0) + 0x38))();
          uVar2 = *(undefined4 *)(param_1 + 0x210);
          *(undefined8 *)(lVar4 + 0x40) = *(undefined8 *)(param_1 + 0x208);
          *(undefined4 *)(lVar4 + 0x48) = uVar2;
          if (lVar4 != *(longlong *)(param_1 + 0x1f0)) {
            *(longlong *)(param_1 + 0x1f0) = lVar4;
            *(undefined4 *)(lVar4 + 0x38) = 0xffffffff;
            FUN_1401f8bc0(lVar4,*(undefined4 *)(lVar4 + 0x34));
          }
        }
        iVar3 = *(int *)(param_1 + 0x1fc);
        fVar1 = *(float *)(param_1 + 0x200);
      } while ((float)iVar3 <= fVar1);
    }
    if (*(longlong **)(param_1 + 0x1d0) != (longlong *)0x0) {
      (**(code **)(**(longlong **)(param_1 + 0x1d0) + 0x28))();
    }
    *(float *)(param_1 + 0x200) =
         (float)*(int *)(*(longlong *)(param_1 + 0x10) + 0x4c) + *(float *)(param_1 + 0x200);
  }
  return;
}

