/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400ff220; RVA 0xff220
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400ff220(longlong param_1,char param_2)

{
  char cVar1;
  longlong lVar2;
  undefined2 uVar3;
  undefined4 *puVar4;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_18;
  undefined4 local_14;
  
  if (*(longlong *)(param_1 + 0x308) == 0) {
    return;
  }
  if (*(undefined8 **)(param_1 + 0x2f8) == (undefined8 *)0x0) {
    return;
  }
  lVar2 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  if (lVar2 == 0) {
    return;
  }
  lVar2 = *(longlong *)(lVar2 + 0x1b8);
  if (lVar2 == 0) {
    return;
  }
  local_48 = 0x12061204;
  local_44 = 0x12051208;
  local_38 = 0xffff13a0;
  local_34 = 0x13a113a2;
  local_28 = 0xffff13a4;
  local_24 = 0x101413a5;
  local_18 = 0xffff13cc;
  local_14 = 0x7ce13e9;
  switch(*(undefined1 *)(param_1 + 0x3d6)) {
  case 1:
  case 10:
    puVar4 = &local_48;
    break;
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
  case 8:
  case 9:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x15:
  case 0x16:
  case 0x17:
    goto switchD_1400ff2e4_caseD_2;
  case 0x14:
    puVar4 = &local_38;
    break;
  case 0x18:
    puVar4 = &local_28;
    break;
  case 0x19:
  case 0x1a:
  case 0x1b:
    puVar4 = &local_18;
    break;
  default:
    goto switchD_1400ff2e4_default;
  }
  cVar1 = *(char *)(param_1 + 0x3cc);
  if (param_2 == '\0') {
    if (cVar1 == '\x01') goto switchD_1400ff326_caseD_15;
    if (cVar1 == '\x03') goto switchD_1400ff326_caseD_17;
    if (cVar1 == '\x04') goto switchD_1400ff326_caseD_18;
  }
  else {
    switch(cVar1) {
    case '\x15':
switchD_1400ff326_caseD_15:
      uVar3 = *(undefined2 *)puVar4;
LAB_1400ff388:
      FUN_1401a61a0(*(longlong *)(param_1 + 0x308),uVar3,0,0,0);
      break;
    case '\x17':
switchD_1400ff326_caseD_17:
      if (*(float *)(lVar2 + 0x1848) < DAT_1402d264c) {
        if (*(int *)(param_1 + 0x378) == (uint)*(byte *)(param_1 + 0x3d1) * 0x1e) {
          uVar3 = *(undefined2 *)((longlong)puVar4 + 2);
        }
        else {
          if (*(int *)(param_1 + 0x378) != (uint)*(byte *)(param_1 + 0x3d1) * 0x2d) break;
          uVar3 = *(undefined2 *)(puVar4 + 1);
        }
        goto LAB_1400ff388;
      }
      break;
    case '\x18':
switchD_1400ff326_caseD_18:
      if (*(int *)(param_1 + 0x378) == 0) {
        uVar3 = *(undefined2 *)((longlong)puVar4 + 6);
        goto LAB_1400ff388;
      }
    }
  }
switchD_1400ff2e4_caseD_2:
switchD_1400ff2e4_default:
  return;
}

