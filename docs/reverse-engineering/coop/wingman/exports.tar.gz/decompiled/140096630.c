/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140096630; RVA 0x96630
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined4 FUN_140096630(longlong *param_1,undefined1 (*param_2) [16],byte param_3,byte param_4)

{
  undefined1 auVar1 [16];
  longlong lVar2;
  float fVar3;
  char cVar4;
  undefined4 uVar5;
  longlong lVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined1 local_78 [16];
  undefined8 local_68;
  undefined8 uStack_60;
  undefined1 local_58 [8];
  float fStack_50;
  
  cVar4 = (**(code **)(*param_1 + 0x30))(param_1,(ulonglong)param_3,param_4);
  if (cVar4 == '\0') {
    fVar11 = 0.0;
    uVar5 = FUN_1400934e0(param_1,param_2,param_3,param_4,0,0);
    local_78 = ZEXT816(0);
    lVar6 = (ulonglong)param_4 * 0x520;
    lVar2 = *(longlong *)(*(longlong *)(*(longlong *)param_1[2] + (ulonglong)param_3 * 8) + 0x110);
    fVar9 = *(float *)(*(longlong *)(lVar2 + 0x1b8 + lVar6) + 0x1848) * DAT_1402d2d8c;
    local_88 = 0;
    uStack_80 = 0;
    local_68 = 0;
    uStack_60 = 0;
    _local_58 = local_78;
    FUN_140202920(&local_88,lVar2 + 0x268 + lVar6);
    auVar1 = *param_2;
    fVar8 = fVar9 * (float)local_68 + (float)local_58._0_4_;
    fVar10 = fVar9 * local_68._4_4_ + (float)local_58._4_4_;
    fStack_50 = fVar9 * (float)uStack_60 + fStack_50;
    fVar9 = auVar1._0_4_ - *(float *)(lVar2 + 600 + lVar6);
    fVar7 = fStack_50 * fStack_50 + fVar10 * fVar10 + fVar8 * fVar8;
    auVar1 = vshufps_avx(auVar1,auVar1,0xaa);
    fVar3 = auVar1._0_4_ - *(float *)(lVar2 + 0x260 + lVar6);
    if (fVar7 != fVar11) {
      fVar10 = -((DAT_1402d2654 / SQRT(fVar7)) * SQRT(fVar3 * fVar3 + fVar9 * fVar9)) + fVar10;
      if (fVar11 <= fVar10) {
        return uVar5;
      }
      fVar10 = DAT_1402d2e94 / fVar10;
      *(float *)*param_2 = -(fVar10 * fVar8) + *(float *)*param_2;
      *(float *)(*param_2 + 8) = -(fVar10 * fStack_50) + *(float *)(*param_2 + 8);
      return uVar5;
    }
  }
  return 0xffffffff;
}

