/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140118ab0; RVA 0x118ab0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined4 FUN_140118ab0(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    return *(undefined4 *)(*(longlong *)(param_1 + 0x1b8) + 0x1848);
  }
  if (*(char *)(param_1 + 0x42b) == '\x01') {
    if (*(longlong *)(param_1 + 0x360) != 0) {
      return *(undefined4 *)(*(longlong *)(param_1 + 0x360) + 0x468);
    }
    if (*(longlong *)(param_1 + 0x370) != 0) {
      return *(undefined4 *)(*(longlong *)(param_1 + 0x370) + 0x288);
    }
  }
  else if ((*(char *)(param_1 + 0x42b) == '\x02') && (*(longlong *)(param_1 + 0x368) != 0)) {
    return *(undefined4 *)(*(longlong *)(param_1 + 0x368) + 0x2c8);
  }
  return 0;
}

