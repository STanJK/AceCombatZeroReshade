/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140118b90; RVA 0x118b90
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_140118b90(longlong param_1)

{
  uint *puVar1;
  undefined1 auVar2 [16];
  byte bVar3;
  undefined1 uVar4;
  longlong lVar5;
  undefined1 auVar6 [16];
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  undefined1 local_e8 [16];
  undefined1 local_d8 [16];
  undefined1 local_c8 [8];
  float fStack_c0;
  float fStack_bc;
  undefined1 local_b8 [8];
  float fStack_b0;
  float fStack_ac;
  
  bVar3 = *(byte *)(param_1 + 0x236);
  if (((bVar3 != 0) && (bVar3 != 0xff)) && (*(byte *)(param_1 + 0x237) != 0xff)) {
    lVar9 = (ulonglong)*(byte *)(param_1 + 0x237) * 0x520;
    lVar5 = *(longlong *)
             (*(longlong *)(**(longlong **)(param_1 + 0x180) + (ulonglong)bVar3 * 8) + 0x110);
    if ((((byte)*(undefined4 *)(lVar5 + 0x1f0 + lVar9) & 3) == 3) &&
       (((*(longlong *)(lVar5 + 0x360 + lVar9) != 0 || (*(longlong *)(lVar5 + 0x1b8 + lVar9) != 0))
        || (*(longlong *)(lVar5 + 0x1c0 + lVar9) != 0)))) {
      if (*(longlong *)(param_1 + 0x1b8) == 0) {
        if (*(longlong *)(param_1 + 0x1c0) == 0) {
          if (*(longlong *)(param_1 + 0x360) == 0) {
            return 0;
          }
          if (*(longlong *)(param_1 + 0x1a0) == 0) {
            return 0;
          }
          plVar7 = *(longlong **)(*(longlong *)(param_1 + 0x1a0) + 0x28);
        }
        else {
          plVar7 = *(longlong **)(*(longlong *)(param_1 + 0x1c0) + 0x30);
        }
        if (plVar7 == (longlong *)0x0) {
          return 0;
        }
        lVar8 = *plVar7;
      }
      else {
        lVar8 = *(longlong *)(*(longlong *)(param_1 + 0x1b8) + 0x1fb8);
      }
      if (lVar8 != 0) {
        auVar2 = *(undefined1 (*) [16])(lVar5 + 600 + lVar9);
        fVar18 = auVar2._0_4_ - *(float *)(param_1 + 600);
        local_e8 = ZEXT816(0);
        local_d8 = ZEXT816(0);
        auVar6 = vshufps_avx(auVar2,auVar2,0x55);
        fVar24 = auVar6._0_4_ - *(float *)(param_1 + 0x25c);
        auVar6 = vshufps_avx(auVar2,auVar2,0xaa);
        fVar13 = auVar6._0_4_ - *(float *)(param_1 + 0x260);
        auVar2 = vshufps_avx(auVar2,auVar2,0xff);
        fVar12 = auVar2._0_4_ - *(float *)(param_1 + 0x264);
        fVar10 = SQRT(fVar12 * fVar12 + fVar13 * fVar13 + fVar24 * fVar24 + fVar18 * fVar18);
        if ((*(float *)(lVar8 + 0x10) * DAT_1402d1e40 <= fVar10 * DAT_1402d2a78) &&
           (fVar10 * DAT_1402d2a78 <= DAT_1402d2424)) {
          _local_c8 = local_e8;
          _local_b8 = local_d8;
          FUN_140202920(local_e8,param_1 + 0x268);
          fVar22 = fStack_ac - fStack_bc;
          fVar21 = fStack_b0 - fStack_c0;
          fVar20 = (float)local_b8._4_4_ - (float)local_c8._4_4_;
          fVar19 = (float)local_b8._0_4_ - (float)local_c8._0_4_;
          fVar23 = 0.0;
          if (fVar10 != 0.0) {
            fVar10 = DAT_1402d22d0 / fVar10;
            fVar18 = fVar10 * fVar18;
            fVar24 = fVar10 * fVar24;
            fVar13 = fVar10 * fVar13;
            fVar12 = fVar10 * fVar12;
          }
          fVar10 = SQRT(fVar22 * fVar22 + fVar21 * fVar21 + fVar20 * fVar20 + fVar19 * fVar19);
          if (fVar10 != 0.0) {
            fVar10 = DAT_1402d22d0 / fVar10;
            fVar19 = fVar10 * fVar19;
            fVar20 = fVar10 * fVar20;
            fVar21 = fVar10 * fVar21;
            fVar22 = fVar10 * fVar22;
          }
          if (0.0 <= fVar12 * fVar22 + fVar13 * fVar21 + fVar24 * fVar20 + fVar19 * fVar18) {
            local_e8 = ZEXT416(0);
            local_d8 = ZEXT816(0);
            _local_b8 = ZEXT816(0);
            fVar14 = DAT_1402d22d0;
            _local_c8 = local_e8;
            FUN_140202920(local_e8,lVar5 + 0x268 + lVar9);
            fVar17 = fStack_ac - fStack_bc;
            fVar16 = fStack_b0 - fStack_c0;
            fVar15 = (float)local_b8._4_4_ - (float)local_c8._4_4_;
            fVar10 = (float)local_b8._0_4_ - (float)local_c8._0_4_;
            fVar11 = SQRT(fVar17 * fVar17 + fVar16 * fVar16 + fVar15 * fVar15 + fVar10 * fVar10);
            fVar12 = fVar17;
            fVar13 = fVar16;
            fVar24 = fVar15;
            fVar18 = fVar10;
            if (fVar11 != fVar23) {
              fVar12 = fVar14 / fVar11;
              fVar18 = fVar12 * fVar10;
              fVar24 = fVar12 * fVar15;
              fVar13 = fVar12 * fVar16;
              fVar12 = fVar12 * fVar17;
            }
            if (DAT_1402d22a8 <=
                fVar22 * fVar12 + fVar21 * fVar13 + fVar20 * fVar24 + fVar19 * fVar18) {
              *(uint *)(param_1 + 0x1fc) = *(uint *)(param_1 + 0x1fc) | 0x1000;
              puVar1 = (uint *)(lVar5 + 0x1fc + lVar9);
              *puVar1 = *puVar1 | 0x2000;
              uVar4 = *(undefined1 *)(param_1 + 0x235);
              *(undefined1 *)(lVar5 + 0x244 + lVar9) = *(undefined1 *)(param_1 + 0x234);
              *(undefined1 *)(lVar5 + 0x245 + lVar9) = uVar4;
              return 1;
            }
            fStack_ac = fStack_ac + fStack_bc;
            fStack_b0 = fStack_b0 + fStack_c0;
            fVar18 = (float)local_b8._4_4_ + (float)local_c8._4_4_;
            fVar24 = (float)local_b8._0_4_ + (float)local_c8._0_4_;
            fVar13 = SQRT(fStack_ac * fStack_ac +
                          fStack_b0 * fStack_b0 + fVar18 * fVar18 + fVar24 * fVar24);
            if (fVar13 != fVar23) {
              fVar13 = fVar14 / fVar13;
              fVar24 = fVar13 * fVar24;
              fVar18 = fVar13 * fVar18;
              fStack_b0 = fVar13 * fStack_b0;
              fStack_ac = fVar13 * fStack_ac;
            }
            if (DAT_1402d22a8 <=
                fVar22 * fStack_ac + fVar21 * fStack_b0 + fVar20 * fVar18 + fVar19 * fVar24) {
              *(uint *)(param_1 + 0x1fc) = *(uint *)(param_1 + 0x1fc) | 0x20;
              return 1;
            }
            if (fVar11 != fVar23) {
              fVar14 = fVar14 / fVar11;
              fVar10 = fVar14 * fVar10;
              fVar15 = fVar14 * fVar15;
              fVar16 = fVar14 * fVar16;
              fVar17 = fVar14 * fVar17;
            }
            if (DAT_1402d22a8 <=
                fVar22 * fVar17 + fVar21 * fVar16 + fVar20 * fVar15 + fVar19 * fVar10) {
              *(uint *)(param_1 + 0x1fc) = *(uint *)(param_1 + 0x1fc) | 0x40;
              return 1;
            }
          }
        }
      }
    }
  }
  return 0;
}

