/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140101050; RVA 0x101050
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140101050(longlong param_1)

{
  uint uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 uVar7;
  float fVar8;
  undefined4 uVar9;
  undefined1 auVar10 [64];
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffbfff;
  uVar1 = *(uint *)(param_1 + 0x3a8);
  lVar2 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar3 = *(longlong *)(lVar2 + 0x1b8);
  *(undefined1 *)(param_1 + 0x3e6) = 4;
  *(uint *)(param_1 + 0x3a8) = uVar1 | 0x20;
  if (*(int *)(param_1 + 0x378) < (int)((uint)*(byte *)(param_1 + 0x3d1) * 5)) {
    if ((uVar1 & 4) == 0) {
      *(int *)(param_1 + 0x378) = *(int *)(param_1 + 0x378) + 1;
    }
    if (((*(float *)(param_1 + 0x354) < *(float *)(lVar2 + 0x260)) ||
        (*(float *)(lVar2 + 0x260) < *(float *)(param_1 + 0x34c) ||
         (*(float *)(param_1 + 0x350) < *(float *)(lVar2 + 600) ||
         *(float *)(lVar2 + 600) < *(float *)(param_1 + 0x348)))) &&
       ((*(byte *)(param_1 + 0x3d0) & 1) != 0)) {
      *(byte *)(lVar3 + 0x1da7) = *(byte *)(lVar3 + 0x1da7) | 1;
      *(undefined4 *)(lVar3 + 0x1d78) = 0xbe800000;
      *(undefined4 *)(lVar3 + 0x1d7c) = 0x3f800000;
      *(byte *)(lVar3 + 0x1863) = *(byte *)(lVar3 + 0x1863) | 1;
      *(undefined4 *)(lVar3 + 0x185c) = 0;
      if ((*(uint *)(lVar3 + 0x2058) >> 0xd & 1) == 0) {
        *(uint *)(lVar3 + 0x2058) = *(uint *)(lVar3 + 0x2058) | 0x2000;
        *(undefined1 *)(lVar3 + 0x2095) = *(undefined1 *)(lVar3 + 0x2094);
      }
      *(undefined1 *)(lVar3 + 0x2096) = 1;
    }
    auVar10 = ZEXT464((uint)DAT_1402d22d0);
    auVar5 = vcvtdq2ps_avx(ZEXT416(*(uint *)(param_1 + 0x378)));
    lVar4 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
    auVar6 = vcvtdq2ps_avx(ZEXT116(*(byte *)(param_1 + 0x3d1)));
    uVar9 = *(undefined4 *)(lVar4 + 0x264);
    fVar12 = (auVar5._0_4_ / auVar6._0_4_ + DAT_1402d2458) * DAT_1402d291c;
    fVar15 = *(float *)(lVar4 + 0x25c) + fVar12;
    fVar12 = fVar12 * DAT_1402d2134;
    fVar11 = fVar12 + *(float *)(lVar4 + 600);
    fVar12 = fVar12 + *(float *)(lVar4 + 0x260);
    fVar16 = *(float *)(lVar4 + 600) - fVar11;
    fVar13 = *(float *)(lVar4 + 0x25c) - fVar15;
    fVar17 = *(float *)(lVar4 + 0x260) - fVar12;
    fVar8 = SQRT(fVar17 * fVar17 + fVar13 * fVar13 + fVar16 * fVar16);
    fVar14 = DAT_1402d22d0 / fVar8;
    FUN_1401fbec0(fVar8);
    FUN_140014960(param_1 + 0xe0,lVar3 + 0x10b0);
    auVar5 = vmaxss_avx(ZEXT416((uint)(fVar14 * fVar13)),ZEXT416(DAT_1402d2d64));
    auVar5 = vminss_avx(auVar5,auVar10._0_16_);
    *(float *)(param_1 + 0x110) = fVar11;
    *(float *)(param_1 + 0x114) = fVar15;
    *(float *)(param_1 + 0x118) = fVar12;
    *(undefined4 *)(param_1 + 0x11c) = uVar9;
    uVar9 = FUN_140272150(auVar5._0_8_);
    *(undefined4 *)(param_1 + 0x120) = uVar9;
    uVar9 = FUN_140272370(CONCAT44(_UNK_1402d3774,(uint)(fVar16 * fVar14) ^ DAT_1402d3770),
                          CONCAT44(_UNK_1402d3774,(uint)(fVar14 * fVar17) ^ DAT_1402d3770));
    *(undefined8 *)(param_1 + 0x128) = 0;
    *(undefined4 *)(param_1 + 0x124) = uVar9;
    FUN_1401fbec0(param_1 + 0xe0);
    if ((*(byte *)(lVar2 + 0x1f0) & 2) == 0) {
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x48;
    }
    if (*(char *)(param_1 + 0x3da) != '\x01') {
      if ((int)((uint)*(byte *)(param_1 + 0x3d1) * 4) <= *(int *)(param_1 + 0x378)) {
        *(float *)(param_1 + 0x3a0) =
             (float)*(int *)(param_1 + 0x378) / (float)*(byte *)(param_1 + 0x3d1) - DAT_1402d2458;
      }
    }
  }
  else {
    uVar7 = 5;
    if (*(char *)(param_1 + 0x3da) != '\x01') {
      uVar7 = 0;
    }
    *(undefined1 *)(param_1 + 0x3cc) = uVar7;
  }
  return;
}

