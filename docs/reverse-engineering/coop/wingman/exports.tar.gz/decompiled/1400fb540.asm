0x1400fb540  MOV RAX,RSP
0x1400fb543  PUSH RDI
0x1400fb544  PUSH R12
0x1400fb546  SUB RSP,0xf8
0x1400fb54d  AND dword ptr [RCX + 0x3a8],0xffffbfff
0x1400fb557  MOV RDI,RCX
0x1400fb55a  MOV qword ptr [RAX + 0x10],RBX
0x1400fb55e  MOV qword ptr [RAX + 0x18],RBP
0x1400fb562  MOV qword ptr [RAX + -0x18],RSI
0x1400fb566  MOV qword ptr [RAX + -0x20],R14
0x1400fb56a  MOV R14,RDX
0x1400fb56d  MOV qword ptr [RAX + -0x28],R15
0x1400fb571  MOV byte ptr [RCX + 0x3cc],0x3
0x1400fb578  MOV RCX,qword ptr [RCX + 0x340]
0x1400fb57f  VMOVAPS xmmword ptr [RAX + -0x38],XMM6
0x1400fb584  VMOVAPS xmmword ptr [RAX + -0x48],XMM7
0x1400fb589  TEST RCX,RCX
0x1400fb58c  JZ 0x1400fb595
0x1400fb58e  XOR EDX,EDX
0x1400fb590  CALL 0x1400d1560
0x1400fb595  MOV RCX,qword ptr [RDI + 0x2f8]
0x1400fb59c  MOV R9,qword ptr [RCX]
0x1400fb59f  MOV RAX,qword ptr [R9]
0x1400fb5a2  MOV RSI,qword ptr [RAX + 0x110]
0x1400fb5a9  MOV EAX,dword ptr [RDI + 0x3a8]
0x1400fb5af  MOV RDX,qword ptr [RSI + 0x1b8]
0x1400fb5b6  TEST AL,0x8
0x1400fb5b8  JZ 0x1400fb5de
0x1400fb5ba  AND EAX,0xfffffff7
0x1400fb5bd  MOV dword ptr [RDI + 0x3a8],EAX
0x1400fb5c3  MOV RAX,qword ptr [RCX]
0x1400fb5c6  MOV RCX,qword ptr [RAX]
0x1400fb5c9  MOV RAX,qword ptr [RCX + 0x110]
0x1400fb5d0  MOV RCX,qword ptr [RAX + 0x1b8]
0x1400fb5d7  AND dword ptr [RCX + 0x2058],0xffffffef
0x1400fb5de  MOV R8D,dword ptr [RDX + 0x2058]
0x1400fb5e5  AND R8D,0xffffffef
0x1400fb5e9  BT R8D,0xd
0x1400fb5ee  JNC 0x1400fb602
0x1400fb5f0  MOVZX EAX,byte ptr [RDX + 0x2095]
0x1400fb5f7  BTR R8D,0xd
0x1400fb5fc  MOV byte ptr [RDX + 0x2096],AL
0x1400fb602  XOR R12D,R12D
0x1400fb605  AND R8D,0xfdffffdf
0x1400fb60c  MOV qword ptr [RDX + 0x1d78],R12
0x1400fb613  AND byte ptr [RDX + 0x1da7],0xfe
0x1400fb61a  AND byte ptr [RDX + 0x1863],0xfe
0x1400fb621  MOV dword ptr [RDX + 0x185c],R12D
0x1400fb628  MOV byte ptr [RDX + 0x1dad],R12B
0x1400fb62f  MOV dword ptr [RDX + 0x2058],R8D
0x1400fb636  MOV RAX,qword ptr [RDX + 0x2040]
0x1400fb63d  TEST RAX,RAX
0x1400fb640  JZ 0x1400fb673
0x1400fb642  MOVZX ECX,byte ptr [RDX + 0x20a1]
0x1400fb649  MOV RAX,qword ptr [RAX]
0x1400fb64c  MOV RCX,qword ptr [RAX + RCX*0x8]
0x1400fb650  CMP dword ptr [RCX + 0x118],0x1
0x1400fb657  JLE 0x1400fb673
0x1400fb659  BTR R8D,0xc
0x1400fb65e  MOV EAX,0xfffe
0x1400fb663  MOV dword ptr [RDX + 0x2058],R8D
0x1400fb66a  AND word ptr [RDX + 0x1c20],AX
0x1400fb671  JMP 0x1400fb687
0x1400fb673  BTS R8D,0xc
0x1400fb678  MOV dword ptr [RDX + 0x2058],R8D
0x1400fb67f  OR word ptr [RDX + 0x1c20],0x1
0x1400fb687  MOV dword ptr [RDX + 0x164c],R12D
0x1400fb68e  MOV RAX,qword ptr [RDI + 0x2f8]
0x1400fb695  AND byte ptr [RAX + 0x69],0xfb
0x1400fb699  VMOVUPS XMM6,xmmword ptr [RDI + 0xb0]
0x1400fb6a1  VMOVUPS XMM7,xmmword ptr [RDI + 0xc0]
0x1400fb6a9  VMOVSS dword ptr [RDX + 0x10e0],XMM6
0x1400fb6b1  VSHUFPS XMM2,XMM7,XMM7,0x55
0x1400fb6b6  VSHUFPS XMM1,XMM7,XMM7,0xaa
0x1400fb6bb  VSHUFPS XMM0,XMM7,XMM7,0xff
0x1400fb6c0  VSHUFPS XMM5,XMM6,XMM6,0x55
0x1400fb6c5  VMOVSS dword ptr [RDX + 0x10e4],XMM5
0x1400fb6cd  VSHUFPS XMM4,XMM6,XMM6,0xaa
0x1400fb6d2  VMOVSS dword ptr [RDX + 0x10e8],XMM4
0x1400fb6da  VSHUFPS XMM3,XMM6,XMM6,0xff
0x1400fb6df  VMOVSS dword ptr [RDX + 0x10ec],XMM3
0x1400fb6e7  VMOVSS dword ptr [RDX + 0x10f0],XMM7
0x1400fb6ef  VMOVSS dword ptr [RDX + 0x10f4],XMM2
0x1400fb6f7  VMOVSS dword ptr [RDX + 0x10f8],XMM1
0x1400fb6ff  VMOVSS dword ptr [RDX + 0x10fc],XMM0
0x1400fb707  MOV qword ptr [RDX + 0x12a0],R12
0x1400fb70e  MOV dword ptr [RDX + 0x12a8],R12D
0x1400fb715  MOV dword ptr [RDX + 0x12ac],0x3f800000
0x1400fb71f  VMOVSS dword ptr [RDX + 0x12b0],XMM7
0x1400fb727  VMOVSS dword ptr [RDX + 0x12b4],XMM2
0x1400fb72f  VMOVSS dword ptr [RDX + 0x12b8],XMM1
0x1400fb737  VMOVSS dword ptr [RDX + 0x12bc],XMM0
0x1400fb73f  VMOVSS dword ptr [RDX + 0x70],XMM6
0x1400fb744  VMOVSS dword ptr [RDX + 0x74],XMM5
0x1400fb749  VMOVSS dword ptr [RDX + 0x78],XMM4
0x1400fb74e  VMOVSS dword ptr [RDX + 0x7c],XMM3
0x1400fb753  VMOVSS dword ptr [RDX + 0x80],XMM7
0x1400fb75b  VMOVSS dword ptr [RDX + 0x84],XMM2
0x1400fb763  VMOVSS dword ptr [RDX + 0x88],XMM1
0x1400fb76b  VMOVSS dword ptr [RDX + 0x8c],XMM0
0x1400fb773  VMOVSS dword ptr [RDX + 0x17f8],XMM6
0x1400fb77b  VMOVSS dword ptr [RDX + 0x17fc],XMM5
0x1400fb783  VMOVSS dword ptr [RDX + 0x1800],XMM4
0x1400fb78b  VMOVSS dword ptr [RDX + 0x1804],XMM3
0x1400fb793  VMOVSS dword ptr [RDX + 0x1808],XMM7
0x1400fb79b  VMOVSS dword ptr [RDX + 0x180c],XMM2
0x1400fb7a3  VMOVSS dword ptr [RDX + 0x1810],XMM1
0x1400fb7ab  VMOVSS dword ptr [RDX + 0x1814],XMM0
0x1400fb7b3  MOV EAX,dword ptr [RDI + 0xb0]
0x1400fb7b9  MOV dword ptr [RSI + 0x258],EAX
0x1400fb7bf  MOV EAX,dword ptr [RDI + 0xb4]
0x1400fb7c5  MOV dword ptr [RSI + 0x25c],EAX
0x1400fb7cb  MOV EAX,dword ptr [RDI + 0xb8]
0x1400fb7d1  MOV dword ptr [RSI + 0x260],EAX
0x1400fb7d7  MOV EAX,dword ptr [RDI + 0xbc]
0x1400fb7dd  MOV dword ptr [RSI + 0x264],EAX
0x1400fb7e3  MOV EAX,dword ptr [RDI + 0xc0]
0x1400fb7e9  MOV dword ptr [RSI + 0x268],EAX
0x1400fb7ef  MOV EAX,dword ptr [RDI + 0xc4]
0x1400fb7f5  MOV dword ptr [RSI + 0x26c],EAX
0x1400fb7fb  MOV EAX,dword ptr [RDI + 0xc8]
0x1400fb801  MOV dword ptr [RSI + 0x270],EAX
0x1400fb807  MOV EAX,dword ptr [RDI + 0xcc]
0x1400fb80d  MOV dword ptr [RSI + 0x274],EAX
0x1400fb813  MOV EAX,dword ptr [RSI + 0x1f0]
0x1400fb819  BTR EAX,0x13
0x1400fb81d  OR EAX,0x3
0x1400fb820  MOV dword ptr [RSI + 0x1f0],EAX
0x1400fb826  MOVZX EAX,byte ptr [RDI + 0x3e2]
0x1400fb82d  MOV word ptr [RSI + 0x428],AX
0x1400fb834  MOV RAX,qword ptr [R9]
0x1400fb837  CMP dword ptr [RAX + 0x118],0x1
0x1400fb83e  JLE 0x1400fba7a
0x1400fb844  MOV RAX,qword ptr [RDI + 0x2f8]
0x1400fb84b  MOV RCX,qword ptr [RAX]
0x1400fb84e  MOV RDX,qword ptr [RCX]
0x1400fb851  MOV RBP,qword ptr [RDX + 0x110]
0x1400fb858  LEA RAX,[RBP + 0x520]
0x1400fb85f  TEST RAX,RAX
0x1400fb862  JZ 0x1400fba7a
0x1400fb868  MOV RAX,qword ptr [RDX + 0x130]
0x1400fb86f  LEA RDX,[RDI + 0xc0]
0x1400fb876  VMOVAPS xmmword ptr [RSP + 0xb0],XMM8
0x1400fb87f  VXORPS XMM0,XMM0,XMM0
0x1400fb883  VXORPS XMM1,XMM1,XMM1
0x1400fb887  MOV RCX,qword ptr [RAX + 0x10]
0x1400fb88b  VMOVAPS xmmword ptr [RSP + 0xa0],XMM9
0x1400fb894  VMOVAPS xmmword ptr [RSP + 0x90],XMM10
0x1400fb89d  VMOVUPS xmmword ptr [RSP + 0x50],XMM0
0x1400fb8a3  MOV RBX,qword ptr [RCX + 0x10]
0x1400fb8a7  LEA RCX,[RSP + 0x50]
0x1400fb8ac  VMOVUPS xmmword ptr [RSP + 0x60],XMM1
0x1400fb8b2  VMOVUPS xmmword ptr [RSP + 0x70],XMM0
0x1400fb8b8  VMOVUPS xmmword ptr [RSP + 0x80],XMM1
0x1400fb8c1  CALL 0x140202920
0x1400fb8c6  VMOVSS XMM7,dword ptr [RBX + 0x4]
0x1400fb8cb  VMOVSS XMM9,dword ptr [RBX]
0x1400fb8cf  VMOVSS XMM10,dword ptr [RBX + 0x8]
0x1400fb8d4  VMOVUPS XMM5,xmmword ptr [RSP + 0x50]
0x1400fb8da  VMOVUPS XMM8,xmmword ptr [RSP + 0x70]
0x1400fb8e0  VMOVSS XMM0,dword ptr [RSP + 0x84]
0x1400fb8e9  VADDSS XMM4,XMM0,dword ptr [RDI + 0xb4]
0x1400fb8f1  VMULSS XMM2,XMM7,dword ptr [RSP + 0x60]
0x1400fb8f7  VMOVSS XMM1,dword ptr [RSP + 0x88]
0x1400fb900  VADDSS XMM6,XMM1,dword ptr [RDI + 0xb8]
0x1400fb908  VMOVSS XMM0,dword ptr [RSP + 0x80]
0x1400fb911  VADDSS XMM1,XMM0,dword ptr [RDI + 0xb0]
0x1400fb919  VMULSS XMM3,XMM7,dword ptr [RSP + 0x64]
0x1400fb91f  VFMADD231SS XMM2,XMM9,XMM5
0x1400fb924  VFMADD231SS XMM2,XMM10,XMM8
0x1400fb929  VADDSS XMM2,XMM2,XMM1
0x1400fb92d  VMOVSS dword ptr [RBP + 0x778],XMM2
0x1400fb935  VMULSS XMM2,XMM7,dword ptr [RSP + 0x68]
0x1400fb93b  VSHUFPS XMM1,XMM5,XMM5,0x55
0x1400fb940  VFMADD231SS XMM3,XMM9,XMM1
0x1400fb945  VSHUFPS XMM1,XMM8,XMM8,0x55
0x1400fb94b  VFMADD231SS XMM3,XMM10,XMM1
0x1400fb950  VADDSS XMM1,XMM3,XMM4
0x1400fb954  VMOVSS dword ptr [RBP + 0x77c],XMM1
0x1400fb95c  VSHUFPS XMM1,XMM5,XMM5,0xaa
0x1400fb961  VFMADD231SS XMM2,XMM9,XMM1
0x1400fb966  VSHUFPS XMM1,XMM8,XMM8,0xaa
0x1400fb96c  VFMADD231SS XMM2,XMM10,XMM1
0x1400fb971  VADDSS XMM1,XMM2,XMM6
0x1400fb975  VMULSS XMM2,XMM7,dword ptr [RSP + 0x6c]
0x1400fb97b  VMOVSS dword ptr [RBP + 0x780],XMM1
0x1400fb983  VSHUFPS XMM5,XMM5,XMM5,0xff
0x1400fb988  VFMADD231SS XMM2,XMM9,XMM5
0x1400fb98d  VSHUFPS XMM8,XMM8,XMM8,0xff
0x1400fb993  VFMADD231SS XMM2,XMM10,XMM8
0x1400fb998  VADDSS XMM1,XMM2,dword ptr [RSP + 0x8c]
0x1400fb9a1  VMOVSS dword ptr [RBP + 0x784],XMM1
0x1400fb9a9  VMOVSS XMM0,dword ptr [RBX + 0xc]
0x1400fb9ae  VMOVSS XMM1,dword ptr [RBX + 0x10]
0x1400fb9b3  VMOVSS dword ptr [RSP + 0x40],XMM0
0x1400fb9b9  VMOVSS XMM0,dword ptr [RBX + 0x14]
0x1400fb9be  VMOVSS dword ptr [RSP + 0x44],XMM1
0x1400fb9c4  VXORPS XMM1,XMM1,XMM1
0x1400fb9c8  LEA RCX,[RBP + 0x788]
0x1400fb9cf  LEA R8,[RSP + 0x40]
0x1400fb9d4  LEA RDX,[RDI + 0xc0]
0x1400fb9db  VMOVSS dword ptr [RSP + 0x48],XMM0
0x1400fb9e1  VMOVSS dword ptr [RSP + 0x4c],XMM1
0x1400fb9e7  CALL 0x140203050
0x1400fb9ec  MOV RBX,qword ptr [RBP + 0x880]
0x1400fb9f3  VMOVSS XMM0,dword ptr [0x1402d2140]
0x1400fb9fb  VXORPS XMM8,XMM8,XMM8
0x1400fba00  VXORPS XMM7,XMM7,XMM7
0x1400fba04  MOVZX EAX,byte ptr [RBX + 0x49c]
0x1400fba0b  VCVTSI2SS XMM8,XMM8,EAX
0x1400fba0f  MOVZX EAX,word ptr [RBX + 0x26c]
0x1400fba16  VDIVSS XMM0,XMM0,XMM8
0x1400fba1b  VCVTSI2SS XMM7,XMM7,EAX
0x1400fba1f  VMULSS XMM6,XMM0,XMM7
0x1400fba23  VMOVSS XMM0,dword ptr [RBX + 0x3dc]
0x1400fba2b  CALL 0x140128d90
0x1400fba30  VDIVSS XMM1,XMM0,dword ptr [RBX + 0x470]
0x1400fba38  VMOVSS XMM0,dword ptr [0x1402d235c]
0x1400fba40  VSQRTSS XMM2,XMM1,XMM1
0x1400fba44  VMOVAPS XMM3,XMM6
0x1400fba48  VFNMADD231SS XMM3,XMM6,XMM2
0x1400fba4d  VMOVAPS XMM10,xmmword ptr [RSP + 0x90]
0x1400fba56  VMOVAPS XMM9,xmmword ptr [RSP + 0xa0]
0x1400fba5f  VDIVSS XMM0,XMM0,XMM8
0x1400fba64  VMOVAPS XMM8,xmmword ptr [RSP + 0xb0]
0x1400fba6d  VFMADD231SS XMM3,XMM7,XMM0
0x1400fba72  VMOVSS dword ptr [RBX + 0x468],XMM3
0x1400fba7a  MOV RBX,qword ptr [RSI + 0x1b8]
0x1400fba81  MOV RCX,RBX
0x1400fba84  MOV byte ptr [RBX + 0xc38],0x3
0x1400fba8b  CALL 0x14010bbb0
0x1400fba90  VMOVAPS XMM7,xmmword ptr [RSP + 0xc0]
0x1400fba99  VMOVAPS XMM6,xmmword ptr [RSP + 0xd0]
0x1400fbaa2  MOV R15,qword ptr [RSP + 0xe0]
0x1400fbaaa  MOV EBP,0x1
0x1400fbaaf  MOV byte ptr [RBX + 0xc38],R12B
0x1400fbab6  MOV qword ptr [RBX + 0xccc],R12
0x1400fbabd  MOV qword ptr [RBX + 0xcd4],R12
0x1400fbac4  MOV dword ptr [RBX + 0xcdc],R12D
0x1400fbacb  MOV dword ptr [RBX + 0xce4],0x42480000
0x1400fbad5  MOV dword ptr [RBX + 0xce0],0x42480000
0x1400fbadf  AND byte ptr [RBX + 0x1677],0xfe
0x1400fbae6  AND byte ptr [RBX + 0x1676],0xfc
0x1400fbaed  AND byte ptr [RBX + 0x1863],0xfb
0x1400fbaf4  AND dword ptr [RBX + 0x2058],0xffffff7f
0x1400fbafe  MOV RBX,qword ptr [RDI + 0x2f8]
0x1400fbb05  MOV RBX,qword ptr [RBX]
0x1400fbb08  MOV RAX,qword ptr [RBX]
0x1400fbb0b  CMP dword ptr [RAX + 0x118],EBP
0x1400fbb11  JLE 0x1400fbb4d
0x1400fbb13  MOV ESI,0x520
0x1400fbb18  MOV RAX,qword ptr [RAX + 0x110]
0x1400fbb1f  MOV RCX,qword ptr [RAX + RSI*0x1 + 0x1c0]
0x1400fbb27  TEST RCX,RCX
0x1400fbb2a  JZ 0x1400fbb39
0x1400fbb2c  MOV RCX,qword ptr [RCX + 0x10]
0x1400fbb30  MOV RAX,qword ptr [RCX]
0x1400fbb33  CALL qword ptr [RAX + 0x1c8]
0x1400fbb39  MOV RAX,qword ptr [RBX]
0x1400fbb3c  INC EBP
0x1400fbb3e  ADD RSI,0x520
0x1400fbb45  CMP EBP,dword ptr [RAX + 0x118]
0x1400fbb4b  JL 0x1400fbb18
0x1400fbb4d  MOV RAX,qword ptr [R14]
0x1400fbb50  MOV RBP,qword ptr [RSP + 0x120]
0x1400fbb58  MOV ECX,dword ptr [RAX]
0x1400fbb5a  MOV dword ptr [RDI + 0x348],ECX
0x1400fbb60  MOV RAX,qword ptr [R14]
0x1400fbb63  MOV ECX,dword ptr [RAX + 0x8]
0x1400fbb66  MOV dword ptr [RDI + 0x34c],ECX
0x1400fbb6c  MOV RAX,qword ptr [R14]
0x1400fbb6f  MOV ECX,dword ptr [RAX + 0x4]
0x1400fbb72  MOV dword ptr [RDI + 0x350],ECX
0x1400fbb78  MOV RAX,qword ptr [R14]
0x1400fbb7b  MOV ECX,dword ptr [RAX + 0xc]
0x1400fbb7e  MOV dword ptr [RDI + 0x354],ECX
0x1400fbb84  MOV RCX,qword ptr [RDI + 0x340]
0x1400fbb8b  MOV EAX,dword ptr [RCX + 0xa8790]
0x1400fbb91  BT EAX,0x1d
0x1400fbb95  JNC 0x1400fbbad
0x1400fbb97  BTR EAX,0x1d
0x1400fbb9b  MOV dword ptr [RCX + 0xa8790],EAX
0x1400fbba1  ADD RCX,0x697b8
0x1400fbba8  CALL 0x1400c3910
0x1400fbbad  MOV RAX,qword ptr GS:[0x58]
0x1400fbbb6  MOV ECX,0x4
0x1400fbbbb  MOV RAX,qword ptr [RAX]
0x1400fbbbe  MOV EAX,dword ptr [RCX + RAX*0x1]
0x1400fbbc1  CMP dword ptr [0x1437dad18],EAX
0x1400fbbc7  JG 0x1400fbd52
0x1400fbbcd  MOVZX EAX,byte ptr [0x1437daeec]
0x1400fbbd4  LEA R14,[0x140000000]
0x1400fbbdb  SHL RAX,0x5
0x1400fbbdf  TEST byte ptr [0x14031f8b1],0x1
0x1400fbbe6  MOV dword ptr [RAX + R14*0x1 + 0x310a64],0x42fe0000
0x1400fbbf2  JNZ 0x1400fbcbd
0x1400fbbf8  MOVZX EAX,byte ptr [0x14031f8b0]
0x1400fbbff  MOVSX RBX,word ptr [0x1437daee4]
0x1400fbc07  LEA RCX,[RBX + RAX*0x4]
0x1400fbc0b  MOV EAX,dword ptr [RDI + 0x2c4]
0x1400fbc11  MOVSX RCX,byte ptr [RCX + R14*0x1 + 0x31f8a8]
0x1400fbc1a  MOV RCX,qword ptr [R14 + RCX*0x8 + 0x33bc00]
0x1400fbc22  MOV dword ptr [RCX + 0x4],EAX
0x1400fbc25  TEST byte ptr [0x14031f8b1],0x1
0x1400fbc2c  MOVSXD RSI,dword ptr [RDI + 0x2c8]
0x1400fbc33  JNZ 0x1400fbcbd
0x1400fbc39  LEA RAX,[RBX + RBX*0x2]
0x1400fbc3d  TEST ESI,ESI
0x1400fbc3f  JS 0x1400fbcbd
0x1400fbc41  CMP ESI,dword ptr [R14 + RAX*0x8 + 0x31f838]
0x1400fbc49  JGE 0x1400fbcbd
0x1400fbc4b  MOV R8,qword ptr [R14 + RAX*0x8 + 0x31f840]
0x1400fbc53  TEST R8,R8
0x1400fbc56  JZ 0x1400fbcbd
0x1400fbc58  MOVZX EAX,byte ptr [0x14031f8b0]
0x1400fbc5f  MOV RDX,RBX
0x1400fbc62  MOV R8D,dword ptr [R8 + RSI*0x4]
0x1400fbc66  MOV R9D,0x1770
0x1400fbc6c  MOV byte ptr [RSP + 0x38],0x1
0x1400fbc71  SHL RDX,0x8
0x1400fbc75  LEA RCX,[RBX + RAX*0x4]
0x1400fbc79  MOV dword ptr [RSP + 0x30],R12D
0x1400fbc7e  MOVSX RAX,byte ptr [RCX + R14*0x1 + 0x31f8a8]
0x1400fbc87  LEA RCX,[0x14031f438]
0x1400fbc8e  ADD RDX,RCX
0x1400fbc91  MOV qword ptr [RSP + 0x28],R12
0x1400fbc96  MOV dword ptr [RSP + 0x20],EAX
0x1400fbc9a  MOV RCX,qword ptr [R14 + RAX*0x8 + 0x33bc00]
0x1400fbca2  CALL 0x140186f20
0x1400fbca7  MOV dword ptr [R14 + RBX*0x4 + 0x31f898],ESI
0x1400fbcaf  MOV EAX,dword ptr [RDI + 0x2c8]
0x1400fbcb5  MOV dword ptr [R14 + RBX*0x4 + 0x31f898],EAX
0x1400fbcbd  MOV RCX,qword ptr [RDI + 0x320]
0x1400fbcc4  MOV R14,qword ptr [RSP + 0xe8]
0x1400fbccc  MOV RSI,qword ptr [RSP + 0xf0]
0x1400fbcd4  MOV RBX,qword ptr [RSP + 0x118]
0x1400fbcdc  TEST RCX,RCX
0x1400fbcdf  JZ 0x1400fbd19
0x1400fbce1  AND byte ptr [RCX + 0x2b],0xfd
0x1400fbce5  MOV RAX,qword ptr [RCX + 0x10]
0x1400fbce9  TEST RAX,RAX
0x1400fbcec  JZ 0x1400fbcf5
0x1400fbcee  AND dword ptr [RAX + 0x56c],0xfffffffe
0x1400fbcf5  MOV RAX,qword ptr [RCX + 0x18]
0x1400fbcf9  TEST RAX,RAX
0x1400fbcfc  JZ 0x1400fbd02
0x1400fbcfe  AND byte ptr [RAX + 0x23],0xfb
0x1400fbd02  MOV RAX,qword ptr [RDI + 0x320]
0x1400fbd09  MOV RCX,qword ptr [RAX + 0x10]
0x1400fbd0d  TEST RCX,RCX
0x1400fbd10  JZ 0x1400fbd19
0x1400fbd12  AND dword ptr [RCX + 0x40],0xfbffffff
0x1400fbd19  MOV RCX,qword ptr [RDI + 0x308]
0x1400fbd20  TEST RCX,RCX
0x1400fbd23  JZ 0x1400fbd2a
0x1400fbd25  CALL 0x1401a5f00
0x1400fbd2a  MOV RCX,qword ptr [RDI + 0x2f8]
0x1400fbd31  MOV dword ptr [RDI + 0x3a0],R12D
0x1400fbd38  CALL 0x140136130
0x1400fbd3d  OR dword ptr [RDI + 0x3a8],0x808000
0x1400fbd47  ADD RSP,0xf8
0x1400fbd4e  POP R12
0x1400fbd50  POP RDI
0x1400fbd51  RET
0x1400fbd52  LEA RCX,[0x1437dad18]
0x1400fbd59  CALL 0x14022d540
0x1400fbd5e  CMP dword ptr [0x1437dad18],-0x1
0x1400fbd65  JNZ 0x1400fbbcd
0x1400fbd6b  VMOVDQU XMM0,xmmword ptr [0x1402d3500]
0x1400fbd73  LEA RCX,[0x1437dad18]
0x1400fbd7a  MOV dword ptr [0x1437daef0],R12D
0x1400fbd81  VMOVDQU xmmword ptr [0x1437daee0],XMM0
0x1400fbd89  MOV byte ptr [0x1437daef4],R12B
0x1400fbd90  CALL 0x14022d4d4
0x1400fbd95  JMP 0x1400fbbcd
