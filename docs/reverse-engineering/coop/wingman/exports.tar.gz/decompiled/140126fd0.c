/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140126fd0; RVA 0x126fd0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140126fd0(float *param_1,longlong *param_2,byte param_3,char param_4,undefined8 param_5,
                  char param_6)

{
  char cVar1;
  float *pfVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined1 auVar5 [16];
  float fVar6;
  undefined1 auVar7 [16];
  short sVar8;
  ushort uVar9;
  uint uVar10;
  byte bVar11;
  longlong lVar12;
  longlong lVar13;
  ulonglong uVar14;
  float fVar15;
  float fVar16;
  undefined1 extraout_var [56];
  undefined1 auVar17 [64];
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined1 auVar22 [64];
  
  uVar14 = (ulonglong)param_3;
  if ((param_4 != '\0') && (((uint)param_1[0x2a] & 0x200) != 0)) {
    return;
  }
  if (param_2 == (longlong *)0x0) {
    return;
  }
  if ((((param_4 != '\0') || (param_6 != '\0')) && (((uint)param_1[0x2a] & 0x200) == 0)) &&
     (*(short *)(param_1 + 0x2b) != 0)) {
    if (param_3 != 0) {
      return;
    }
    sVar8 = *(short *)(param_1 + 0x2b) + -1;
    *(short *)(param_1 + 0x2b) = sVar8;
    if (sVar8 != 0) {
      return;
    }
  }
  if (*(char *)(uVar14 + *(longlong *)(param_1 + 0x1a)) == '\0') {
    return;
  }
  pfVar2 = (float *)*param_2;
  if ((*(byte *)((longlong)pfVar2 + 0x3d) & 0x20) != 0) {
    if (((uint)param_1[0x2a] & 0x4000) == 0) {
      return;
    }
    if (*(char *)(param_1 + 0x2e) == '\0') {
      return;
    }
    if (*(char *)(param_1 + 0x2e) == '\x01') {
      return;
    }
    *(byte *)((longlong)param_1 + 0xae) = *(byte *)((longlong)param_1 + 0xae) | 0x10;
  }
  fVar16 = DAT_1402d2edc;
  fVar21 = DAT_1402d2a54;
  bVar11 = *(byte *)((longlong)pfVar2 + 0x3d) & 0x10;
  uVar10 = (uint)param_1[0x2a] & 0x8000;
  if (uVar10 == 0) {
    if (bVar11 != 0) {
      return;
    }
  }
  else if (bVar11 == 0) {
    return;
  }
  cVar1 = *(char *)(pfVar2 + 0xe);
  auVar22 = ZEXT864(0);
  if (cVar1 == '\0') {
    if (*(char *)((longlong)pfVar2 + 0x39) != *(char *)(*(longlong *)(param_1 + 0x22) + 0x20)) {
      return;
    }
    if ((param_4 != '\0') && (*pfVar2 == 0.0)) {
      return;
    }
    if (*(int *)(*(longlong *)(*(longlong *)(param_1 + 0x22) + 0x10) + 0x38c) <
        (int)((float)*(byte *)((longlong)param_1 + 0xb3) * *pfVar2)) {
      return;
    }
LAB_14012730d:
    if (((uint)param_1[0x2a] & 0x8000) == 0) goto LAB_140127319;
  }
  else {
    if (cVar1 == '\x01') {
      if (uVar10 != 0) {
        return;
      }
      lVar4 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x1e) + 0x110);
      fVar15 = pfVar2[1] - *(float *)(lVar4 + 600);
      fVar18 = pfVar2[2] - *(float *)(lVar4 + 0x25c);
      fVar19 = pfVar2[3] - *(float *)(lVar4 + 0x260);
      fVar20 = DAT_1402d22d0 - *(float *)(lVar4 + 0x264);
      if (pfVar2[4] <
          SQRT(fVar19 * fVar19 + fVar18 * fVar18 + fVar15 * fVar15 +
               -(fVar20 * *(float *)(lVar4 + 0x264)) + fVar20)) {
        return;
      }
    }
    else {
      if (cVar1 != '\x02') {
        if (cVar1 != '\x03') {
          return;
        }
        if (uVar10 != 0) {
          return;
        }
        lVar4 = (*(undefined8 **)(param_1 + 0x1c))[3];
        if (lVar4 == 0) {
LAB_140127300:
          sVar8 = 0;
        }
        else {
          puVar3 = (undefined8 *)**(undefined8 **)(param_1 + 0x1c);
          if (puVar3 == (undefined8 *)0x0) {
            sVar8 = 0;
          }
          else {
            if (*(ushort *)*puVar3 <= *(ushort *)((longlong)pfVar2 + 0x36)) goto LAB_140127300;
            sVar8 = *(short *)(lVar4 + (ulonglong)*(ushort *)((longlong)pfVar2 + 0x36) * 2);
          }
        }
        if (sVar8 != *(short *)(pfVar2 + 0xd)) {
          return;
        }
        goto LAB_14012730d;
      }
      if (uVar10 != 0) {
        return;
      }
      lVar4 = *(longlong *)(*(longlong *)**(longlong **)(param_1 + 0x1e) + 0x110);
      if (*(byte *)((longlong)pfVar2 + 0x3a) == 0xff) {
        fVar15 = DAT_1402d2edc;
        fVar18 = DAT_1402d2a54;
        fVar19 = DAT_1402d2edc;
        fVar20 = DAT_1402d22d0;
      }
      else {
        lVar12 = ((longlong *)**(longlong **)(param_1 + 0x1e))[*(byte *)((longlong)pfVar2 + 0x3a)];
        if (*(byte *)((longlong)pfVar2 + 0x3b) == 0xff) {
          fVar15 = *(float *)(lVar12 + 8);
          fVar18 = *(float *)(lVar12 + 0xc);
          fVar19 = *(float *)(lVar12 + 0x10);
          fVar20 = *(float *)(lVar12 + 0x14);
        }
        else {
          lVar12 = *(longlong *)(lVar12 + 0x110);
          lVar13 = (ulonglong)*(byte *)((longlong)pfVar2 + 0x3b) * 0x520;
          if ((*(byte *)(lVar13 + 0x1f0 + lVar12) & 2) == 0) {
            return;
          }
          fVar15 = *(float *)(lVar13 + 600 + lVar12);
          fVar18 = *(float *)(lVar13 + 0x25c + lVar12);
          fVar19 = *(float *)(lVar13 + 0x260 + lVar12);
          fVar20 = *(float *)(lVar13 + 0x264 + lVar12);
        }
      }
      fVar15 = fVar15 - *(float *)(lVar4 + 600);
      fVar18 = fVar18 - *(float *)(lVar4 + 0x25c);
      fVar19 = fVar19 - *(float *)(lVar4 + 0x260);
      fVar20 = fVar20 - *(float *)(lVar4 + 0x264);
      if (pfVar2[4] < SQRT(fVar20 * fVar20 + fVar19 * fVar19 + fVar18 * fVar18 + fVar15 * fVar15)) {
        return;
      }
    }
LAB_140127319:
    cVar1 = *(char *)(uVar14 + *(longlong *)(param_1 + 0x1a));
    if (cVar1 != -1) {
      *(char *)(uVar14 + *(longlong *)(param_1 + 0x1a)) = cVar1 + -1;
    }
  }
  if (((param_4 != '\0') || (param_6 != '\0')) &&
     (uVar9 = (ushort)(int)((float)*(byte *)((longlong)param_1 + 0xb3) * *(float *)(*param_2 + 0x30)
                           ), *(ushort *)(param_1 + 0x2b) = uVar9, uVar9 < 2)) {
    *(undefined2 *)(param_1 + 0x2b) = 2;
  }
  *(byte *)(param_1 + 0x2c) = param_3;
  *(undefined1 *)((longlong)param_1 + 0xaf) = 1;
  *(byte *)((longlong)param_1 + 0xae) = *(byte *)((longlong)param_1 + 0xae) | 2;
  cVar1 = *(char *)(pfVar2 + 0xf);
  if (cVar1 == '\0') {
    fVar16 = pfVar2[6];
    fVar21 = pfVar2[5];
    param_1[2] = pfVar2[7];
    fVar15 = DAT_1402d1f38;
    param_1[1] = fVar16;
    *param_1 = fVar21;
    param_1[3] = 1.0;
    fVar16 = pfVar2[0xb];
    param_1[4] = fVar15 * pfVar2[10];
    param_1[5] = fVar15 * fVar16;
  }
  else if (cVar1 == '\x01') {
    fVar15 = fVar16;
    if (*(byte *)((longlong)pfVar2 + 0x3e) != 0xff) {
      lVar4 = *(longlong *)
               (**(longlong **)(param_1 + 0x1e) + (ulonglong)*(byte *)((longlong)pfVar2 + 0x3e) * 8)
      ;
      if (*(byte *)((longlong)pfVar2 + 0x3f) == 0xff) {
        fVar16 = *(float *)(lVar4 + 8);
        fVar21 = *(float *)(lVar4 + 0xc);
        fVar15 = *(float *)(lVar4 + 0x10);
      }
      else {
        lVar4 = *(longlong *)(lVar4 + 0x110);
        lVar12 = (ulonglong)*(byte *)((longlong)pfVar2 + 0x3f) * 0x520;
        fVar16 = *(float *)(lVar12 + 600 + lVar4);
        fVar21 = *(float *)(lVar12 + 0x25c + lVar4);
        fVar15 = *(float *)(lVar12 + 0x260 + lVar4);
      }
    }
    fVar18 = pfVar2[6];
    fVar19 = pfVar2[5];
    fVar20 = DAT_1402d1f38 * pfVar2[10];
    fVar6 = DAT_1402d1f38 * pfVar2[0xb];
    param_1[2] = fVar15 + pfVar2[7];
    *param_1 = fVar16 + fVar19;
    param_1[1] = fVar21 + fVar18;
    param_1[4] = fVar20;
    param_1[5] = fVar6;
  }
  else {
    if (cVar1 != '\x02') goto LAB_14012759f;
    if (*(byte *)((longlong)pfVar2 + 0x3e) == 0xff) {
      fVar15 = fVar16;
    }
    else {
      lVar4 = *(longlong *)
               (**(longlong **)(param_1 + 0x1e) + (ulonglong)*(byte *)((longlong)pfVar2 + 0x3e) * 8)
      ;
      if (*(byte *)((longlong)pfVar2 + 0x3f) == 0xff) {
        fVar15 = *(float *)(lVar4 + 8);
        fVar21 = *(float *)(lVar4 + 0xc);
        fVar16 = *(float *)(lVar4 + 0x10);
        auVar22 = ZEXT464(*(uint *)(lVar4 + 0x1c));
      }
      else {
        lVar4 = *(longlong *)(lVar4 + 0x110);
        lVar12 = (ulonglong)*(byte *)((longlong)pfVar2 + 0x3f) * 0x520;
        fVar15 = *(float *)(lVar12 + 600 + lVar4);
        fVar21 = *(float *)(lVar12 + 0x25c + lVar4);
        fVar16 = *(float *)(lVar12 + 0x260 + lVar4);
        auVar22 = ZEXT464(*(uint *)(lVar12 + 0x26c + lVar4));
      }
    }
    fVar20 = (float)((uint)pfVar2[9] ^ DAT_1402d3770);
    auVar7._4_12_ = auVar22._4_12_;
    auVar7._0_4_ = DAT_1402d1f38 * pfVar2[8] + auVar22._0_4_;
    auVar17._0_8_ = FUN_14026f3b0(auVar7._0_8_);
    auVar17._8_56_ = extraout_var;
    fVar18 = pfVar2[0xb];
    fVar19 = pfVar2[10] * DAT_1402d1f38;
    auVar7 = vpermilps_avx(auVar17._0_16_,1);
    param_1[1] = fVar21 + pfVar2[6];
    param_1[2] = auVar7._0_4_ * fVar20 + fVar16;
    *param_1 = (float)auVar17._0_8_ * fVar20 + fVar15;
    fVar16 = fVar18 * DAT_1402d1f38 + auVar22._0_4_;
    auVar5._4_12_ = auVar22._4_12_;
    auVar5._0_4_ = fVar16;
    auVar7 = vcmpss_avx(auVar5,ZEXT416(DAT_1402d2db4),1);
    auVar7 = vblendvps_avx(auVar5,ZEXT416((uint)(fVar16 + DAT_1402d249c)),auVar7);
    auVar5 = vcmpss_avx(ZEXT416(DAT_1402d2420),auVar7,1);
    auVar7 = vblendvps_avx(auVar7,ZEXT416((uint)(auVar7._0_4_ - DAT_1402d249c)),auVar5);
    param_1[5] = auVar7._0_4_;
    param_1[4] = fVar19;
  }
  param_1[6] = 0.0;
  param_1[7] = 0.0;
LAB_14012759f:
  param_1[3] = 1.0;
  if ((*(byte *)((longlong)pfVar2 + 0x3d) & 1) != 0) {
    fVar16 = (float)FUN_140079410(*(undefined8 *)(param_1 + 0x20),*param_1,param_1[2]);
    param_1[1] = fVar16 + pfVar2[6];
  }
  param_1[1] = param_1[0x24] + param_1[1];
  if ((*(byte *)((longlong)pfVar2 + 0x3d) & 8) == 0) {
    fVar16 = (float)((uint)param_1[0x2a] & 0xffffffef);
  }
  else {
    fVar16 = (float)((uint)param_1[0x2a] | 0x10);
  }
  param_1[0x2a] = fVar16;
  FUN_140126b00(param_1,*(longlong *)
                         (*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 8 + uVar14 * 0x10) +
                        0x40);
  return;
}

