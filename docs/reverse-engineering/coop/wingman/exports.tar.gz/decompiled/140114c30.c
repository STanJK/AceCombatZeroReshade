/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140114c30; RVA 0x114c30
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140114c30(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined1 uVar4;
  int iVar5;
  byte bVar6;
  short sVar7;
  ulonglong uVar8;
  longlong lVar9;
  longlong unaff_GS_OFFSET;
  
  FUN_140125300();
  FUN_1401c56d0();
  lVar9 = **(longlong **)(unaff_GS_OFFSET + 0x58);
  if ((*(int *)(lVar9 + 4) < DAT_1437daf04) && (FUN_14022d540(&DAT_1437daf04), DAT_1437daf04 == -1))
  {
    FUN_1401c93c0();
    _Init_thread_footer(&DAT_1437daf04);
  }
  FUN_1401cb010(&DAT_1437daf20,param_1 + 0x34c);
  FUN_1401c56d0();
  if ((*(int *)(lVar9 + 4) < DAT_1437daf04) && (FUN_14022d540(&DAT_1437daf04), DAT_1437daf04 == -1))
  {
    FUN_1401c93c0();
    _Init_thread_footer(&DAT_1437daf04);
  }
  FUN_1401cb010(&DAT_1437daf20,param_1 + 0x350);
  FUN_1401c56d0();
  if ((*(int *)(lVar9 + 4) < DAT_1437daf04) && (FUN_14022d540(&DAT_1437daf04), DAT_1437daf04 == -1))
  {
    FUN_1401c93c0();
    _Init_thread_footer(&DAT_1437daf04);
  }
  FUN_1401cb010(&DAT_1437daf20,param_1 + 0x348);
  plVar2 = *(longlong **)(param_1 + 0x1a0);
  *(undefined8 *)(param_1 + 0x34c) = 0;
  lVar9 = 0;
  *(undefined4 *)(param_1 + 0x348) = 0;
  if (plVar2 != (longlong *)0x0) {
    lVar9 = *plVar2;
  }
  *(uint *)(param_1 + 0x1f0) = *(uint *)(param_1 + 0x1f0) & 0x7c000000;
  *(undefined4 *)(param_1 + 0x420) = 0;
  *(undefined8 *)(param_1 + 0x400) = 0;
  *(undefined8 *)(param_1 + 0x3f8) = 0;
  *(undefined8 *)(param_1 + 0x3f0) = 0;
  *(undefined8 *)(param_1 + 1000) = 0;
  *(undefined8 *)(param_1 + 0x3d8) = 0;
  *(undefined8 *)(param_1 + 0x3d0) = 0;
  *(undefined4 *)(param_1 + 0x408) = 0;
  *(undefined4 *)(param_1 + 0x3c4) = 0;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    if (plVar2 != (longlong *)0x0) {
      cVar1 = *(char *)(param_1 + 0x24c);
      bVar6 = *(byte *)(*(longlong *)(*(longlong *)(param_1 + 0x1b8) + 0xfe0) + 0xf);
      uVar8 = (ulonglong)bVar6;
      if (cVar1 == '\0') {
        uVar8 = (ulonglong)(ushort)((ushort)bVar6 * 2);
      }
      else if (cVar1 == '\x01') {
        uVar8 = (ulonglong)(uint)((short)(ushort)bVar6 * 3 >> 1);
      }
      else if (cVar1 != '\x02') {
        if (cVar1 == '\x03') {
          uVar8 = (ulonglong)(bVar6 >> 1);
        }
        else if (cVar1 == '\x04') {
          uVar8 = uVar8 / 3;
        }
        else if (cVar1 == '\x05') {
          uVar8 = (ulonglong)(bVar6 >> 2);
        }
      }
      if (0xff < (ushort)uVar8) {
        uVar8 = 0xff;
      }
      *(char *)(*plVar2 + 0x6e) = (char)uVar8;
    }
    *(undefined4 *)(param_1 + 600) = 0;
    *(undefined8 *)(param_1 + 0x25c) = 0x46000000;
    *(undefined4 *)(param_1 + 0x264) = 0x3f800000;
  }
  if (lVar9 == 0) {
    *(undefined1 *)(param_1 + 0x42a) = 100;
    bVar6 = 100;
    *(undefined4 *)(param_1 + 0x1e0) = 0;
    uVar4 = 0;
  }
  else {
    bVar6 = *(byte *)(lVar9 + 0x6e);
    *(byte *)(param_1 + 0x42a) = bVar6;
    *(undefined4 *)(param_1 + 0x1e0) = *(undefined4 *)(lVar9 + 0x48);
    uVar4 = *(undefined1 *)(lVar9 + 0x6a);
  }
  *(undefined1 *)(param_1 + 0x248) = uVar4;
  *(undefined2 *)(param_1 + 0x222) = 0xffff;
  *(ushort *)(param_1 + 0x428) = (ushort)bVar6;
  if (*(longlong *)(param_1 + 8) != 0) {
    FUN_140126a10();
  }
  if (*(longlong *)(param_1 + 0x10) != 0) {
    FUN_140126a10();
  }
  lVar9 = *(longlong *)(param_1 + 0x340);
  if (lVar9 == 0) goto LAB_140115068;
  cVar1 = *(char *)(**(longlong **)(param_1 + 0x388) + 0x15d);
  if (((cVar1 == '\0') || (cVar1 == '\x02')) && (*(char *)(param_1 + 0x235) == '\0'))
  goto LAB_140115060;
  uVar4 = 0xff;
  if ((*(longlong **)(param_1 + 0x1a0) != (longlong *)0x0) &&
     (lVar3 = **(longlong **)(param_1 + 0x1a0), lVar3 != 0)) {
    uVar4 = *(undefined1 *)(lVar3 + 0x79);
  }
  switch(uVar4) {
  case 1:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xb400b3;
    *(undefined1 *)(lVar9 + 0x98) = 0;
    goto switchD_140114eb7_caseD_7;
  case 2:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xb600b5;
    *(undefined1 *)(lVar9 + 0x98) = 0;
    goto switchD_140114eb7_caseD_7;
  case 3:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xb800b7;
    *(undefined1 *)(lVar9 + 0x98) = 0;
    goto switchD_140114eb7_caseD_7;
  case 4:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xba00b9;
    *(undefined1 *)(lVar9 + 0x98) = 0;
    goto switchD_140114eb7_caseD_7;
  case 5:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xbc00bb;
    *(undefined1 *)(lVar9 + 0x98) = 0;
    goto switchD_140114eb7_caseD_7;
  case 6:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xc200c2;
    goto LAB_140114ff6;
  default:
    goto switchD_140114eb7_caseD_7;
  case 8:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xc300c3;
    goto LAB_140114ff6;
  case 9:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xc400c4;
    goto LAB_140114ff6;
  case 10:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xc500c5;
    goto LAB_140114ff6;
  case 0xb:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0xc600c6;
    goto LAB_140114ff6;
  case 0x10:
    *(undefined1 *)(lVar9 + 0x40) = 1;
    *(undefined4 *)(lVar9 + 0x90) = 0x1200120;
    goto LAB_140114ff6;
  case 0x11:
  case 0x18:
  case 0x1a:
  case 0x1e:
    *(undefined4 *)(lVar9 + 0x90) = 0;
    break;
  case 0x12:
  case 0x19:
  case 0x1b:
    *(undefined4 *)(lVar9 + 0x90) = 0x10001;
    break;
  case 0x13:
  case 0x1c:
    *(undefined4 *)(lVar9 + 0x90) = 0x20002;
    break;
  case 0x14:
  case 0x1d:
    *(undefined4 *)(lVar9 + 0x90) = 0x30003;
    break;
  case 0x15:
    *(undefined4 *)(lVar9 + 0x90) = 0x40004;
    break;
  case 0x16:
    *(undefined4 *)(lVar9 + 0x90) = 0x50005;
    break;
  case 0x17:
    *(undefined4 *)(lVar9 + 0x90) = 0x60006;
  }
  *(undefined1 *)(lVar9 + 0x40) = 2;
LAB_140114ff6:
  *(undefined1 *)(lVar9 + 0x98) = 1;
switchD_140114eb7_caseD_7:
  (**(code **)(**(longlong **)(param_1 + 0x340) + 8))();
  lVar9 = *(longlong *)(param_1 + 0x340);
  *(undefined4 *)(lVar9 + 0x5c) = *(undefined4 *)(param_1 + 0x268);
  *(undefined4 *)(lVar9 + 0x60) = *(undefined4 *)(param_1 + 0x26c);
  *(undefined4 *)(lVar9 + 100) = *(undefined4 *)(param_1 + 0x270);
  *(undefined4 *)(lVar9 + 0x68) = *(undefined4 *)(param_1 + 0x274);
  lVar9 = *(longlong *)(param_1 + 0x340);
  *(undefined4 *)(lVar9 + 0x4c) = *(undefined4 *)(param_1 + 600);
  *(undefined4 *)(lVar9 + 0x50) = *(undefined4 *)(param_1 + 0x25c);
  *(undefined4 *)(lVar9 + 0x54) = *(undefined4 *)(param_1 + 0x260);
  *(undefined4 *)(lVar9 + 0x58) = *(undefined4 *)(param_1 + 0x264);
LAB_140115060:
  FUN_140115a70(param_1);
LAB_140115068:
  *(undefined2 *)(param_1 + 0x22a) = 0;
  cVar1 = *(char *)(**(longlong **)(param_1 + 0x1a0) + 0x75);
  if (cVar1 == '\0') {
    if (*(longlong *)(param_1 + 0x1b8) == 0) {
      iVar5 = FUN_140242630();
      sVar7 = (short)(int)((float)*(byte *)(param_1 + 0x24a) *
                          ((float)iVar5 * DAT_1402d1e0c + DAT_1402d23c0));
      goto LAB_1401150ee;
    }
  }
  else if (cVar1 != '\x01') {
    if (cVar1 == '\x05') {
      sVar7 = (ushort)*(byte *)(param_1 + 0x24a) * 0x1e;
    }
    else {
      sVar7 = -1;
    }
    goto LAB_1401150ee;
  }
  sVar7 = (ushort)*(byte *)(param_1 + 0x24a) * 3;
LAB_1401150ee:
  *(short *)(param_1 + 0x22c) = sVar7;
  if (*(longlong *)(param_1 + 0x360) != 0) {
    FUN_1400aabf0();
  }
  if (*(longlong *)(param_1 + 0x368) != 0) {
    FUN_1401153a0(*(longlong *)(param_1 + 0x368),param_1);
    FUN_14011dd30(*(undefined8 *)(param_1 + 0x368));
  }
  if (*(longlong *)(param_1 + 0x370) != 0) {
    *(undefined8 *)(*(longlong *)(param_1 + 0x370) + 0x288) = 0;
  }
  lVar9 = *(longlong *)(param_1 + 0x1c0);
  if (lVar9 != 0) {
    if (*(longlong **)(lVar9 + 0x38) != (longlong *)0x0) {
      *(undefined1 *)(lVar9 + 0x83) =
           *(undefined1 *)((ulonglong)*(byte *)(lVar9 + 0x85) + 0xb + **(longlong **)(lVar9 + 0x38))
      ;
    }
    *(undefined1 *)(lVar9 + 0x82) = 0;
    *(undefined4 *)(lVar9 + 0x78) = 0;
    *(undefined2 *)(lVar9 + 0x7c) = 0;
    *(undefined2 *)(lVar9 + 0x86) = 0;
  }
  if (*(longlong **)(param_1 + 0x378) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x378) + 0x30))();
  }
  if ((((*(uint *)(param_1 + 0x1f0) & 0x20000000) != 0) &&
      (*(longlong **)(param_1 + 0x398) != (longlong *)0x0)) && (*(longlong *)(param_1 + 0x1c0) == 0)
     ) {
    (**(code **)(**(longlong **)(param_1 + 0x398) + 0x60))();
  }
  if ((((*(short *)(param_1 + 0x22e) == 0x13c) || (*(short *)(param_1 + 0x22e) == 0x13d)) &&
      ((*(uint *)(param_1 + 0x1f0) & 0x20000000) != 0)) &&
     (*(longlong **)(param_1 + 0x390) != (longlong *)0x0)) {
    (**(code **)(**(longlong **)(param_1 + 0x390) + 0x60))();
  }
  *(undefined4 *)(param_1 + 0x424) = 0;
  *(undefined1 *)(param_1 + 0x42e) = 0;
  if (*(longlong **)(param_1 + 0x390) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x390) + 0x1a0))();
  }
  if (*(longlong **)(param_1 + 0x398) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x398) + 0x1a0))();
  }
  plVar2 = *(longlong **)(param_1 + 0x1a0);
  if ((plVar2 != (longlong *)0x0) && (*plVar2 != 0)) {
    if (*(short *)(*plVar2 + 0x6c) == 0x20b) {
      *(uint *)(param_1 + 500) = *(uint *)(param_1 + 500) | 1;
    }
    if ((*(short *)(*plVar2 + 0x6c) == 0x61) || (*(short *)(*plVar2 + 0x6c) == 0x646)) {
      *(uint *)(param_1 + 500) = *(uint *)(param_1 + 500) | 1;
    }
    if (*(short *)(*plVar2 + 0x6c) == 0x20a) {
      *(uint *)(param_1 + 500) = *(uint *)(param_1 + 500) | 2;
    }
  }
  return;
}

