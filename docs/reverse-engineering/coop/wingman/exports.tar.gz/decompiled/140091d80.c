/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140091d80; RVA 0x91d80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140091d80(longlong param_1,uint param_2,undefined1 (*param_3) [16],float param_4,
                  undefined1 param_5,char param_6)

{
  int *piVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  char cVar6;
  undefined1 uVar7;
  ushort uVar8;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  char cVar11;
  byte bVar12;
  undefined2 uVar13;
  int iVar14;
  int iVar15;
  undefined4 *puVar16;
  undefined1 *puVar17;
  longlong *plVar18;
  uint uVar19;
  undefined1 *puVar20;
  longlong lVar21;
  uint uVar22;
  ulonglong uVar23;
  longlong lVar24;
  longlong lVar25;
  ulonglong uVar26;
  longlong lVar27;
  longlong lVar28;
  undefined4 uVar29;
  ulonglong uVar30;
  undefined8 uVar31;
  undefined1 auVar32 [16];
  undefined1 auVar33 [16];
  undefined1 extraout_var [56];
  undefined1 extraout_var_00 [56];
  undefined1 extraout_var_01 [56];
  undefined1 extraout_var_02 [56];
  undefined1 extraout_var_03 [56];
  undefined1 extraout_var_04 [56];
  undefined1 extraout_var_05 [56];
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  undefined8 uVar40;
  undefined1 auVar39 [64];
  float fVar41;
  undefined1 auVar42 [64];
  undefined1 auVar43 [64];
  undefined1 auVar44 [64];
  undefined1 in_ZMM11 [64];
  undefined1 auVar45 [64];
  undefined1 in_ZMM12 [64];
  undefined1 auVar46 [64];
  undefined1 auVar47 [64];
  float fVar48;
  longlong *local_res18;
  float local_res20;
  undefined2 uStack000000000000002a;
  longlong in_stack_fffffffffffffdd0;
  uint local_1f4;
  undefined1 local_1f0 [4];
  undefined1 auStack_1ec [4];
  undefined8 uStack_1e8;
  int local_1e0;
  undefined1 local_1d8 [16];
  undefined1 local_1c8 [16];
  undefined1 *local_1b8;
  float fStack_1b0;
  undefined4 uStack_1ac;
  longlong *local_1a8;
  float local_1a0;
  undefined1 auStack_19c [4];
  undefined8 uStack_198;
  int local_190;
  uint local_18c;
  undefined4 local_188;
  float local_184;
  uint local_180;
  float local_17c;
  float local_178;
  float local_174;
  float local_170;
  float local_16c;
  uint local_168;
  float local_164;
  undefined4 local_160;
  float local_15c;
  float local_158;
  float local_154;
  float local_150;
  float local_14c;
  float local_148;
  float local_144;
  float local_140;
  float local_13c;
  float local_138;
  float local_134;
  float local_130;
  float local_12c;
  float local_128;
  float local_124;
  float local_120;
  float local_11c;
  float local_118;
  float local_114;
  float local_110;
  float local_10c;
  longlong local_108;
  ulonglong local_100;
  longlong local_f8;
  undefined1 local_b8 [16];
  undefined1 local_a8 [16];
  
  uVar29 = (undefined4)((ulonglong)in_stack_fffffffffffffdd0 >> 0x20);
  auVar32 = *param_3;
  uVar26 = (ulonglong)(byte)param_3[5][0];
  fVar2 = *(float *)param_3[2];
  fVar3 = *(float *)(param_3[2] + 4);
  fVar4 = *(float *)(param_3[2] + 8);
  fVar5 = *(float *)(param_3[2] + 0xc);
  auVar33 = vshufps_avx(auVar32,auVar32,0x55);
  uStack_198 = auVar32._8_8_;
  auStack_19c = (undefined1  [4])auVar33._0_4_;
  auVar9 = vshufps_avx(auVar32,auVar32,0xaa);
  local_1a0 = auVar32._0_4_;
  auVar10 = _local_1a0;
  uStack_198._4_4_ = auVar32._12_4_;
  _local_1a0 = auVar10._0_8_;
  uStack_198._0_4_ = auVar9._0_4_;
  auVar33 = vinsertps_avx(ZEXT416((uint)(fVar2 + auVar32._0_4_)),
                          ZEXT416((uint)(fVar3 + auVar33._0_4_)),0x10);
  auVar10 = vshufps_avx(auVar32,auVar32,0xff);
  auVar32 = vinsertps_avx(auVar33,ZEXT416((uint)(fVar4 + auVar9._0_4_)),0x20);
  local_1c8 = vinsertps_avx(auVar32,ZEXT416((uint)(fVar5 + auVar10._0_4_)),0x30);
  lVar28 = **(longlong **)(param_1 + 0x10);
  local_18c = (uint)*(byte *)((longlong)*(longlong **)(param_1 + 0x10) + 0x34);
  local_1f4 = 0;
  local_res20 = param_4;
  local_100 = uVar26;
  local_f8 = lVar28;
  if (local_18c != 0) {
    local_a8 = in_ZMM11._0_16_;
    local_b8 = in_ZMM12._0_16_;
    local_108 = 0;
    fVar38 = DAT_1402d1ef8;
    uVar19 = DAT_1402d3770;
    do {
      uVar23 = 0;
      local_1a8 = (longlong *)(**(longlong **)(param_1 + 0x10) + local_108);
      lVar25 = *local_1a8;
      bVar12 = *(byte *)(*(longlong *)(lVar28 + uVar26 * 8) + 0x15d);
      if (*(byte *)(lVar25 + 0x15d) != bVar12) {
        if ((&DAT_1402accc0)[(ulonglong)bVar12 + (ulonglong)*(byte *)(lVar25 + 0x15d) * 8] != '\0')
        {
          if ((*(byte *)(lVar25 + 0x120) & 4) != 0) {
            local_190 = *(int *)(lVar25 + 0x118);
            _param_5 = 0;
            if (0 < local_190) {
              auVar32._8_8_ = 0;
              auVar32._0_8_ = uStack_1e8;
              _local_1f0 = auVar32 << 0x40;
              uVar26 = uVar23;
              do {
                uVar22 = (uint)uVar23;
                if (((local_1f4 != (byte)param_3[5][0]) || (uVar22 != (byte)param_3[5][1])) &&
                   (lVar28 = *(longlong *)(*local_1a8 + 0x110) + uVar26,
                   (*(byte *)(lVar28 + 0x1f0) & 1) != 0)) {
                  local_1d8 = *(undefined1 (*) [16])(lVar28 + 600);
                  fVar36 = local_1d8._0_4_ - local_1a0;
                  auVar32 = vshufps_avx(local_1d8,local_1d8,0x55);
                  fVar35 = SQRT(fVar5 * fVar5 + fVar4 * fVar4 + fVar3 * fVar3 + fVar2 * fVar2) +
                           *(float *)(lVar28 + 0x41c);
                  fVar41 = auVar32._0_4_ - (float)auStack_19c;
                  auVar32 = vshufps_avx(local_1d8,local_1d8,0xaa);
                  fVar48 = auVar32._0_4_ - (float)uStack_198;
                  if (fVar48 * fVar48 + fVar41 * fVar41 + fVar36 * fVar36 <= fVar35 * fVar35) {
                    lVar25 = **(longlong **)(lVar28 + 0x1a0);
                    if (*(short *)(lVar25 + 0x6c) == 0x46) {
                      local_1b8 = *(undefined1 **)(lVar28 + 600);
                      fStack_1b0 = *(float *)(lVar28 + 0x260);
                      uStack_1ac = *(undefined4 *)(lVar28 + 0x264);
                      fVar38 = *(float *)(lVar28 + 600) - *(float *)*param_3;
                      uVar19 = *(uint *)(lVar28 + 0x268);
                      auVar47 = ZEXT464(*(uint *)(lVar28 + 0x26c));
                      fVar35 = fStack_1b0 - *(float *)(*param_3 + 8);
                      fVar36 = *(float *)(lVar28 + 0x25c) - *(float *)(*param_3 + 4);
                      auVar43._0_8_ = FUN_14026f3b0(uVar19);
                      auVar43._8_56_ = extraout_var;
                      auVar32 = auVar43._0_16_;
                      auVar46 = ZEXT1664(auVar32);
                      fVar48 = (float)((uint)auVar43._0_8_ ^ DAT_1402d3770);
                      auVar32 = vshufps_avx(auVar32,auVar32,1);
                      auVar43 = ZEXT1664(auVar32);
                      auVar39._0_8_ = FUN_14026f3b0(auVar47._0_8_);
                      auVar39._8_56_ = extraout_var_00;
                      auVar32 = auVar39._0_16_;
                      auVar45 = ZEXT1664(auVar32);
                      auVar32 = vshufps_avx(auVar32,auVar32,1);
                      auVar44 = ZEXT1664(auVar32);
                      fVar41 = 0.0;
                      local_res18 = (longlong *)
                                    CONCAT44(local_res18._4_4_,
                                             (uint)(float)auVar39._0_8_ ^ DAT_1402d3770);
                      if (auVar43._0_4_ * auVar32._0_4_ * fVar35 +
                          auVar43._0_4_ * (float)auVar39._0_8_ * fVar38 + fVar48 * fVar36 < 0.0) {
                        _local_1f0 = param_3[2];
                        auVar39 = ZEXT1664(_local_1f0);
                        auVar42._0_8_ = FUN_14026f3b0(uVar19 ^ DAT_1402d3770);
                        auVar42._8_56_ = extraout_var_01;
                        auVar42 = ZEXT1664(auVar42._0_16_);
                        auVar33._4_12_ = ZEXT812(0);
                        auVar33._0_4_ = auVar47._0_4_ ^ DAT_1402d3770;
                        uVar19 = DAT_1402d3770;
                        auVar47._0_8_ = FUN_14026f3b0(auVar33._0_8_,0);
                        auVar47._8_56_ = extraout_var_02;
                        auVar32 = vshufps_avx(auVar47._0_16_,auVar47._0_16_,1);
                        auVar33 = vshufps_avx(auVar39._0_16_,auVar39._0_16_,0xaa);
                        fVar38 = (float)auVar47._0_8_ * auVar33._0_4_ +
                                 auVar32._0_4_ * auVar39._0_4_;
                        fVar36 = fVar38 * 0.0 + uStack_1e8._4_4_;
                        auVar9 = vshufps_avx(auVar42._0_16_,auVar42._0_16_,1);
                        fVar35 = auVar9._0_4_ * (float)auStack_1ec +
                                 (float)((uint)(auVar42._0_4_ *
                                               (auVar32._0_4_ * auVar33._0_4_ -
                                               (float)auVar47._0_8_ * auVar39._0_4_)) ^ uVar19);
                        fVar34 = fVar35 * DAT_1402d2158 + fVar38 * DAT_1402d2158;
                        _local_1f0 = _auStack_1ec << 0x20;
                        uStack_1e8._0_4_ = fVar34;
                        if (fVar41 < fVar34) {
                          uStack_1e8._0_4_ = (float)((uint)fVar34 ^ uVar19);
                        }
                        fVar34 = (float)((uint)fVar34 & _DAT_1402d3760 ^ uVar19);
                        fVar37 = SQRT(fVar36 * fVar36 +
                                      fVar34 * fVar34 + fVar35 * fVar35 + fVar38 * fVar38);
                        if (fVar37 != fVar41) {
                          fVar37 = DAT_1402d22d0 / fVar37;
                          fVar38 = fVar38 * fVar37;
                          fVar35 = fVar35 * fVar37;
                          fVar34 = fVar34 * fVar37;
                          fVar36 = fVar36 * fVar37;
                        }
                        uStack_1e8._4_4_ = fVar36;
                        fVar36 = fVar35 * auVar46._0_4_ + fVar34 * auVar43._0_4_;
                        fVar41 = fVar38 * local_res18._0_4_ + auVar44._0_4_ * fVar36;
                        auVar46 = ZEXT464((uint)fVar41);
                        fVar38 = fVar38 * auVar44._0_4_ + auVar45._0_4_ * fVar36;
                        auVar39 = ZEXT464((uint)fVar38);
                        local_1f0 = (undefined1  [4])fVar38;
                        uVar29 = FUN_140272370(fVar35 * auVar43._0_4_ + fVar48 * fVar34,
                                               SQRT(fVar41 * fVar41 + fVar38 * fVar38));
                        *(undefined4 *)param_3[1] = uVar29;
                        fVar38 = (float)FUN_140272370(auVar39._0_8_,auVar46._0_8_);
                        fVar35 = DAT_1402d2420;
                        fVar38 = fVar38 + DAT_1402d2420;
                        *(float *)(param_3[1] + 4) = fVar38;
                        *(undefined8 *)(param_3[1] + 8) = 0;
                        if (fVar35 < fVar38) {
                          *(float *)(param_3[1] + 4) = fVar38 - DAT_1402d249c;
                        }
                        *(undefined2 *)(param_3[5] + 2) = 0xffff;
                        param_3[5][0] = *(undefined1 *)(lVar28 + 0x234);
                        param_3[5][1] = *(undefined1 *)(lVar28 + 0x235);
                        goto LAB_140092466;
                      }
                      fVar38 = DAT_1402d1ef8;
                      param_4 = local_res20;
                      uVar19 = DAT_1402d3770;
                    }
                    fVar35 = 0.0;
                    plVar18 = *(longlong **)(lVar28 + 0x3a0);
                    if (*(char *)(lVar25 + 0x6f) == '\x01') {
                      uVar30 = (ulonglong)*(uint *)(lVar25 + 0x40);
                    }
                    else if (plVar18 == (longlong *)0x0) {
                      uVar30 = (ulonglong)DAT_1402d2698;
                    }
                    else {
                      uVar30 = (**(code **)(*plVar18 + 0xa0))(plVar18);
                    }
                    iVar14 = FUN_14014d070(&local_1a0,local_1c8,local_1d8,uVar30);
                    if (iVar14 != 0) {
                      if (*(char *)(lVar25 + 0x6f) == '\x02') {
                        if (plVar18 != (longlong *)0x0) {
                          auVar44._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar28 + 0x26c));
                          auVar44._8_56_ = extraout_var_03;
                          auVar32 = vshufps_avx(auVar44._0_16_,auVar44._0_16_,1);
                          local_168 = (uint)auVar44._0_8_;
                          local_180 = local_168 ^ uVar19;
                          local_188 = auVar32._0_4_;
                          local_174 = DAT_1402d22d0;
                          local_14c = DAT_1402d22d0;
                          fVar36 = DAT_1402d22d0;
                          local_184 = fVar35;
                          local_17c = fVar35;
                          local_178 = fVar35;
                          local_170 = fVar35;
                          local_16c = fVar35;
                          local_164 = fVar35;
                          local_160 = local_188;
                          local_15c = fVar35;
                          local_158 = fVar35;
                          local_154 = fVar35;
                          local_150 = fVar35;
                          auVar45._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar28 + 0x268));
                          auVar45._8_56_ = extraout_var_04;
                          auVar32 = vshufps_avx(auVar45._0_16_,auVar45._0_16_,1);
                          local_130 = (float)auVar45._0_8_;
                          local_124 = (float)((uint)local_130 ^ uVar19);
                          local_134 = auVar32._0_4_;
                          local_148 = fVar36;
                          local_144 = fVar35;
                          local_140 = fVar35;
                          local_13c = fVar35;
                          local_138 = fVar35;
                          local_12c = fVar35;
                          local_128 = fVar35;
                          local_120 = local_134;
                          local_11c = fVar35;
                          local_118 = fVar35;
                          local_114 = fVar35;
                          local_110 = fVar35;
                          local_10c = fVar36;
                          FUN_140005940(&local_188,&local_188,&local_148);
                          auVar46._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar28 + 0x270));
                          auVar46._8_56_ = extraout_var_05;
                          auVar32 = vshufps_avx(auVar46._0_16_,auVar46._0_16_,1);
                          local_144 = (float)auVar46._0_8_;
                          local_138 = (float)((uint)local_144 ^ uVar19);
                          local_148 = auVar32._0_4_;
                          local_134 = local_148;
                          local_130 = fVar35;
                          local_124 = fVar35;
                          local_120 = fVar36;
                          FUN_140005940(&local_188,&local_188,&local_148);
                          local_158 = local_158 + *(float *)(lVar28 + 600);
                          local_154 = local_154 + *(float *)(lVar28 + 0x25c);
                          local_150 = local_150 + *(float *)(lVar28 + 0x260);
                          iVar14 = (**(code **)(*plVar18 + 0x120))
                                             (plVar18,local_1d8,&local_188,&local_1a0,local_1c8);
                          if (iVar14 != 0) goto LAB_140092762;
                        }
                      }
                      else {
                        fVar36 = DAT_1402d22d0;
LAB_140092762:
                        puVar17 = operator_new((longlong)*(int *)(*local_1a8 + 0x118));
                        iVar14 = 0;
                        if (0 < *(int *)(*local_1a8 + 0x118)) {
                          puVar20 = puVar17;
                          do {
                            *puVar20 = 0;
                            puVar20 = puVar20 + 1;
                            iVar14 = iVar14 + 1;
                          } while (iVar14 < *(int *)(*local_1a8 + 0x118));
                        }
                        lVar25 = **(longlong **)(param_1 + 0x10);
                        lVar21 = (ulonglong)(byte)param_3[5][1] * 0x520 +
                                 *(longlong *)
                                  (*(longlong *)(lVar25 + (ulonglong)(byte)param_3[5][0] * 8) +
                                  0x110);
                        in_stack_fffffffffffffdd0 = lVar21;
                        local_1b8 = puVar17;
                        if (param_6 == '\x01') {
                          local_res18 = (longlong *)0x0;
                          if (*(char *)(**(longlong **)(lVar28 + 0x1a0) + 0x75) == '\x05') {
                            local_res18 = local_1a8;
                            cVar11 = (char)uVar23;
                            lVar27 = lVar28;
LAB_14009285f:
                            if (lVar27 == 0) goto LAB_140092919;
                            lVar25 = *local_res18;
                            iVar14 = 0;
                            if (0 < *(int *)(lVar25 + 0x118)) {
                              lVar24 = 0;
                              plVar18 = local_res18;
                              do {
                                lVar25 = *(longlong *)(lVar25 + 0x110) + lVar24;
                                if ((*(byte *)(lVar25 + 0x1f0) & 1) != 0) {
                                  cVar6 = *(char *)(**(longlong **)(lVar25 + 0x1a8) + 0x1d);
                                  if ((cVar6 != -1) && (cVar11 == cVar6)) {
                                    FUN_140118040(lVar25,&local_res18,0,
                                                  (int)((float)*(byte *)(*(longlong *)param_3[4] +
                                                                        0x49) * param_4) & 0xff,2,
                                                  lVar21,3);
                                    plVar18 = local_res18;
                                  }
                                }
                                lVar25 = *plVar18;
                                iVar14 = iVar14 + 1;
                                lVar24 = lVar24 + 0x520;
                              } while (iVar14 < *(int *)(lVar25 + 0x118));
                            }
                            uVar22 = _param_5;
                          }
                          else {
                            bVar12 = *(byte *)(**(longlong **)(lVar28 + 0x1a8) + 0x1d);
                            if (bVar12 != 0xff) {
                              lVar27 = (ulonglong)bVar12 * 0x520 +
                                       *(longlong *)
                                        (*(longlong *)
                                          (lVar25 + (ulonglong)*(byte *)(lVar28 + 0x234) * 8) +
                                        0x110);
                              if (*(char *)(**(longlong **)(lVar27 + 0x1a0) + 0x75) == '\x05') {
                                cVar11 = *(char *)(**(longlong **)(lVar28 + 0x1a8) + 0x1d);
                                local_res18 = (longlong *)
                                              (lVar25 + (ulonglong)*(byte *)(lVar28 + 0x234) * 8);
                                goto LAB_14009285f;
                              }
                            }
LAB_140092919:
                            lVar27 = lVar28;
                          }
                          puVar17 = local_1b8;
                          param_4 = (float)*(byte *)(*(longlong *)param_3[4] + 0x49) * param_4;
                          FUN_140118040(lVar27,param_4,local_1b8,(int)param_4 & 0xff,2,lVar21,3);
                          uVar26 = _local_1f0;
                        }
                        else {
                          FUN_140118040(lVar28,&local_1a8,puVar17,
                                        (int)((float)*(byte *)(*(longlong *)param_3[4] + 0x49) *
                                             param_4) & 0xff,2,lVar21,3);
                        }
                        auVar33 = local_1d8;
                        auVar32 = _local_1f0;
                        if (((*(uint *)(lVar28 + 0x1f0) >> 0x18 & 1) == 0) &&
                           ((0 < *(short *)(lVar28 + 0x428) ||
                            ((*(uint *)(lVar28 + 0x1f0) & 1) != 0)))) {
                          if (*(longlong *)(param_1 + 8) != 0) {
                            _local_1f0 = local_1f0._4_8_ << 0x20;
                            uStack_1e8._4_4_ = auVar32._12_4_;
                            uStack_1e8._0_4_ = (float)local_1d8._8_4_;
                            local_1d8._12_4_ = fVar36;
                            _local_1f0 = auVar33._0_8_;
                            uStack_1e8._4_4_ = fVar36;
                            iVar14 = FUN_140242630();
                            local_1f0 = (undefined1  [4])
                                        ((float)(iVar14 % 0x7d1 + -1000) * fVar38 + (float)local_1f0
                                        );
                            iVar14 = FUN_140242630();
                            auStack_1ec = (undefined1  [4])
                                          ((float)(iVar14 % 0x3e9) * fVar38 + (float)auStack_1ec);
                            iVar14 = FUN_140242630();
                            local_1e0 = 1;
                            uStack_1e8._0_4_ =
                                 (float)(iVar14 % 0x7d1 + -1000) * fVar38 + (float)uStack_1e8;
                            FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x33
                                          ,local_1f0,0);
                          }
                          lVar25 = *(longlong *)(lVar28 + 0x1b8);
                          uVar31 = FUN_1401c56d0();
                          if (lVar25 != 0) {
                            cVar11 = *(char *)(lVar25 + 0x2094);
                            if (cVar11 == '\0') {
                              uVar13 = 0x59;
                            }
                            else if (cVar11 == '\x02') {
                              uVar13 = 0x5a;
                            }
                            else {
                              if (cVar11 != '\x01') goto LAB_140092b3c;
                              uVar13 = 0x5b;
                            }
                            _param_5 = CONCAT22(uStack000000000000002a,uVar13);
                            local_res18 = (longlong *)CONCAT62(local_res18._2_6_,1);
                            FUN_1401c6150(uVar31,&local_res18,&param_5);
LAB_140092b3c:
                            puVar17 = local_1b8;
                            goto LAB_140092b40;
                          }
                          uStack_1e8 = _UNK_1402d35f8;
                          _local_1f0 = _DAT_1402d35f0;
                          in_stack_fffffffffffffdd0 =
                               CONCAT44((int)((ulonglong)in_stack_fffffffffffffdd0 >> 0x20),
                                        DAT_1402d2100);
                          cVar11 = FUN_1401c6a00(DAT_1402d2100,1,0x1b,local_1c8,local_1f0,
                                                 in_stack_fffffffffffffdd0,DAT_1402d234c,
                                                 DAT_1402d2458,fVar35,0,1);
                          if (((cVar11 == '\0') ||
                              (lVar25 = FUN_1401c97a0(), *(char *)(lVar25 + 0x3dc2) < '\x02')) ||
                             (uVar8 = *(ushort *)(lVar25 + 0x138),
                             (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar8 * 0x18) +
                                        0x882) & 1) == 0)) goto LAB_140092b3c;
                          puVar16 = (undefined4 *)FUN_1401c9e60();
                          if (puVar16 != (undefined4 *)0x0) {
                            *(ushort *)(puVar16 + 0x11) = uVar8;
                            *(undefined2 *)((longlong)puVar16 + 0x46) = 0x1b;
                            *puVar16 = local_1c8._0_4_;
                            puVar16[1] = local_1c8._4_4_;
                            puVar16[2] = local_1c8._8_4_;
                            puVar16[3] = local_1c8._12_4_;
                            *(undefined8 *)(puVar16 + 4) = 0;
                            puVar16[6] = 0;
                            puVar16[7] = 0x3f800000;
                            puVar16[8] = 0x3ea3d70a;
                            puVar16[9] = 0x3fb33333;
                            *(undefined8 *)(puVar16 + 10) = 0x40800000;
                            puVar16[0xf] = 0x3f800000;
                            *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
                            *(byte *)(puVar16 + 0x1c) = *(byte *)(puVar16 + 0x1c) & 0xee | 0x26;
                            *(code **)(puVar16 + 0xc) = FUN_1401caa00;
                          }
                          puVar17 = local_1b8;
                        }
                        else {
LAB_140092b40:
                        }
                        plVar18 = (longlong *)0x0;
                        if ((*(uint *)(lVar21 + 0x1f8) >> 9 & 1) == 0) {
                          bVar12 = 0;
                          lVar25 = *(longlong *)(lVar21 + 0x1b8);
                          if (lVar25 != 0) {
                            bVar12 = *(byte *)(lVar25 + 0x279a);
                            plVar18 = (longlong *)(lVar25 + 0xff8);
                          }
                          lVar25 = *(longlong *)(lVar21 + 0x1c0);
                          if (lVar25 != 0) {
                            plVar18 = *(longlong **)(lVar25 + 0x48);
                            bVar12 = *(byte *)(lVar25 + 0x85);
                          }
                          if (((plVar18 != (longlong *)0x0) && (*plVar18 != 0)) &&
                             (bVar12 = *(byte *)((ulonglong)bVar12 + 4 + *plVar18), bVar12 != 0)) {
                            if (bVar12 < 8) {
                              *(uint *)(lVar21 + 0x1fc) = *(uint *)(lVar21 + 0x1fc) | 0x400;
                            }
                            else if ((bVar12 < 0x16) && ((0x218c00U >> (bVar12 & 0x1f) & 1) != 0)) {
                              *(uint *)(lVar21 + 0x1fc) = *(uint *)(lVar21 + 0x1fc) | 0x200;
                            }
                          }
                        }
                        uVar7 = *(undefined1 *)(lVar28 + 0x235);
                        *(undefined1 *)(lVar21 + 0x240) = *(undefined1 *)(lVar28 + 0x234);
                        *(undefined1 *)(lVar21 + 0x241) = uVar7;
                        *(uint *)(param_1 + 0x5c) =
                             *(uint *)(param_1 + 0x5c) & ~(1 << (param_2 & 0x1f));
                        thunk_FUN_1402500f0(puVar17);
                      }
                    }
                  }
                }
LAB_140092466:
                _param_5 = uVar22 + 1;
                uVar23 = (ulonglong)_param_5;
                uVar26 = uVar26 + 0x520;
                _local_1f0 = uVar26;
                fVar38 = DAT_1402d1ef8;
                param_4 = local_res20;
              } while ((int)_param_5 < local_190);
              uVar26 = local_100;
              lVar28 = local_f8;
            }
          }
        }
      }
      uVar29 = (undefined4)((ulonglong)in_stack_fffffffffffffdd0 >> 0x20);
      local_1f4 = local_1f4 + 1;
      local_108 = local_108 + 8;
    } while ((int)local_1f4 < (int)local_18c);
  }
  local_1d8 = ZEXT816(0);
  _param_5 = 0;
  iVar15 = FUN_1400782c0(*(undefined8 *)(param_1 + 0x18),local_1d8,&param_5,&local_1a0,local_1c8);
  iVar14 = _param_5;
  if (iVar15 != 0) {
    *(uint *)(param_1 + 0x5c) = *(uint *)(param_1 + 0x5c) & ~(1 << (param_2 & 0x1f));
    if (*(longlong *)(param_1 + 8) != 0) {
      lVar28 = *(longlong *)(*(longlong *)(param_1 + 8) + 0x66ee0);
      uVar19 = (uint)(*(ushort *)(param_3[5] + 0xc) & 0x3ff);
      if (*(short *)(param_3[5] + 0xc) == -1) {
        uVar19 = 0xffffffff;
      }
      lVar25 = (longlong)(short)uVar19 >> 5;
      uVar22 = *(uint *)(lVar28 + 0x1bc48 + lVar25 * 4);
      if ((uVar22 >> (uVar19 & 0x1f) & 1) != 0) {
        *(uint *)(lVar28 + 0x1bc48 + lVar25 * 4) = uVar22 & ~(1 << (uVar19 & 0x1f));
        piVar1 = (int *)(lVar28 + 0x1bc88);
        *piVar1 = *piVar1 + -1;
        if (*piVar1 < 0) {
          *(undefined4 *)(lVar28 + 0x1bc88) = 0;
        }
      }
      _local_1f0 = local_1f0._4_8_ << 0x20;
      uStack_1e8._0_4_ = (float)local_1d8._8_4_;
      uStack_1e8._4_4_ = DAT_1402d22d0;
      _local_1f0 = local_1d8._0_8_;
      local_1e0 = _param_5;
      FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x33,local_1f0,0);
    }
    FUN_1401c56d0();
    local_1d8._8_8_ = _UNK_1402d35f8;
    local_1d8._0_8_ = _DAT_1402d35f0;
    if (iVar14 == 2) {
      uVar31 = _DAT_1402d35f0;
      uVar40 = _UNK_1402d35f8;
      cVar11 = FUN_1401c6a00(DAT_1402d2100,1,0x2e,local_1c8,local_1d8,CONCAT44(uVar29,DAT_1402d2100)
                             ,DAT_1402d236c,DAT_1402d2458,0,0,1);
      if (cVar11 == '\0') {
        return;
      }
      lVar28 = FUN_1401c97a0();
      if (*(char *)(lVar28 + 0x3dc2) < '\x02') {
        return;
      }
      uVar8 = *(ushort *)(lVar28 + 0x138);
      if ((~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar8 * 0x18) + 0xe72) & 1) == 0) {
        return;
      }
      puVar16 = (undefined4 *)FUN_1401c9e60(lVar28);
      if (puVar16 == (undefined4 *)0x0) {
        return;
      }
      *(ushort *)(puVar16 + 0x11) = uVar8;
      *(undefined2 *)((longlong)puVar16 + 0x46) = 0x2e;
      *puVar16 = local_1c8._0_4_;
      puVar16[1] = local_1c8._4_4_;
      puVar16[2] = local_1c8._8_4_;
      puVar16[3] = local_1c8._12_4_;
      *(undefined8 *)(puVar16 + 4) = uVar31;
      *(undefined8 *)(puVar16 + 6) = uVar40;
      puVar16[8] = 0x3ea3d70a;
      puVar16[9] = 0x3fc00000;
      puVar16[10] = 0x40800000;
      puVar16[0xb] = 0;
      *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
      puVar16[0xf] = 0x3f800000;
      bVar12 = *(byte *)(puVar16 + 0x1c);
    }
    else {
      uVar31 = _DAT_1402d35f0;
      uVar40 = _UNK_1402d35f8;
      cVar11 = FUN_1401c6a00(DAT_1402d2100,1,0x1b,local_1c8,local_1d8,CONCAT44(uVar29,DAT_1402d2100)
                             ,DAT_1402d236c,DAT_1402d2458,0,0,1);
      if (cVar11 == '\0') {
        return;
      }
      lVar28 = FUN_1401c97a0();
      if (*(char *)(lVar28 + 0x3dc2) < '\x02') {
        return;
      }
      uVar8 = *(ushort *)(lVar28 + 0x138);
      if ((~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar8 * 0x18) + 0x882) & 1) == 0) {
        return;
      }
      puVar16 = (undefined4 *)FUN_1401c9e60(lVar28);
      if (puVar16 == (undefined4 *)0x0) {
        return;
      }
      *(ushort *)(puVar16 + 0x11) = uVar8;
      *(undefined2 *)((longlong)puVar16 + 0x46) = 0x1b;
      *puVar16 = local_1c8._0_4_;
      puVar16[1] = local_1c8._4_4_;
      puVar16[2] = local_1c8._8_4_;
      puVar16[3] = local_1c8._12_4_;
      *(undefined8 *)(puVar16 + 4) = uVar31;
      *(undefined8 *)(puVar16 + 6) = uVar40;
      puVar16[8] = 0x3ea3d70a;
      puVar16[9] = 0x3fc00000;
      *(undefined8 *)(puVar16 + 10) = 0x40800000;
      puVar16[0xf] = 0x3f800000;
      *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
      bVar12 = *(byte *)(puVar16 + 0x1c);
    }
    *(byte *)(puVar16 + 0x1c) = bVar12 & 0xee | 0x26;
    *(code **)(puVar16 + 0xc) = FUN_1401caa00;
  }
  return;
}

