/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400a3570; RVA 0xa3570
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400a3570(longlong param_1)

{
  ushort *puVar1;
  undefined8 *puVar2;
  undefined1 auVar3 [16];
  longlong lVar4;
  longlong *plVar5;
  longlong lVar6;
  float fVar7;
  float fVar8;
  undefined1 auVar9 [16];
  int iVar10;
  float *pfVar11;
  uint uVar12;
  longlong lVar13;
  ulonglong uVar14;
  undefined4 uVar15;
  undefined1 auVar16 [64];
  undefined1 local_res10 [8];
  longlong local_res18;
  undefined4 local_f8;
  undefined4 local_f4;
  undefined4 local_f0;
  undefined4 local_ec;
  undefined4 local_e8;
  undefined1 local_e0 [16];
  undefined8 local_d0;
  undefined8 uStack_c8;
  float local_c0;
  float local_bc;
  float local_b8;
  float local_b4;
  float local_b0;
  float local_ac;
  float local_a8;
  float local_a4;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined1 local_88 [16];
  undefined8 local_78;
  undefined8 uStack_70;
  undefined1 local_68 [8];
  float fStack_60;
  undefined4 uStack_5c;
  
  auVar16 = ZEXT464(DAT_1402d2698);
  pfVar11 = (float *)(param_1 + 0xa0);
  uVar12 = 1;
  local_res18 = 0x10;
  uVar15 = DAT_1402d22d0;
  do {
    if ((*(uint *)(param_1 + 0x5c) & uVar12) != 0) {
      if (*(longlong *)(param_1 + 0x18) != 0) {
        local_e0 = ZEXT816(0);
        auVar3 = *(undefined1 (*) [16])(pfVar11 + -8);
        local_b0 = auVar3._0_4_ + *pfVar11;
        auVar9 = vshufps_avx(auVar3,auVar3,0x55);
        local_ac = auVar9._0_4_ + pfVar11[1];
        auVar9 = vshufps_avx(auVar3,auVar3,0xaa);
        local_a8 = auVar9._0_4_ + pfVar11[2];
        auVar3 = vshufps_avx(auVar3,auVar3,0xff);
        local_a4 = auVar3._0_4_ + pfVar11[3];
        iVar10 = FUN_1400782c0(*(longlong *)(param_1 + 0x18),local_e0,local_res10,
                               (undefined1 (*) [16])(pfVar11 + -8),&local_b0);
        if (iVar10 != 0) {
          if (*(longlong *)(param_1 + 8) != 0) {
            local_f8 = local_e0._0_4_;
            local_f0 = local_e0._8_4_;
            local_f4 = local_e0._4_4_;
            local_e8 = 0;
            local_e0._12_4_ = uVar15;
            local_ec = uVar15;
            FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x75,&local_f8,0);
          }
          if (DAT_14033bd60 == '\0') {
            puVar1 = (ushort *)
                     (*(longlong *)
                       (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x10) + 0x110) +
                       0x1b8) + 0x2090);
            *puVar1 = *puVar1 | 0x20;
          }
          *(uint *)(param_1 + 0x5c) = *(uint *)(param_1 + 0x5c) & ~uVar12;
        }
      }
      if ((*(byte *)((longlong)pfVar11 + 0x32) != 0xff) &&
         (*(byte *)((longlong)pfVar11 + 0x33) != 0xff)) {
        local_e0 = *(undefined1 (*) [16])(pfVar11 + -8);
        local_c0 = local_e0._0_4_ + *pfVar11;
        auVar3 = vshufps_avx(local_e0,local_e0,0x55);
        local_bc = auVar3._0_4_ + pfVar11[1];
        auVar3 = vshufps_avx(local_e0,local_e0,0xaa);
        local_b8 = auVar3._0_4_ + pfVar11[2];
        auVar3 = vshufps_avx(local_e0,local_e0,0xff);
        local_b4 = auVar3._0_4_ + pfVar11[3];
        lVar13 = (ulonglong)*(byte *)((longlong)pfVar11 + 0x33) * 0x520;
        lVar4 = *(longlong *)
                 (*(longlong *)
                   (**(longlong **)(param_1 + 0x10) +
                   (ulonglong)*(byte *)((longlong)pfVar11 + 0x32) * 8) + 0x110);
        if ((*(byte *)(lVar4 + 0x1f0 + lVar13) & 1) != 0) {
          puVar2 = (undefined8 *)(lVar4 + 600 + lVar13);
          local_d0 = *puVar2;
          uStack_c8 = puVar2[1];
          plVar5 = *(longlong **)(lVar4 + 0x3a0 + lVar13);
          lVar6 = **(longlong **)(lVar4 + 0x1a0 + lVar13);
          if (*(char *)(lVar6 + 0x6f) == '\x01') {
            uVar14 = (ulonglong)*(uint *)(lVar6 + 0x40);
          }
          else if (plVar5 == (longlong *)0x0) {
            uVar14 = auVar16._0_8_;
          }
          else {
            uVar14 = (**(code **)(*plVar5 + 0xa0))(plVar5);
          }
          iVar10 = FUN_14014d070(local_e0,&local_c0,&local_d0,uVar14);
          if (iVar10 != 0) {
            if (*(char *)(lVar6 + 0x6f) == '\x02') {
              if (plVar5 != (longlong *)0x0) {
                local_88 = ZEXT816(0);
                local_98 = 0;
                uStack_90 = 0;
                local_78 = 0;
                uStack_70 = 0;
                _local_68 = local_88;
                FUN_140202920(&local_98,lVar4 + 0x268 + lVar13);
                auVar3 = _local_68;
                fVar7 = (float)local_68._0_4_ + *(float *)(lVar4 + 600 + lVar13);
                fVar8 = (float)local_68._4_4_ + *(float *)(lVar4 + 0x25c + lVar13);
                local_68._0_4_ = fVar7;
                auVar9 = _local_68;
                fStack_60 = auVar3._8_4_;
                uStack_5c = auVar3._12_4_;
                local_68 = auVar9._0_8_;
                fStack_60 = fStack_60 + *(float *)(lVar4 + 0x260 + lVar13);
                local_68._4_4_ = fVar8;
                iVar10 = (**(code **)(*plVar5 + 0x120))
                                   (plVar5,&local_d0,&local_98,local_e0,&local_c0);
                if (iVar10 != 0) goto LAB_1400a386f;
              }
            }
            else {
LAB_1400a386f:
              if (*(longlong *)(param_1 + 8) != 0) {
                local_f8 = (undefined4)local_d0;
                local_f0 = (undefined4)uStack_c8;
                uStack_c8 = CONCAT44(uVar15,(undefined4)uStack_c8);
                local_f4 = local_d0._4_4_;
                local_e8 = 0;
                local_ec = uVar15;
                FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x75,&local_f8,0
                             );
              }
              if (DAT_14033bd60 == '\0') {
                puVar1 = (ushort *)
                         (*(longlong *)
                           (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x10) + 0x110) +
                           0x1b8) + 0x2090);
                *puVar1 = *puVar1 | 0x20;
              }
              *(uint *)(param_1 + 0x5c) = *(uint *)(param_1 + 0x5c) & ~uVar12;
            }
          }
        }
      }
    }
    uVar12 = uVar12 << 1 | (uint)((int)uVar12 < 0);
    pfVar11 = pfVar11 + 0x1a;
    local_res18 = local_res18 + -1;
    if (local_res18 == 0) {
      return;
    }
  } while( true );
}

