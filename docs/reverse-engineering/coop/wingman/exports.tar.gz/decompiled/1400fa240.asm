0x1400fa240  MOV qword ptr [RSP + 0x20],RBX
0x1400fa245  PUSH RBP
0x1400fa246  PUSH RSI
0x1400fa247  PUSH RDI
0x1400fa248  PUSH R12
0x1400fa24a  PUSH R13
0x1400fa24c  PUSH R14
0x1400fa24e  PUSH R15
0x1400fa250  SUB RSP,0x40
0x1400fa254  MOV RDX,qword ptr [RDX]
0x1400fa257  MOV R12,RCX
0x1400fa25a  AND dword ptr [RCX + 0x3a8],0xffffffb7
0x1400fa261  MOV RAX,qword ptr [RCX + 0x2f8]
0x1400fa268  MOV qword ptr [RSP + 0x90],RDX
0x1400fa270  MOVZX R8D,byte ptr [RDX + 0xb6]
0x1400fa278  MOV RCX,qword ptr [RAX]
0x1400fa27b  MOV RAX,qword ptr [RCX]
0x1400fa27e  MOV R13,qword ptr [RAX + 0x110]
0x1400fa285  LEA RAX,[RDX + 0xb7]
0x1400fa28c  MOV qword ptr [RSP + 0x88],R13
0x1400fa294  MOV qword ptr [RSP + 0x80],RAX
0x1400fa29c  MOV R13,qword ptr [R13 + 0x1b8]
0x1400fa2a3  CMP R8B,0xff
0x1400fa2a7  JZ 0x1400fa2c5
0x1400fa2a9  MOVZX EDX,byte ptr [RAX]
0x1400fa2ac  CMP DL,0xff
0x1400fa2af  JZ 0x1400fa2c5
0x1400fa2b1  MOV RCX,qword ptr [RCX + R8*0x8]
0x1400fa2b5  IMUL RDX,RDX,0x520
0x1400fa2bc  ADD RDX,qword ptr [RCX + 0x110]
0x1400fa2c3  JMP 0x1400fa2cf
0x1400fa2c5  XOR EDX,EDX
0x1400fa2c7  MOV qword ptr [RSP + 0x80],RAX
0x1400fa2cf  MOV qword ptr [R13 + 0x2048],RDX
0x1400fa2d6  MOV qword ptr [R13 + 0x1638],RDX
0x1400fa2dd  AND dword ptr [R13 + 0x2058],0xfffffeff
0x1400fa2e8  AND byte ptr [R13 + 0x1677],0xfd
0x1400fa2f0  MOV RAX,qword ptr [R12 + 0x340]
0x1400fa2f8  CMP byte ptr [RAX + 0xa881d],0x5
0x1400fa2ff  JZ 0x1400fa312
0x1400fa301  MOVZX EAX,byte ptr [R12 + 0x3e3]
0x1400fa30a  MOV byte ptr [R12 + 0x3e2],AL
0x1400fa312  MOVZX R15D,word ptr [R13 + 0x2728]
0x1400fa31a  MOV RCX,R13
0x1400fa31d  MOVZX R14D,word ptr [R13 + 0x272a]
0x1400fa325  MOVZX EBP,byte ptr [R13 + 0x272c]
0x1400fa32d  MOVZX ESI,byte ptr [R13 + 0x272d]
0x1400fa335  MOVZX EDI,byte ptr [R13 + 0x272e]
0x1400fa33d  MOV EBX,dword ptr [R13 + 0x2784]
0x1400fa344  CALL 0x140102ab0
0x1400fa349  MOV dword ptr [R13 + 0x2784],EBX
0x1400fa350  MOV RBX,qword ptr [RSP + 0x88]
0x1400fa358  MOV RCX,RBX
0x1400fa35b  MOV word ptr [R13 + 0x2728],R15W
0x1400fa363  MOV word ptr [R13 + 0x272a],R14W
0x1400fa36b  MOV byte ptr [R13 + 0x272c],BPL
0x1400fa372  MOV byte ptr [R13 + 0x272d],SIL
0x1400fa379  MOV byte ptr [R13 + 0x272e],DIL
0x1400fa380  CALL 0x140114c30
0x1400fa385  MOV EAX,dword ptr [R12 + 0x404]
0x1400fa38d  XOR EDI,EDI
0x1400fa38f  MOV dword ptr [RBX + 0x420],EAX
0x1400fa395  MOVZX EAX,byte ptr [R12 + 0x3e2]
0x1400fa39e  MOV word ptr [RBX + 0x428],AX
0x1400fa3a5  MOV RAX,qword ptr [RSP + 0x90]
0x1400fa3ad  MOV qword ptr [RBX + 0x268],RDI
0x1400fa3b4  MOV qword ptr [RBX + 0x270],RDI
0x1400fa3bb  MOVZX ECX,byte ptr [RAX + 0xb6]
0x1400fa3c2  CMP CL,0xff
0x1400fa3c5  JZ 0x1400fa3fa
0x1400fa3c7  MOV RAX,qword ptr [RSP + 0x80]
0x1400fa3cf  MOVZX R9D,byte ptr [RAX]
0x1400fa3d3  CMP R9B,0xff
0x1400fa3d7  JZ 0x1400fa3fa
0x1400fa3d9  MOV RAX,qword ptr [R12 + 0x2f8]
0x1400fa3e1  MOV EDX,ECX
0x1400fa3e3  MOV RCX,qword ptr [RAX]
0x1400fa3e6  MOV R8,qword ptr [RCX + RDX*0x8]
0x1400fa3ea  IMUL RCX,R9,0x520
0x1400fa3f1  ADD RCX,qword ptr [R8 + 0x110]
0x1400fa3f8  JMP 0x1400fa3fd
0x1400fa3fa  MOV RCX,RDI
0x1400fa3fd  MOV qword ptr [R13 + 0x2048],RCX
0x1400fa404  MOV qword ptr [R13 + 0x1638],RCX
0x1400fa40b  MOV RCX,R13
0x1400fa40e  AND dword ptr [R13 + 0x2058],0xfffffeff
0x1400fa419  AND byte ptr [R13 + 0x1677],0xfd
0x1400fa421  OR dword ptr [RBX + 0x1f0],0x3
0x1400fa428  CALL 0x14010bb50
0x1400fa42d  VMOVUPS XMM0,xmmword ptr [RBX + 0x268]
0x1400fa435  VMOVUPS xmmword ptr [RSP + 0x20],XMM0
0x1400fa43b  VMOVUPS XMM0,xmmword ptr [RBX + 0x258]
0x1400fa443  LEA R8,[RSP + 0x20]
0x1400fa448  MOV RCX,R13
0x1400fa44b  LEA RDX,[RSP + 0x30]
0x1400fa450  VMOVUPS xmmword ptr [RSP + 0x30],XMM0
0x1400fa456  CALL 0x14010a690
0x1400fa45b  MOV EAX,dword ptr [R13 + 0x70]
0x1400fa45f  MOV dword ptr [RBX + 0x258],EAX
0x1400fa465  MOV EAX,dword ptr [R13 + 0x74]
0x1400fa469  MOV dword ptr [RBX + 0x25c],EAX
0x1400fa46f  MOV EAX,dword ptr [R13 + 0x78]
0x1400fa473  MOV dword ptr [RBX + 0x260],EAX
0x1400fa479  MOV EAX,dword ptr [R13 + 0x7c]
0x1400fa47d  MOV dword ptr [RBX + 0x264],EAX
0x1400fa483  MOV EAX,dword ptr [R13 + 0x80]
0x1400fa48a  MOV dword ptr [RBX + 0x268],EAX
0x1400fa490  MOV EAX,dword ptr [R13 + 0x84]
0x1400fa497  MOV dword ptr [RBX + 0x26c],EAX
0x1400fa49d  MOV EAX,dword ptr [R13 + 0x88]
0x1400fa4a4  MOV dword ptr [RBX + 0x270],EAX
0x1400fa4aa  MOV EAX,dword ptr [R13 + 0x8c]
0x1400fa4b1  MOV dword ptr [RBX + 0x274],EAX
0x1400fa4b7  OR dword ptr [R13 + 0x2058],0x1000
0x1400fa4c2  MOV EAX,dword ptr [R13 + 0x2058]
0x1400fa4c9  OR word ptr [R13 + 0x1c20],0x1
0x1400fa4d2  BT EAX,0xd
0x1400fa4d6  JC 0x1400fa4f2
0x1400fa4d8  BTS EAX,0xd
0x1400fa4dc  MOV dword ptr [R13 + 0x2058],EAX
0x1400fa4e3  MOVZX EAX,byte ptr [R13 + 0x2094]
0x1400fa4eb  MOV byte ptr [R13 + 0x2095],AL
0x1400fa4f2  MOV byte ptr [R13 + 0x2096],0x2
0x1400fa4fa  OR byte ptr [R13 + 0x1863],0x1
0x1400fa502  MOV dword ptr [R13 + 0x185c],EDI
0x1400fa509  MOV RCX,qword ptr [R12 + 0x308]
0x1400fa511  TEST RCX,RCX
0x1400fa514  JZ 0x1400fa51b
0x1400fa516  CALL 0x1401a5f00
0x1400fa51b  AND dword ptr [R12 + 0x3a8],0xffffbfff
0x1400fa527  MOV RBX,qword ptr [RSP + 0x98]
0x1400fa52f  MOV dword ptr [R12 + 0x3a0],EDI
0x1400fa537  MOV byte ptr [R12 + 0x3cc],0x13
0x1400fa540  ADD RSP,0x40
0x1400fa544  POP R15
0x1400fa546  POP R14
0x1400fa548  POP R13
0x1400fa54a  POP R12
0x1400fa54c  POP RDI
0x1400fa54d  POP RSI
0x1400fa54e  POP RBP
0x1400fa54f  RET
