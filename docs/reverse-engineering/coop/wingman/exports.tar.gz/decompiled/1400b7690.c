/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b7690; RVA 0xb7690
 * Ghidra-generated research pseudocode, inferred types, not original source. */

ulonglong FUN_1400b7690(longlong param_1,ulonglong *param_2)

{
  undefined1 auVar1 [16];
  longlong lVar2;
  float fVar3;
  float fVar4;
  
  lVar2 = *(longlong *)(*(longlong *)(*param_2 + (ulonglong)*(byte *)(param_1 + 0x3ca) * 8) + 0x110)
  ;
  if (lVar2 == 0) {
    return *param_2 & 0xffffffffffffff00;
  }
  auVar1 = *(undefined1 (*) [16])(param_1 + 0x44);
  fVar4 = (float)*(byte *)(param_1 + 0x3c0) * auVar1._0_4_ * DAT_1402d2458 + *(float *)(lVar2 + 600)
  ;
  auVar1 = vshufps_avx(auVar1,auVar1,0xaa);
  fVar3 = (float)*(byte *)(param_1 + 0x3c0) * auVar1._0_4_ * DAT_1402d2458 +
          *(float *)(lVar2 + 0x260);
  if (((fVar4 <= *(float *)(param_1 + 0x138) - DAT_1402d2a54) &&
      (DAT_1402d2a54 + *(float *)(param_1 + 0x130) <= fVar4)) &&
     (fVar3 <= *(float *)(param_1 + 0x13c) - DAT_1402d2a54)) {
    return (ulonglong)(fVar3 < DAT_1402d2a54 + *(float *)(param_1 + 0x134));
  }
  return 1;
}

