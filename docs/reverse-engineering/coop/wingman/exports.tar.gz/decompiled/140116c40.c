/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140116c40; RVA 0x116c40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140116c40(longlong param_1,undefined4 *param_2,int param_3,longlong param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  
  if (((param_2 != (undefined4 *)0x0) &&
      (plVar2 = *(longlong **)(param_1 + 0x340), plVar2 != (longlong *)0x0)) &&
     (((cVar1 = *(char *)(**(longlong **)(param_1 + 0x388) + 0x15d), cVar1 != '\0' &&
       (cVar1 != '\x02')) || (*(char *)(param_1 + 0x235) != '\0')))) {
    if ((*(byte *)(param_1 + 0x1f0) & 1) != 0) {
      if ((char)plVar2[8] == '\x02') {
        switch(*(undefined1 *)(param_4 + 0x79)) {
        case 0x11:
        case 0x12:
        case 0x13:
        case 0x14:
        case 0x15:
        case 0x16:
        case 0x17:
        case 0x1a:
        case 0x1b:
        case 0x1c:
        case 0x1d:
switchD_140116cb8_caseD_11:
          lVar4 = *(longlong *)(param_1 + 0x360);
          if (lVar4 != 0) {
            FUN_1401c81f0(plVar2,*(undefined4 *)(lVar4 + 0x490),*(undefined4 *)(lVar4 + 0x494));
          }
          lVar4 = *(longlong *)(param_1 + 0x340);
          *(undefined4 *)(lVar4 + 0x5c) = *(undefined4 *)(param_1 + 0x268);
          *(undefined4 *)(lVar4 + 0x60) = *(undefined4 *)(param_1 + 0x26c);
          *(undefined4 *)(lVar4 + 100) = *(undefined4 *)(param_1 + 0x270);
          *(undefined4 *)(lVar4 + 0x68) = *(undefined4 *)(param_1 + 0x274);
          lVar4 = *(longlong *)(param_1 + 0x340);
          *(undefined4 *)(lVar4 + 0x4c) = *(undefined4 *)(param_1 + 600);
          *(undefined4 *)(lVar4 + 0x50) = *(undefined4 *)(param_1 + 0x25c);
          *(undefined4 *)(lVar4 + 0x54) = *(undefined4 *)(param_1 + 0x260);
          *(undefined4 *)(lVar4 + 0x58) = *(undefined4 *)(param_1 + 0x264);
          *(undefined4 *)(*(longlong *)(param_1 + 0x340) + 0x7c) = *param_2;
          *(float *)(*(longlong *)(param_1 + 0x340) + 0x80) =
               *(float *)(param_1 + 0x438) * DAT_1402d2a78;
          *(undefined4 *)(*(longlong *)(param_1 + 0x340) + 0x78) = *(undefined4 *)(param_1 + 0x43c);
          puVar3 = (undefined8 *)**(longlong **)(param_1 + 0x340);
          if (*(char *)((longlong)*(longlong **)(param_1 + 0x340) + 0x99) == '\x01') {
                    /* WARNING: Could not recover jumptable at 0x000140116dca. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)puVar3[2])();
            return;
          }
                    /* WARNING: Could not recover jumptable at 0x000140116dd3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)*puVar3)();
          return;
        }
      }
      if (0 < param_3) {
        lVar4 = 0;
        do {
          if ((float)param_2[lVar4] < *(float *)(param_1 + 0x434) * DAT_1402d2a78)
          goto switchD_140116cb8_caseD_11;
          lVar4 = lVar4 + 1;
        } while (lVar4 < param_3);
      }
    }
    (**(code **)(*plVar2 + 0x18))(plVar2);
  }
  return;
}

