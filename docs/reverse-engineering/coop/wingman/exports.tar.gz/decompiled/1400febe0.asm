0x1400febe0  MOV qword ptr [RSP + 0x8],RBX
0x1400febe5  MOV qword ptr [RSP + 0x10],RBP
0x1400febea  MOV qword ptr [RSP + 0x18],RSI
0x1400febef  PUSH RDI
0x1400febf0  SUB RSP,0x20
0x1400febf4  MOV RAX,qword ptr [RCX + 0x2f8]
0x1400febfb  XOR EBP,EBP
0x1400febfd  MOV RDI,RCX
0x1400fec00  MOV RDX,qword ptr [RAX]
0x1400fec03  MOV RAX,qword ptr [RDX]
0x1400fec06  MOV RSI,qword ptr [RAX + 0x110]
0x1400fec0d  MOV EAX,dword ptr [RCX + 0x3a8]
0x1400fec13  OR EAX,0x20
0x1400fec16  MOV RBX,qword ptr [RSI + 0x1b8]
0x1400fec1d  MOV dword ptr [RCX + 0x3a8],EAX
0x1400fec23  TEST byte ptr [RSI + 0x1f0],0x2
0x1400fec2a  JNZ 0x1400fec49
0x1400fec2c  CMP byte ptr [RCX + 0x3e6],0x5
0x1400fec33  MOV dword ptr [RCX + 0x378],EBP
0x1400fec39  MOV byte ptr [RCX + 0x3cc],0x5
0x1400fec40  JZ 0x1400fec49
0x1400fec42  MOV byte ptr [RCX + 0x3e6],0x4
0x1400fec49  TEST AL,0x4
0x1400fec4b  JNZ 0x1400fec65
0x1400fec4d  VMOVSS XMM0,dword ptr [RSI + 0x25c]
0x1400fec55  VADDSS XMM0,XMM0,dword ptr [0x1402d22d0]
0x1400fec5d  VMOVSS dword ptr [RSI + 0x25c],XMM0
0x1400fec65  MOVZX EDX,byte ptr [RCX + 0x3d1]
0x1400fec6c  MOV ECX,dword ptr [RCX + 0x378]
0x1400fec72  LEA EAX,[RDX + RDX*0x8]
0x1400fec75  CMP ECX,EAX
0x1400fec77  JGE 0x1400fecfd
0x1400fec7d  TEST byte ptr [RDI + 0x3a8],0x4
0x1400fec84  JNZ 0x1400fec8e
0x1400fec86  INC ECX
0x1400fec88  MOV dword ptr [RDI + 0x378],ECX
0x1400fec8e  VXORPS XMM0,XMM0,XMM0
0x1400fec92  VCVTSI2SS XMM0,XMM0,EDX
0x1400fec96  VXORPS XMM1,XMM1,XMM1
0x1400fec9a  VCVTSI2SS XMM1,XMM1,ECX
0x1400fec9e  VDIVSS XMM2,XMM1,XMM0
0x1400feca2  VMULSS XMM3,XMM2,dword ptr [0x1402d1fb4]
0x1400fecaa  VADDSS XMM0,XMM3,dword ptr [0x1402d20b0]
0x1400fecb2  VMOVSS dword ptr [RBX + 0x1d7c],XMM0
0x1400fecba  VMOVSS dword ptr [RBX + 0x1d78],XMM3
0x1400fecc2  MOVZX ECX,byte ptr [RDI + 0x3d1]
0x1400fecc9  MOV EAX,dword ptr [RDI + 0x378]
0x1400feccf  VXORPS XMM0,XMM0,XMM0
0x1400fecd3  LEA EDX,[RCX*0x8]
0x1400fecda  CMP EAX,EDX
0x1400fecdc  JL 0x1400fecf0
0x1400fecde  SUB EAX,EDX
0x1400fece0  VXORPS XMM1,XMM1,XMM1
0x1400fece4  VCVTSI2SS XMM1,XMM1,EAX
0x1400fece8  VCVTSI2SS XMM0,XMM0,ECX
0x1400fecec  VDIVSS XMM0,XMM1,XMM0
0x1400fecf0  VMOVSS dword ptr [RDI + 0x3a0],XMM0
0x1400fecf8  JMP 0x1400fee95
0x1400fecfd  MOV RAX,qword ptr [RDI + 0x310]
0x1400fed04  TEST RAX,RAX
0x1400fed07  JZ 0x1400fed3c
0x1400fed09  MOV qword ptr [RAX + 0x568],RBP
0x1400fed10  MOV dword ptr [RAX + 0x40],EBP
0x1400fed13  MOV dword ptr [RAX + 0x2a8],EBP
0x1400fed19  MOV word ptr [RAX + 0x2ac],0xffff
0x1400fed22  MOV dword ptr [RAX + 0x2f8],EBP
0x1400fed28  MOV dword ptr [RAX + 0x468],EBP
0x1400fed2e  MOV RAX,qword ptr [RDI + 0x310]
0x1400fed35  AND dword ptr [RAX + 0x56c],0xfffffffd
0x1400fed3c  MOV R8,qword ptr [RDI + 0x318]
0x1400fed43  TEST R8,R8
0x1400fed46  JZ 0x1400fed8d
0x1400fed48  MOV R9,qword ptr [RDI + 0x2f8]
0x1400fed4f  TEST R9,R9
0x1400fed52  JZ 0x1400fed8d
0x1400fed54  MOV RAX,qword ptr [R9]
0x1400fed57  MOV RCX,qword ptr [RAX]
0x1400fed5a  MOV EDX,dword ptr [RCX + 0x118]
0x1400fed60  TEST EDX,EDX
0x1400fed62  LEA EAX,[RDX + -0x1]
0x1400fed65  MOVZX ECX,AL
0x1400fed68  CMOVLE ECX,EBP
0x1400fed6b  MOV byte ptr [R8 + 0x20],CL
0x1400fed6f  MOVZX EAX,byte ptr [R9 + 0x68]
0x1400fed74  MOV byte ptr [R8 + 0x22],AL
0x1400fed78  MOVZX EAX,byte ptr [R9 + 0x69]
0x1400fed7d  NOT AL
0x1400fed7f  AND AL,0x1
0x1400fed81  MOV byte ptr [R8 + 0x21],AL
0x1400fed85  MOV qword ptr [R8 + 0x18],RBP
0x1400fed89  MOV byte ptr [R8 + 0x23],BPL
0x1400fed8d  MOV RAX,qword ptr [RDI + 0x320]
0x1400fed94  TEST RAX,RAX
0x1400fed97  JZ 0x1400fedd1
0x1400fed99  AND byte ptr [RAX + 0x2b],0xfd
0x1400fed9d  MOV RCX,qword ptr [RAX + 0x10]
0x1400feda1  TEST RCX,RCX
0x1400feda4  JZ 0x1400fedad
0x1400feda6  AND dword ptr [RCX + 0x56c],0xfffffffe
0x1400fedad  MOV RCX,qword ptr [RAX + 0x18]
0x1400fedb1  TEST RCX,RCX
0x1400fedb4  JZ 0x1400fedba
0x1400fedb6  AND byte ptr [RCX + 0x23],0xfb
0x1400fedba  MOV RAX,qword ptr [RDI + 0x320]
0x1400fedc1  MOV RCX,qword ptr [RAX + 0x10]
0x1400fedc5  TEST RCX,RCX
0x1400fedc8  JZ 0x1400fedd1
0x1400fedca  AND dword ptr [RCX + 0x40],0xfbffffff
0x1400fedd1  MOV RCX,qword ptr [RDI + 0x308]
0x1400fedd8  TEST RCX,RCX
0x1400feddb  JZ 0x1400fede2
0x1400feddd  CALL 0x1401a5f00
0x1400fede2  MOV ECX,dword ptr [RBX + 0x2058]
0x1400fede8  BT ECX,0xd
0x1400fedec  JNC 0x1400fedff
0x1400fedee  MOVZX EAX,byte ptr [RBX + 0x2095]
0x1400fedf5  BTR ECX,0xd
0x1400fedf9  MOV byte ptr [RBX + 0x2096],AL
0x1400fedff  AND byte ptr [RBX + 0x1da7],0xfe
0x1400fee06  BTR ECX,0x7
0x1400fee0a  MOV qword ptr [RBX + 0x1d78],RBP
0x1400fee11  MOV EBP,0x1
0x1400fee16  AND byte ptr [RBX + 0x1677],0xfe
0x1400fee1d  AND byte ptr [RBX + 0x1676],0xfc
0x1400fee24  AND byte ptr [RBX + 0x1863],0xfb
0x1400fee2b  MOV dword ptr [RBX + 0x2058],ECX
0x1400fee31  MOVZX EAX,byte ptr [RSI + 0x42a]
0x1400fee38  MOV word ptr [RSI + 0x428],AX
0x1400fee3f  MOV RBX,qword ptr [RDI + 0x2f8]
0x1400fee46  MOV RBX,qword ptr [RBX]
0x1400fee49  MOV RAX,qword ptr [RBX]
0x1400fee4c  CMP dword ptr [RAX + 0x118],EBP
0x1400fee52  JLE 0x1400fee8e
0x1400fee54  MOV ESI,0x520
0x1400fee59  MOV RAX,qword ptr [RAX + 0x110]
0x1400fee60  MOV RCX,qword ptr [RAX + RSI*0x1 + 0x1c0]
0x1400fee68  TEST RCX,RCX
0x1400fee6b  JZ 0x1400fee7a
0x1400fee6d  MOV RCX,qword ptr [RCX + 0x10]
0x1400fee71  MOV RAX,qword ptr [RCX]
0x1400fee74  CALL qword ptr [RAX + 0x1c8]
0x1400fee7a  MOV RAX,qword ptr [RBX]
0x1400fee7d  INC EBP
0x1400fee7f  ADD RSI,0x520
0x1400fee86  CMP EBP,dword ptr [RAX + 0x118]
0x1400fee8c  JL 0x1400fee59
0x1400fee8e  OR dword ptr [RDI + 0x3a8],0x2
0x1400fee95  MOV RBX,qword ptr [RSP + 0x30]
0x1400fee9a  MOV RBP,qword ptr [RSP + 0x38]
0x1400fee9f  MOV RSI,qword ptr [RSP + 0x40]
0x1400feea4  ADD RSP,0x20
0x1400feea8  POP RDI
0x1400feea9  RET
