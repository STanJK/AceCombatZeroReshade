/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401bc340; RVA 0x1bc340
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401bc340(longlong *param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  undefined *puVar4;
  int iVar5;
  int *piVar6;
  
  puVar4 = &DAT_140316e78;
  if (DAT_14031cf18 == '\0') {
    puVar4 = &DAT_140310ec0;
  }
  piVar6 = &DAT_140291a28;
  iVar5 = 0;
  *(undefined4 *)(param_1 + 0x17) = 0;
  do {
    iVar1 = piVar6[-2];
    uVar3 = 0;
    do {
      if (((uVar3 < 5) && (puVar4[uVar3 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
         (puVar4[uVar3 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
        *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
        *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
        break;
      }
      uVar3 = uVar3 + 1;
    } while ((longlong)uVar3 < 1);
    iVar1 = piVar6[-1];
    uVar3 = 0;
    do {
      if (((uVar3 < 5) && (puVar4[uVar3 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
         (puVar4[uVar3 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
        *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
        *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
        break;
      }
      uVar3 = uVar3 + 1;
    } while ((longlong)uVar3 < 1);
    iVar1 = *piVar6;
    uVar3 = 0;
    do {
      if (((uVar3 < 5) && (puVar4[uVar3 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
         (puVar4[uVar3 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
        *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
        *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
        break;
      }
      uVar3 = uVar3 + 1;
    } while ((longlong)uVar3 < 1);
    iVar1 = piVar6[1];
    uVar3 = 0;
    do {
      if (((uVar3 < 5) && (puVar4[uVar3 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
         (puVar4[uVar3 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
        *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
        *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
        break;
      }
      uVar3 = uVar3 + 1;
    } while ((longlong)uVar3 < 1);
    iVar1 = piVar6[2];
    uVar3 = 0;
    do {
      if (((uVar3 < 5) && (puVar4[uVar3 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
         (puVar4[uVar3 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
        *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
        *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
        break;
      }
      uVar3 = uVar3 + 1;
    } while ((longlong)uVar3 < 1);
    iVar1 = piVar6[3];
    uVar3 = 0;
    do {
      if (((uVar3 < 5) && (puVar4[uVar3 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
         (puVar4[uVar3 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
        *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
        *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
        break;
      }
      uVar3 = uVar3 + 1;
    } while ((longlong)uVar3 < 1);
    piVar6 = piVar6 + 6;
  } while ((longlong)piVar6 < 0x140291ab8);
  if (((int)param_1[1] == -1) && ((int)param_1[4] == 0)) {
    iVar1 = (**(code **)(*param_1 + 0x20))(param_1);
    if (0 < iVar1) {
      *(undefined4 *)(param_1 + 1) = 0;
    }
    *(undefined4 *)(param_1 + 0x19) = 0;
    if (0 < (int)param_1[0x17]) {
      plVar2 = param_1 + 5;
      do {
        if ((int)*plVar2 ==
            *(int *)(puVar4 + (longlong)*(int *)((longlong)param_1 + 0xbc) * 4 + 0x24c)) {
          iVar1 = (**(code **)(*param_1 + 0x20))(param_1);
          if (iVar5 < iVar1) {
            *(int *)(param_1 + 1) = iVar5;
          }
          *(undefined4 *)(param_1 + 0x19) =
               *(undefined4 *)(puVar4 + (longlong)*(int *)((longlong)param_1 + 0xbc) * 4 + 0x254);
          break;
        }
        iVar5 = iVar5 + 1;
        plVar2 = (longlong *)((longlong)plVar2 + 4);
      } while (iVar5 < (int)param_1[0x17]);
    }
    *(undefined4 *)(puVar4 + (longlong)*(int *)((longlong)param_1 + 0xbc) * 4 + 0x24c) =
         *(undefined4 *)((longlong)param_1 + (longlong)(int)param_1[1] * 4 + 0x28);
  }
                    /* WARNING: Could not recover jumptable at 0x0001401bc62f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x10))(param_1);
  return;
}

