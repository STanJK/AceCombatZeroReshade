/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f9a50; RVA 0xf9a50
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400f9a50(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong lVar2;
  uint uVar3;
  int iVar4;
  float fVar5;
  float fVar6;
  
  lVar1 = *param_2;
  uVar3 = *(uint *)(param_1 + 0x3a8);
  lVar2 = *(longlong *)
           (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
  iVar4 = *(int *)(param_1 + 0x37c);
  *(uint *)(param_1 + 0x3a8) = uVar3 | 0x10020;
  if (iVar4 < (int)((int)((float)*(byte *)(param_1 + 0x3d1) * *(float *)(lVar1 + 0x74)) & 0xffffU))
  {
    if ((uVar3 & 4) == 0) {
      iVar4 = iVar4 + 1;
      *(int *)(param_1 + 0x37c) = iVar4;
    }
    fVar5 = DAT_1402d2168;
    fVar6 = (float)iVar4 / ((float)*(byte *)(param_1 + 0x3d1) * *(float *)(lVar1 + 0x74));
    *(float *)(lVar2 + 0x1d7c) = DAT_1402d2d2c - (-(fVar6 * DAT_1402d20b0) + DAT_1402d20b0);
    *(float *)(lVar2 + 0x1d78) = -(fVar6 * fVar5) + fVar5;
    fVar5 = 0.0;
    if (*(int *)(param_1 + 0x37c) < (int)(uint)*(byte *)(param_1 + 0x3d1)) {
      fVar5 = DAT_1402d22d0 - (float)*(int *)(param_1 + 0x37c) / (float)*(byte *)(param_1 + 0x3d1);
    }
    *(float *)(param_1 + 0x3a0) = fVar5;
    *(uint *)(lVar2 + 0x2058) = *(uint *)(lVar2 + 0x2058) | 0x2000000;
    return;
  }
  *(undefined4 *)(param_1 + 0x3a0) = 0;
  *(byte *)(lVar2 + 0x1863) = *(byte *)(lVar2 + 0x1863) & 0xfe;
  *(undefined4 *)(lVar2 + 0x185c) = 0;
  *(byte *)(lVar2 + 0x1da7) = *(byte *)(lVar2 + 0x1da7) & 0xfe;
  *(undefined8 *)(lVar2 + 0x1d78) = 0;
  uVar3 = *(uint *)(lVar2 + 0x2058);
  if ((uVar3 >> 0xd & 1) != 0) {
    uVar3 = uVar3 & 0xffffdfff;
    *(undefined1 *)(lVar2 + 0x2096) = *(undefined1 *)(lVar2 + 0x2095);
  }
  *(uint *)(lVar2 + 0x2058) = uVar3 & 0xfdffffff;
  *(undefined4 *)(param_1 + 0x37c) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 0xf;
  *(undefined1 *)(param_1 + 0x3e6) = 1;
  if (*(char *)(param_1 + 0x3da) == '\x01') {
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffffdf;
  }
  return;
}

