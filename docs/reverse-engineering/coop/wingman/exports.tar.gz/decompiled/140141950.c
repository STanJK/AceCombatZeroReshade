/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140141950; RVA 0x141950
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140141950(longlong param_1,undefined1 param_2)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 in_stack_ffffffffffffffc8;
  undefined4 uVar3;
  
  uVar3 = (undefined4)((ulonglong)in_stack_ffffffffffffffc8 >> 0x20);
  lVar2 = *(longlong *)(param_1 + 0x280);
  if ((lVar2 != 0) &&
     ((*(byte *)(*(longlong *)
                  (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x288) + 0x110) + 0x1b8) +
                0x2058) & 2) == 0)) {
    *(undefined1 *)(param_1 + 0x2af) = param_2;
    if ((*(byte *)(param_1 + 0x2a6) & 0x40) != 0) {
      *(undefined1 *)(param_1 + 0x2af) = 1;
    }
    if (*(char *)(param_1 + 0x2a8) == '\0') {
      lVar1 = (ulonglong)*(byte *)(param_1 + 0x2a7) * 0x58 + 0x158 + lVar2;
      FUN_1401420d0(param_1,*(undefined4 *)(lVar2 + 0x6e8));
      if (*(char *)(param_1 + 0x2b9) != '\0') {
        FUN_140145790(param_1,lVar1,lVar1 + 0x10,DAT_1402d2474,CONCAT44(uVar3,DAT_1402d2994),
                      DAT_1402d2a30,DAT_1402d2994,DAT_1402d2784,0);
        return;
      }
      FUN_140142fb0(param_1,lVar1,lVar1 + 0x20);
    }
    else if (*(char *)(param_1 + 0x2a8) == '\x01') {
      FUN_140141d80();
      return;
    }
  }
  return;
}

