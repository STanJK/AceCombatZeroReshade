/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400bd780; RVA 0xbd780
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400bd780(undefined4 *param_1)

{
  undefined1 uVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  ushort *puVar5;
  uint uVar6;
  uint uVar7;
  longlong lVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  undefined4 *puVar12;
  int *piVar13;
  uint uVar14;
  uint uVar15;
  undefined1 *puVar16;
  longlong lVar17;
  int iVar18;
  int *piVar19;
  
  lVar8 = FUN_140189320();
  piVar19 = *(int **)(param_1 + 0xf4);
  uVar15 = 0;
  iVar18 = 1;
  uVar4 = *(undefined4 *)(lVar8 + 0x14);
  if ((piVar19 == (int *)0x0) || (param_1 == (undefined4 *)0xfffffffffffffc28)) goto LAB_1400be19e;
  iVar11 = *piVar19;
  piVar13 = (int *)0x0;
  if ((0 < iVar11) && (piVar19[1] != 0)) {
    piVar13 = (int *)((longlong)piVar19 + (longlong)piVar19[1]);
  }
  iVar10 = *piVar13;
  lVar8 = 0;
  *(undefined8 *)(param_1 + 0x12) = 0;
  *(undefined8 *)(param_1 + 0x14) = 0;
  *(undefined8 *)(param_1 + 0x16) = 0;
  *(undefined8 *)(param_1 + 0x10) = 0;
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined8 *)(param_1 + 0x1a) = 0;
  *(undefined8 *)(param_1 + 0x1c) = 0;
  param_1[0x1e] = 1;
  *(undefined1 *)(param_1 + 0x1f) = 1;
  param_1[0x20] = 0;
  if ((0 < iVar10) && (piVar13[1] != 0)) {
    lVar8 = (longlong)piVar13 + (longlong)piVar13[1];
  }
  FUN_1402038c0(param_1 + 0x10,lVar8);
  if (*(undefined2 **)(param_1 + 0x14) != (undefined2 *)0x0) {
    **(undefined2 **)(param_1 + 0x14) = 0x10;
    if (*(undefined2 **)(param_1 + 0x16) != (undefined2 *)0x0) {
      **(undefined2 **)(param_1 + 0x16) = 0x1510;
    }
    puVar5 = *(ushort **)(param_1 + 0x14);
    if (puVar5 != (ushort *)0x0) {
      uVar14 = 0;
      uVar7 = 0;
      iVar9 = 1;
      uVar6 = 0;
      do {
        if ((int)(uint)puVar5[6] <= iVar9) {
          uVar14 = uVar6;
          break;
        }
        iVar9 = iVar9 * 2;
        uVar6 = uVar6 + 1;
      } while ((int)uVar6 < 0xc);
      iVar9 = 1;
      uVar6 = 0;
      do {
        if ((int)(uint)puVar5[7] <= iVar9) {
          uVar7 = uVar6;
          break;
        }
        iVar9 = iVar9 * 2;
        uVar6 = uVar6 + 1;
      } while ((int)uVar6 < 0xc);
      param_1[0x10] =
           (((uVar7 << 4 | uVar14) << 6 | (uint)*(byte *)((longlong)puVar5 + 3)) << 6 |
           (uint)(byte)puVar5[1]) << 0xe | (uint)*puVar5;
      uVar14 = ((uint)*(byte *)((longlong)param_1 + 0x79) * 2 | (uint)*(byte *)(param_1 + 0x1e)) <<
               2 | uVar7 >> 2;
      param_1[0x11] = uVar14;
      if (*(longlong *)(param_1 + 0x1a) != 0) {
        param_1[0x11] =
             ((((uint)*(byte *)(param_1 + 0x1f) << 5 | (uint)*(ushort *)((longlong)param_1 + 0x7a))
               << 5 | (uint)*(byte *)((longlong)*(ushort **)(param_1 + 0x16) + 3)) << 0xe |
             (uint)**(ushort **)(param_1 + 0x16)) << 5 |
             (*(uint *)(*(longlong *)(param_1 + 0x12) + 4) & 2) << 0x16 | uVar14;
      }
    }
  }
  *(undefined8 *)(param_1 + 0xe6) = *(undefined8 *)(param_1 + 0x10);
  param_1[0x20] = 1;
  if (iVar10 < 2) {
    *(undefined8 *)(param_1 + 0xd6) = 0;
    *(undefined8 *)(param_1 + 0xca) = 0;
    lVar8 = 0;
    *(undefined8 *)(param_1 + 0xce) = 0;
    *(undefined8 *)(param_1 + 0xd2) = 0;
    *(undefined8 *)(param_1 + 0xda) = 0;
    *(undefined8 *)(param_1 + 0xde) = 0;
    *(undefined8 *)(param_1 + 0xe2) = 0;
  }
  else {
    if (piVar13[2] == 0) {
      lVar8 = 0;
    }
    else {
      lVar8 = (longlong)piVar13[2] + (longlong)piVar13;
    }
    *(longlong *)(param_1 + 0xd6) = lVar8;
    if (iVar10 < 3) {
      *(undefined8 *)(param_1 + 0xca) = 0;
      *(undefined8 *)(param_1 + 0xce) = 0;
      lVar8 = 0;
      *(undefined8 *)(param_1 + 0xd2) = 0;
      *(undefined8 *)(param_1 + 0xda) = 0;
      *(undefined8 *)(param_1 + 0xde) = 0;
      *(undefined8 *)(param_1 + 0xe2) = 0;
    }
    else {
      if (piVar13[3] == 0) {
        lVar8 = 0;
      }
      else {
        lVar8 = (longlong)piVar13[3] + (longlong)piVar13;
      }
      *(longlong *)(param_1 + 0xca) = lVar8;
      if (iVar10 < 4) {
        *(longlong *)(param_1 + 0xce) = 0;
        lVar8 = 0;
        *(undefined8 *)(param_1 + 0xd2) = 0;
        *(undefined8 *)(param_1 + 0xda) = 0;
        *(undefined8 *)(param_1 + 0xde) = 0;
        *(undefined8 *)(param_1 + 0xe2) = 0;
      }
      else {
        if (piVar13[4] == 0) {
          lVar8 = 0;
        }
        else {
          lVar8 = (longlong)piVar13[4] + (longlong)piVar13;
        }
        *(longlong *)(param_1 + 0xce) = lVar8;
        if (iVar10 < 5) {
          *(longlong *)(param_1 + 0xd2) = 0;
          lVar8 = 0;
          *(undefined8 *)(param_1 + 0xda) = 0;
          *(undefined8 *)(param_1 + 0xde) = 0;
          *(undefined8 *)(param_1 + 0xe2) = 0;
        }
        else {
          if (piVar13[5] == 0) {
            lVar8 = 0;
          }
          else {
            lVar8 = (longlong)piVar13[5] + (longlong)piVar13;
          }
          *(longlong *)(param_1 + 0xd2) = lVar8;
          if (iVar10 < 6) {
            *(longlong *)(param_1 + 0xda) = 0;
            lVar8 = 0;
            *(undefined8 *)(param_1 + 0xde) = 0;
            *(undefined8 *)(param_1 + 0xe2) = 0;
          }
          else {
            if (piVar13[6] == 0) {
              lVar8 = 0;
            }
            else {
              lVar8 = (longlong)piVar13[6] + (longlong)piVar13;
            }
            *(longlong *)(param_1 + 0xda) = lVar8;
            if (iVar10 < 7) {
              *(longlong *)(param_1 + 0xde) = 0;
              lVar8 = 0;
              *(undefined8 *)(param_1 + 0xe2) = 0;
            }
            else {
              if (piVar13[7] == 0) {
                lVar8 = 0;
              }
              else {
                lVar8 = (longlong)piVar13[7] + (longlong)piVar13;
              }
              *(longlong *)(param_1 + 0xde) = lVar8;
              if (iVar10 < 8) {
                *(longlong *)(param_1 + 0xe2) = 0;
                lVar8 = 0;
              }
              else {
                if (piVar13[8] == 0) {
                  lVar8 = 0;
                }
                else {
                  lVar8 = (longlong)piVar13[8] + (longlong)piVar13;
                }
                *(longlong *)(param_1 + 0xe2) = lVar8;
                if (iVar10 < 9) {
                  lVar8 = 0;
                }
                else if (piVar13[9] == 0) {
                  lVar8 = 0;
                }
                else {
                  lVar8 = (longlong)piVar13[9] + (longlong)piVar13;
                }
              }
            }
          }
        }
      }
    }
  }
  puVar16 = (undefined1 *)(lVar8 + 2);
  lVar17 = 0x3b;
  do {
    uVar1 = puVar16[1];
    uVar2 = *puVar16;
    uVar3 = puVar16[-1];
    puVar16[(longlong)param_1 + (0x236 - lVar8)] = puVar16[-2];
    puVar16[(longlong)param_1 + (0x237 - lVar8)] = uVar3;
    puVar16[(longlong)param_1 + (0x238 - lVar8)] = uVar2;
    puVar16[(longlong)param_1 + (0x239 - lVar8)] = uVar1;
    puVar16 = puVar16 + 4;
    lVar17 = lVar17 + -1;
  } while (lVar17 != 0);
  *(undefined1 *)(param_1 + 0x100) = 0;
  *(undefined8 *)(param_1 + 0x36) = 0;
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)(param_1 + 0x3a) = 0;
  *(undefined8 *)(param_1 + 0x34) = 0;
  *(undefined8 *)(param_1 + 0x3c) = 0;
  *(undefined8 *)(param_1 + 0x3e) = 0;
  *(undefined8 *)(param_1 + 0x40) = 0;
  param_1[0x42] = 1;
  *(undefined1 *)(param_1 + 0x43) = 1;
  param_1[0x44] = 0;
  FUN_1402038c0(param_1 + 0x34,*(undefined8 *)(param_1 + 0xf6));
  if (*(undefined2 **)(param_1 + 0x38) != (undefined2 *)0x0) {
    **(undefined2 **)(param_1 + 0x38) = 0x140;
    if (*(undefined2 **)(param_1 + 0x3a) != (undefined2 *)0x0) {
      **(undefined2 **)(param_1 + 0x3a) = 0x1540;
    }
    puVar5 = *(ushort **)(param_1 + 0x38);
    if (puVar5 != (ushort *)0x0) {
      uVar14 = 0;
      uVar7 = 0;
      iVar10 = 1;
      uVar6 = 0;
      do {
        if ((int)(uint)puVar5[6] <= iVar10) {
          uVar14 = uVar6;
          break;
        }
        iVar10 = iVar10 * 2;
        uVar6 = uVar6 + 1;
      } while ((int)uVar6 < 0xc);
      iVar10 = 1;
      uVar6 = 0;
      do {
        if ((int)(uint)puVar5[7] <= iVar10) {
          uVar7 = uVar6;
          break;
        }
        iVar10 = iVar10 * 2;
        uVar6 = uVar6 + 1;
      } while ((int)uVar6 < 0xc);
      param_1[0x34] =
           (((uVar7 << 4 | uVar14) << 6 | (uint)*(byte *)((longlong)puVar5 + 3)) << 6 |
           (uint)(byte)puVar5[1]) << 0xe | (uint)*puVar5;
      uVar14 = ((uint)*(byte *)((longlong)param_1 + 0x109) * 2 | (uint)*(byte *)(param_1 + 0x42)) <<
               2 | uVar7 >> 2;
      param_1[0x35] = uVar14;
      if (*(longlong *)(param_1 + 0x3e) != 0) {
        param_1[0x35] =
             ((((uint)*(byte *)(param_1 + 0x43) << 5 | (uint)*(ushort *)((longlong)param_1 + 0x10a))
               << 5 | (uint)*(byte *)((longlong)*(ushort **)(param_1 + 0x3a) + 3)) << 0xe |
             (uint)**(ushort **)(param_1 + 0x3a)) << 5 |
             (*(uint *)(*(longlong *)(param_1 + 0x36) + 4) & 2) << 0x16 | uVar14;
      }
    }
  }
  *(undefined8 *)(param_1 + 0xea) = *(undefined8 *)(param_1 + 0x34);
  if (*(longlong *)(param_1 + 0xf8) != 0) {
    *(undefined8 *)(param_1 + 0x48) = 0;
    *(undefined8 *)(param_1 + 0x4a) = 0;
    *(undefined8 *)(param_1 + 0x4c) = 0;
    *(undefined8 *)(param_1 + 0x46) = 0;
    *(undefined8 *)(param_1 + 0x4e) = 0;
    *(undefined8 *)(param_1 + 0x50) = 0;
    *(undefined8 *)(param_1 + 0x52) = 0;
    param_1[0x54] = 1;
    *(undefined1 *)(param_1 + 0x55) = 1;
    param_1[0x56] = 0;
    FUN_1402038c0(param_1 + 0x46);
    if (*(undefined2 **)(param_1 + 0x4a) != (undefined2 *)0x0) {
      **(undefined2 **)(param_1 + 0x4a) = 0x240;
      if (*(undefined2 **)(param_1 + 0x4c) != (undefined2 *)0x0) {
        **(undefined2 **)(param_1 + 0x4c) = 0x1550;
      }
      puVar5 = *(ushort **)(param_1 + 0x4a);
      if (puVar5 != (ushort *)0x0) {
        uVar14 = 0;
        uVar7 = 0;
        iVar10 = 1;
        uVar6 = 0;
        do {
          if ((int)(uint)puVar5[6] <= iVar10) {
            uVar14 = uVar6;
            break;
          }
          iVar10 = iVar10 * 2;
          uVar6 = uVar6 + 1;
        } while ((int)uVar6 < 0xc);
        iVar10 = 1;
        uVar6 = 0;
        do {
          if ((int)(uint)puVar5[7] <= iVar10) {
            uVar7 = uVar6;
            break;
          }
          iVar10 = iVar10 * 2;
          uVar6 = uVar6 + 1;
        } while ((int)uVar6 < 0xc);
        param_1[0x46] =
             (((uVar7 << 4 | uVar14) << 6 | (uint)*(byte *)((longlong)puVar5 + 3)) << 6 |
             (uint)(byte)puVar5[1]) << 0xe | (uint)*puVar5;
        uVar14 = ((uint)*(byte *)((longlong)param_1 + 0x151) * 2 | (uint)*(byte *)(param_1 + 0x54))
                 << 2 | uVar7 >> 2;
        param_1[0x47] = uVar14;
        if (*(longlong *)(param_1 + 0x50) != 0) {
          param_1[0x47] =
               ((((uint)*(byte *)(param_1 + 0x55) << 5 |
                 (uint)*(ushort *)((longlong)param_1 + 0x152)) << 5 |
                (uint)*(byte *)((longlong)*(ushort **)(param_1 + 0x4c) + 3)) << 0xe |
               (uint)**(ushort **)(param_1 + 0x4c)) << 5 |
               (*(uint *)(*(longlong *)(param_1 + 0x48) + 4) & 2) << 0x16 | uVar14;
        }
      }
    }
    *(undefined8 *)(param_1 + 0xec) = *(undefined8 *)(param_1 + 0x46);
  }
  switch(uVar4) {
  case 0:
    piVar13 = (int *)0x0;
    if ((2 < iVar11) && (piVar19[3] != 0)) {
      piVar13 = (int *)((longlong)piVar19 + (longlong)piVar19[3]);
    }
    *(undefined1 *)((longlong)param_1 + 0x401) = 1;
    break;
  default:
    piVar13 = (int *)0x0;
    if ((1 < iVar11) && (piVar19[2] != 0)) {
      piVar13 = (int *)((longlong)piVar19 + (longlong)piVar19[2]);
    }
    *(undefined1 *)((longlong)param_1 + 0x401) = 0;
    break;
  case 2:
    if (iVar11 < 4) {
      piVar13 = (int *)0x0;
      *(undefined1 *)((longlong)param_1 + 0x401) = 3;
    }
    else {
      iVar11 = piVar19[4];
LAB_1400bdf82:
      piVar13 = (int *)0x0;
      if (iVar11 != 0) {
        piVar13 = (int *)((longlong)piVar19 + (longlong)iVar11);
      }
      *(undefined1 *)((longlong)param_1 + 0x401) = 3;
    }
    break;
  case 3:
    piVar13 = (int *)0x0;
    if ((4 < iVar11) && (piVar19[5] != 0)) {
      piVar13 = (int *)((longlong)piVar19 + (longlong)piVar19[5]);
    }
    *(undefined1 *)((longlong)param_1 + 0x401) = 2;
    break;
  case 4:
    piVar13 = (int *)0x0;
    if ((7 < iVar11) && (piVar19[8] != 0)) {
      piVar13 = (int *)((longlong)piVar19 + (longlong)piVar19[8]);
    }
    *(undefined1 *)((longlong)param_1 + 0x401) = 4;
    break;
  case 5:
    piVar13 = (int *)0x0;
    if ((6 < iVar11) && (piVar19[7] != 0)) {
      piVar13 = (int *)((longlong)piVar19 + (longlong)piVar19[7]);
    }
    *(undefined1 *)((longlong)param_1 + 0x401) = 5;
    break;
  case 6:
    if (5 < iVar11) {
      iVar11 = piVar19[6];
      goto LAB_1400bdf82;
    }
    piVar13 = (int *)0x0;
    *(undefined1 *)((longlong)param_1 + 0x401) = 3;
  }
  if (piVar13 != (int *)0x0) {
    iVar11 = *piVar13;
    lVar8 = 0;
    *(undefined8 *)(param_1 + 0x24) = 0;
    *(undefined8 *)(param_1 + 0x26) = 0;
    *(undefined8 *)(param_1 + 0x28) = 0;
    *(undefined8 *)(param_1 + 0x22) = 0;
    *(undefined8 *)(param_1 + 0x2a) = 0;
    *(undefined8 *)(param_1 + 0x2c) = 0;
    *(undefined8 *)(param_1 + 0x2e) = 0;
    param_1[0x30] = 1;
    *(undefined1 *)(param_1 + 0x31) = 1;
    param_1[0x32] = 0;
    if ((0 < iVar11) && (piVar13[1] != 0)) {
      lVar8 = (longlong)piVar13 + (longlong)piVar13[1];
    }
    FUN_1402038c0(param_1 + 0x22,lVar8);
    if (*(undefined2 **)(param_1 + 0x26) != (undefined2 *)0x0) {
      **(undefined2 **)(param_1 + 0x26) = 0x90;
      if (*(undefined2 **)(param_1 + 0x28) != (undefined2 *)0x0) {
        **(undefined2 **)(param_1 + 0x28) = 0x1520;
      }
      puVar5 = *(ushort **)(param_1 + 0x26);
      if (puVar5 != (ushort *)0x0) {
        uVar14 = 0;
        uVar7 = 0;
        iVar10 = 1;
        uVar6 = 0;
        do {
          if ((int)(uint)puVar5[6] <= iVar10) {
            uVar14 = uVar6;
            break;
          }
          iVar10 = iVar10 * 2;
          uVar6 = uVar6 + 1;
        } while ((int)uVar6 < 0xc);
        iVar10 = 1;
        uVar6 = 0;
        do {
          if ((int)(uint)puVar5[7] <= iVar10) {
            uVar7 = uVar6;
            break;
          }
          iVar10 = iVar10 * 2;
          uVar6 = uVar6 + 1;
        } while ((int)uVar6 < 0xc);
        param_1[0x22] =
             (((uVar7 << 4 | uVar14) << 6 | (uint)*(byte *)((longlong)puVar5 + 3)) << 6 |
             (uint)(byte)puVar5[1]) << 0xe | (uint)*puVar5;
        uVar14 = ((uint)*(byte *)((longlong)param_1 + 0xc1) * 2 | (uint)*(byte *)(param_1 + 0x30))
                 << 2 | uVar7 >> 2;
        param_1[0x23] = uVar14;
        if (*(longlong *)(param_1 + 0x2c) != 0) {
          param_1[0x23] =
               ((((uint)*(byte *)(param_1 + 0x31) << 5 | (uint)*(ushort *)((longlong)param_1 + 0xc2)
                 ) << 5 | (uint)*(byte *)((longlong)*(ushort **)(param_1 + 0x28) + 3)) << 0xe |
               (uint)**(ushort **)(param_1 + 0x28)) << 5 |
               (*(uint *)(*(longlong *)(param_1 + 0x24) + 4) & 2) << 0x16 | uVar14;
        }
      }
    }
    puVar12 = (undefined4 *)0x0;
    *(undefined8 *)(param_1 + 0xe8) = *(undefined8 *)(param_1 + 0x22);
    param_1[0x32] = 0x10001;
    if ((1 < iVar11) && (piVar13[2] != 0)) {
      puVar12 = (undefined4 *)((longlong)piVar13 + (longlong)piVar13[2]);
    }
    *(undefined4 **)(param_1 + 0xc) = puVar12;
    *param_1 = *puVar12;
    *(undefined4 **)(param_1 + 4) = puVar12 + 1;
    *(undefined4 **)(param_1 + 0xe) = param_1 + 0xe6;
    *(undefined4 **)(param_1 + 2) = puVar12;
  }
LAB_1400be19e:
  piVar19 = *(int **)(param_1 + 0xfa);
  if ((piVar19 != (int *)0x0) && (iVar11 = *piVar19, iVar11 != 0)) {
    *(undefined8 *)(param_1 + 0x7e) = 0;
    lVar8 = 0;
    *(undefined8 *)(param_1 + 0x80) = 0;
    *(undefined8 *)(param_1 + 0x82) = 0;
    *(undefined8 *)(param_1 + 0x7c) = 0;
    *(undefined8 *)(param_1 + 0x84) = 0;
    *(undefined8 *)(param_1 + 0x86) = 0;
    *(undefined8 *)(param_1 + 0x88) = 0;
    param_1[0x8a] = 1;
    *(undefined1 *)(param_1 + 0x8b) = 1;
    param_1[0x8c] = 0;
    if ((0 < iVar11) && (piVar19[1] != 0)) {
      lVar8 = (longlong)piVar19 + (longlong)piVar19[1];
    }
    FUN_1402038c0(param_1 + 0x7c,lVar8);
    if (*(undefined2 **)(param_1 + 0x80) != (undefined2 *)0x0) {
      **(undefined2 **)(param_1 + 0x80) = 0x3600;
      if (*(undefined2 **)(param_1 + 0x82) != (undefined2 *)0x0) {
        **(undefined2 **)(param_1 + 0x82) = 0x2420;
      }
      puVar5 = *(ushort **)(param_1 + 0x80);
      if (puVar5 != (ushort *)0x0) {
        uVar14 = 0;
        uVar7 = 0;
        iVar10 = 1;
        uVar6 = 0;
        do {
          if ((int)(uint)puVar5[6] <= iVar10) {
            uVar14 = uVar6;
            break;
          }
          iVar10 = iVar10 * 2;
          uVar6 = uVar6 + 1;
        } while ((int)uVar6 < 0xc);
        iVar10 = 1;
        uVar6 = 0;
        do {
          if ((int)(uint)puVar5[7] <= iVar10) {
            uVar7 = uVar6;
            break;
          }
          iVar10 = iVar10 * 2;
          uVar6 = uVar6 + 1;
        } while ((int)uVar6 < 0xc);
        param_1[0x7c] =
             (((uVar7 << 4 | uVar14) << 6 | (uint)*(byte *)((longlong)puVar5 + 3)) << 6 |
             (uint)(byte)puVar5[1]) << 0xe | (uint)*puVar5;
        uVar14 = ((uint)*(byte *)((longlong)param_1 + 0x229) * 2 | (uint)*(byte *)(param_1 + 0x8a))
                 << 2 | uVar7 >> 2;
        param_1[0x7d] = uVar14;
        if (*(longlong *)(param_1 + 0x86) != 0) {
          param_1[0x7d] =
               ((((uint)*(byte *)(param_1 + 0x8b) << 5 |
                 (uint)*(ushort *)((longlong)param_1 + 0x22a)) << 5 |
                (uint)*(byte *)((longlong)*(ushort **)(param_1 + 0x82) + 3)) << 0xe |
               (uint)**(ushort **)(param_1 + 0x82)) << 5 |
               (*(uint *)(*(longlong *)(param_1 + 0x7e) + 4) & 2) << 0x16 | uVar14;
        }
      }
    }
    *(undefined8 *)(param_1 + 0xf2) = *(undefined8 *)(param_1 + 0x7c);
    if (((2 < iVar11) && (piVar19[3] != 0)) &&
       (piVar19 = (int *)((longlong)piVar19 + (longlong)piVar19[3]), piVar19 != (int *)0x0)) {
      iVar11 = *piVar19;
      lVar8 = 0;
      *(undefined8 *)(param_1 + 0x5a) = 0;
      *(undefined8 *)(param_1 + 0x5c) = 0;
      *(undefined8 *)(param_1 + 0x5e) = 0;
      *(undefined8 *)(param_1 + 0x58) = 0;
      *(undefined8 *)(param_1 + 0x60) = 0;
      *(undefined8 *)(param_1 + 0x62) = 0;
      *(undefined8 *)(param_1 + 100) = 0;
      param_1[0x66] = 1;
      *(undefined1 *)(param_1 + 0x67) = 1;
      param_1[0x68] = 0;
      if ((0 < iVar11) && (piVar19[1] != 0)) {
        lVar8 = (longlong)piVar19 + (longlong)piVar19[1];
      }
      FUN_1402038c0(param_1 + 0x58,lVar8);
      if (*(undefined2 **)(param_1 + 0x5c) != (undefined2 *)0x0) {
        **(undefined2 **)(param_1 + 0x5c) = 0x3000;
        if (*(undefined2 **)(param_1 + 0x5e) != (undefined2 *)0x0) {
          **(undefined2 **)(param_1 + 0x5e) = 0x2400;
        }
        puVar5 = *(ushort **)(param_1 + 0x5c);
        if (puVar5 != (ushort *)0x0) {
          uVar14 = 0;
          uVar7 = 0;
          iVar10 = 1;
          uVar6 = 0;
          do {
            if ((int)(uint)puVar5[6] <= iVar10) {
              uVar14 = uVar6;
              break;
            }
            iVar10 = iVar10 * 2;
            uVar6 = uVar6 + 1;
          } while ((int)uVar6 < 0xc);
          iVar10 = 1;
          uVar6 = 0;
          do {
            if ((int)(uint)puVar5[7] <= iVar10) {
              uVar7 = uVar6;
              break;
            }
            iVar10 = iVar10 * 2;
            uVar6 = uVar6 + 1;
          } while ((int)uVar6 < 0xc);
          param_1[0x58] =
               (((uVar7 << 4 | uVar14) << 6 | (uint)*(byte *)((longlong)puVar5 + 3)) << 6 |
               (uint)(byte)puVar5[1]) << 0xe | (uint)*puVar5;
          uVar14 = ((uint)*(byte *)((longlong)param_1 + 0x199) * 2 | (uint)*(byte *)(param_1 + 0x66)
                   ) << 2 | uVar7 >> 2;
          param_1[0x59] = uVar14;
          if (*(longlong *)(param_1 + 0x62) != 0) {
            param_1[0x59] =
                 ((((uint)*(byte *)(param_1 + 0x67) << 5 |
                   (uint)*(ushort *)((longlong)param_1 + 0x19a)) << 5 |
                  (uint)*(byte *)((longlong)*(ushort **)(param_1 + 0x5e) + 3)) << 0xe |
                 (uint)**(ushort **)(param_1 + 0x5e)) << 5 |
                 (*(uint *)(*(longlong *)(param_1 + 0x5a) + 4) & 2) << 0x16 | uVar14;
          }
        }
      }
      lVar8 = 0;
      *(undefined8 *)(param_1 + 0xee) = *(undefined8 *)(param_1 + 0x58);
      *(undefined8 *)(param_1 + 0x6c) = 0;
      *(undefined8 *)(param_1 + 0x6e) = 0;
      *(undefined8 *)(param_1 + 0x70) = 0;
      *(undefined8 *)(param_1 + 0x6a) = 0;
      *(undefined8 *)(param_1 + 0x72) = 0;
      *(undefined8 *)(param_1 + 0x74) = 0;
      *(undefined8 *)(param_1 + 0x76) = 0;
      param_1[0x78] = 1;
      *(undefined1 *)(param_1 + 0x79) = 1;
      param_1[0x7a] = 0;
      if ((1 < iVar11) && (piVar19[2] != 0)) {
        lVar8 = (longlong)piVar19 + (longlong)piVar19[2];
      }
      FUN_1402038c0(param_1 + 0x6a,lVar8);
      if (*(undefined2 **)(param_1 + 0x6e) != (undefined2 *)0x0) {
        **(undefined2 **)(param_1 + 0x6e) = 0x3000;
        if (*(undefined2 **)(param_1 + 0x70) != (undefined2 *)0x0) {
          **(undefined2 **)(param_1 + 0x70) = 0x2400;
        }
        puVar5 = *(ushort **)(param_1 + 0x6e);
        if (puVar5 != (ushort *)0x0) {
          uVar14 = 0;
          iVar11 = 1;
          uVar7 = 0;
          do {
            if ((int)(uint)puVar5[6] <= iVar11) {
              uVar14 = uVar7;
              break;
            }
            iVar11 = iVar11 * 2;
            uVar7 = uVar7 + 1;
          } while ((int)uVar7 < 0xc);
          uVar7 = 0;
          do {
            if ((int)(uint)puVar5[7] <= iVar18) {
              uVar15 = uVar7;
              break;
            }
            iVar18 = iVar18 * 2;
            uVar7 = uVar7 + 1;
          } while ((int)uVar7 < 0xc);
          param_1[0x6a] =
               (((uVar15 << 4 | uVar14) << 6 | (uint)*(byte *)((longlong)puVar5 + 3)) << 6 |
               (uint)(byte)puVar5[1]) << 0xe | (uint)*puVar5;
          uVar15 = ((uint)*(byte *)((longlong)param_1 + 0x1e1) * 2 | (uint)*(byte *)(param_1 + 0x78)
                   ) << 2 | uVar15 >> 2;
          param_1[0x6b] = uVar15;
          if (*(longlong *)(param_1 + 0x74) != 0) {
            param_1[0x6b] =
                 ((((uint)*(byte *)(param_1 + 0x79) << 5 |
                   (uint)*(ushort *)((longlong)param_1 + 0x1e2)) << 5 |
                  (uint)*(byte *)((longlong)*(ushort **)(param_1 + 0x70) + 3)) << 0xe |
                 (uint)**(ushort **)(param_1 + 0x70)) << 5 |
                 (*(uint *)(*(longlong *)(param_1 + 0x6c) + 4) & 2) << 0x16 | uVar15;
          }
        }
      }
      *(undefined8 *)(param_1 + 0xf0) = *(undefined8 *)(param_1 + 0x6a);
    }
  }
  return;
}

