/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140127650; RVA 0x127650
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140127650(uint *param_1,undefined8 *param_2,undefined1 param_3)

{
  char cVar1;
  uint uVar2;
  float *pfVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined1 auVar6 [16];
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  short sVar11;
  bool bVar12;
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  
  uVar2 = param_1[0x2a];
  if ((uVar2 >> 9 & 1) == 0) {
    return;
  }
  if (param_2 == (undefined8 *)0x0) {
    return;
  }
  pfVar3 = (float *)*param_2;
  cVar1 = *(char *)(pfVar3 + 6);
  if (cVar1 == '\0') {
    if (*(char *)((longlong)pfVar3 + 0x19) != *(char *)(*(longlong *)(param_1 + 0x22) + 0x20)) {
      return;
    }
    bVar12 = (int)((float)*(byte *)((longlong)param_1 + 0xb3) * *pfVar3) ==
             *(int *)(*(longlong *)(*(longlong *)(param_1 + 0x22) + 0x10) + 0x38c);
LAB_1401277db:
    if (!bVar12) {
      return;
    }
  }
  else {
    if (cVar1 != '\x01') {
      if (cVar1 == '\x02') {
        if (*(byte *)((longlong)pfVar3 + 0x1b) == 0xff) {
          return;
        }
        lVar4 = *(longlong *)
                 (**(longlong **)(param_1 + 0x1e) +
                 (ulonglong)*(byte *)((longlong)pfVar3 + 0x1b) * 8);
        if (*(char *)(pfVar3 + 7) == -1) {
          bVar12 = (*(byte *)(lVar4 + 0x120) & 2) == 0;
        }
        else {
          bVar12 = (*(byte *)((ulonglong)*(byte *)(pfVar3 + 7) * 0x520 + 0x1f0 +
                             *(longlong *)(lVar4 + 0x110)) & 2) == 0;
        }
      }
      else {
        if (cVar1 != '\x03') {
          return;
        }
        lVar4 = (*(undefined8 **)(param_1 + 0x1c))[3];
        if (((lVar4 == 0) ||
            (puVar5 = (undefined8 *)**(undefined8 **)(param_1 + 0x1c), puVar5 == (undefined8 *)0x0))
           || (*(ushort *)*puVar5 <= *(ushort *)((longlong)pfVar3 + 0x16))) {
          sVar11 = 0;
        }
        else {
          sVar11 = *(short *)(lVar4 + (ulonglong)*(ushort *)((longlong)pfVar3 + 0x16) * 2);
        }
        bVar12 = sVar11 == *(short *)(pfVar3 + 5);
      }
      goto LAB_1401277db;
    }
    auVar6 = *(undefined1 (*) [16])
              (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x1e) + 0x110) + 600);
    fVar7 = pfVar3[1] - auVar6._0_4_;
    auVar13 = vshufps_avx(auVar6,auVar6,0x55);
    fVar8 = pfVar3[2] - auVar13._0_4_;
    auVar13 = vshufps_avx(auVar6,auVar6,0xaa);
    fVar9 = pfVar3[3] - auVar13._0_4_;
    auVar6 = vshufps_avx(auVar6,auVar6,0xff);
    fVar10 = DAT_1402d22d0 - auVar6._0_4_;
    if (pfVar3[4] < SQRT(fVar10 * fVar10 + fVar9 * fVar9 + fVar8 * fVar8 + fVar7 * fVar7)) {
      return;
    }
  }
  *(byte *)((longlong)param_1 + 0xae) = *(byte *)((longlong)param_1 + 0xae) | 4;
  cVar1 = *(char *)((longlong)pfVar3 + 0x1a);
  if (cVar1 == '\0') {
    param_1[0x2a] = uVar2 & 0xffefffff;
    if ((*(byte *)((longlong)pfVar3 + 0x1d) & 1) != 0) {
      param_1[0x2a] = uVar2 & 0xffcfffff | 0x100000;
      if (((1 < *(byte *)(*(longlong *)(param_1 + 0x1e) + 0x37)) &&
          (*(char *)(pfVar3 + 6) == '\x03')) && (*(short *)(pfVar3 + 5) == 2)) {
        param_1[0x2a] = uVar2 & 0xffcfffff | 0x300000;
      }
    }
  }
  else {
    if (cVar1 == '\x01') {
      *(undefined1 *)(param_1 + 0x2d) = 1;
      goto LAB_14012783f;
    }
    if (cVar1 == '\x02') {
      auVar6 = vcmpss_avx(ZEXT816(0),ZEXT416(*param_1),2);
      auVar13 = ZEXT416(DAT_1402d2edc);
      auVar14 = ZEXT416(DAT_1402d2bd0);
      auVar6 = vblendvps_avx(auVar13,auVar14,auVar6);
      *param_1 = auVar6._0_4_;
      auVar6 = vcmpss_avx(ZEXT816(0),ZEXT416(param_1[2]),2);
      auVar6 = vblendvps_avx(auVar13,auVar14,auVar6);
      param_1[2] = auVar6._0_4_;
      *(undefined1 *)(param_1 + 0x2d) = 2;
      goto LAB_14012783f;
    }
  }
  *(undefined1 *)(param_1 + 0x2d) = 0;
LAB_14012783f:
  param_1[0x2a] = param_1[0x2a] & 0xffffff7f;
  *(undefined1 *)(param_1 + 0x2c) = param_3;
  *(undefined1 *)((longlong)param_1 + 0xaf) = 0;
  return;
}

