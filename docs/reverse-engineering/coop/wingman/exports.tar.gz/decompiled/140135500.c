/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140135500; RVA 0x135500
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140135500(longlong param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  byte bVar4;
  uint uVar5;
  undefined8 *puVar6;
  float *pfVar7;
  float fVar8;
  float fVar9;
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  float *pfVar12;
  int iVar13;
  longlong *plVar14;
  float *pfVar15;
  longlong lVar16;
  int iVar17;
  undefined1 extraout_var [56];
  undefined1 auVar18 [64];
  undefined1 extraout_var_00 [56];
  undefined1 auVar19 [64];
  float fVar20;
  float fVar21;
  float fVar22;
  uint uVar23;
  float fVar24;
  int local_res10;
  longlong local_res20;
  float local_168;
  float local_164;
  float local_160;
  float local_15c;
  float local_158;
  float local_154;
  float local_150;
  float local_14c;
  float local_148;
  float local_144;
  float local_140;
  float local_13c;
  float local_138;
  float local_134;
  float local_130;
  float local_12c;
  float local_128;
  float local_124;
  float local_120;
  float local_11c;
  float local_118;
  float local_114;
  float local_110;
  float local_10c;
  float local_108;
  float local_104;
  float local_100;
  float local_fc;
  float local_f8;
  float local_f4;
  float local_f0;
  float local_ec;
  longlong *local_e8;
  
  uVar5 = *(uint *)(param_1 + 0x120);
  if ((uVar5 & 1) == 0) {
    *(uint *)(param_1 + 0x120) = uVar5 & 0xfffffffb;
    return;
  }
  if (*(char *)(**(longlong **)(param_1 + 0x130) + 0xf) == '\0') {
    if (((byte)uVar5 & 6) == 2) {
      iVar17 = 0;
      *(uint *)(param_1 + 0x120) = uVar5 | 4;
      if (0 < *(int *)(param_1 + 0x118)) {
        lVar16 = 0;
        do {
          iVar17 = iVar17 + 1;
          *(undefined2 *)(lVar16 + 0x224 + *(longlong *)(param_1 + 0x110)) = 0xffff;
          lVar16 = lVar16 + 0x520;
        } while (iVar17 < *(int *)(param_1 + 0x118));
        return;
      }
    }
  }
  else {
    puVar6 = *(undefined8 **)(param_1 + 0x140);
    iVar17 = 0;
    bVar4 = *(byte *)((longlong)puVar6 + 0x37);
    if ((uVar5 & 4) == 0) {
      iVar13 = 0;
      if (bVar4 != 0) {
        plVar14 = (longlong *)*puVar6;
        pfVar15 = (float *)(param_1 + 0x124);
        while (*(float *)**(undefined8 **)(*plVar14 + 0x130) <= *pfVar15) {
          iVar13 = iVar13 + 1;
          pfVar15 = pfVar15 + 1;
          plVar14 = plVar14 + 1;
          if ((int)(uint)bVar4 <= iVar13) {
            return;
          }
        }
        *(uint *)(param_1 + 0x120) = uVar5 | 4;
        if (0 < *(int *)(param_1 + 0x118)) {
          lVar16 = 0;
          do {
            iVar17 = iVar17 + 1;
            *(undefined2 *)(lVar16 + 0x224 + *(longlong *)(param_1 + 0x110)) = 0xffff;
            lVar16 = lVar16 + 0x520;
          } while (iVar17 < *(int *)(param_1 + 0x118));
          return;
        }
      }
    }
    else {
      local_res10 = 0;
      if (bVar4 != 0) {
        local_e8 = (longlong *)*puVar6;
        local_res20 = 0x20c;
        fVar21 = 0.0;
        fVar22 = DAT_1402d22d0;
        uVar23 = DAT_1402d3770;
        fVar24 = DAT_1402d2bf4;
        do {
          fVar20 = *(float *)**(undefined8 **)(*local_e8 + 0x130);
          if (*(float *)(local_res20 + -0xe8 + param_1) <= fVar20) {
            return;
          }
          iVar17 = *(int *)(param_1 + 0x118);
          iVar13 = 0;
          if (0 < iVar17) {
            lVar16 = 0;
            pfVar15 = (float *)(*(longlong *)(param_1 + 0x110) + 0x264);
            pfVar12 = (float *)(*(longlong *)(param_1 + 0x110) + local_res20);
            do {
              if (*pfVar12 <= fVar20) {
                return;
              }
              auVar18._0_8_ =
                   FUN_14026f3f3(*(undefined4 *)(param_1 + 0x1c),*(undefined4 *)(param_1 + 0x18));
              auVar18._8_56_ = extraout_var;
              auVar10 = vpermilps_avx(auVar18._0_16_,1);
              auVar11 = vpermilps_avx(auVar18._0_16_,0xe);
              local_148 = (float)auVar18._0_8_;
              local_160 = (float)((uint)local_148 ^ uVar23);
              local_168 = auVar10._0_4_;
              auVar10 = vpermilps_avx(auVar11,1);
              local_110 = auVar11._0_4_;
              local_104 = (float)((uint)local_110 ^ uVar23);
              local_114 = auVar10._0_4_;
              local_164 = fVar21;
              local_15c = fVar21;
              local_158 = fVar21;
              local_154 = fVar22;
              local_150 = fVar21;
              local_14c = fVar21;
              local_144 = fVar21;
              local_140 = local_168;
              local_13c = fVar21;
              local_138 = fVar21;
              local_134 = fVar21;
              local_130 = fVar21;
              local_12c = fVar22;
              local_128 = fVar22;
              local_124 = fVar21;
              local_120 = fVar21;
              local_11c = fVar21;
              local_118 = fVar21;
              local_10c = fVar21;
              local_108 = fVar21;
              local_100 = local_114;
              local_fc = fVar21;
              local_f8 = fVar21;
              local_f4 = fVar21;
              local_f0 = fVar21;
              local_ec = fVar22;
              FUN_140005940(&local_168,&local_168,&local_128);
              auVar19._0_8_ = FUN_14026f3b0(*(undefined4 *)(param_1 + 0x20));
              auVar19._8_56_ = extraout_var_00;
              auVar10 = vpermilps_avx(auVar19._0_16_,1);
              local_124 = (float)auVar19._0_8_;
              local_118 = (float)((uint)local_124 ^ uVar23);
              local_128 = auVar10._0_4_;
              local_114 = local_128;
              local_110 = fVar21;
              local_104 = fVar21;
              local_100 = fVar22;
              FUN_140005940(&local_168,&local_168,&local_128);
              pfVar7 = *(float **)(lVar16 + *(longlong *)(*(longlong *)(param_1 + 0x130) + 0x10));
              fVar1 = *pfVar7;
              fVar2 = pfVar7[1];
              fVar3 = pfVar7[2];
              fVar8 = (fVar2 * local_158 + fVar1 * local_168 + fVar3 * local_148 +
                      local_138 + *(float *)(param_1 + 8)) - pfVar15[-3];
              fVar9 = (fVar2 * local_150 + fVar1 * local_160 + fVar3 * local_140 +
                      local_130 + *(float *)(param_1 + 0x10)) - pfVar15[-1];
              fVar1 = (fVar2 * local_14c + fVar1 * local_15c + fVar3 * local_13c + local_12c) -
                      *pfVar15;
              if (fVar24 <= fVar1 * fVar1 + fVar9 * fVar9 + fVar8 * fVar8) {
                return;
              }
              iVar13 = iVar13 + 1;
              pfVar12 = pfVar12 + 0x148;
              lVar16 = lVar16 + 0x10;
              pfVar15 = pfVar15 + 0x148;
            } while (iVar13 < iVar17);
          }
          local_res10 = local_res10 + 1;
          local_e8 = local_e8 + 1;
          local_res20 = local_res20 + 4;
        } while (local_res10 < (int)(uint)bVar4);
      }
      *(uint *)(param_1 + 0x120) = uVar5 & 0xfffffffb;
    }
  }
  return;
}

