/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fc120; RVA 0xfc120
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400fc120(longlong param_1,undefined8 *param_2)

{
  byte *pbVar1;
  uint *puVar2;
  float fVar3;
  float fVar4;
  undefined1 uVar5;
  undefined1 uVar6;
  undefined1 uVar7;
  undefined2 uVar8;
  undefined2 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  uint uVar12;
  float *pfVar13;
  longlong lVar14;
  longlong lVar15;
  longlong *plVar16;
  undefined1 auVar17 [16];
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  uint uVar23;
  byte bVar24;
  float fVar25;
  byte bVar26;
  int iVar27;
  longlong lVar28;
  undefined1 (*pauVar29) [16];
  float *pfVar30;
  int iVar31;
  float fVar32;
  undefined1 auVar33 [64];
  undefined1 auVar34 [64];
  undefined1 auVar35 [64];
  float fVar36;
  float fVar37;
  undefined1 auVar38 [16];
  undefined8 local_128;
  undefined8 uStack_120;
  undefined1 local_118 [8];
  float fStack_110;
  undefined1 local_108 [8];
  float fStack_100;
  float fStack_fc;
  undefined1 local_f8 [8];
  float fStack_f0;
  undefined1 local_e8 [8];
  float fStack_e0;
  float fStack_dc;
  float local_d8;
  float local_d4;
  float local_d0;
  undefined4 local_cc;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  
  pfVar13 = (float *)*param_2;
  lVar14 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  bVar26 = *(byte *)(pfVar13 + 0xc) & 4;
  lVar15 = *(longlong *)(lVar14 + 0x1b8);
  *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xfffe3ff7 | 0x20;
  *(undefined4 *)(param_1 + 0x394) = 0;
  *(undefined4 *)(param_1 + 0x348) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x350) = 0x48800000;
  *(undefined4 *)(param_1 + 0x34c) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x354) = 0x48800000;
  if (*(longlong *)(param_1 + 0x338) != 0) {
    lVar28 = *(longlong *)(*(longlong *)(param_1 + 0x338) + 0x66ee0);
    *(undefined8 *)(lVar28 + 0x1bc48) = 0;
    *(undefined8 *)(lVar28 + 0x1bc50) = 0;
    *(undefined8 *)(lVar28 + 0x1bc58) = 0;
    *(undefined8 *)(lVar28 + 0x1bc60) = 0;
    *(undefined8 *)(lVar28 + 0x1bc68) = 0;
    *(undefined8 *)(lVar28 + 0x1bc70) = 0;
    *(undefined8 *)(lVar28 + 0x1bc78) = 0;
    *(undefined8 *)(lVar28 + 0x1bc80) = 0;
    *(int *)(lVar28 + 0x1bc8c) = *(int *)(lVar28 + 0x1bc8c) + 1;
    *(undefined4 *)(lVar28 + 0x1bc88) = 0;
    if (0xe < *(int *)(lVar28 + 0x1bc8c)) {
      *(undefined4 *)(lVar28 + 0x1bc8c) = 0;
    }
  }
  *(undefined2 *)(param_1 + 0x3c0) = 0xffff;
  *(undefined4 *)(param_1 + 0x90) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x94) = 0xc61c4000;
  *(undefined4 *)(param_1 + 0x98) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x9c) = 0x3f800000;
  *(undefined4 *)(param_1 + 0xa0) = 0x48800000;
  *(undefined4 *)(param_1 + 0xa4) = 0x461c4000;
  *(undefined4 *)(param_1 + 0xa8) = 0x48800000;
  *(undefined4 *)(param_1 + 0xac) = 0x3f800000;
  fVar32 = pfVar13[6];
  fVar3 = pfVar13[9];
  auVar17 = vcmpss_avx(ZEXT416((uint)fVar32),ZEXT416((uint)fVar3),1);
  pfVar30 = pfVar13 + 9;
  if (fVar3 <= fVar32) {
    pfVar30 = pfVar13 + 6;
  }
  auVar17 = vblendvps_avx(ZEXT416((uint)fVar3),ZEXT416((uint)fVar32),auVar17);
  *(int *)(param_1 + 0x90) = auVar17._0_4_;
  *(float *)(param_1 + 0xa0) = *pfVar30;
  fVar32 = pfVar13[7];
  fVar3 = pfVar13[10];
  auVar17 = vcmpss_avx(ZEXT416((uint)fVar32),ZEXT416((uint)fVar3),1);
  pfVar30 = pfVar13 + 10;
  if (fVar3 <= fVar32) {
    pfVar30 = pfVar13 + 7;
  }
  auVar17 = vblendvps_avx(ZEXT416((uint)fVar3),ZEXT416((uint)fVar32),auVar17);
  *(int *)(param_1 + 0x94) = auVar17._0_4_;
  *(float *)(param_1 + 0xa4) = *pfVar30;
  auVar17 = vminss_avx(ZEXT416((uint)pfVar13[8]),ZEXT416((uint)pfVar13[0xb]));
  lVar28 = 0x2c;
  if (pfVar13[0xb] <= pfVar13[8]) {
    lVar28 = 0x20;
  }
  *(int *)(param_1 + 0x98) = auVar17._0_4_;
  *(undefined4 *)(param_1 + 0xa8) = *(undefined4 *)(lVar28 + (longlong)pfVar13);
  local_128 = pfVar13;
  if (*(longlong *)(param_1 + 0x340) != 0) {
    FUN_1400d1560(*(longlong *)(param_1 + 0x340),((uint)pfVar13[0xc] & 1) != 0);
  }
  auVar17 = vpcmpeqd_avx(ZEXT116(*(byte *)(pfVar13 + 0xc) & 8),SUB6416(ZEXT464(0),0));
  auVar38 = ZEXT416(DAT_1402d22d0);
  auVar17 = vblendvps_avx(auVar38,ZEXT816(0),auVar17);
  *(int *)(param_1 + 0x398) = auVar17._0_4_;
  *(int *)(param_1 + 900) = (int)((float)*(byte *)(param_1 + 0x3d1) * *pfVar13);
  auVar33 = ZEXT1664(auVar38);
  FUN_1400d5780(*(undefined8 *)(param_1 + 0x340));
  lVar28 = 0;
  if (lVar15 != 0) {
    uVar8 = *(undefined2 *)(lVar15 + 0x272a);
    uVar5 = *(undefined1 *)(lVar15 + 0x272c);
    uVar6 = *(undefined1 *)(lVar15 + 0x272d);
    uVar7 = *(undefined1 *)(lVar15 + 0x272e);
    uVar10 = *(undefined4 *)(lVar14 + 0x420);
    uVar9 = *(undefined2 *)(lVar15 + 0x2728);
    uVar11 = *(undefined4 *)(lVar15 + 0x2784);
    FUN_140102ab0(lVar15);
    *(undefined2 *)(lVar15 + 0x272a) = uVar8;
    *(undefined2 *)(lVar15 + 0x2728) = uVar9;
    *(undefined1 *)(lVar15 + 0x272c) = uVar5;
    *(undefined1 *)(lVar15 + 0x272d) = uVar6;
    *(undefined1 *)(lVar15 + 0x272e) = uVar7;
    *(undefined4 *)(lVar15 + 0x2784) = uVar11;
    FUN_140114c30(lVar14);
    *(undefined4 *)(lVar14 + 0x420) = uVar10;
    *(ushort *)(lVar14 + 0x428) = (ushort)*(byte *)(param_1 + 0x3e2);
    *(undefined2 *)(lVar15 + 0x208e) = *(undefined2 *)(param_1 + 0x3c2);
    *(undefined1 *)(lVar15 + 0x2099) = *(undefined1 *)(param_1 + 0x3e4);
    *(undefined1 *)(lVar15 + 0x209a) = *(undefined1 *)(param_1 + 0x3e5);
    *(byte *)(lVar15 + 0x1863) = *(byte *)(lVar15 + 0x1863) | 1;
    *(undefined4 *)(lVar15 + 0x185c) = 0;
    uVar12 = *(uint *)(lVar15 + 0x2058);
    *(byte *)(lVar15 + 0x1da7) = *(byte *)(lVar15 + 0x1da7) | 1;
    *(undefined8 *)(lVar15 + 0x1d78) = 0;
    uVar23 = uVar12 & 0xffffffef;
    *(ushort *)(lVar15 + 0x1c20) = *(ushort *)(lVar15 + 0x1c20) | 1;
    *(uint *)(lVar15 + 0x2058) = uVar23 | 0x1020;
    if ((*(byte *)((longlong)local_128 + 0x31) == 0xff) ||
       (*(byte *)((longlong)local_128 + 0x32) == 0xff)) {
      lVar28 = 0;
    }
    else {
      lVar28 = (ulonglong)*(byte *)((longlong)local_128 + 0x32) * 0x520 +
               *(longlong *)
                (*(longlong *)
                  (**(longlong **)(param_1 + 0x2f8) +
                  (ulonglong)*(byte *)((longlong)local_128 + 0x31) * 8) + 0x110);
    }
    *(longlong *)(lVar15 + 0x2048) = lVar28;
    *(longlong *)(lVar15 + 0x1638) = lVar28;
    uVar23 = uVar23 | 0x1120;
    if (bVar26 == 0) {
      uVar23 = uVar12 & 0xfffffeef | 0x1020;
    }
    *(uint *)(lVar15 + 0x2058) = uVar23;
    bVar24 = *(byte *)(lVar15 + 0x1677) | 2;
    if (bVar26 == 0) {
      bVar24 = *(byte *)(lVar15 + 0x1677) & 0xfd;
    }
    *(byte *)(lVar15 + 0x1677) = bVar24;
    switch(*(undefined1 *)(param_1 + 0x3db)) {
    default:
      iVar31 = 1;
      break;
    case 2:
      iVar31 = 0x200;
      break;
    case 3:
    case 4:
    case 5:
      iVar31 = 0x800;
    }
    if (bVar26 == 0) {
      if (lVar28 != 0) {
        local_128 = _DAT_1402d2f60;
        uStack_120 = _UNK_1402d2f68;
        iVar27 = FUN_140242630();
        fVar37 = (float)(iVar27 % (iVar31 * 2) - iVar31);
        FUN_140203050(&local_128,lVar28 + 0x268,&local_128);
        _local_108 = ZEXT816(0);
        _local_118 = ZEXT816(0);
        _local_f8 = ZEXT816(0);
        _local_e8 = _local_108;
        FUN_140202920(local_118,&local_128);
        fVar22 = DAT_1402d2b4c;
        fVar4 = DAT_1402d2a6c * (float)local_108._4_4_;
        fVar20 = DAT_1402d2b4c * (float)local_f8._4_4_;
        fVar32 = *(float *)(lVar28 + 0x25c);
        fVar18 = DAT_1402d2a6c * fStack_100;
        fVar21 = DAT_1402d2b4c * fStack_f0;
        fVar3 = *(float *)(lVar28 + 0x260);
        fVar19 = DAT_1402d2a6c * fStack_fc;
        *(float *)(lVar14 + 600) =
             local_f8._0_4_ * DAT_1402d2b4c +
             fVar37 * local_118._0_4_ + DAT_1402d2a6c * (float)local_108._0_4_ +
             (float)local_e8._0_4_ + *(float *)(lVar28 + 600);
        *(float *)(lVar14 + 0x25c) =
             fVar20 + fVar37 * (float)local_118._4_4_ + fVar4 + (float)local_e8._4_4_ + fVar32;
        *(float *)(lVar14 + 0x260) = fVar21 + fVar37 * fStack_110 + fVar18 + fStack_e0 + fVar3;
        *(float **)(lVar14 + 0x268) = local_128;
        *(undefined8 *)(lVar14 + 0x270) = uStack_120;
        auVar17 = vshufps_avx(_local_118,_local_118,0xff);
        auVar38 = vshufps_avx(_local_f8,_local_f8,0xff);
        *(float *)(lVar14 + 0x264) =
             auVar38._0_4_ * fVar22 + fVar37 * auVar17._0_4_ + fVar19 + fStack_dc;
        *(uint *)(lVar15 + 0xd48) = *(uint *)(lVar15 + 0xd48) & 0xfffffcff;
        *(undefined4 *)(param_1 + 0x39c) = 0;
      }
    }
    else if (lVar28 != 0) {
      local_128 = _DAT_1402d2f60;
      uStack_120 = _UNK_1402d2f68;
      iVar27 = FUN_140242630();
      fVar36 = (float)(iVar27 % (iVar31 * 2) - iVar31);
      FUN_140203050(&local_128,lVar28 + 0x268,&local_128);
      _local_108 = ZEXT816(0);
      _local_118 = ZEXT816(0);
      _local_f8 = ZEXT816(0);
      _local_e8 = _local_108;
      FUN_140202920(local_118,&local_128);
      fVar25 = DAT_1402d2b00;
      fVar37 = DAT_1402d2a54;
      fVar18 = DAT_1402d2a54 * (float)local_108._4_4_;
      fVar21 = DAT_1402d2b00 * (float)local_f8._4_4_;
      fVar32 = *(float *)(lVar28 + 0x25c);
      fVar19 = DAT_1402d2a54 * fStack_100;
      fVar22 = DAT_1402d2b00 * fStack_f0;
      fVar3 = *(float *)(lVar28 + 0x260);
      fVar20 = DAT_1402d2a54 * (float)local_108._0_4_;
      fVar4 = *(float *)(lVar28 + 600);
      *(float **)(lVar14 + 0x268) = local_128;
      *(undefined8 *)(lVar14 + 0x270) = uStack_120;
      uStack_b0 = _UNK_1402d2f58;
      local_b8 = _DAT_1402d2f50;
      *(float *)(lVar14 + 600) =
           local_f8._0_4_ * fVar25 + fVar36 * local_118._0_4_ + fVar20 +
           (float)local_e8._0_4_ + fVar4;
      *(float *)(lVar14 + 0x25c) =
           fVar21 + fVar36 * (float)local_118._4_4_ + fVar18 + (float)local_e8._4_4_ + fVar32;
      *(float *)(lVar14 + 0x260) = fVar22 + fVar36 * fStack_110 + fVar19 + fStack_e0 + fVar3;
      auVar17 = vshufps_avx(_local_118,_local_118,0xff);
      auVar38 = vshufps_avx(_local_f8,_local_f8,0xff);
      *(float *)(lVar14 + 0x264) =
           auVar38._0_4_ * fVar25 + fVar36 * auVar17._0_4_ + fVar37 * fStack_fc + fStack_dc;
      *(uint *)(lVar15 + 0xd48) = *(uint *)(lVar15 + 0xd48) & 0xfffffdff;
      *(uint *)(lVar15 + 0xd48) = *(uint *)(lVar15 + 0xd48) | 0x100;
      _local_118 = ZEXT816(0);
      _local_108 = ZEXT816(0);
      _local_e8 = ZEXT816(0);
      _local_f8 = _local_118;
      FUN_140202920(local_118,&local_b8);
      auVar17 = _local_e8;
      fVar32 = fStack_e0;
      local_e8._0_4_ = (float)local_e8._0_4_ + DAT_1402d26d8;
      auVar38 = _local_e8;
      fStack_dc = auVar17._12_4_;
      local_e8 = auVar38._0_8_;
      fStack_e0 = fVar32 + DAT_1402d2e6c;
      FUN_140202230(local_118,local_118,lVar28 + 0x268);
      auVar17 = _local_e8;
      local_d8 = (float)local_e8._0_4_ + *(float *)(lVar28 + 600);
      fVar32 = (float)local_e8._4_4_ + *(float *)(lVar28 + 0x25c);
      local_d0 = fStack_e0 + *(float *)(lVar28 + 0x260);
      local_d4 = fVar32 + DAT_1402d271c;
      plVar16 = *(longlong **)(lVar28 + 0x390);
      local_e8._4_4_ = fVar32;
      local_e8._0_4_ = local_d8;
      fStack_dc = auVar17._12_4_;
      fStack_e0 = local_d0;
      local_cc = auVar33._0_4_;
      local_128 = (float *)CONCAT44(fVar32 - DAT_1402d271c,local_d8);
      uStack_120 = CONCAT44(local_cc,local_d0);
      FUN_140202920(local_118,lVar28 + 0x268);
      auVar17 = _local_e8;
      local_e8._4_4_ = (float)local_e8._4_4_ + *(float *)(lVar28 + 0x25c);
      local_e8._0_4_ = (float)local_e8._0_4_ + *(float *)(lVar28 + 600);
      fStack_dc = auVar17._12_4_;
      fStack_e0 = fStack_e0 + *(float *)(lVar28 + 0x260);
      local_c8 = 0;
      uStack_c0 = 0;
      (**(code **)(*plVar16 + 0x120))(plVar16,&local_c8,local_118,&local_d8,&local_128);
      *(undefined4 *)(param_1 + 0x39c) = local_c8._4_4_;
      (**(code **)(*plVar16 + 0x90))(plVar16,0);
    }
    auVar17 = vcvtdq2ps_avx(ZEXT116(*(byte *)(lVar15 + 0x1674)));
    auVar35 = ZEXT1664(auVar17);
    auVar38 = vcvtdq2ps_avx(ZEXT216(*(ushort *)(lVar15 + 0x1444)));
    auVar34 = ZEXT1664(auVar38);
    auVar33 = ZEXT464((uint)((DAT_1402d2140 / auVar17._0_4_) * auVar38._0_4_));
    fVar32 = (float)FUN_140128d90(*(undefined4 *)(lVar15 + 0x15b4));
    *(float *)(lVar15 + 0x1640) =
         auVar34._0_4_ * (DAT_1402d235c / auVar35._0_4_) +
         -(auVar33._0_4_ * SQRT(fVar32 / *(float *)(lVar15 + 0x1648))) + auVar33._0_4_;
    FUN_14010baa0(lVar15);
    *(uint *)(lVar14 + 0x1f0) = *(uint *)(lVar14 + 0x1f0) | 3;
  }
  if (*(longlong *)(param_1 + 0x308) != 0) {
    FUN_1401a7df0(*(longlong *)(param_1 + 0x308),0);
    FUN_1401a5fc0(*(undefined8 *)(param_1 + 0x308));
    *(byte *)(param_1 + 0x3d9) = *(byte *)(param_1 + 0x3d9) & 0xfb;
    if (lVar28 != 0) {
      pauVar29 = (undefined1 (*) [16])FUN_140101cc0(param_1,&local_b8);
      auVar17 = *pauVar29;
      fVar32 = auVar17._0_4_ - *(float *)(lVar28 + 600);
      auVar38 = vshufps_avx(auVar17,auVar17,0xaa);
      fVar3 = auVar38._0_4_ - *(float *)(lVar28 + 0x260);
      auVar38 = vshufps_avx(auVar17,auVar17,0x55);
      fVar4 = auVar38._0_4_ - *(float *)(lVar28 + 0x25c);
      auVar17 = vshufps_avx(auVar17,auVar17,0xff);
      fVar18 = auVar17._0_4_ - *(float *)(lVar28 + 0x264);
      *(char *)(param_1 + 0x3d7) =
           (char)(int)(SQRT(fVar18 * fVar18 + fVar3 * fVar3 + fVar4 * fVar4 + fVar32 * fVar32) *
                      DAT_1402d1dac);
    }
    *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1);
    *(undefined1 *)(param_1 + 0x3d7) = 0xff;
    *(undefined1 *)(param_1 + 0x3d9) = 0;
  }
  lVar14 = *(longlong *)(param_1 + 800);
  if (lVar14 != 0) {
    *(byte *)(lVar14 + 0x2b) = *(byte *)(lVar14 + 0x2b) | 2;
    if (*(longlong *)(lVar14 + 0x10) != 0) {
      puVar2 = (uint *)(*(longlong *)(lVar14 + 0x10) + 0x56c);
      *puVar2 = *puVar2 | 1;
    }
    if (*(longlong *)(lVar14 + 0x18) != 0) {
      pbVar1 = (byte *)(*(longlong *)(lVar14 + 0x18) + 0x23);
      *pbVar1 = *pbVar1 | 4;
    }
    lVar14 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
    if (lVar14 != 0) {
      puVar2 = (uint *)(lVar14 + 0x40);
      *puVar2 = *puVar2 | 0x4000000;
    }
  }
  *(undefined1 *)(param_1 + 0x3e9) = 4;
  *(undefined4 *)(param_1 + 0x378) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 1;
  return;
}

