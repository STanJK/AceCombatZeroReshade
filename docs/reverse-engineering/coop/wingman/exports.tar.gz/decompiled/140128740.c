/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140128740; RVA 0x128740
 * Ghidra-generated research pseudocode, inferred types, not original source. */

ushort * FUN_140128740(longlong param_1,ushort *param_2)

{
  byte bVar1;
  ushort uVar2;
  longlong lVar3;
  ulonglong uVar4;
  ushort *puVar5;
  undefined8 *puVar6;
  
  lVar3 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 8);
  *(char *)(param_1 + 0xaf) = *(char *)(param_1 + 0xaf) + '\x01';
  puVar6 = (undefined8 *)
           ((ulonglong)*(byte *)(param_1 + 0xaf) * 0x40 +
           *(longlong *)(lVar3 + 8 + (ulonglong)*(byte *)(param_1 + 0xb0) * 0x10));
  puVar5 = (ushort *)*puVar6;
  if ((char)*puVar5 == '\x02') {
    if (puVar6[3] == 0) goto LAB_1401287b5;
    puVar5 = (ushort *)FUN_140126b60(param_1);
  }
  else {
    if (((char)*puVar5 != '\x03') || (puVar6[4] == 0)) goto LAB_1401287b5;
    puVar5 = (ushort *)FUN_140126ec0(param_1);
  }
  *(byte *)(param_1 + 0xae) = *(byte *)(param_1 + 0xae) | 1;
LAB_1401287b5:
  puVar6 = *(undefined8 **)(param_1 + 0x70);
  if ((puVar6 != (undefined8 *)0x0) && (lVar3 = puVar6[3], lVar3 != 0)) {
    bVar1 = (byte)param_2[2];
    puVar5 = (ushort *)(ulonglong)bVar1;
    if (bVar1 == 0) {
      puVar5 = (ushort *)0x0;
      if ((undefined8 *)*puVar6 != (undefined8 *)0x0) {
        puVar5 = *(ushort **)*puVar6;
        if (*param_2 < *puVar5) {
          uVar2 = param_2[1];
          *(ushort *)(lVar3 + (ulonglong)*param_2 * 2) = uVar2;
          return (ushort *)(ulonglong)uVar2;
        }
      }
    }
    else if (bVar1 == 1) {
      uVar2 = *param_2;
      puVar5 = (ushort *)0x0;
      if ((undefined8 *)*puVar6 != (undefined8 *)0x0) {
        puVar5 = *(ushort **)*puVar6;
        if (uVar2 < *puVar5) {
          *(ushort *)(lVar3 + (ulonglong)uVar2 * 2) =
               *(short *)(lVar3 + (ulonglong)uVar2 * 2) + param_2[1];
          return puVar5;
        }
      }
    }
    else if (bVar1 == 2) {
      FUN_140189320();
      puVar5 = (ushort *)FUN_140242630();
      if (((puVar6[3] != 0) && ((undefined8 *)*puVar6 != (undefined8 *)0x0)) &&
         (*param_2 < **(ushort **)*puVar6)) {
        uVar4 = (ulonglong)(uint)((int)puVar5 >> 0x1f) << 0x20 | (ulonglong)puVar5 & 0xffffffff;
        puVar5 = (ushort *)((longlong)uVar4 / (longlong)(int)(short)param_2[1] & 0xffffffff);
        *(short *)(puVar6[3] + (ulonglong)*param_2 * 2) =
             (short)((longlong)uVar4 % (longlong)(int)(short)param_2[1]) + 1;
      }
    }
  }
  return puVar5;
}

