/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140099900; RVA 0x99900
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_140099900(longlong param_1,float *param_2,byte param_3,byte param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  int iVar7;
  longlong lVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  undefined1 auVar12 [64];
  undefined1 local_res18 [16];
  float local_d8;
  float local_d4;
  float local_d0;
  undefined4 local_cc;
  float local_c8;
  float local_c4;
  float local_c0;
  undefined4 local_bc;
  undefined1 local_b8 [8];
  float fStack_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  
  lVar8 = (ulonglong)param_4 * 0x520;
  lVar1 = *(longlong *)
           (*(longlong *)(**(longlong **)(param_1 + 0x10) + (ulonglong)param_3 * 8) + 0x110);
  fVar10 = *(float *)(lVar1 + 600 + lVar8);
  fVar11 = *(float *)(lVar1 + 0x25c + lVar8);
  auVar12 = ZEXT464(*(uint *)(lVar1 + 0x260 + lVar8));
  fVar9 = (*(float *)(*(longlong *)(lVar1 + 0x1b8 + lVar8) + 0x1848) + DAT_1402d2990) *
          DAT_1402d2d8c;
  local_98 = 0;
  uStack_90 = 0;
  local_78 = 0;
  uStack_70 = 0;
  local_a8 = 0;
  uStack_a0 = 0;
  local_88 = 0;
  uStack_80 = 0;
  FUN_140202920(&local_a8,lVar1 + 0x268 + lVar8);
  local_bc = DAT_1402d22d0;
  auVar6._8_8_ = uStack_70;
  auVar6._0_8_ = local_78;
  auVar5._8_8_ = uStack_80;
  auVar5._0_8_ = local_88;
  uVar2 = *(undefined8 *)(param_1 + 0x18);
  auVar3 = vshufps_avx(auVar5,auVar5,0x55);
  local_d8 = ((float)local_88 * fVar9 + (float)local_78) * DAT_1402d24d0 + fVar10;
  auVar4 = vshufps_avx(auVar6,auVar6,0x55);
  local_d4 = (auVar3._0_4_ * fVar9 + auVar4._0_4_) * DAT_1402d24d0 + fVar11;
  auVar3 = vshufps_avx(auVar6,auVar6,0xaa);
  auVar4 = vshufps_avx(auVar5,auVar5,0xaa);
  local_c0 = auVar12._0_4_;
  local_d0 = (auVar4._0_4_ * fVar9 + auVar3._0_4_) * DAT_1402d24d0 + local_c0;
  _local_b8 = ZEXT816(0);
  param_2[3] = 1.0;
  local_cc = local_bc;
  *param_2 = local_d8;
  param_2[1] = local_d4;
  param_2[2] = local_d0;
  local_c8 = fVar10;
  local_c4 = fVar11;
  iVar7 = FUN_1400782c0(uVar2,local_b8,local_res18,&local_c8,&local_d8);
  if (iVar7 != 0) {
    *param_2 = (float)local_b8._0_4_;
    param_2[2] = fStack_b0;
    param_2[1] = (float)local_b8._4_4_;
    param_2[3] = 1.0;
  }
  return 0;
}

