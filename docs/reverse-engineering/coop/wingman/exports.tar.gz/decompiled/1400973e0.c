/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400973e0; RVA 0x973e0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400973e0(longlong param_1)

{
  int *piVar1;
  undefined1 uVar2;
  float fVar3;
  uint uVar4;
  undefined8 uVar5;
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  byte bVar8;
  undefined2 uVar9;
  short sVar10;
  uint uVar11;
  longlong lVar12;
  float *pfVar13;
  int iVar14;
  longlong lVar15;
  float *pfVar16;
  ulonglong uVar17;
  float fVar18;
  float fVar19;
  undefined1 auVar20 [16];
  float fVar21;
  undefined1 auVar22 [64];
  float fVar23;
  undefined1 auVar24 [64];
  undefined1 auVar25 [64];
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  uint local_res10;
  undefined1 local_res18 [16];
  longlong local_158;
  undefined1 local_150 [8];
  float fStack_148;
  float fStack_144;
  undefined1 local_138 [8];
  float fStack_130;
  float fStack_12c;
  undefined1 local_128 [12];
  undefined4 uStack_11c;
  undefined1 local_118 [4];
  undefined1 auStack_114 [12];
  undefined1 local_108 [8];
  float fStack_100;
  float local_f8;
  undefined4 local_f4;
  undefined4 local_f0;
  undefined4 local_ec;
  float local_e8;
  float local_e4;
  undefined4 local_e0;
  undefined4 local_dc;
  
  auVar24 = ZEXT464(DAT_1402d22d0);
  pfVar16 = (float *)(param_1 + 0xa8);
  local_res10 = 1;
  local_158 = 0x10;
  auVar25 = ZEXT864(0);
  fVar26 = DAT_1402d2440;
  fVar27 = DAT_1402d2654;
  fVar28 = DAT_1402d235c;
  fVar29 = DAT_1402d24a4;
  do {
    if ((*(uint *)(param_1 + 0x5c) & local_res10) != 0) {
      auVar20._0_4_ = pfVar16[-2] + pfVar16[-10];
      auVar20._4_4_ = pfVar16[-1] + pfVar16[-9];
      auVar20._8_4_ = *pfVar16 + pfVar16[-8];
      auVar20._12_4_ = pfVar16[1] + pfVar16[-7];
      *(undefined1 (*) [16])(pfVar16 + -10) = auVar20;
      if (*(char *)(pfVar16 + 0xe5) == '\0') {
        lVar15 = *(longlong *)
                  (*(longlong *)
                    (**(longlong **)(param_1 + 0x10) + (ulonglong)*(byte *)(pfVar16 + 10) * 8) +
                  0x110) + (ulonglong)*(byte *)((longlong)pfVar16 + 0x29) * 0x520;
        if (*(char *)((longlong)pfVar16 + 0x397) == '\x01') {
          *(undefined1 *)((longlong)pfVar16 + 0x397) = 0;
          lVar12 = FUN_140189320();
          fVar19 = (float)*(int *)(lVar12 + 0xc) * pfVar16[9];
        }
        else {
          auVar20 = *(undefined1 (*) [16])(lVar15 + 600);
          fVar19 = auVar20._0_4_ - pfVar16[0xe0];
          auVar6 = vshufps_avx(auVar20,auVar20,0x55);
          fVar18 = auVar6._0_4_ - pfVar16[0xe1];
          auVar20 = vshufps_avx(auVar20,auVar20,0xaa);
          fVar21 = auVar20._0_4_ - pfVar16[0xe2];
          lVar12 = FUN_140189320();
          auVar20 = vcvtdq2ps_avx(ZEXT416(*(uint *)(lVar12 + 0xc)));
          fVar19 = SQRT(fVar21 * fVar21 + fVar18 * fVar18 + fVar19 * fVar19) * auVar20._0_4_;
        }
        fVar19 = fVar19 * DAT_1402d21c8;
        pfVar16[0xe0] = *(float *)(lVar15 + 600);
        pfVar16[0xe1] = *(float *)(lVar15 + 0x25c);
        pfVar16[0xe2] = *(float *)(lVar15 + 0x260);
        pfVar16[0xe3] = *(float *)(lVar15 + 0x264);
        uVar17 = (ulonglong)*(byte *)((longlong)pfVar16 + 0x395);
        bVar8 = *(byte *)((longlong)pfVar16 + 0x396);
        fVar18 = auVar24._0_4_ / (float)*(byte *)(param_1 + 0x30);
        pfVar16[-1] = -(fVar18 * fVar18 * fVar27) + pfVar16[-1];
        if (*(byte *)((longlong)pfVar16 + 0x395) < bVar8) {
          pfVar13 = pfVar16 + uVar17 * 0x1a + 0x12;
          do {
            pfVar16[0xe4] = (float)((uint)pfVar16[0xe4] | 1 << ((uint)uVar17 & 0x1f));
            _local_150 = *(undefined1 (*) [16])(lVar15 + 600);
            if (DAT_14033bd60 == '\0') {
              fVar18 = (float)local_150._0_4_;
              fVar21 = (float)local_150._4_4_;
              fVar23 = fStack_148;
            }
            else {
              _local_138 = ZEXT816(0);
              _local_128 = ZEXT816(0);
              _local_118 = _local_138;
              _local_108 = _local_128;
              FUN_140202920(local_138,lVar15 + 0x268);
              auVar22 = ZEXT1664(auVar25._0_16_);
              if (*(longlong *)(lVar15 + 0x1b8) == 0) {
                if (*(char *)(lVar15 + 0x42b) == '\x01') {
                  if (*(longlong *)(lVar15 + 0x360) == 0) {
                    if (*(longlong *)(lVar15 + 0x370) != 0) {
                      auVar22 = ZEXT464(*(uint *)(*(longlong *)(lVar15 + 0x370) + 0x288));
                    }
                  }
                  else {
                    auVar22 = ZEXT464(*(uint *)(*(longlong *)(lVar15 + 0x360) + 0x468));
                  }
                }
                else if ((*(char *)(lVar15 + 0x42b) == '\x02') &&
                        (*(longlong *)(lVar15 + 0x368) != 0)) {
                  auVar22 = ZEXT464(*(uint *)(*(longlong *)(lVar15 + 0x368) + 0x2c8));
                }
              }
              else {
                auVar22 = ZEXT464(*(uint *)(*(longlong *)(lVar15 + 0x1b8) + 0x1848));
              }
              lVar12 = FUN_140189320();
              auVar20 = vcvtdq2ps_avx(ZEXT416(*(uint *)(lVar12 + 0xc)));
              fVar23 = (fVar28 / auVar20._0_4_) * auVar22._0_4_;
              fVar18 = fVar23 * (float)local_118 + (float)local_108._0_4_ + (float)local_150._0_4_;
              fVar21 = fVar23 * (float)auStack_114._0_4_ + (float)local_108._4_4_ +
                       (float)local_150._4_4_;
              fVar23 = fVar23 * (float)auStack_114._4_4_ + fStack_100 + fStack_148;
            }
            auVar20 = *(undefined1 (*) [16])(lVar15 + 0x268);
            uVar2 = *(undefined1 *)((longlong)pfVar16 + 0x29);
            uVar5 = *(undefined8 *)(pfVar16 + 6);
            *(undefined1 *)(pfVar13 + 0x12) = *(undefined1 *)(pfVar16 + 10);
            *(undefined1 *)((longlong)pfVar13 + 0x49) = uVar2;
            pfVar13[-2] = fVar18;
            pfVar13[-1] = fVar21;
            *pfVar13 = fVar23;
            pfVar13[1] = fStack_144;
            pfVar13[2] = auVar20._0_4_;
            fVar3 = (float)vextractps_avx(auVar20,1);
            pfVar13[3] = fVar3;
            fVar3 = (float)vextractps_avx(auVar20,2);
            pfVar13[4] = fVar3;
            fVar3 = (float)vextractps_avx(auVar20,3);
            pfVar13[5] = fVar3;
            pfVar13[0x10] = 0.0;
            pfVar13[0x13] = 0.0;
            pfVar13[0x14] = 0.0;
            *(undefined1 *)((longlong)pfVar13 + 0x56) = 0;
            pfVar13[0x11] = fVar19;
            *(undefined2 *)((longlong)pfVar13 + 0x4a) = 0xffff;
            *(undefined8 *)(pfVar13 + 0xe) = uVar5;
            *(undefined2 *)(pfVar13 + 0x15) = 0xffff;
            FUN_1400903a0(param_1);
            auVar20 = _local_128;
            if (*(longlong *)(param_1 + 8) != 0) {
              local_128._0_8_ = local_128._4_8_ << 0x20;
              uStack_11c = auVar20._12_4_;
              local_128._8_4_ = pfVar13[4];
              local_138._4_4_ = fVar21;
              local_138._0_4_ = fVar18;
              fStack_130 = fVar23;
              fStack_12c = (float)auVar24._0_4_;
              local_128._0_8_ = *(undefined8 *)(pfVar13 + 2);
              uStack_11c = auVar25._0_4_;
              auVar6._12_4_ = 0;
              auVar6._0_12_ = auStack_114;
              _local_118 = auVar6 << 0x20;
              uVar9 = FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x13,
                                    local_138,0);
              *(undefined2 *)(pfVar13 + 0x15) = uVar9;
            }
            bVar8 = *(byte *)((longlong)pfVar16 + 0x396);
            uVar11 = (uint)uVar17 + 1;
            uVar17 = (ulonglong)uVar11;
            pfVar13 = pfVar13 + 0x1a;
          } while ((int)uVar11 < (int)(uint)bVar8);
        }
        *(byte *)((longlong)pfVar16 + 0x395) = bVar8;
        iVar14 = 0;
        if (bVar8 != 0) {
          pfVar13 = pfVar16;
          do {
            auVar20 = _local_128;
            fVar19 = auVar24._0_4_ / (float)*(byte *)(param_1 + 0x30);
            fVar18 = -(fVar19 * fVar19 * fVar27) + pfVar13[0x19];
            pfVar13[0x19] = fVar18;
            fVar19 = pfVar13[0x10];
            pfVar13[0x10] = pfVar13[0x18] + fVar19;
            fVar18 = fVar18 + pfVar13[0x11];
            pfVar13[0x11] = fVar18;
            fVar21 = pfVar13[0x1a] + pfVar13[0x12];
            pfVar13[0x12] = fVar21;
            pfVar13[0x13] = pfVar13[0x1b] + pfVar13[0x13];
            if ((*(longlong *)(param_1 + 8) != 0) && (-1 < *(short *)(pfVar13 + 0x27))) {
              local_128._0_8_ = local_128._4_8_ << 0x20;
              uStack_11c = auVar20._12_4_;
              local_128._8_4_ = pfVar13[0x16];
              local_138._4_4_ = fVar18;
              local_138._0_4_ = pfVar13[0x18] + fVar19;
              fStack_130 = fVar21;
              fStack_12c = auVar24._0_4_;
              local_128._0_8_ = *(undefined8 *)(pfVar13 + 0x14);
              uStack_11c = auVar25._0_4_;
              auVar7._12_4_ = 0;
              auVar7._0_12_ = auStack_114;
              _local_118 = auVar7 << 0x20;
              sVar10 = FUN_140035b10(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x13,
                                     local_138,*(short *)(pfVar13 + 0x27),0xffff);
              if (sVar10 == -1) {
                *(undefined2 *)(pfVar13 + 0x27) = 0xffff;
              }
              if (fVar26 < pfVar13[0x25]) {
                lVar15 = *(longlong *)(*(longlong *)(param_1 + 8) + 0x66ee0);
                uVar11 = (uint)(*(ushort *)(pfVar13 + 0x27) & 0x3ff);
                if (*(short *)(pfVar13 + 0x27) == -1) {
                  uVar11 = 0xffffffff;
                }
                lVar12 = (longlong)(short)uVar11 >> 5;
                uVar4 = *(uint *)(lVar15 + 0x1bc48 + lVar12 * 4);
                if ((uVar4 >> (uVar11 & 0x1f) & 1) != 0) {
                  *(uint *)(lVar15 + 0x1bc48 + lVar12 * 4) = uVar4 & ~(1 << (uVar11 & 0x1f));
                  piVar1 = (int *)(lVar15 + 0x1bc88);
                  *piVar1 = *piVar1 + -1;
                  if (*piVar1 < 0) {
                    *(undefined4 *)(lVar15 + 0x1bc88) = 0;
                  }
                }
                *(undefined2 *)(pfVar13 + 0x27) = 0xffff;
              }
            }
            iVar14 = iVar14 + 1;
            pfVar13[0x25] = auVar24._0_4_ / (float)*(byte *)(param_1 + 0x30) + pfVar13[0x25];
            pfVar13 = pfVar13 + 0x1a;
          } while (iVar14 < (int)(uint)*(byte *)((longlong)pfVar16 + 0x395));
        }
        fVar19 = auVar24._0_4_ / (float)*(byte *)(param_1 + 0x30) + pfVar16[0xb];
        pfVar16[0xb] = fVar19;
        if (*(byte *)((longlong)pfVar16 + 0x396) < 8) {
          bVar8 = (char)(int)(fVar19 * fVar29) + 1;
          *(byte *)((longlong)pfVar16 + 0x396) = bVar8;
          if (7 < bVar8) {
            *(undefined1 *)((longlong)pfVar16 + 0x396) = 8;
          }
        }
      }
      else {
        if (*(longlong *)(param_1 + 0x18) != 0) {
          _local_150 = ZEXT816(0);
          auVar6 = vshufps_avx(auVar20,auVar20,0xaa);
          local_f0 = auVar6._0_4_;
          auVar6 = vshufps_avx(auVar20,auVar20,0x55);
          local_e4 = auVar6._0_4_ + DAT_1402d2a34;
          local_f4 = DAT_1402d2e9c;
          local_ec = auVar24._0_4_;
          local_f8 = auVar20._0_4_;
          local_e8 = auVar20._0_4_;
          local_e0 = local_f0;
          local_dc = local_ec;
          uVar11 = FUN_1400782c0(*(longlong *)(param_1 + 0x18),local_150,local_res18,&local_e8,
                                 &local_f8);
          auVar20 = vpcmpeqd_avx(ZEXT416(uVar11),ZEXT416(0));
          auVar20 = vblendvps_avx(ZEXT416((uint)local_150._4_4_),auVar25._0_16_,auVar20);
          pfVar16[-9] = auVar20._0_4_;
        }
        pfVar16[0xb] = auVar24._0_4_ / (float)*(byte *)(param_1 + 0x30) + pfVar16[0xb];
      }
    }
    local_res10 = local_res10 << 1 | (uint)((int)local_res10 < 0);
    pfVar16 = pfVar16 + 0xf2;
    local_158 = local_158 + -1;
  } while (local_158 != 0);
  return;
}

