/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140093a80; RVA 0x93a80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140093a80(longlong param_1,longlong param_2,ushort param_3)

{
  char cVar1;
  longlong lVar2;
  ushort uVar3;
  longlong unaff_GS_OFFSET;
  
  lVar2 = *(longlong *)
           (*(longlong *)
             (**(longlong **)(param_1 + 0x10) + (ulonglong)*(byte *)(param_2 + 0x50) * 8) + 0x110) +
          (ulonglong)*(byte *)(param_2 + 0x51) * 0x520;
  cVar1 = *(char *)(**(longlong **)(lVar2 + 0x388) + 0x15d);
  if (((cVar1 == '\0') || (cVar1 == '\x02')) && (*(char *)(lVar2 + 0x235) == '\0')) {
    cVar1 = *(char *)(*(longlong *)(lVar2 + 0x1b8) + 0x2094);
    if (cVar1 == '\x01') {
      uVar3 = param_3 + 2;
    }
    else {
      uVar3 = param_3 + 1;
      if (cVar1 == '\0') {
        uVar3 = param_3;
      }
    }
    FUN_1401c56d0();
    if (*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437daf04) {
      FUN_14022d540(&DAT_1437daf04);
      if (DAT_1437daf04 == -1) {
        FUN_1401c93c0();
        _Init_thread_footer(&DAT_1437daf04);
      }
    }
    if (('\x01' < DAT_1437dece2) && (uVar3 < DAT_1437db05a)) {
      FUN_1401c6150();
    }
  }
  return;
}

