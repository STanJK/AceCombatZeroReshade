/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fb540; RVA 0xfb540
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400fb540(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  uint *puVar2;
  float fVar3;
  float fVar4;
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  uint uVar7;
  longlong *plVar8;
  float *pfVar9;
  byte bVar10;
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  longlong lVar15;
  int iVar16;
  longlong lVar17;
  uint uVar18;
  longlong unaff_GS_OFFSET;
  undefined4 uVar19;
  float fVar20;
  undefined4 uVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  undefined4 uVar26;
  undefined1 auVar27 [64];
  undefined4 uVar28;
  float fVar29;
  float fVar30;
  float local_c8;
  float local_c4;
  float local_c0;
  undefined4 local_bc;
  undefined1 local_b8 [16];
  undefined1 local_a8 [8];
  float fStack_a0;
  float fStack_9c;
  undefined1 local_98 [16];
  undefined1 local_88 [8];
  float fStack_80;
  float fStack_7c;
  
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffbfff;
  *(undefined1 *)(param_1 + 0x3cc) = 3;
  if (*(longlong *)(param_1 + 0x340) != 0) {
    FUN_1400d1560(*(longlong *)(param_1 + 0x340),0);
  }
  plVar8 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
  lVar15 = *(longlong *)(*plVar8 + 0x110);
  lVar17 = *(longlong *)(lVar15 + 0x1b8);
  if ((*(uint *)(param_1 + 0x3a8) & 8) != 0) {
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xfffffff7;
    puVar2 = (uint *)(*(longlong *)
                       (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) +
                       0x1b8) + 0x2058);
    *puVar2 = *puVar2 & 0xffffffef;
  }
  uVar7 = *(uint *)(lVar17 + 0x2058);
  uVar18 = uVar7 & 0xffffffef;
  if ((uVar7 >> 0xd & 1) != 0) {
    uVar18 = uVar7 & 0xffffdfef;
    *(undefined1 *)(lVar17 + 0x2096) = *(undefined1 *)(lVar17 + 0x2095);
  }
  *(undefined8 *)(lVar17 + 0x1d78) = 0;
  *(byte *)(lVar17 + 0x1da7) = *(byte *)(lVar17 + 0x1da7) & 0xfe;
  *(byte *)(lVar17 + 0x1863) = *(byte *)(lVar17 + 0x1863) & 0xfe;
  *(undefined4 *)(lVar17 + 0x185c) = 0;
  *(undefined1 *)(lVar17 + 0x1dad) = 0;
  *(uint *)(lVar17 + 0x2058) = uVar18 & 0xfdffffdf;
  if ((*(longlong **)(lVar17 + 0x2040) == (longlong *)0x0) ||
     (*(int *)(*(longlong *)
                (**(longlong **)(lVar17 + 0x2040) + (ulonglong)*(byte *)(lVar17 + 0x20a1) * 8) +
              0x118) < 2)) {
    *(uint *)(lVar17 + 0x2058) = uVar18 & 0xfdffffdf | 0x1000;
    *(ushort *)(lVar17 + 0x1c20) = *(ushort *)(lVar17 + 0x1c20) | 1;
  }
  else {
    *(uint *)(lVar17 + 0x2058) = uVar18 & 0xfdffefdf;
    *(ushort *)(lVar17 + 0x1c20) = *(ushort *)(lVar17 + 0x1c20) & 0xfffe;
  }
  *(undefined4 *)(lVar17 + 0x164c) = 0;
  pbVar1 = (byte *)(*(longlong *)(param_1 + 0x2f8) + 0x69);
  *pbVar1 = *pbVar1 & 0xfb;
  auVar5 = *(undefined1 (*) [16])(param_1 + 0xb0);
  auVar6 = *(undefined1 (*) [16])(param_1 + 0xc0);
  uVar26 = auVar5._0_4_;
  *(undefined4 *)(lVar17 + 0x10e0) = uVar26;
  auVar11 = vshufps_avx(auVar6,auVar6,0x55);
  auVar12 = vshufps_avx(auVar6,auVar6,0xaa);
  auVar13 = vshufps_avx(auVar6,auVar6,0xff);
  auVar14 = vshufps_avx(auVar5,auVar5,0x55);
  uVar25 = auVar14._0_4_;
  *(undefined4 *)(lVar17 + 0x10e4) = uVar25;
  auVar14 = vshufps_avx(auVar5,auVar5,0xaa);
  uVar24 = auVar14._0_4_;
  *(undefined4 *)(lVar17 + 0x10e8) = uVar24;
  auVar5 = vshufps_avx(auVar5,auVar5,0xff);
  uVar23 = auVar5._0_4_;
  *(undefined4 *)(lVar17 + 0x10ec) = uVar23;
  uVar28 = auVar6._0_4_;
  *(undefined4 *)(lVar17 + 0x10f0) = uVar28;
  uVar22 = auVar11._0_4_;
  *(undefined4 *)(lVar17 + 0x10f4) = uVar22;
  uVar21 = auVar12._0_4_;
  *(undefined4 *)(lVar17 + 0x10f8) = uVar21;
  uVar19 = auVar13._0_4_;
  *(undefined4 *)(lVar17 + 0x10fc) = uVar19;
  *(undefined8 *)(lVar17 + 0x12a0) = 0;
  *(undefined4 *)(lVar17 + 0x12a8) = 0;
  *(undefined4 *)(lVar17 + 0x12ac) = 0x3f800000;
  *(undefined4 *)(lVar17 + 0x12b0) = uVar28;
  *(undefined4 *)(lVar17 + 0x12b4) = uVar22;
  *(undefined4 *)(lVar17 + 0x12b8) = uVar21;
  *(undefined4 *)(lVar17 + 0x12bc) = uVar19;
  *(undefined4 *)(lVar17 + 0x70) = uVar26;
  *(undefined4 *)(lVar17 + 0x74) = uVar25;
  *(undefined4 *)(lVar17 + 0x78) = uVar24;
  *(undefined4 *)(lVar17 + 0x7c) = uVar23;
  *(undefined4 *)(lVar17 + 0x80) = uVar28;
  *(undefined4 *)(lVar17 + 0x84) = uVar22;
  *(undefined4 *)(lVar17 + 0x88) = uVar21;
  *(undefined4 *)(lVar17 + 0x8c) = uVar19;
  *(undefined4 *)(lVar17 + 0x17f8) = uVar26;
  *(undefined4 *)(lVar17 + 0x17fc) = uVar25;
  *(undefined4 *)(lVar17 + 0x1800) = uVar24;
  *(undefined4 *)(lVar17 + 0x1804) = uVar23;
  *(undefined4 *)(lVar17 + 0x1808) = uVar28;
  *(undefined4 *)(lVar17 + 0x180c) = uVar22;
  *(undefined4 *)(lVar17 + 0x1810) = uVar21;
  *(undefined4 *)(lVar17 + 0x1814) = uVar19;
  *(undefined4 *)(lVar15 + 600) = *(undefined4 *)(param_1 + 0xb0);
  *(undefined4 *)(lVar15 + 0x25c) = *(undefined4 *)(param_1 + 0xb4);
  *(undefined4 *)(lVar15 + 0x260) = *(undefined4 *)(param_1 + 0xb8);
  *(undefined4 *)(lVar15 + 0x264) = *(undefined4 *)(param_1 + 0xbc);
  *(undefined4 *)(lVar15 + 0x268) = *(undefined4 *)(param_1 + 0xc0);
  *(undefined4 *)(lVar15 + 0x26c) = *(undefined4 *)(param_1 + 0xc4);
  *(undefined4 *)(lVar15 + 0x270) = *(undefined4 *)(param_1 + 200);
  *(undefined4 *)(lVar15 + 0x274) = *(undefined4 *)(param_1 + 0xcc);
  *(uint *)(lVar15 + 0x1f0) = *(uint *)(lVar15 + 0x1f0) & 0xfff7ffff | 3;
  *(ushort *)(lVar15 + 0x428) = (ushort)*(byte *)(param_1 + 0x3e2);
  if (1 < *(int *)(*plVar8 + 0x118)) {
    lVar17 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
    if (lVar17 != -0x520) {
      local_b8 = ZEXT816(0);
      _local_a8 = ZEXT816(0);
      pfVar9 = *(float **)
                (*(longlong *)
                  (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x130) + 0x10) +
                0x10);
      local_98 = local_b8;
      _local_88 = _local_a8;
      FUN_140202920(local_b8,param_1 + 0xc0);
      fVar20 = pfVar9[1];
      fVar29 = *pfVar9;
      fVar30 = pfVar9[2];
      fVar3 = *(float *)(param_1 + 0xb4);
      fVar4 = *(float *)(param_1 + 0xb8);
      *(float *)(lVar17 + 0x778) =
           fVar30 * local_98._0_4_ + fVar29 * local_b8._0_4_ + fVar20 * (float)local_a8._0_4_ +
           (float)local_88._0_4_ + *(float *)(param_1 + 0xb0);
      auVar5 = vshufps_avx(local_b8,local_b8,0x55);
      auVar6 = vshufps_avx(local_98,local_98,0x55);
      *(float *)(lVar17 + 0x77c) =
           fVar30 * auVar6._0_4_ + fVar29 * auVar5._0_4_ + fVar20 * (float)local_a8._4_4_ +
           (float)local_88._4_4_ + fVar3;
      auVar5 = vshufps_avx(local_b8,local_b8,0xaa);
      auVar6 = vshufps_avx(local_98,local_98,0xaa);
      *(float *)(lVar17 + 0x780) =
           fVar30 * auVar6._0_4_ + fVar29 * auVar5._0_4_ + fVar20 * fStack_a0 + fStack_80 + fVar4;
      auVar5 = vshufps_avx(local_b8,local_b8,0xff);
      auVar6 = vshufps_avx(local_98,local_98,0xff);
      *(float *)(lVar17 + 0x784) =
           fVar30 * auVar6._0_4_ + fVar29 * auVar5._0_4_ + fVar20 * fStack_9c + fStack_7c;
      local_c8 = pfVar9[3];
      local_c4 = pfVar9[4];
      local_c0 = pfVar9[5];
      local_bc = 0;
      FUN_140203050(lVar17 + 0x788,param_1 + 0xc0,&local_c8);
      lVar17 = *(longlong *)(lVar17 + 0x880);
      fVar30 = (float)*(byte *)(lVar17 + 0x49c);
      fVar29 = (float)*(ushort *)(lVar17 + 0x26c);
      auVar27 = ZEXT464((uint)((DAT_1402d2140 / fVar30) * fVar29));
      fVar20 = (float)FUN_140128d90(*(undefined4 *)(lVar17 + 0x3dc));
      *(float *)(lVar17 + 0x468) =
           fVar29 * (DAT_1402d235c / fVar30) +
           -(auVar27._0_4_ * SQRT(fVar20 / *(float *)(lVar17 + 0x470))) + auVar27._0_4_;
    }
  }
  lVar15 = *(longlong *)(lVar15 + 0x1b8);
  *(undefined1 *)(lVar15 + 0xc38) = 3;
  FUN_14010bbb0(lVar15);
  iVar16 = 1;
  *(undefined1 *)(lVar15 + 0xc38) = 0;
  *(undefined8 *)(lVar15 + 0xccc) = 0;
  *(undefined8 *)(lVar15 + 0xcd4) = 0;
  *(undefined4 *)(lVar15 + 0xcdc) = 0;
  *(undefined4 *)(lVar15 + 0xce4) = 0x42480000;
  *(undefined4 *)(lVar15 + 0xce0) = 0x42480000;
  *(byte *)(lVar15 + 0x1677) = *(byte *)(lVar15 + 0x1677) & 0xfe;
  *(byte *)(lVar15 + 0x1676) = *(byte *)(lVar15 + 0x1676) & 0xfc;
  *(byte *)(lVar15 + 0x1863) = *(byte *)(lVar15 + 0x1863) & 0xfb;
  *(uint *)(lVar15 + 0x2058) = *(uint *)(lVar15 + 0x2058) & 0xffffff7f;
  plVar8 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
  lVar15 = *plVar8;
  if (1 < *(int *)(lVar15 + 0x118)) {
    lVar17 = 0x520;
    do {
      lVar15 = *(longlong *)(*(longlong *)(lVar15 + 0x110) + 0x1c0 + lVar17);
      if (lVar15 != 0) {
        (**(code **)(**(longlong **)(lVar15 + 0x10) + 0x1c8))();
      }
      lVar15 = *plVar8;
      iVar16 = iVar16 + 1;
      lVar17 = lVar17 + 0x520;
    } while (iVar16 < *(int *)(lVar15 + 0x118));
  }
  *(undefined4 *)(param_1 + 0x348) = *(undefined4 *)*param_2;
  *(undefined4 *)(param_1 + 0x34c) = *(undefined4 *)(*param_2 + 8);
  *(undefined4 *)(param_1 + 0x350) = *(undefined4 *)(*param_2 + 4);
  *(undefined4 *)(param_1 + 0x354) = *(undefined4 *)(*param_2 + 0xc);
  lVar15 = *(longlong *)(param_1 + 0x340);
  if ((*(uint *)(lVar15 + 0xa8790) >> 0x1d & 1) != 0) {
    *(uint *)(lVar15 + 0xa8790) = *(uint *)(lVar15 + 0xa8790) & 0xdfffffff;
    FUN_1400c3910(lVar15 + 0x697b8);
  }
  if (*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dad18) {
    FUN_14022d540(&DAT_1437dad18);
    if (DAT_1437dad18 == -1) {
      _DAT_1437daef0 = 0;
      _DAT_1437daee0 = _DAT_1402d3500;
      uRam00000001437daee8 = _UNK_1402d3508;
      DAT_1437daef4 = 0;
      _Init_thread_footer(&DAT_1437dad18);
    }
  }
  bVar10 = DAT_14031f8b1 & 1;
  (&DAT_140310a64)[(uRam00000001437daee8 >> 0x20 & 0xff) * 8] = 0x42fe0000;
  if (bVar10 == 0) {
    lVar15 = (longlong)DAT_1437daee4;
    *(undefined4 *)
     ((&DAT_14033bc00)[(char)(&DAT_14031f8a8)[lVar15 + (ulonglong)DAT_14031f8b0 * 4]] + 4) =
         *(undefined4 *)(param_1 + 0x2c4);
    iVar16 = *(int *)(param_1 + 0x2c8);
    if (((((DAT_14031f8b1 & 1) == 0) && (-1 < iVar16)) &&
        (iVar16 < *(int *)(&DAT_14031f838 + lVar15 * 0x18))) &&
       (*(longlong *)(&DAT_14031f840 + lVar15 * 0x18) != 0)) {
      FUN_140186f20((&DAT_14033bc00)[(char)(&DAT_14031f8a8)[lVar15 + (ulonglong)DAT_14031f8b0 * 4]],
                    &DAT_14031f438 + lVar15 * 0x100,
                    *(undefined4 *)
                     (*(longlong *)(&DAT_14031f840 + lVar15 * 0x18) + (longlong)iVar16 * 4),6000,
                    (int)(char)(&DAT_14031f8a8)[lVar15 + (ulonglong)DAT_14031f8b0 * 4],0,0,1);
      *(int *)(&DAT_14031f898 + lVar15 * 4) = iVar16;
      *(undefined4 *)(&DAT_14031f898 + lVar15 * 4) = *(undefined4 *)(param_1 + 0x2c8);
    }
  }
  lVar15 = *(longlong *)(param_1 + 800);
  if (lVar15 != 0) {
    *(byte *)(lVar15 + 0x2b) = *(byte *)(lVar15 + 0x2b) & 0xfd;
    if (*(longlong *)(lVar15 + 0x10) != 0) {
      puVar2 = (uint *)(*(longlong *)(lVar15 + 0x10) + 0x56c);
      *puVar2 = *puVar2 & 0xfffffffe;
    }
    if (*(longlong *)(lVar15 + 0x18) != 0) {
      pbVar1 = (byte *)(*(longlong *)(lVar15 + 0x18) + 0x23);
      *pbVar1 = *pbVar1 & 0xfb;
    }
    lVar15 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
    if (lVar15 != 0) {
      puVar2 = (uint *)(lVar15 + 0x40);
      *puVar2 = *puVar2 & 0xfbffffff;
    }
  }
  if (*(longlong *)(param_1 + 0x308) != 0) {
    FUN_1401a5f00();
  }
  *(undefined4 *)(param_1 + 0x3a0) = 0;
  FUN_140136130(*(undefined8 *)(param_1 + 0x2f8));
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x808000;
  return;
}

