/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fd650; RVA 0xfd650
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400fd650(longlong param_1,byte param_2,byte param_3,char param_4)

{
  undefined1 auVar1 [16];
  char cVar2;
  byte bVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  float fVar9;
  float fVar10;
  float fVar11;
  byte bVar12;
  undefined2 uVar13;
  short sVar14;
  undefined8 *puVar15;
  ushort uVar16;
  int iVar17;
  longlong lVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  undefined1 auVar23 [64];
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  undefined1 auVar28 [64];
  undefined1 auVar29 [64];
  undefined1 uVar30;
  undefined1 local_168 [16];
  undefined8 local_158;
  undefined8 uStack_150;
  undefined1 local_148 [16];
  undefined8 local_138;
  undefined8 uStack_130;
  undefined8 local_128;
  undefined8 uStack_120;
  undefined8 uStack_118;
  undefined8 uStack_110;
  undefined4 local_108;
  undefined2 local_104;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  undefined4 local_d8;
  undefined2 local_d4;
  
  if (*(longlong *)(param_1 + 0x308) == 0) {
    return;
  }
  if (*(longlong **)(param_1 + 0x2f8) == (longlong *)0x0) {
    return;
  }
  if (param_2 == 0xff) {
    return;
  }
  if (param_3 == 0xff) {
    return;
  }
  plVar4 = (longlong *)**(longlong **)(param_1 + 0x2f8);
  lVar5 = *(longlong *)(*plVar4 + 0x110);
  lVar18 = *(longlong *)(plVar4[param_2] + 0x110) + (ulonglong)param_3 * 0x520;
  if (lVar5 == 0) {
    return;
  }
  if (lVar18 == 0) {
    return;
  }
  lVar6 = *(longlong *)(lVar5 + 0x1b8);
  if (lVar6 == 0) {
    return;
  }
  local_d4 = 0x11fe;
  sVar14 = -1;
  cVar2 = *(char *)(param_1 + 0x3d6);
  local_d8 = 0x11fd11fc;
  local_108 = 0xffffffff;
  local_104 = 0xffff;
  local_f8 = _DAT_1402d4000;
  uStack_f0 = _UNK_1402d4008;
  uStack_e8 = _UNK_1402d4010;
  uStack_e0 = _UNK_1402d4018;
  local_128 = _DAT_1402d42c0;
  uStack_120 = _UNK_1402d42c8;
  uStack_118 = _UNK_1402d42d0;
  uStack_110 = _UNK_1402d42d8;
  if ((cVar2 == '\b') || (cVar2 == '\n')) {
    puVar15 = &local_f8;
  }
  else {
    if (cVar2 != '\x14') {
      return;
    }
    puVar15 = &local_128;
  }
  cVar2 = *(char *)(param_1 + 0x3cc);
  if (param_4 != '\0') {
    switch(cVar2) {
    default:
      goto switchD_1400fd7a5_caseD_c;
    case '\r':
      goto switchD_1400fd7a5_caseD_d;
    case '\x0f':
      goto switchD_1400fd7a5_caseD_f;
    case '\x10':
switchD_1400fd7a5_caseD_10:
      if (*(int *)(param_1 + 0x378) != 0) {
        return;
      }
      if (param_4 != '\0') {
        return;
      }
      cVar2 = *(char *)(param_1 + 0x3e9);
      if (cVar2 == '\0') {
        uVar13 = *(undefined2 *)((longlong)puVar15 + 0x1c);
        goto LAB_1400fdce5;
      }
      uVar30 = 1;
      if (cVar2 == '\x01') {
        uVar13 = *(undefined2 *)((longlong)puVar15 + 0x1e);
      }
      else if (cVar2 == '\x02') {
        uVar13 = *(undefined2 *)(puVar15 + 4);
      }
      else if (cVar2 == '\x03') {
        uVar13 = *(undefined2 *)((longlong)puVar15 + 0x22);
      }
      else {
        uVar13 = *(undefined2 *)((longlong)puVar15 + 0x24);
      }
      break;
    case '\x11':
switchD_1400fd7a5_caseD_11:
      if (*(int *)(param_1 + 0x378) != 0) {
        return;
      }
      if ((*(byte *)(lVar5 + 0x1f0) & 2) == 0) {
        return;
      }
      uVar13 = *(undefined2 *)((longlong)puVar15 + 0x1a);
      uVar30 = 0;
    }
LAB_1400fdcf3:
    FUN_1401a61a0(*(longlong *)(param_1 + 0x308),uVar13,0,0,uVar30);
switchD_1400fd7a5_caseD_c:
    return;
  }
  if (cVar2 == '\x01') {
switchD_1400fd7a5_caseD_d:
    uVar13 = *(undefined2 *)puVar15;
LAB_1400fdce5:
    uVar30 = 1;
    goto LAB_1400fdcf3;
  }
  if (cVar2 != '\x03') {
    if (cVar2 != '\x04') {
      if (cVar2 != '\x05') {
        return;
      }
      goto switchD_1400fd7a5_caseD_11;
    }
    goto switchD_1400fd7a5_caseD_10;
  }
switchD_1400fd7a5_caseD_f:
  if ((*(byte *)(param_1 + 0x3d9) & 2) != 0) {
    return;
  }
  if (((*(byte *)(param_1 + 0x3a8) & 4) == 0) && (0 < *(int *)(param_1 + 0x390))) {
    *(int *)(param_1 + 0x390) = *(int *)(param_1 + 0x390) + -1;
    return;
  }
  auVar1 = *(undefined1 (*) [16])(lVar18 + 600);
  fVar21 = auVar1._0_4_ - *(float *)(lVar6 + 0x70);
  auVar7 = vshufps_avx(auVar1,auVar1,0x55);
  fVar24 = auVar7._0_4_ - *(float *)(lVar6 + 0x74);
  auVar7 = vshufps_avx(auVar1,auVar1,0xaa);
  fVar25 = auVar7._0_4_ - *(float *)(lVar6 + 0x78);
  auVar1 = vshufps_avx(auVar1,auVar1,0xff);
  fVar26 = auVar1._0_4_ - *(float *)(lVar6 + 0x7c);
  fVar22 = SQRT(fVar26 * fVar26 + fVar25 * fVar25 + fVar24 * fVar24 + fVar21 * fVar21);
  if (fVar22 != 0.0) {
    fVar22 = DAT_1402d22d0 / fVar22;
    fVar21 = fVar21 * fVar22;
    fVar24 = fVar24 * fVar22;
    fVar25 = fVar25 * fVar22;
    fVar26 = fVar26 * fVar22;
  }
  if ((*(byte *)(param_1 + 0x3d9) & 4) == 0) {
    *(float *)(param_1 + 0xd0) = fVar21;
    *(float *)(param_1 + 0xd4) = fVar24;
    *(float *)(param_1 + 0xd8) = fVar25;
    *(float *)(param_1 + 0xdc) = fVar26;
    *(byte *)(param_1 + 0x3d9) = *(byte *)(param_1 + 0x3d9) | 4;
  }
  local_168 = ZEXT416(0);
  local_158 = 0;
  uStack_150 = 0;
  local_138 = 0;
  uStack_130 = 0;
  auVar23 = ZEXT464(*(uint *)(lVar6 + 0x84));
  fVar27 = 0.0;
  local_148 = local_168;
  FUN_140202920(local_168,lVar18 + 0x268);
  auVar1 = *(undefined1 (*) [16])(param_1 + 0xd0);
  auVar28 = ZEXT1664(auVar1);
  auVar7 = vshufps_avx(auVar1,auVar1,0xff);
  auVar1 = vshufps_avx(auVar1,auVar1,0xaa);
  auVar29 = ZEXT1664(auVar1);
  fVar19 = (float)FUN_140272c30(auVar23._0_8_);
  fVar22 = DAT_1402d2d64 * (float)local_148._0_4_;
  fVar19 = fVar19 * DAT_1402d2d64 * (float)local_148._8_4_;
  fVar20 = (float)FUN_140275650(auVar23._0_4_ + DAT_1402d2420);
  fVar11 = DAT_1402d2284;
  auVar1 = *(undefined1 (*) [16])(lVar6 + 0x70);
  fVar9 = auVar1._0_4_ - *(float *)(lVar18 + 600);
  fVar19 = fVar20 * fVar22 - fVar19;
  auVar8 = vshufps_avx(auVar1,auVar1,0xaa);
  fVar22 = auVar8._0_4_ - *(float *)(lVar18 + 0x260);
  auVar8 = vshufps_avx(auVar1,auVar1,0x55);
  fVar20 = auVar8._0_4_ - *(float *)(lVar18 + 0x25c);
  auVar1 = vshufps_avx(auVar1,auVar1,0xff);
  fVar10 = auVar1._0_4_ - *(float *)(lVar18 + 0x264);
  fVar22 = SQRT(fVar10 * fVar10 + fVar22 * fVar22 + fVar20 * fVar20 + fVar9 * fVar9);
  iVar17 = (int)(fVar22 * DAT_1402d1dac);
  if ((*(byte *)(lVar6 + 0x1676) & 1) == 0) {
    uVar16 = (ushort)iVar17;
    if ((fVar27 <= fVar26 * auVar7._0_4_ + fVar21 * auVar28._0_4_ + auVar29._0_4_ * fVar25) ||
       ((short)(int)(fVar22 * DAT_1402d2094) < 0x7d1)) {
      bVar3 = *(byte *)(param_1 + 0x3d9);
      bVar12 = bVar3 & 0xfd;
      *(byte *)(param_1 + 0x3d9) = bVar12;
      if (fVar19 <= fVar11) {
        if ((DAT_1402d1fe8 < fVar19) && (*(float *)(lVar5 + 0x270) < DAT_1402d2148)) {
          if ((*(ushort *)(lVar6 + 0x2090) & 0x40) == 0) {
            if (-1 < (char)*(ushort *)(lVar6 + 0x2090)) goto LAB_1400fdc14;
            sVar14 = *(short *)(puVar15 + 1);
          }
          else {
            sVar14 = *(short *)((longlong)puVar15 + 10);
          }
          *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1) << 3;
        }
      }
      else {
        if ((short)uVar16 < (short)(ushort)*(byte *)(param_1 + 0x3d7)) {
          if (uVar16 == 0) {
            sVar14 = *(short *)((longlong)puVar15 + 6);
          }
          else if (uVar16 == 1) {
            sVar14 = *(short *)((longlong)puVar15 + 4);
          }
          else if (uVar16 == 2) {
            sVar14 = *(short *)((longlong)puVar15 + 2);
          }
        }
        if ((short)uVar16 < 2) {
          if ((((DAT_1402d2298 < fVar19) && (DAT_1402d2d00 < fVar24)) && (fVar24 < DAT_1402d2ccc))
             && ((bVar3 & 1) == 0)) {
            sVar14 = *(short *)((longlong)puVar15 + 0x12);
            *(byte *)(param_1 + 0x3d9) = bVar12 | 1;
          }
        }
        else {
          if (DAT_1402d2d00 <= fVar24) {
            if (fVar24 <= DAT_1402d2cb0) goto LAB_1400fdb79;
          }
          else {
            sVar14 = *(short *)((longlong)puVar15 + 0xc);
            *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1) * 5;
LAB_1400fdb79:
            if (DAT_1402d2854 <= *(float *)(lVar6 + 0x74)) goto LAB_1400fdb9d;
          }
          sVar14 = *(short *)((longlong)puVar15 + 0xe);
          *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1) * 5;
        }
LAB_1400fdb9d:
        if ((uVar16 < 3) && (DAT_1402d28b8 < *(float *)(lVar6 + 0x1848))) {
          sVar14 = *(short *)(puVar15 + 2);
          *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1) * 5;
        }
      }
    }
    else {
      *(byte *)(param_1 + 0x3d9) = *(byte *)(param_1 + 0x3d9) | 2;
      sVar14 = *(short *)((longlong)puVar15 + 0x14);
    }
LAB_1400fdc14:
    if (1 < (short)uVar16) {
      fVar21 = (float)FUN_1401019d0(param_1);
      if (fVar21 == DAT_1402d2690) {
        sVar14 = *(short *)((longlong)puVar15 + 0x16);
      }
      else {
        fVar21 = (float)FUN_1401019d0(param_1);
        if (fVar21 == DAT_1402d2760) {
          sVar14 = *(short *)(puVar15 + 3);
        }
      }
    }
  }
  else {
    if (*(float *)(lVar6 + 0x1848) <= DAT_1402d28b8) goto LAB_1400fdc91;
    sVar14 = *(short *)(puVar15 + 2);
    *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1) * 5;
  }
  if (-1 < sVar14) {
    FUN_1401a61a0(*(undefined8 *)(param_1 + 0x308),sVar14,0,0,1);
  }
LAB_1400fdc91:
  *(char *)(param_1 + 0x3d7) = (char)iVar17;
  return;
}

