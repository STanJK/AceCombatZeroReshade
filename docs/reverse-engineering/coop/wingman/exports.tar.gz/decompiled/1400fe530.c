/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fe530; RVA 0xfe530
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400fe530(longlong param_1,longlong *param_2)

{
  uint *puVar1;
  byte bVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  char cVar6;
  uint uVar7;
  int iVar8;
  longlong lVar9;
  float fVar10;
  
  lVar3 = *param_2;
  lVar4 = *(longlong *)
           (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
  *(uint *)(lVar4 + 0x2058) = *(uint *)(lVar4 + 0x2058) | 0x1000;
  *(ushort *)(lVar4 + 0x1c20) = *(ushort *)(lVar4 + 0x1c20) | 1;
  if ((*(byte *)(lVar3 + 0x2f) != 0xff) && (*(byte *)(lVar3 + 0x30) != 0xff)) {
    plVar5 = *(longlong **)(param_1 + 0x2f8);
    lVar9 = *(longlong *)(*(longlong *)(*plVar5 + (ulonglong)*(byte *)(lVar3 + 0x2f) * 8) + 0x110) +
            (ulonglong)*(byte *)(lVar3 + 0x30) * 0x520;
    if (lVar9 != 0) {
      uVar7 = *(uint *)(param_1 + 0x3a8);
      iVar8 = *(int *)(param_1 + 0x378);
      bVar2 = *(byte *)(lVar3 + 0x2e);
      fVar10 = (float)*(byte *)(param_1 + 0x3d1);
      *(uint *)(param_1 + 0x3a8) = uVar7 | 0x10020;
      if (iVar8 < (int)((int)(fVar10 * *(float *)(lVar3 + 4)) & 0xffffU)) {
        if ((uVar7 & 4) == 0) {
          iVar8 = iVar8 + 1;
          *(int *)(param_1 + 0x378) = iVar8;
        }
        if (iVar8 < (int)(uint)*(byte *)(param_1 + 0x3d1)) {
          *(float *)(param_1 + 0x3a0) = DAT_1402d22d0 - (float)iVar8 / fVar10;
        }
        lVar3 = *(longlong *)(*(longlong *)(*(longlong *)*plVar5 + 0x110) + 0x1b8);
        if ((*(char *)(param_1 + 999) == '\0') &&
           (cVar6 = FUN_140101f20(param_1,bVar2 >> 2 & 1,lVar9), cVar6 != '\0')) {
          *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 8;
          *(undefined1 *)(param_1 + 999) = 1;
          puVar1 = (uint *)(lVar3 + 0x2058);
          *puVar1 = *puVar1 | 0x10;
        }
        *(uint *)(lVar4 + 0x2058) = *(uint *)(lVar4 + 0x2058) | 0x2000000;
      }
      else {
        *(uint *)(param_1 + 0x3a8) = uVar7 & 0xfffffff7 | 0x10020;
        puVar1 = (uint *)(*(longlong *)(*(longlong *)(*(longlong *)*plVar5 + 0x110) + 0x1b8) +
                         0x2058);
        *puVar1 = *puVar1 & 0xffffffef;
        *(byte *)(lVar4 + 0x1863) = *(byte *)(lVar4 + 0x1863) & 0xfe;
        *(undefined4 *)(lVar4 + 0x185c) = 0;
        *(byte *)(lVar4 + 0x1da7) = *(byte *)(lVar4 + 0x1da7) & 0xfe;
        *(undefined8 *)(lVar4 + 0x1d78) = 0;
        uVar7 = *(uint *)(lVar4 + 0x2058);
        if ((uVar7 >> 0xd & 1) != 0) {
          uVar7 = uVar7 & 0xffffdfff;
          *(undefined1 *)(lVar4 + 0x2096) = *(undefined1 *)(lVar4 + 0x2095);
        }
        *(uint *)(lVar4 + 0x2058) = uVar7 & 0xfdffffff;
        *(undefined4 *)(param_1 + 0x378) = 0;
        *(undefined1 *)(param_1 + 0x3cc) = 3;
        *(undefined1 *)(param_1 + 0x3e6) = 1;
        *(undefined4 *)(param_1 + 0x3a0) = 0;
      }
    }
  }
  return;
}

