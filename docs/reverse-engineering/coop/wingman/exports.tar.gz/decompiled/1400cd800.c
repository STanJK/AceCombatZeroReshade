/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400cd800; RVA 0xcd800
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400cd800(longlong param_1,char param_2)

{
  uint *puVar1;
  uint uVar2;
  byte bVar3;
  uint uVar4;
  int iVar5;
  longlong lVar6;
  
  if ((*(longlong *)(param_1 + 0xa8318) != 0) &&
     (lVar6 = *(longlong *)(*(longlong *)(param_1 + 0xa8318) + 0x10), lVar6 != 0)) {
    if (param_2 == '\0') {
      bVar3 = *(byte *)(lVar6 + 0x3d0) & 0xfe;
    }
    else {
      bVar3 = *(byte *)(lVar6 + 0x3d0) | 1;
    }
    *(byte *)(lVar6 + 0x3d0) = bVar3;
  }
  iVar5 = 0;
  if (*(char *)(param_1 + 0xa87e4) != '\0') {
    lVar6 = 0;
    do {
      puVar1 = (uint *)(*(longlong *)(param_1 + 0xa8248) + 0x2058 + lVar6);
      uVar2 = *puVar1;
      lVar6 = lVar6 + 0x27a0;
      uVar4 = uVar2 | 0x40;
      if (param_2 == '\0') {
        uVar4 = uVar2 & 0xffffffbf;
      }
      iVar5 = iVar5 + 1;
      *puVar1 = uVar4;
    } while (iVar5 < (int)(uint)*(byte *)(param_1 + 0xa87e4));
  }
  return;
}

