/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140171680; RVA 0x171680
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140171680(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined *puVar4;
  int *piVar5;
  ulonglong uVar6;
  int iVar7;
  undefined1 auStack_c8 [32];
  int local_a8 [36];
  ulonglong local_18;
  
  local_18 = DAT_140309040 ^ (ulonglong)auStack_c8;
  if (*(char *)(DAT_14032c8c0 + 0x83) != -1) {
    lVar2 = (longlong)DAT_14030cab4;
    *(undefined4 *)(param_1 + 0x58) = 2;
    DAT_14031ce48._4_4_ = 0;
    _DAT_14031ce58 = 0;
    _DAT_14031ce60 = 0;
    (&DAT_140328458)[lVar2] = FUN_140178620;
    _DAT_14031ce78 = 0;
    DAT_14031ce80 = 0;
    DAT_14030c8cc = 0;
    _DAT_14031ce68 = (undefined1  [16])0x0;
    DAT_14031ce48 = (ulonglong)DAT_14031ce48._4_4_ << 0x20;
    _DAT_14031ce50 = 0x100000001;
    FUN_140164290(&DAT_140310e60);
    puVar3 = &DAT_14031cdd8;
    iVar7 = 0;
    if (DAT_14031cf18 == '\0') {
      puVar3 = &DAT_140316e20;
    }
    piVar5 = &DAT_140291a28;
    *(undefined4 *)puVar3 = 0;
    puVar4 = &DAT_140316e78;
    if (DAT_14031cf18 == '\0') {
      puVar4 = &DAT_140310ec0;
    }
    do {
      iVar1 = piVar5[-2];
      uVar6 = 0;
      do {
        if (((uVar6 < 5) && (puVar4[uVar6 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
           (puVar4[uVar6 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
          lVar2 = (longlong)iVar7;
          iVar7 = iVar7 + 1;
          local_a8[lVar2] = iVar1;
          break;
        }
        uVar6 = uVar6 + 1;
      } while ((longlong)uVar6 < 1);
      iVar1 = piVar5[-1];
      uVar6 = 0;
      do {
        if (((uVar6 < 5) && (puVar4[uVar6 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
           (puVar4[uVar6 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
          lVar2 = (longlong)iVar7;
          iVar7 = iVar7 + 1;
          local_a8[lVar2] = iVar1;
          break;
        }
        uVar6 = uVar6 + 1;
      } while ((longlong)uVar6 < 1);
      iVar1 = *piVar5;
      uVar6 = 0;
      do {
        if (((uVar6 < 5) && (puVar4[uVar6 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
           (puVar4[uVar6 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
          lVar2 = (longlong)iVar7;
          iVar7 = iVar7 + 1;
          local_a8[lVar2] = iVar1;
          break;
        }
        uVar6 = uVar6 + 1;
      } while ((longlong)uVar6 < 1);
      iVar1 = piVar5[1];
      uVar6 = 0;
      do {
        if (((uVar6 < 5) && (puVar4[uVar6 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
           (puVar4[uVar6 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
          lVar2 = (longlong)iVar7;
          iVar7 = iVar7 + 1;
          local_a8[lVar2] = iVar1;
          break;
        }
        uVar6 = uVar6 + 1;
      } while ((longlong)uVar6 < 1);
      iVar1 = piVar5[2];
      uVar6 = 0;
      do {
        if (((uVar6 < 5) && (puVar4[uVar6 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
           (puVar4[uVar6 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
          lVar2 = (longlong)iVar7;
          iVar7 = iVar7 + 1;
          local_a8[lVar2] = iVar1;
          break;
        }
        uVar6 = uVar6 + 1;
      } while ((longlong)uVar6 < 1);
      iVar1 = piVar5[3];
      uVar6 = 0;
      do {
        if (((uVar6 < 5) && (puVar4[uVar6 + ((longlong)iVar1 + 0x3c) * 5] != '\0')) &&
           (puVar4[uVar6 + (longlong)iVar1 * 5 + 0xc] != '\0')) {
          lVar2 = (longlong)iVar7;
          iVar7 = iVar7 + 1;
          local_a8[lVar2] = iVar1;
          break;
        }
        uVar6 = uVar6 + 1;
      } while ((longlong)uVar6 < 1);
      piVar5 = piVar5 + 6;
    } while ((longlong)piVar5 < 0x140291ab8);
    if (0 < iVar7) {
      iVar1 = *(int *)(puVar4 + 0x24c);
      lVar2 = 0;
      do {
        if (local_a8[lVar2] == iVar1) {
          iVar7 = *(int *)(puVar4 + 0x25c);
          if (((iVar7 < 0) || (2 < iVar7)) ||
             (puVar4[(longlong)iVar7 + (longlong)iVar1 * 3 + 0x1e0] == '\0')) {
            *(undefined4 *)(puVar4 + 0x25c) = 0;
            iVar7 = 0;
          }
          *(undefined4 *)(puVar4 + 600) = *(undefined4 *)(puVar4 + 0x254);
          *(int *)(puVar4 + 0x250) = iVar1;
          *(int *)(puVar4 + 0x260) = iVar7;
          return;
        }
        lVar2 = lVar2 + 1;
      } while (lVar2 < iVar7);
    }
    *(int *)(puVar4 + 0x24c) = local_a8[0];
    *(int *)(puVar4 + 0x250) = local_a8[0];
    *(undefined8 *)(puVar4 + 0x254) = 0;
    *(undefined8 *)(puVar4 + 0x25c) = 0;
  }
  return;
}

