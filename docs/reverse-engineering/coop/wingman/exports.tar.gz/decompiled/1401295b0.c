/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401295b0; RVA 0x1295b0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401295b0(longlong param_1)

{
  float fVar1;
  float fVar2;
  
  fVar2 = *(float *)(param_1 + 0x22c);
  fVar1 = 0.0;
  if (0.0 <= fVar2) {
    if (DAT_1402d224c <= fVar2) {
      fVar1 = (fVar2 - DAT_1402d224c) * DAT_1402d2500;
      fVar2 = DAT_1402d22d0;
    }
    else {
      fVar2 = (fVar2 - DAT_1402d2d34) * DAT_1402d21b0;
    }
    *(float *)(param_1 + 0x23c) = fVar2;
    *(float *)(param_1 + 0x238) = fVar1;
    *(undefined4 *)(param_1 + 0x240) = 0;
    return;
  }
  if (DAT_1402d2d34 <= fVar2) {
    fVar1 = (fVar2 - DAT_1402d2d34) * DAT_1402d21b0;
    fVar2 = 0.0;
  }
  else {
    fVar2 = -(fVar2 * DAT_1402d23f0) + DAT_1402d2d94;
  }
  *(float *)(param_1 + 0x23c) = fVar1;
  *(float *)(param_1 + 0x240) = fVar2;
  *(undefined4 *)(param_1 + 0x238) = 0;
  return;
}

