/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140178fc0; RVA 0x178fc0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_140178fc0(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong lVar3;
  longlong lVar4;
  
  puVar1 = (undefined8 *)FUN_140200de0(DAT_14032c8f8,0xb38,0x10);
  *param_1 = puVar1;
  *puVar1 = &PTR_FUN_1402c25d0;
  puVar1[0x6f] = &PTR_FUN_1402cbb20;
  puVar1[1] = &PTR_LAB_1402c1d70;
  puVar1[2] = &PTR_FUN_1402cdd80;
  puVar1[0x76] = &PTR_FUN_1402cd410;
  puVar1[0x86] = &PTR_FUN_1402cd410;
  puVar1[0x7f] = &PTR_FUN_1402cbb20;
  lVar3 = 0x24;
  puVar1[0x8c] = &PTR_FUN_1402c4f58;
  puVar2 = puVar1 + 0x8d;
  puVar1[0x6c] = &PTR_FUN_1402c8518;
  puVar1[0x7c] = &PTR_FUN_1402c8518;
  lVar4 = 0x24;
  *(undefined4 *)(puVar1 + 3) = 0x20;
  puVar1[100] = 0;
  puVar1[0x65] = 0;
  *(undefined1 *)(puVar1 + 0x66) = 0;
  puVar1[0x67] = 0;
  puVar1[0x68] = 0;
  puVar1[0x6b] = &PTR_FUN_1402cbb50;
  puVar1[0x6d] = 0;
  puVar1[0x74] = 0;
  puVar1[0x75] = 0;
  puVar1[0x77] = 0;
  puVar1[0x7b] = &PTR_FUN_1402cbb50;
  puVar1[0x7d] = 0;
  puVar1[0x84] = 0;
  puVar1[0x85] = 0;
  puVar1[0x87] = 0;
  do {
    *puVar2 = 0;
    puVar2 = puVar2 + 3;
    lVar4 = lVar4 + -1;
  } while (lVar4 != 0);
  puVar2 = puVar1 + 0xf9;
  do {
    *puVar2 = 0;
    puVar2 = puVar2 + 3;
    lVar3 = lVar3 + -1;
  } while (lVar3 != 0);
  puVar1[0x165] = 0;
  puVar1[0x166] = 0;
  return puVar1;
}

