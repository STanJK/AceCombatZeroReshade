/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fa240; RVA 0xfa240
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400fa240(longlong param_1,longlong *param_2)

{
  byte bVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  undefined1 uVar4;
  undefined2 uVar5;
  undefined2 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  
  lVar10 = *param_2;
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffffb7;
  lVar8 = *(longlong *)(*(longlong *)**(longlong **)(param_1 + 0x2f8) + 0x110);
  lVar9 = *(longlong *)(lVar8 + 0x1b8);
  if ((*(byte *)(lVar10 + 0xb6) == 0xff) || (bVar1 = *(byte *)(lVar10 + 0xb7), bVar1 == 0xff)) {
    lVar11 = 0;
  }
  else {
    lVar11 = (ulonglong)bVar1 * 0x520 +
             *(longlong *)
              (((longlong *)**(longlong **)(param_1 + 0x2f8))[*(byte *)(lVar10 + 0xb6)] + 0x110);
  }
  *(longlong *)(lVar9 + 0x2048) = lVar11;
  *(longlong *)(lVar9 + 0x1638) = lVar11;
  *(uint *)(lVar9 + 0x2058) = *(uint *)(lVar9 + 0x2058) & 0xfffffeff;
  *(byte *)(lVar9 + 0x1677) = *(byte *)(lVar9 + 0x1677) & 0xfd;
  if (*(char *)(*(longlong *)(param_1 + 0x340) + 0xa881d) != '\x05') {
    *(undefined1 *)(param_1 + 0x3e2) = *(undefined1 *)(param_1 + 0x3e3);
  }
  uVar5 = *(undefined2 *)(lVar9 + 0x2728);
  uVar6 = *(undefined2 *)(lVar9 + 0x272a);
  uVar2 = *(undefined1 *)(lVar9 + 0x272c);
  uVar3 = *(undefined1 *)(lVar9 + 0x272d);
  uVar4 = *(undefined1 *)(lVar9 + 0x272e);
  uVar7 = *(undefined4 *)(lVar9 + 0x2784);
  FUN_140102ab0(lVar9);
  *(undefined4 *)(lVar9 + 0x2784) = uVar7;
  *(undefined2 *)(lVar9 + 0x2728) = uVar5;
  *(undefined2 *)(lVar9 + 0x272a) = uVar6;
  *(undefined1 *)(lVar9 + 0x272c) = uVar2;
  *(undefined1 *)(lVar9 + 0x272d) = uVar3;
  *(undefined1 *)(lVar9 + 0x272e) = uVar4;
  FUN_140114c30(lVar8);
  *(undefined4 *)(lVar8 + 0x420) = *(undefined4 *)(param_1 + 0x404);
  *(ushort *)(lVar8 + 0x428) = (ushort)*(byte *)(param_1 + 0x3e2);
  *(undefined8 *)(lVar8 + 0x268) = 0;
  *(undefined8 *)(lVar8 + 0x270) = 0;
  if ((*(byte *)(lVar10 + 0xb6) == 0xff) || (bVar1 = *(byte *)(lVar10 + 0xb7), bVar1 == 0xff)) {
    lVar10 = 0;
  }
  else {
    lVar10 = (ulonglong)bVar1 * 0x520 +
             *(longlong *)
              (*(longlong *)
                (**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar10 + 0xb6) * 8) + 0x110
              );
  }
  *(longlong *)(lVar9 + 0x2048) = lVar10;
  *(longlong *)(lVar9 + 0x1638) = lVar10;
  *(uint *)(lVar9 + 0x2058) = *(uint *)(lVar9 + 0x2058) & 0xfffffeff;
  *(byte *)(lVar9 + 0x1677) = *(byte *)(lVar9 + 0x1677) & 0xfd;
  *(uint *)(lVar8 + 0x1f0) = *(uint *)(lVar8 + 0x1f0) | 3;
  FUN_14010bb50(lVar9);
  local_58 = *(undefined8 *)(lVar8 + 0x268);
  uStack_50 = *(undefined8 *)(lVar8 + 0x270);
  local_48 = *(undefined8 *)(lVar8 + 600);
  uStack_40 = *(undefined8 *)(lVar8 + 0x260);
  FUN_14010a690(lVar9,&local_48,&local_58);
  *(undefined4 *)(lVar8 + 600) = *(undefined4 *)(lVar9 + 0x70);
  *(undefined4 *)(lVar8 + 0x25c) = *(undefined4 *)(lVar9 + 0x74);
  *(undefined4 *)(lVar8 + 0x260) = *(undefined4 *)(lVar9 + 0x78);
  *(undefined4 *)(lVar8 + 0x264) = *(undefined4 *)(lVar9 + 0x7c);
  *(undefined4 *)(lVar8 + 0x268) = *(undefined4 *)(lVar9 + 0x80);
  *(undefined4 *)(lVar8 + 0x26c) = *(undefined4 *)(lVar9 + 0x84);
  *(undefined4 *)(lVar8 + 0x270) = *(undefined4 *)(lVar9 + 0x88);
  *(undefined4 *)(lVar8 + 0x274) = *(undefined4 *)(lVar9 + 0x8c);
  *(uint *)(lVar9 + 0x2058) = *(uint *)(lVar9 + 0x2058) | 0x1000;
  *(ushort *)(lVar9 + 0x1c20) = *(ushort *)(lVar9 + 0x1c20) | 1;
  if ((*(uint *)(lVar9 + 0x2058) >> 0xd & 1) == 0) {
    *(uint *)(lVar9 + 0x2058) = *(uint *)(lVar9 + 0x2058) | 0x2000;
    *(undefined1 *)(lVar9 + 0x2095) = *(undefined1 *)(lVar9 + 0x2094);
  }
  *(undefined1 *)(lVar9 + 0x2096) = 2;
  *(byte *)(lVar9 + 0x1863) = *(byte *)(lVar9 + 0x1863) | 1;
  *(undefined4 *)(lVar9 + 0x185c) = 0;
  if (*(longlong *)(param_1 + 0x308) != 0) {
    FUN_1401a5f00();
  }
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffbfff;
  *(undefined4 *)(param_1 + 0x3a0) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 0x13;
  return;
}

