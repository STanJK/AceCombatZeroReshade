/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140128500; RVA 0x128500
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140128500(undefined1 (*param_1) [16],float *param_2)

{
  undefined1 auVar1 [16];
  char cVar2;
  byte bVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined1 auVar6 [16];
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  longlong lVar11;
  int iVar12;
  longlong lVar13;
  byte bVar14;
  short sVar15;
  int iVar16;
  longlong lVar17;
  
  *(float *)(param_1[9] + 4) = param_2[1];
  cVar2 = *(char *)(param_2 + 3);
  if (cVar2 == '\x01') {
    if ((float)*(uint *)(param_1[10] + 4) / (float)(byte)param_1[0xb][3] < *param_2) {
      *(uint *)(param_1[10] + 4) = *(uint *)(param_1[10] + 4) + 1;
      return;
    }
  }
  else if (cVar2 == '\x02') {
    plVar5 = *(longlong **)(param_1[7] + 8);
    if (plVar5 == (longlong *)0x0) {
      return;
    }
    iVar16 = 0;
    if (*(byte *)((longlong)plVar5 + 0x34) != 0) {
      lVar17 = 0;
      do {
        lVar13 = *(longlong *)(*plVar5 + lVar17);
        if ((*(byte *)(lVar13 + 0x15d) != param_1[0xb][5]) &&
           ((1 < *(byte *)(lVar13 + 0x15d) || (1 < (byte)param_1[0xb][5])))) {
          iVar12 = 0;
          if (0 < *(int *)(lVar13 + 0x118)) {
            lVar11 = *(longlong *)(lVar13 + 0x110);
            do {
              if ((*(byte *)(lVar11 + 0x1f0) & 2) != 0) {
                auVar1 = *param_1;
                fVar7 = auVar1._0_4_ - *(float *)(lVar11 + 600);
                auVar6 = vshufps_avx(auVar1,auVar1,0xaa);
                fVar8 = auVar6._0_4_ - *(float *)(lVar11 + 0x260);
                auVar6 = vshufps_avx(auVar1,auVar1,0x55);
                fVar9 = auVar6._0_4_ - *(float *)(lVar11 + 0x25c);
                auVar1 = vshufps_avx(auVar1,auVar1,0xff);
                fVar10 = auVar1._0_4_ - *(float *)(lVar11 + 0x264);
                if (SQRT(fVar10 * fVar10 + fVar8 * fVar8 + fVar9 * fVar9 + fVar7 * fVar7) <
                    param_2[1]) {
                  return;
                }
                break;
              }
              iVar12 = iVar12 + 1;
              lVar11 = lVar11 + 0x520;
            } while (iVar12 < *(int *)(lVar13 + 0x118));
          }
        }
        iVar16 = iVar16 + 1;
        lVar17 = lVar17 + 8;
      } while (iVar16 < (int)(uint)*(byte *)((longlong)plVar5 + 0x34));
    }
  }
  else {
    if (cVar2 != '\x03') {
      return;
    }
    lVar17 = (*(undefined8 **)param_1[7])[3];
    if (((lVar17 == 0) ||
        (puVar4 = (undefined8 *)**(undefined8 **)param_1[7], puVar4 == (undefined8 *)0x0)) ||
       (*(ushort *)*puVar4 <= *(ushort *)((longlong)param_2 + 10))) {
      sVar15 = 0;
    }
    else {
      sVar15 = *(short *)(lVar17 + (ulonglong)*(ushort *)((longlong)param_2 + 10) * 2);
    }
    if (sVar15 != *(short *)(param_2 + 2)) {
      return;
    }
  }
  bVar3 = param_1[0xb][0];
  lVar17 = *(longlong *)(*(longlong *)param_1[6] + 8);
  if ((int)(uint)(byte)param_1[10][0xf] < (int)(**(byte **)(lVar17 + (ulonglong)bVar3 * 0x10) - 1))
  {
    bVar14 = param_1[10][0xf] + 1;
    param_1[10][0xf] = bVar14;
    lVar17 = *(longlong *)(lVar17 + 8 + (ulonglong)bVar3 * 0x10);
    lVar13 = (ulonglong)bVar14 * 0x40;
    if (**(char **)(lVar13 + lVar17) == '\x02') {
      if (*(longlong *)(lVar13 + 0x18 + lVar17) == 0) {
        return;
      }
      FUN_140126b60(param_1);
    }
    else {
      if (**(char **)(lVar13 + lVar17) != '\x03') {
        return;
      }
      if (*(longlong *)(lVar13 + 0x20 + lVar17) == 0) {
        return;
      }
      FUN_140126ec0(param_1);
    }
    param_1[10][0xe] = param_1[10][0xe] | 1;
  }
  return;
}

