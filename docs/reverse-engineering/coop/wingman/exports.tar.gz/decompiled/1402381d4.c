/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1402381d4; RVA 0x2381d4
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1402381d4(void)

{
  longlong lVar1;
  
  lVar1 = FUN_1402381c8();
  if (lVar1 != 0) {
    (*(code *)PTR__guard_dispatch_icall_14027b890)();
  }
                    /* WARNING: Subroutine does not return */
  FUN_14024fe78();
}

