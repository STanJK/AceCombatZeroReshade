/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f6380; RVA 0xf6380
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400f6380(longlong param_1,longlong *param_2)

{
  uint *puVar1;
  byte *pbVar2;
  float fVar3;
  float fVar4;
  undefined4 *puVar5;
  longlong lVar6;
  undefined4 *puVar7;
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  float fVar10;
  byte bVar11;
  short sVar12;
  longlong lVar13;
  longlong *plVar14;
  ulonglong uVar15;
  ushort uVar16;
  longlong *plVar17;
  longlong lVar18;
  uint uVar19;
  longlong lVar20;
  longlong lVar21;
  undefined8 *puVar22;
  longlong *plVar23;
  uint uVar24;
  int iVar25;
  longlong lVar26;
  uint *puVar27;
  longlong lVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  undefined1 auVar32 [16];
  float fVar33;
  float fVar34;
  undefined1 auVar35 [64];
  longlong local_res8;
  longlong *local_res10;
  int local_res18;
  longlong *local_res20;
  uint in_stack_ffffffffffffff28;
  ulonglong in_stack_ffffffffffffff30;
  undefined1 local_a0 [16];
  short local_90;
  
  puVar5 = (undefined4 *)*param_2;
  plVar23 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
  lVar26 = *(longlong *)(*(longlong *)(*plVar23 + 0x110) + 0x1b8);
  local_res8 = param_1;
  local_res10 = param_2;
  local_res20 = plVar23;
  lVar13 = FUN_1401c56d0();
  plVar17 = *(longlong **)(param_1 + 0x2f8);
  puVar27 = (uint *)(param_1 + 0x3a8);
  *puVar27 = *puVar27 & 0xfffe3ee7 | 0x20;
  if ((plVar17 != (longlong *)0x0) &&
     ((*(uint *)(*(longlong *)(param_1 + 0x340) + 0xa8790) & 0x40000000) == 0)) {
    plVar14 = (longlong *)*plVar17;
    if (plVar14 != plVar14 + *(byte *)((longlong)plVar17 + 0x34)) {
      do {
        lVar28 = *plVar14;
        iVar25 = 0;
        if (0 < *(int *)(lVar28 + 0x118)) {
          lVar20 = 0;
          do {
            lVar20 = lVar20 + 0x520;
            iVar25 = iVar25 + 1;
            pbVar2 = (byte *)(*(longlong *)(lVar28 + 0x110) + -0x2d2 + lVar20);
            *pbVar2 = *pbVar2 & 0xfd;
          } while (iVar25 < *(int *)(lVar28 + 0x118));
        }
        plVar14 = plVar14 + 1;
      } while (plVar14 !=
               (longlong *)(*plVar17 + (ulonglong)*(byte *)((longlong)plVar17 + 0x34) * 8));
    }
    plVar17 = *(longlong **)(param_1 + 0x2f8);
    plVar14 = (longlong *)*plVar17;
    if (plVar14 != plVar14 + *(byte *)((longlong)plVar17 + 0x34)) {
      do {
        lVar28 = *plVar14;
        iVar25 = 0;
        if (0 < *(int *)(lVar28 + 0x118)) {
          lVar20 = 0;
          do {
            lVar20 = lVar20 + 0x520;
            iVar25 = iVar25 + 1;
            pbVar2 = (byte *)(*(longlong *)(lVar28 + 0x110) + -0x2d2 + lVar20);
            *pbVar2 = *pbVar2 & 0xfe;
          } while (iVar25 < *(int *)(lVar28 + 0x118));
        }
        *(uint *)(lVar28 + 0x120) = *(uint *)(lVar28 + 0x120) & 0xffffffef;
        plVar14 = plVar14 + 1;
      } while (plVar14 !=
               (longlong *)(*plVar17 + (ulonglong)*(byte *)((longlong)plVar17 + 0x34) * 8));
    }
  }
  if (((*(byte *)(puVar5 + 0x10) & 0x10) == 0) && (*(longlong *)(param_1 + 0x338) != 0)) {
    lVar28 = *(longlong *)(*(longlong *)(param_1 + 0x338) + 0x66ee0);
    *(undefined8 *)(lVar28 + 0x1bc48) = 0;
    *(undefined8 *)(lVar28 + 0x1bc50) = 0;
    *(undefined8 *)(lVar28 + 0x1bc58) = 0;
    *(undefined8 *)(lVar28 + 0x1bc60) = 0;
    *(undefined8 *)(lVar28 + 0x1bc68) = 0;
    *(undefined8 *)(lVar28 + 0x1bc70) = 0;
    *(undefined8 *)(lVar28 + 0x1bc78) = 0;
    *(undefined8 *)(lVar28 + 0x1bc80) = 0;
    *(int *)(lVar28 + 0x1bc8c) = *(int *)(lVar28 + 0x1bc8c) + 1;
    *(undefined4 *)(lVar28 + 0x1bc88) = 0;
    if (0xe < *(int *)(lVar28 + 0x1bc8c)) {
      *(undefined4 *)(lVar28 + 0x1bc8c) = 0;
    }
  }
  uVar24 = puVar5[0x10];
  if ((uVar24 & 4) == 0) {
    *(undefined4 *)(param_1 + 900) = 0;
    uVar24 = puVar5[0x10];
  }
  lVar28 = *(longlong *)(param_1 + 0x318);
  if (lVar28 != 0) {
    if ((uVar24 >> 0x10 & 1) == 0) {
      bVar11 = *(byte *)(lVar28 + 0x23) & 0xef;
    }
    else {
      bVar11 = *(byte *)(lVar28 + 0x23) | 0x10;
    }
    *(byte *)(lVar28 + 0x23) = bVar11;
  }
  if (*(longlong *)(param_1 + 0x340) != 0) {
    FUN_1400d1560(*(longlong *)(param_1 + 0x340),0);
  }
  plVar17 = *(longlong **)(param_1 + 0x2f8);
  local_res18 = 0;
  if (*(char *)((longlong)plVar17 + 0x34) != '\0') {
    lVar28 = 0;
    do {
      lVar20 = *plVar17;
      lVar18 = *(longlong *)(lVar28 + lVar20);
      if (*(longlong *)(*(longlong *)(lVar18 + 0x130) + 8) != 0) {
        iVar25 = 0;
        if (0 < *(int *)(lVar18 + 0x118)) {
          lVar21 = 0;
          do {
            lVar18 = *(longlong *)(lVar18 + 0x110);
            lVar6 = *(longlong *)(lVar18 + 0x10 + lVar21);
            if (lVar6 != 0) {
              puVar27 = (uint *)(lVar6 + 0xa8);
              *puVar27 = *puVar27 & 0xffff7fff;
            }
            lVar18 = *(longlong *)(lVar18 + 8 + lVar21);
            if (lVar18 != 0) {
              puVar27 = (uint *)(lVar18 + 0xa8);
              *puVar27 = *puVar27 & 0xffff7fff;
            }
            lVar18 = *(longlong *)(lVar28 + lVar20);
            iVar25 = iVar25 + 1;
            lVar21 = lVar21 + 0x520;
          } while (iVar25 < *(int *)(lVar18 + 0x118));
        }
        *(uint *)(lVar18 + 0xf0) = *(uint *)(lVar18 + 0xf0) & 0xffff7fff;
        uVar24 = 0;
        lVar18 = *(longlong *)(lVar28 + lVar20);
        if (*(char *)**(undefined8 **)(*(longlong *)(lVar18 + 0x130) + 8) != '\0') {
          do {
            puVar22 = *(undefined8 **)
                       (*(longlong *)(*(longlong *)(*(longlong *)(lVar18 + 0x130) + 8) + 8) + 8 +
                       (longlong)(int)uVar24 * 0x10);
            if (*(char *)*puVar22 == '\0') {
              in_stack_ffffffffffffff30 = in_stack_ffffffffffffff30 & 0xffffffffffffff00;
              in_stack_ffffffffffffff28 = in_stack_ffffffffffffff28 & 0xffffff00;
              FUN_140126fd0(lVar18 + 0x48,puVar22[1],uVar24 & 0xff,0,in_stack_ffffffffffffff28,
                            in_stack_ffffffffffffff30);
              if (((*(byte *)(*(longlong *)(lVar28 + lVar20) + 0xf6) & 2) != 0) &&
                 (FUN_140133cd0(*(longlong *)(lVar28 + lVar20),1),
                 (*(byte *)(*(longlong *)(lVar28 + lVar20) + 0xf6) & 1) != 0)) {
                FUN_140133ae0();
              }
            }
            lVar18 = *(longlong *)(lVar28 + lVar20);
            uVar24 = uVar24 + 1;
          } while ((int)uVar24 <
                   (int)(uint)*(byte *)**(undefined8 **)(*(longlong *)(lVar18 + 0x130) + 8));
        }
        if ((*(byte *)(lVar18 + 0x120) & 1) != 0) {
          iVar25 = 0;
          if (0 < *(int *)(lVar18 + 0x118)) {
            lVar21 = 0;
            do {
              lVar18 = *(longlong *)(lVar18 + 0x110);
              puVar7 = *(undefined4 **)(lVar18 + 0x10 + lVar21);
              if (puVar7 == (undefined4 *)0x0) {
                puVar27 = (uint *)(lVar18 + 0x1f0 + lVar21);
                *puVar27 = *puVar27 & 0xffffbfff;
              }
              else {
                puVar22 = *(undefined8 **)(puVar7 + 0x18);
                uVar24 = 0;
                *(undefined1 *)((longlong)puVar7 + 0xae) = 0;
                if (*(char *)*puVar22 != '\0') {
                  do {
                    puVar22 = *(undefined8 **)(puVar22[1] + 8 + (longlong)(int)uVar24 * 0x10);
                    if (*(char *)*puVar22 == '\0') {
                      in_stack_ffffffffffffff30 = in_stack_ffffffffffffff30 & 0xffffffffffffff00;
                      in_stack_ffffffffffffff28 = in_stack_ffffffffffffff28 & 0xffffff00;
                      FUN_140126fd0(puVar7,puVar22[1],uVar24 & 0xff,0,in_stack_ffffffffffffff28,
                                    in_stack_ffffffffffffff30);
                    }
                    if ((*(byte *)((longlong)puVar7 + 0xae) & 2) != 0) {
                      *(undefined4 *)(lVar18 + 600 + lVar21) = *puVar7;
                      *(undefined4 *)(lVar18 + 0x25c + lVar21) = puVar7[1];
                      *(undefined4 *)(lVar18 + 0x260 + lVar21) = puVar7[2];
                      *(undefined4 *)(lVar18 + 0x264 + lVar21) = puVar7[3];
                      *(undefined4 *)(lVar18 + 0x268 + lVar21) = puVar7[4];
                      *(undefined4 *)(lVar18 + 0x26c + lVar21) = puVar7[5];
                      *(undefined4 *)(lVar18 + 0x270 + lVar21) = puVar7[6];
                      *(undefined4 *)(lVar18 + 0x274 + lVar21) = puVar7[7];
                      puVar27 = (uint *)(lVar18 + 0x1f0 + lVar21);
                      *puVar27 = *puVar27 | 0x4003;
                      goto LAB_1400f6793;
                    }
                    puVar22 = *(undefined8 **)(puVar7 + 0x18);
                    uVar24 = uVar24 + 1;
                  } while ((int)uVar24 < (int)(uint)*(byte *)*puVar22);
                }
                *(uint *)(lVar18 + 0x1f0 + lVar21) = *(uint *)(lVar18 + 0x1f0 + lVar21) & 0xffffbfff
                ;
              }
LAB_1400f6793:
              lVar18 = *(longlong *)(lVar28 + lVar20);
              iVar25 = iVar25 + 1;
              lVar21 = lVar21 + 0x520;
            } while (iVar25 < *(int *)(lVar18 + 0x118));
            param_1 = local_res8;
          }
        }
      }
      plVar17 = *(longlong **)(param_1 + 0x2f8);
      local_res18 = local_res18 + 1;
      lVar28 = lVar28 + 8;
    } while (local_res18 < (int)(uint)*(byte *)((longlong)plVar17 + 0x34));
    puVar27 = (uint *)(param_1 + 0x3a8);
    plVar23 = local_res20;
  }
  FUN_140136130();
  auVar8 = vpcmpeqd_avx(ZEXT416(puVar5[0x10] & 0x10),ZEXT416(0));
  auVar9._12_4_ = 0;
  auVar9._0_12_ = ZEXT812(0);
  auVar35 = ZEXT1264(ZEXT812(0)) << 0x20;
  auVar32 = ZEXT416(DAT_1402d22d0);
  auVar8 = vblendvps_avx(auVar9 << 0x20,auVar32,auVar8);
  *(int *)(param_1 + 0x3a0) = auVar8._0_4_;
  *(undefined4 *)(param_1 + 0x378) = 0;
  *(undefined4 *)(param_1 + 0x38c) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 2;
  uVar24 = puVar5[0x10];
  if (-1 < (char)uVar24) {
    if ((uVar24 >> 9 & 1) == 0) {
      auVar8 = vpcmpeqd_avx(ZEXT416(uVar24 & 0x100),ZEXT416(0));
      auVar8 = vblendvps_avx(auVar32,auVar9 << 0x20,auVar8);
      *(int *)(param_1 + 0x398) = auVar8._0_4_;
    }
    *(undefined2 *)(param_1 + 0x3bc) = 0;
  }
  if ((puVar5[0x10] & 0x400) == 0) {
    if ((DAT_14031f8b1 & 1) == 0) {
      FUN_140187110((int)(char)(&DAT_14031f8a8)
                               [(longlong)*(short *)(lVar13 + 4) + (ulonglong)DAT_14031f8b0 * 4],0);
    }
    uVar15 = (ulonglong)*(byte *)(lVar13 + 0xc);
    *(undefined8 *)(&DAT_140310a70 + uVar15 * 8) = 0x42fe0000;
    (&DAT_140310a6c)[uVar15 * 8] = 0;
    (&DAT_140310a78)[uVar15 * 0x20] = 2;
  }
  else {
    uVar15 = (ulonglong)DAT_14031f8b0;
    bVar11 = DAT_14031f8b1 & 1;
    if ((((DAT_14031f8b1 & 1) != 0) ||
        (iVar25 = FUN_140187060((int)(char)(&DAT_14031f8a8)
                                           [(longlong)*(short *)(lVar13 + 4) + uVar15 * 4],local_a0)
        , iVar25 != 0)) || (local_90 != 3)) {
      sVar12 = *(short *)((longlong)puVar5 + 0x5e);
      (&DAT_140310a64)[(ulonglong)*(byte *)(lVar13 + 0xc) * 8] = 0x42fe0000;
      if (bVar11 == 0) {
        lVar13 = (longlong)*(short *)(lVar13 + 4);
        if (((-1 < sVar12) && ((int)sVar12 < *(int *)(&DAT_14031f838 + lVar13 * 0x18))) &&
           (*(longlong *)(&DAT_14031f840 + lVar13 * 0x18) != 0)) {
          in_stack_ffffffffffffff28 = (uint)(char)(&DAT_14031f8a8)[lVar13 + uVar15 * 4];
          FUN_140186f20((&DAT_14033bc00)[(char)(&DAT_14031f8a8)[lVar13 + uVar15 * 4]],
                        &DAT_14031f438 + lVar13 * 0x100,
                        *(undefined4 *)
                         (*(longlong *)(&DAT_14031f840 + lVar13 * 0x18) + (longlong)sVar12 * 4),0,
                        in_stack_ffffffffffffff28,0,0,1);
          *(int *)(&DAT_14031f898 + lVar13 * 4) = (int)sVar12;
        }
        param_1 = local_res8;
      }
    }
  }
  if ((puVar5[0x10] & 0x2000) == 0) {
    *(undefined1 *)(lVar26 + 0x60) = 0;
    iVar25 = 1;
    lVar13 = *plVar23;
    if (1 < *(int *)(lVar13 + 0x118)) {
      lVar28 = 0x520;
      do {
        lVar13 = *(longlong *)(*(longlong *)(lVar13 + 0x110) + 0x1c0 + lVar28);
        if (lVar13 != 0) {
          *(undefined1 *)(lVar13 + 0xf8) = 0;
          if (*(longlong *)(lVar13 + 0x10) != 0) {
            puVar1 = (uint *)(*(longlong *)(lVar13 + 0x10) + 0x558);
            *puVar1 = *puVar1 & 0xfffffdff;
          }
        }
        lVar13 = *plVar23;
        iVar25 = iVar25 + 1;
        lVar28 = lVar28 + 0x520;
      } while (iVar25 < *(int *)(lVar13 + 0x118));
    }
  }
  else {
    *(undefined1 *)(lVar26 + 0x60) = 1;
    iVar25 = 1;
    lVar13 = *plVar23;
    if (1 < *(int *)(lVar13 + 0x118)) {
      lVar28 = 0x520;
      do {
        lVar13 = *(longlong *)(*(longlong *)(lVar13 + 0x110) + 0x1c0 + lVar28);
        if (lVar13 != 0) {
          lVar20 = *(longlong *)(lVar13 + 0x10);
          *(undefined1 *)(lVar13 + 0xf8) = 1;
          if (lVar20 != 0) {
            if ((*(uint *)(lVar20 + 0x558) >> 8 & 1) != 0) {
              *(uint *)(lVar20 + 0x558) = *(uint *)(lVar20 + 0x558) | 0x200;
            }
            puVar1 = (uint *)(*(longlong *)(lVar13 + 0x10) + 0x558);
            *puVar1 = *puVar1 & 0xfffffbff;
          }
        }
        lVar13 = *plVar23;
        iVar25 = iVar25 + 1;
        lVar28 = lVar28 + 0x520;
      } while (iVar25 < *(int *)(lVar13 + 0x118));
    }
  }
  iVar25 = 1;
  pbVar2 = (byte *)(*(longlong *)(param_1 + 0x2f8) + 0x69);
  *pbVar2 = *pbVar2 | 4;
  plVar23 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
  lVar13 = *plVar23;
  if (1 < *(int *)(lVar13 + 0x118)) {
    lVar28 = 0x520;
    do {
      lVar13 = *(longlong *)(*(longlong *)(lVar13 + 0x110) + 0x1c0 + lVar28);
      if (lVar13 != 0) {
        (**(code **)(**(longlong **)(lVar13 + 0x10) + 0x1c8))();
      }
      lVar13 = *plVar23;
      iVar25 = iVar25 + 1;
      lVar28 = lVar28 + 0x520;
    } while (iVar25 < *(int *)(lVar13 + 0x118));
  }
  if (lVar26 != 0) {
    uVar24 = *(uint *)(lVar26 + 0x2058);
    *(byte *)(lVar26 + 0x1863) = *(byte *)(lVar26 + 0x1863) | 1;
    uVar19 = uVar24 & 0xffffffef;
    *(undefined4 *)(lVar26 + 0x185c) = 0;
    *(undefined8 *)(lVar26 + 0x1d78) = 0;
    *(byte *)(lVar26 + 0x1da7) = *(byte *)(lVar26 + 0x1da7) & 0xfe;
    if ((uVar24 >> 0xd & 1) != 0) {
      uVar19 = uVar24 & 0xffffdfef;
      *(undefined1 *)(lVar26 + 0x2096) = *(undefined1 *)(lVar26 + 0x2095);
    }
    *(uint *)(lVar26 + 0x2058) = uVar19 & 0xfdffffff | 0x20;
    if ((*(longlong **)(lVar26 + 0x2040) == (longlong *)0x0) ||
       (*(int *)(*(longlong *)
                  (**(longlong **)(lVar26 + 0x2040) + (ulonglong)*(byte *)(lVar26 + 0x20a1) * 8) +
                0x118) < 2)) {
      *(uint *)(lVar26 + 0x2058) = uVar19 & 0xfdffffff | 0x1020;
      *(ushort *)(lVar26 + 0x1c20) = *(ushort *)(lVar26 + 0x1c20) | 1;
    }
    else {
      *(uint *)(lVar26 + 0x2058) = uVar19 & 0xfdffefff | 0x20;
      *(ushort *)(lVar26 + 0x1c20) = *(ushort *)(lVar26 + 0x1c20) & 0xfffe;
    }
  }
  if ((*(longlong *)(param_1 + 0x308) != 0) && (-1 < *(short *)(puVar5 + 0x11))) {
    FUN_1401a61a0(*(longlong *)(param_1 + 0x308),*(short *)(puVar5 + 0x11),0,0,
                  in_stack_ffffffffffffff28 & 0xffffff00);
  }
  *(undefined4 *)(param_1 + 0x348) = *puVar5;
  *(undefined4 *)(param_1 + 0x34c) = puVar5[2];
  *(undefined4 *)(param_1 + 0x350) = puVar5[1];
  *(undefined4 *)(param_1 + 0x354) = puVar5[3];
  bVar11 = *(byte *)(param_1 + 0x3d0) | 2;
  if ((*(uint *)(*local_res10 + 0x40) & 2) == 0) {
    bVar11 = *(byte *)(param_1 + 0x3d0) & 0xfd;
  }
  *(byte *)(param_1 + 0x3d0) = bVar11;
  FUN_1400f43c0(param_1,local_res10);
  fVar33 = DAT_1402d2bcc;
  uVar24 = *puVar27;
  if ((puVar5[0x10] & 0x20000) == 0) {
    uVar24 = uVar24 & 0xffdfffff;
  }
  else {
    *puVar27 = uVar24 | 0x200000;
    fVar3 = (float)puVar5[4];
    *(float *)(param_1 + 0x358) = fVar3;
    fVar31 = (float)puVar5[6];
    *(float *)(param_1 + 0x35c) = fVar31;
    fVar29 = (float)puVar5[5];
    *(float *)(param_1 + 0x360) = fVar29;
    fVar10 = DAT_1402d2ed8;
    fVar4 = (float)puVar5[7];
    fVar34 = auVar35._0_4_;
    *(float *)(param_1 + 0x364) = fVar4;
    fVar30 = fVar3;
    if ((fVar34 < fVar31 * fVar3) && (fVar30 = fVar10, fVar34 < fVar3)) {
      fVar30 = fVar3;
      fVar31 = fVar33;
    }
    *(float *)(param_1 + 0x368) = fVar30;
    *(float *)(param_1 + 0x370) = fVar31;
    fVar3 = fVar29;
    if (fVar4 * fVar29 <= fVar34) {
LAB_1400f6d75:
      fVar29 = fVar3;
      fVar33 = fVar4;
    }
    else {
      fVar3 = fVar10;
      if (fVar29 <= fVar34) goto LAB_1400f6d75;
    }
    *(float *)(param_1 + 0x36c) = fVar29;
    *(float *)(param_1 + 0x374) = fVar33;
    uVar24 = uVar24 | 0xa00000;
  }
  *puVar27 = uVar24;
  if (*(char *)(puVar5 + 0x1a) == '\x01') {
    *(undefined1 *)(param_1 + 0x3e6) = 1;
  }
  else if (*(char *)(puVar5 + 0x1a) == '\x02') {
    local_res10 = (longlong *)CONCAT62(local_res10._2_6_,1);
    local_res8 = CONCAT62(local_res8._2_6_,0x14);
    FUN_1401c6150(puVar27,&local_res10,&local_res8);
    *(undefined1 *)(param_1 + 0x3e6) = 2;
  }
  uVar16 = *(ushort *)((longlong)puVar5 + 0x4a);
  if (uVar16 == 0xffff) goto LAB_1400f6ebb;
  lVar13 = (*(undefined8 **)(param_1 + 0x300))[3];
  if (lVar13 == 0) {
LAB_1400f6e37:
    sVar12 = 0;
  }
  else {
    puVar22 = (undefined8 *)**(undefined8 **)(param_1 + 0x300);
    if (puVar22 == (undefined8 *)0x0) {
      sVar12 = 0;
    }
    else {
      if (*(ushort *)*puVar22 <= uVar16) goto LAB_1400f6e37;
      sVar12 = *(short *)(lVar13 + (ulonglong)uVar16 * 2);
    }
  }
  if (sVar12 == *(short *)(puVar5 + 0x13)) {
    if ((*(byte *)(puVar5 + 0x10) & 1) == 0) {
      if ((*(uint *)(lVar26 + 0x2058) >> 0xd & 1) != 0) {
        *(uint *)(lVar26 + 0x2058) = *(uint *)(lVar26 + 0x2058) & 0xffffdfff;
        *(undefined1 *)(lVar26 + 0x2096) = *(undefined1 *)(lVar26 + 0x2095);
      }
      *puVar27 = *puVar27 | 2;
      if ((*(char *)(param_1 + 0x3c9) == '\0') && (*(char *)(param_1 + 0x3d4) == '\0')) {
        FUN_1401363c0(*(undefined8 *)(param_1 + 0x2f8),CONCAT71((int7)((ulonglong)lVar13 >> 8),1));
      }
    }
    else {
      *(undefined1 *)(*(longlong *)(param_1 + 0x340) + 0xa8820) = 1;
      *(undefined1 *)(param_1 + 0x3cc) = 8;
      *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
    }
  }
LAB_1400f6ebb:
  if (*(char *)(param_1 + 0x402) == '\x01') {
    iVar25 = 0;
    plVar23 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
    lVar26 = *plVar23;
    if (*(char *)**(undefined8 **)(*(longlong *)(lVar26 + 0x130) + 8) != '\0') {
      lVar13 = 0;
      do {
        uVar16 = (ushort)(int)((float)*(byte *)(lVar26 + 0xfb) *
                              *(float *)(**(longlong **)
                                           (*(longlong *)
                                             (*(longlong *)
                                               (*(longlong *)(*(longlong *)(lVar26 + 0x130) + 8) + 8
                                               ) + 8 + lVar13) + 8) + 0x30));
        *(ushort *)(lVar26 + 0xf4) = uVar16;
        if (uVar16 < 2) {
          *(undefined2 *)(lVar26 + 0xf4) = 2;
        }
        lVar26 = *plVar23;
        iVar25 = iVar25 + 1;
        lVar13 = lVar13 + 0x10;
      } while (iVar25 < (int)(uint)*(byte *)**(undefined8 **)(*(longlong *)(lVar26 + 0x130) + 8));
    }
    *(undefined1 *)(param_1 + 0x400) = 0;
    iVar25 = 0;
    *(undefined2 *)(param_1 + 0x3fc) = 0;
    lVar26 = **(longlong **)(param_1 + 0x2f8);
    lVar13 = *(longlong *)(lVar26 + 8);
    if (*(char *)**(undefined8 **)(*(longlong *)(lVar13 + 0x130) + 8) != '\0') {
      lVar28 = 0;
      do {
        uVar16 = (ushort)(int)((float)*(byte *)(lVar13 + 0xfb) *
                              *(float *)(**(longlong **)
                                           (*(longlong *)
                                             (*(longlong *)
                                               (*(longlong *)(*(longlong *)(lVar13 + 0x130) + 8) + 8
                                               ) + 8 + lVar28) + 8) + 0x30));
        *(ushort *)(lVar13 + 0xf4) = uVar16;
        if (uVar16 < 2) {
          *(undefined2 *)(lVar13 + 0xf4) = 2;
        }
        lVar13 = *(longlong *)(lVar26 + 8);
        iVar25 = iVar25 + 1;
        lVar28 = lVar28 + 0x10;
      } while (iVar25 < (int)(uint)*(byte *)**(undefined8 **)(*(longlong *)(lVar13 + 0x130) + 8));
    }
    *(undefined1 *)(param_1 + 0x401) = 0;
    *(undefined2 *)(param_1 + 0x3fe) = 0;
    iVar25 = *(int *)(param_1 + 0x3f8);
  }
  else {
    iVar25 = (int)(float)puVar5[9];
  }
  *(int *)(param_1 + 0x3f0) = iVar25;
  return;
}

