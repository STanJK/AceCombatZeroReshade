/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400a0c80; RVA 0xa0c80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400a0c80(longlong param_1)

{
  undefined1 (*pauVar1) [16];
  ushort uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  float fVar5;
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  float fVar8;
  float fVar9;
  float fVar10;
  undefined1 auVar11 [16];
  char cVar12;
  byte bVar13;
  undefined2 uVar14;
  int iVar15;
  longlong lVar16;
  undefined4 *puVar17;
  ulonglong uVar18;
  longlong lVar19;
  ulonglong uVar20;
  longlong lVar21;
  uint uVar22;
  longlong lVar23;
  uint uVar24;
  undefined8 uVar25;
  undefined1 extraout_var [56];
  undefined1 extraout_var_00 [56];
  undefined1 auVar26 [64];
  undefined1 auVar27 [64];
  undefined1 auVar28 [64];
  float fVar29;
  undefined1 auVar30 [64];
  uint uVar31;
  undefined8 uVar32;
  undefined8 uVar33;
  undefined4 uVar34;
  undefined4 uVar35;
  undefined4 uVar36;
  undefined1 auVar37 [64];
  uint local_res10 [2];
  longlong local_res18;
  undefined1 local_res20 [8];
  longlong local_228;
  longlong local_220;
  undefined1 local_218 [16];
  undefined4 local_208;
  undefined1 local_200 [16];
  undefined4 local_1e8;
  float local_1e4;
  uint local_1e0;
  float local_1dc;
  float local_1d8;
  undefined4 local_1d4;
  float local_1d0;
  float local_1cc;
  uint local_1c8;
  float local_1c4;
  undefined4 local_1c0;
  float local_1bc;
  float local_1b8;
  float local_1b4;
  float local_1b0;
  undefined4 local_1ac;
  undefined4 local_1a8;
  float local_1a4;
  float local_1a0;
  float local_19c;
  float local_198;
  undefined4 local_194;
  uint local_190;
  float local_18c;
  float local_188;
  uint local_184;
  undefined4 local_180;
  float local_17c;
  float local_178;
  float local_174;
  float local_170;
  undefined4 local_16c;
  longlong local_168;
  float local_160;
  float local_15c;
  float local_158;
  float local_154;
  float local_150;
  float local_14c;
  float local_148;
  float local_144;
  undefined1 local_140 [8];
  float fStack_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined4 local_124;
  undefined4 local_120;
  float local_11c;
  undefined4 local_118;
  undefined4 local_114;
  undefined1 local_110 [8];
  longlong local_108;
  undefined1 local_100 [12] [16];
  
  auVar30 = ZEXT464(DAT_1402d22d0);
  local_res10[0] = 1;
  local_228 = 0;
  auVar37 = ZEXT464(DAT_1402d23c0);
  local_220 = 0x10;
  auVar28 = ZEXT864(0);
  fVar29 = DAT_1402d28ec;
  uVar31 = DAT_1402d3770;
  uVar34 = DAT_1402d2458;
  uVar35 = DAT_1402d234c;
  uVar36 = DAT_1402d2100;
  uVar32 = _DAT_1402d35f0;
  uVar33 = _UNK_1402d35f8;
  do {
    uVar24 = local_res10[0];
    uVar22 = 0;
    if ((*(uint *)(param_1 + 0x5c) & local_res10[0]) != 0) {
      pauVar1 = (undefined1 (*) [16])(local_228 + 0x80 + param_1);
      iVar15 = *(int *)(pauVar1[6] + 8);
      if (iVar15 == 0) {
        if (*(longlong *)(param_1 + 0x18) != 0) {
          local_200 = *pauVar1;
          local_160 = local_200._0_4_ + *(float *)pauVar1[2];
          auVar6 = vshufps_avx(local_200,local_200,0x55);
          local_15c = auVar6._0_4_ + *(float *)(pauVar1[2] + 4);
          auVar6 = vshufps_avx(local_200,local_200,0xaa);
          local_158 = auVar6._0_4_ + *(float *)(pauVar1[2] + 8);
          auVar6 = vshufps_avx(local_200,local_200,0xff);
          local_154 = auVar6._0_4_ + *(float *)(pauVar1[2] + 0xc);
          local_100[0] = ZEXT816(0);
          iVar15 = FUN_1400782c0(*(longlong *)(param_1 + 0x18),local_100,local_res20,local_200,
                                 &local_160);
          if (iVar15 != 0) {
            *(undefined4 *)(pauVar1[6] + 8) = 1;
          }
        }
        uVar18 = CONCAT71(0,pauVar1[5][0]);
        local_200._0_8_ = uVar18;
        local_res18 = 0;
        lVar16 = **(longlong **)(param_1 + 0x10);
        uVar20 = CONCAT71(0,*(byte *)((longlong)*(longlong **)(param_1 + 0x10) + 0x34));
        local_100[0]._0_8_ = uVar20;
        local_108 = lVar16;
        if (uVar20 != 0) {
          do {
            uVar20 = 0;
            lVar19 = **(longlong **)(param_1 + 0x10);
            lVar23 = *(longlong *)(lVar19 + local_res18 * 8);
            bVar13 = *(byte *)(*(longlong *)(lVar16 + uVar18 * 8) + 0x15d);
            lVar21 = local_res18;
            local_168 = lVar19;
            if (((*(byte *)(lVar23 + 0x15d) != bVar13) &&
                ((&DAT_1402accc0)[(ulonglong)bVar13 + (ulonglong)*(byte *)(lVar23 + 0x15d) * 8] !=
                 '\0')) &&
               (((*(byte *)(lVar23 + 0x120) & 4) != 0 &&
                (lVar23 = (longlong)*(int *)(lVar23 + 0x118), uVar18 = uVar20, 0 < lVar23)))) {
              do {
                uVar24 = (uint)uVar18;
                if (((uVar22 != (byte)pauVar1[5][0]) || (uVar24 != (byte)pauVar1[5][1])) &&
                   (lVar16 = *(longlong *)(*(longlong *)(lVar19 + lVar21 * 8) + 0x110),
                   (*(byte *)(lVar16 + 0x1f0 + uVar20) & 1) != 0)) {
                  _local_140 = *(undefined1 (*) [16])(lVar16 + 600 + uVar20);
                  plVar4 = *(longlong **)(lVar16 + 0x3a0 + uVar20);
                  if (*(char *)(**(longlong **)(lVar16 + 0x1a0 + uVar20) + 0x6f) == '\x02') {
                    if (plVar4 == (longlong *)0x0) goto LAB_1400a1148;
                    local_218 = *pauVar1;
                    local_150 = local_218._0_4_ + *(float *)pauVar1[2];
                    auVar6 = vshufps_avx(local_218,local_218,0x55);
                    local_14c = auVar6._0_4_ + *(float *)(pauVar1[2] + 4);
                    auVar6 = vshufps_avx(local_218,local_218,0xaa);
                    local_148 = auVar6._0_4_ + *(float *)(pauVar1[2] + 8);
                    auVar6 = vshufps_avx(local_218,local_218,0xff);
                    local_144 = auVar6._0_4_ + *(float *)(pauVar1[2] + 0xc);
                    auVar27._0_8_ =
                         FUN_14026f3f3(*(undefined4 *)(lVar16 + 0x26c + uVar20),
                                       *(undefined4 *)(lVar16 + 0x268 + uVar20));
                    auVar27._8_56_ = extraout_var;
                    auVar6 = vpermilps_avx(auVar27._0_16_,1);
                    auVar11 = vpermilps_avx(auVar27._0_16_,0xe);
                    local_1c8 = (uint)auVar27._0_8_;
                    local_1e0 = local_1c8 ^ uVar31;
                    local_1e8 = auVar6._0_4_;
                    auVar6 = vpermilps_avx(auVar11,1);
                    local_190 = auVar11._0_4_;
                    local_184 = local_190 ^ uVar31;
                    local_1e4 = auVar28._0_4_;
                    local_1d4 = auVar30._0_4_;
                    local_194 = auVar6._0_4_;
                    local_1dc = local_1e4;
                    local_1d8 = local_1e4;
                    local_1d0 = local_1e4;
                    local_1cc = local_1e4;
                    local_1c4 = local_1e4;
                    local_1c0 = local_1e8;
                    local_1bc = local_1e4;
                    local_1b8 = local_1e4;
                    local_1b4 = local_1e4;
                    local_1b0 = local_1e4;
                    local_1ac = local_1d4;
                    local_1a8 = local_1d4;
                    local_1a4 = local_1e4;
                    local_1a0 = local_1e4;
                    local_19c = local_1e4;
                    local_198 = local_1e4;
                    local_18c = local_1e4;
                    local_188 = local_1e4;
                    local_180 = local_194;
                    local_17c = local_1e4;
                    local_178 = local_1e4;
                    local_174 = local_1e4;
                    local_170 = local_1e4;
                    local_16c = local_1d4;
                    FUN_140005940(&local_1e8,&local_1e8,&local_1a8);
                    auVar26._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar16 + 0x270 + uVar20));
                    auVar26._8_56_ = extraout_var_00;
                    auVar6 = vpermilps_avx(auVar26._0_16_,1);
                    local_1a4 = (float)auVar26._0_8_;
                    local_198 = (float)((uint)local_1a4 ^ uVar31);
                    local_1a8 = auVar6._0_4_;
                    local_190 = auVar28._0_4_;
                    local_180 = auVar30._0_4_;
                    local_194 = local_1a8;
                    local_184 = local_190;
                    FUN_140005940(&local_1e8,&local_1e8,&local_1a8);
                    local_1b8 = local_1b8 + *(float *)(lVar16 + 600 + uVar20);
                    local_1b4 = local_1b4 + *(float *)(lVar16 + 0x25c + uVar20);
                    local_1b0 = local_1b0 + *(float *)(lVar16 + 0x260 + uVar20);
                    iVar15 = (**(code **)(*plVar4 + 0x120))
                                       (plVar4,local_140,&local_1e8,local_218,&local_150);
                    lVar21 = local_res18;
                    lVar19 = local_168;
                    if (iVar15 != 0) {
                      *(undefined4 *)(pauVar1[6] + 8) = 1;
                    }
                  }
                  if (((0x14 < *(int *)(pauVar1[6] + 0xc)) && (uVar22 == (byte)pauVar1[5][2])) &&
                     (uVar24 == (byte)pauVar1[5][3])) {
                    fVar8 = (float)local_140._0_4_ - *(float *)*pauVar1;
                    fVar9 = (float)local_140._4_4_ - *(float *)(*pauVar1 + 4);
                    fVar5 = fVar29 + *(float *)(lVar16 + 0x41c + uVar20);
                    fVar10 = fStack_138 - *(float *)(*pauVar1 + 8);
                    if (fVar10 * fVar10 + fVar9 * fVar9 + fVar8 * fVar8 < fVar5 * fVar5) {
                      *(undefined4 *)(pauVar1[6] + 8) = 1;
                    }
                  }
                }
LAB_1400a1148:
                uVar18 = (ulonglong)(uVar24 + 1);
                uVar20 = uVar20 + 0x520;
                lVar23 = lVar23 + -1;
              } while (lVar23 != 0);
              lVar16 = local_108;
            }
            local_res18 = lVar21 + 1;
            uVar22 = uVar22 + 1;
            uVar18 = local_200._0_8_;
            uVar24 = local_res10[0];
          } while (local_res18 < (longlong)local_100[0]._0_8_);
        }
      }
      else if (iVar15 == 1) {
        uVar25 = FUN_1401c56d0();
        local_218._8_8_ = uVar33;
        local_218._0_8_ = uVar32;
        cVar12 = FUN_1401c6a00(uVar25,0,0x124,pauVar1,local_218,uVar36,uVar35,uVar34,auVar28._0_4_,1
                               ,1);
        if (((cVar12 != '\0') && (lVar16 = FUN_1401c97a0(), '\0' < *(char *)(lVar16 + 0x3dc2))) &&
           ((uVar2 = *(ushort *)(lVar16 + 0x120),
            (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar2 * 0x18) + 0x5b52) & 1) != 0
            && (puVar17 = (undefined4 *)FUN_1401c9e60(lVar16), puVar17 != (undefined4 *)0x0)))) {
          *(ushort *)(puVar17 + 0x11) = uVar2;
          *(undefined2 *)((longlong)puVar17 + 0x46) = 0x124;
          *puVar17 = *(undefined4 *)*pauVar1;
          puVar17[1] = *(undefined4 *)(*pauVar1 + 4);
          puVar17[2] = *(undefined4 *)(*pauVar1 + 8);
          puVar17[3] = *(undefined4 *)(*pauVar1 + 0xc);
          *(undefined8 *)(puVar17 + 4) = 0;
          puVar17[6] = 0;
          puVar17[7] = 0x3f800000;
          puVar17[8] = 0x3ea3d70a;
          puVar17[9] = 0x3fb33333;
          *(undefined8 *)(puVar17 + 10) = 0x40800000;
          puVar17[0xf] = 0x3f800000;
          *(undefined2 *)((longlong)puVar17 + 0x4a) = 0;
          *(byte *)(puVar17 + 0x1c) = *(byte *)(puVar17 + 0x1c) & 0xfe | 0x36;
          *(code **)(puVar17 + 0xc) = FUN_1401caa00;
        }
        if (*(longlong *)(param_1 + 8) != 0) {
          auVar6 = *pauVar1;
          auVar27 = ZEXT464(*(uint *)(*pauVar1 + 4));
          local_200 = ZEXT816(0);
          auVar11 = vshufps_avx(auVar6,auVar6,0xff);
          auVar7 = vshufps_avx(auVar6,auVar6,0xaa);
          local_124 = auVar11._0_4_;
          local_130 = auVar6._0_4_;
          auVar6 = vshufps_avx(auVar6,auVar6,0x55);
          local_11c = auVar6._0_4_ + DAT_1402d2698;
          local_12c = DAT_1402d2e2c;
          local_128 = auVar7._0_4_;
          local_120 = local_130;
          local_118 = local_128;
          local_114 = local_124;
          uVar22 = FUN_1400782c0(*(undefined8 *)(param_1 + 0x18),local_200,local_110,&local_120,
                                 &local_130);
          auVar6 = vpcmpeqd_avx(ZEXT416(uVar22),ZEXT416(0));
          auVar6 = vblendvps_avx(ZEXT416((uint)local_200._4_4_),auVar28._0_16_,auVar6);
          auVar6 = vmaxss_avx(ZEXT416((uint)(auVar6._0_4_ + DAT_1402d29b8)),auVar27._0_16_);
          local_218._4_4_ = auVar6._0_4_;
          local_218._0_4_ = *(undefined4 *)*pauVar1;
          local_218._8_4_ = *(undefined4 *)(*pauVar1 + 8);
          local_218._12_4_ = auVar30._0_4_;
          local_208 = 0x28;
          uVar14 = FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x33,
                                 local_218,0);
          *(undefined2 *)(pauVar1[5] + 0xc) = uVar14;
        }
        lVar19 = (ulonglong)(byte)pauVar1[5][1] * 0x520;
        lVar16 = *(longlong *)
                  (*(longlong *)
                    (**(longlong **)(param_1 + 0x10) + (ulonglong)(byte)pauVar1[5][0] * 8) + 0x110);
        cVar12 = *(char *)(**(longlong **)(lVar16 + 0x388 + lVar19) + 0x15d);
        if (((cVar12 != '\0') && (cVar12 != '\x02')) || (*(char *)(lVar16 + 0x235 + lVar19) != '\0')
           ) {
          *(undefined8 *)(pauVar1[6] + 8) = 2;
          goto LAB_1400a11a8;
        }
        bVar13 = FUN_140091880(param_1,pauVar1,DAT_1402d29c4,auVar37._0_8_,0);
        if ((bVar13 != 0) && (*(longlong **)(param_1 + 0x10) != (longlong *)0x0)) {
          lVar16 = *(longlong *)
                    (*(longlong *)(**(longlong **)(param_1 + 0x10) + -8 + (ulonglong)bVar13 * 8) +
                    0x110);
          lVar19 = *(longlong *)(lVar16 + 0x1b8);
          uVar25 = FUN_1401c56d0();
          cVar12 = *(char *)(lVar19 + 0x2094);
          if (cVar12 == '\0') {
            uVar14 = 0x59;
LAB_1400a14e0:
            local_res10[0] = CONCAT22(local_res10[0]._2_2_,uVar14);
            local_res18 = CONCAT62(local_res18._2_6_,1);
            FUN_1401c6150(uVar25,&local_res18,local_res10);
          }
          else {
            if (cVar12 == '\x02') {
              uVar14 = 0x5a;
              goto LAB_1400a14e0;
            }
            if (cVar12 == '\x01') {
              uVar14 = 0x5b;
              goto LAB_1400a14e0;
            }
          }
          uVar25 = FUN_1401c56d0();
          local_218._8_8_ = uVar33;
          local_218._0_8_ = uVar32;
          cVar12 = FUN_1401c6a00(uVar25,1,0x1b,(undefined4 *)(lVar16 + 600),local_218,uVar36,uVar35,
                                 uVar34,auVar28._0_4_,0,1);
          if ((((cVar12 != '\0') && (lVar19 = FUN_1401c97a0(), '\x01' < *(char *)(lVar19 + 0x3dc2)))
              && (uVar2 = *(ushort *)(lVar19 + 0x138),
                 (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar2 * 0x18) + 0x882) & 1)
                 != 0)) &&
             (puVar17 = (undefined4 *)FUN_1401c9e60(lVar19), puVar17 != (undefined4 *)0x0)) {
            *(ushort *)(puVar17 + 0x11) = uVar2;
            *(undefined2 *)((longlong)puVar17 + 0x46) = 0x1b;
            *puVar17 = *(undefined4 *)(lVar16 + 600);
            puVar17[1] = *(undefined4 *)(lVar16 + 0x25c);
            puVar17[2] = *(undefined4 *)(lVar16 + 0x260);
            uVar3 = *(undefined4 *)(lVar16 + 0x264);
            *(undefined8 *)(puVar17 + 4) = 0;
            puVar17[6] = 0;
            puVar17[3] = uVar3;
            puVar17[7] = 0x3f800000;
            puVar17[8] = 0x3ea3d70a;
            puVar17[9] = 0x3fb33333;
            *(undefined8 *)(puVar17 + 10) = 0x40800000;
            *(undefined2 *)((longlong)puVar17 + 0x4a) = 0;
            puVar17[0xf] = 0x3f800000;
            *(byte *)(puVar17 + 0x1c) = *(byte *)(puVar17 + 0x1c) & 0xee | 0x26;
            *(code **)(puVar17 + 0xc) = FUN_1401caa00;
            *(uint *)(param_1 + 0x5c) = *(uint *)(param_1 + 0x5c) & ~uVar24;
            goto LAB_1400a11a8;
          }
        }
        *(uint *)(param_1 + 0x5c) = *(uint *)(param_1 + 0x5c) & ~uVar24;
      }
      else {
        if (iVar15 != 2) goto LAB_1400a11a8;
        if (*(int *)(pauVar1[6] + 0xc) == (*(int *)(pauVar1[6] + 0xc) / 0x3c) * 0x3c) {
          bVar13 = FUN_140091880(param_1,pauVar1,*(undefined4 *)(*(longlong *)pauVar1[4] + 8),
                                 auVar30._0_8_,0);
          if ((bVar13 != 0) && (*(longlong **)(param_1 + 0x10) != (longlong *)0x0)) {
            lVar16 = *(longlong *)
                      (*(longlong *)(**(longlong **)(param_1 + 0x10) + -8 + (ulonglong)bVar13 * 8) +
                      0x110);
            lVar19 = *(longlong *)(lVar16 + 0x1b8);
            uVar25 = FUN_1401c56d0();
            cVar12 = *(char *)(lVar19 + 0x2094);
            if (cVar12 == '\0') {
              uVar14 = 0x59;
LAB_1400a16dd:
              local_res10[0] = CONCAT22(local_res10[0]._2_2_,uVar14);
              local_res18 = CONCAT62(local_res18._2_6_,1);
              FUN_1401c6150(uVar25,&local_res18,local_res10);
            }
            else {
              if (cVar12 == '\x02') {
                uVar14 = 0x5a;
                goto LAB_1400a16dd;
              }
              if (cVar12 == '\x01') {
                uVar14 = 0x5b;
                goto LAB_1400a16dd;
              }
            }
            uVar25 = FUN_1401c56d0();
            local_218._8_8_ = uVar33;
            local_218._0_8_ = uVar32;
            cVar12 = FUN_1401c6a00(uVar25,1,0x1b,(undefined4 *)(lVar16 + 600),local_218,uVar36,
                                   uVar35,uVar34,auVar28._0_4_,0,1);
            if ((((cVar12 != '\0') &&
                 (lVar19 = FUN_1401c97a0(), '\x01' < *(char *)(lVar19 + 0x3dc2))) &&
                (uVar2 = *(ushort *)(lVar19 + 0x138),
                (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar2 * 0x18) + 0x882) & 1) !=
                0)) && (puVar17 = (undefined4 *)FUN_1401c9e60(lVar19), puVar17 != (undefined4 *)0x0)
               ) {
              *(ushort *)(puVar17 + 0x11) = uVar2;
              *(undefined2 *)((longlong)puVar17 + 0x46) = 0x1b;
              *puVar17 = *(undefined4 *)(lVar16 + 600);
              puVar17[1] = *(undefined4 *)(lVar16 + 0x25c);
              puVar17[2] = *(undefined4 *)(lVar16 + 0x260);
              uVar3 = *(undefined4 *)(lVar16 + 0x264);
              *(undefined8 *)(puVar17 + 4) = 0;
              puVar17[6] = 0;
              puVar17[3] = uVar3;
              puVar17[7] = 0x3f800000;
              puVar17[8] = 0x3ea3d70a;
              puVar17[9] = 0x3fb33333;
              *(undefined8 *)(puVar17 + 10) = 0x40800000;
              *(undefined2 *)((longlong)puVar17 + 0x4a) = 0;
              puVar17[0xf] = 0x3f800000;
              *(byte *)(puVar17 + 0x1c) = *(byte *)(puVar17 + 0x1c) & 0xee | 0x26;
              *(code **)(puVar17 + 0xc) = FUN_1401caa00;
            }
          }
        }
        if (300 < *(int *)(pauVar1[6] + 0xc)) {
          *(uint *)(param_1 + 0x5c) = *(uint *)(param_1 + 0x5c) & ~uVar24;
        }
      }
    }
LAB_1400a11a8:
    local_res10[0] = uVar24 << 1 | (uint)((int)uVar24 < 0);
    local_228 = local_228 + 0x70;
    local_220 = local_220 + -1;
    if (local_220 == 0) {
      return;
    }
  } while( true );
}

