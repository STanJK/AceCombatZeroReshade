/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fa550; RVA 0xfa550
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400fa550(longlong param_1,longlong *param_2)

{
  float fVar1;
  float fVar2;
  longlong lVar3;
  undefined1 auVar4 [16];
  longlong lVar5;
  
  lVar3 = *param_2;
  lVar5 = *(longlong *)
           (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xfffebff7 | 0x20;
  *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
  if ((*(uint *)(lVar5 + 0x2058) >> 0xd & 1) == 0) {
    *(uint *)(lVar5 + 0x2058) = *(uint *)(lVar5 + 0x2058) | 0x2000;
    *(undefined1 *)(lVar5 + 0x2095) = *(undefined1 *)(lVar5 + 0x2094);
  }
  *(undefined1 *)(lVar5 + 0x2096) = 1;
  *(undefined4 *)(param_1 + 0x348) = 0xc8333300;
  *(undefined4 *)(param_1 + 0x350) = 0x48333300;
  *(undefined4 *)(param_1 + 0x34c) = 0xc8333300;
  *(undefined4 *)(param_1 + 0x354) = 0x48333300;
  if (*(longlong *)(param_1 + 0x338) != 0) {
    lVar5 = *(longlong *)(*(longlong *)(param_1 + 0x338) + 0x66ee0);
    *(undefined8 *)(lVar5 + 0x1bc48) = 0;
    *(undefined8 *)(lVar5 + 0x1bc50) = 0;
    *(undefined8 *)(lVar5 + 0x1bc58) = 0;
    *(undefined8 *)(lVar5 + 0x1bc60) = 0;
    *(undefined8 *)(lVar5 + 0x1bc68) = 0;
    *(undefined8 *)(lVar5 + 0x1bc70) = 0;
    *(undefined8 *)(lVar5 + 0x1bc78) = 0;
    *(undefined8 *)(lVar5 + 0x1bc80) = 0;
    *(int *)(lVar5 + 0x1bc8c) = *(int *)(lVar5 + 0x1bc8c) + 1;
    *(undefined4 *)(lVar5 + 0x1bc88) = 0;
    if (0xe < *(int *)(lVar5 + 0x1bc8c)) {
      *(undefined4 *)(lVar5 + 0x1bc8c) = 0;
    }
  }
  *(undefined4 *)(param_1 + 0x90) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x94) = 0xc61c4000;
  *(undefined4 *)(param_1 + 0x98) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x9c) = 0x3f800000;
  *(undefined4 *)(param_1 + 0xa0) = 0x48800000;
  *(undefined4 *)(param_1 + 0xa4) = 0x461c4000;
  *(undefined4 *)(param_1 + 0xa8) = 0x48800000;
  *(undefined4 *)(param_1 + 0xac) = 0x3f800000;
  fVar1 = *(float *)(lVar3 + 0xa8);
  fVar2 = *(float *)(lVar3 + 0x9c);
  auVar4 = vminss_avx(ZEXT416((uint)fVar2),ZEXT416((uint)fVar1));
  *(int *)(param_1 + 0x90) = auVar4._0_4_;
  lVar5 = 0xa8;
  if (fVar1 <= fVar2) {
    lVar5 = 0x9c;
  }
  *(undefined4 *)(param_1 + 0xa0) = *(undefined4 *)(lVar5 + lVar3);
  fVar1 = *(float *)(lVar3 + 0xac);
  fVar2 = *(float *)(lVar3 + 0xa0);
  auVar4 = vminss_avx(ZEXT416((uint)fVar2),ZEXT416((uint)fVar1));
  *(int *)(param_1 + 0x94) = auVar4._0_4_;
  lVar5 = 0xac;
  if (fVar1 <= fVar2) {
    lVar5 = 0xa0;
  }
  *(undefined4 *)(param_1 + 0xa4) = *(undefined4 *)(lVar5 + lVar3);
  fVar1 = *(float *)(lVar3 + 0xb0);
  fVar2 = *(float *)(lVar3 + 0xa4);
  auVar4 = vminss_avx(ZEXT416((uint)fVar2),ZEXT416((uint)fVar1));
  *(int *)(param_1 + 0x98) = auVar4._0_4_;
  lVar5 = 0xb0;
  if (fVar1 <= fVar2) {
    lVar5 = 0xa4;
  }
  *(undefined4 *)(param_1 + 0xa8) = *(undefined4 *)(lVar5 + lVar3);
  if (*(float *)(param_1 + 0x94) == 0.0) {
    *(undefined4 *)(param_1 + 0x94) = 0xc61c4000;
  }
  if (*(float *)(param_1 + 0xa4) == 0.0) {
    *(undefined4 *)(param_1 + 0xa4) = 0x461c4000;
  }
  *(int *)(param_1 + 0x380) = (int)((float)*(byte *)(param_1 + 0x3d1) * *(float *)(lVar3 + 0x94));
  if (*(longlong *)(param_1 + 0x308) != 0) {
    FUN_1401a7df0(*(longlong *)(param_1 + 0x308),0);
  }
  *(undefined4 *)(param_1 + 0x37c) = 0;
  *(undefined1 *)(param_1 + 999) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 0x15;
  return;
}

