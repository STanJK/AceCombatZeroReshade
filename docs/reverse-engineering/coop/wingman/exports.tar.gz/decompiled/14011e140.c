/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14011e140; RVA 0x11e140
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14011e140(longlong param_1)

{
  longlong lVar1;
  uint *puVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  byte bVar6;
  byte bVar7;
  undefined4 uVar8;
  float *pfVar9;
  longlong lVar10;
  float *pfVar11;
  longlong *plVar12;
  undefined8 *puVar13;
  undefined8 uVar14;
  undefined1 auVar15 [16];
  float fVar16;
  char cVar17;
  undefined1 uVar18;
  int iVar19;
  uint uVar20;
  longlong lVar21;
  longlong lVar22;
  undefined1 auVar23 [16];
  undefined1 extraout_var [56];
  undefined1 extraout_var_00 [56];
  float fVar24;
  uint uVar25;
  float fVar26;
  undefined4 uVar27;
  float fVar28;
  undefined4 uVar29;
  float fVar30;
  float fVar31;
  undefined4 uVar32;
  float fVar33;
  float fVar34;
  undefined1 auVar35 [16];
  undefined1 auVar36 [64];
  undefined1 auVar37 [64];
  undefined1 auVar38 [64];
  float fVar39;
  undefined1 auVar40 [64];
  float fVar41;
  undefined1 auVar42 [64];
  float local_148;
  float fStack_144;
  float fStack_140;
  float fStack_13c;
  undefined1 local_138 [16];
  undefined1 local_128 [8];
  float fStack_120;
  undefined1 local_118 [8];
  float fStack_110;
  float fStack_10c;
  undefined1 local_108 [8];
  float fStack_100;
  undefined1 local_f8 [8];
  float fStack_f0;
  float fStack_ec;
  
  uVar25 = DAT_1402d3770;
  fVar34 = DAT_1402d1f38;
  if ((*(uint *)(param_1 + 0x1f0) & 1) == 0) {
    return;
  }
  if (*(undefined8 **)(param_1 + 0x1a8) == (undefined8 *)0x0) {
    return;
  }
  pfVar9 = (float *)**(undefined8 **)(param_1 + 0x1a8);
  auVar38 = ZEXT864(0);
  if (*(byte *)((longlong)pfVar9 + 0x1d) == 0xff) {
    if (((*(byte *)(param_1 + 0x2e9) & 1) == 0) && ((*(uint *)(param_1 + 0x1f0) >> 0x11 & 1) != 0))
    {
      if (*(char *)(param_1 + 0x2e5) != '\x01') {
        *(undefined2 *)(param_1 + 0x2e5) = 1;
      }
      *(undefined4 *)(param_1 + 0x2b8) = *(undefined4 *)(param_1 + 0x298);
      *(undefined4 *)(param_1 + 700) = *(undefined4 *)(param_1 + 0x29c);
      *(undefined4 *)(param_1 + 0x2c0) = *(undefined4 *)(param_1 + 0x2a0);
      *(undefined4 *)(param_1 + 0x2c4) = *(undefined4 *)(param_1 + 0x2a4);
      *(undefined4 *)(param_1 + 0x2a8) = *(undefined4 *)(param_1 + 0x298);
      *(undefined2 *)(param_1 + 0x2e7) = 1;
      *(undefined4 *)(param_1 + 0x2ac) = *(undefined4 *)(param_1 + 700);
      *(undefined4 *)(param_1 + 0x2b0) = *(undefined4 *)(param_1 + 0x2c0);
      *(undefined4 *)(param_1 + 0x2b4) = *(undefined4 *)(param_1 + 0x2c4);
      if ((*(byte *)(**(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x1a0) + 8) + 0x10) +
                    0x16) & 2) == 0) {
        uVar20 = *(uint *)(param_1 + 0x1f0) & 0xfffffffb;
      }
      else {
        uVar20 = *(uint *)(param_1 + 0x1f0) | 4;
      }
      *(uint *)(param_1 + 0x1f0) = uVar20;
      FUN_14011ddc0(param_1);
      _local_118 = ZEXT816(0);
      _local_128 = ZEXT816(0);
      _local_108 = ZEXT816(0);
      fVar26 = (float)(*(uint *)(param_1 + 0x2c8) ^ uVar25);
      _local_f8 = _local_118;
      FUN_140202920(local_128,param_1 + 0x268);
      auVar23 = vshufps_avx(_local_108,_local_108,0x55);
      auVar35 = vshufps_avx(_local_108,_local_108,0xaa);
      auVar15 = vshufps_avx(_local_108,_local_108,0xff);
      *(float *)(param_1 + 0x264) = fVar26 * auVar15._0_4_ + fStack_ec;
      *(float *)(param_1 + 600) =
           fVar26 * local_108._0_4_ + (float)local_f8._0_4_ + *(float *)(param_1 + 600);
      *(float *)(param_1 + 0x25c) =
           auVar23._0_4_ * fVar26 + (float)local_f8._4_4_ + *(float *)(param_1 + 0x25c);
      *(float *)(param_1 + 0x260) = auVar35._0_4_ * fVar26 + fStack_f0 + *(float *)(param_1 + 0x260)
      ;
      if (((byte)*(undefined4 *)(param_1 + 0x1f0) & 6) == 6) {
        auVar23 = ZEXT816(0);
        if (*(longlong **)(param_1 + 0x2d0) != (longlong *)0x0) {
          auVar36._0_8_ = (**(code **)(**(longlong **)(param_1 + 0x2d0) + 0xa8))();
          auVar36._8_56_ = extraout_var;
          auVar23 = auVar36._0_16_;
        }
        auVar36 = ZEXT1664(auVar23);
        fVar26 = (float)FUN_140079410(*(undefined8 *)(param_1 + 400),*(undefined4 *)(param_1 + 600),
                                      *(undefined4 *)(param_1 + 0x260));
        *(float *)(param_1 + 0x25c) = fVar26 + auVar36._0_4_;
      }
    }
  }
  else {
    auVar36 = ZEXT1664(*(undefined1 (*) [16])(param_1 + 600));
    lVar21 = (ulonglong)*(byte *)((longlong)pfVar9 + 0x1d) * 0x520;
    fStack_13c = 0.0;
    lVar10 = *(longlong *)
              (*(longlong *)
                (**(longlong **)(param_1 + 0x180) + (ulonglong)*(byte *)(param_1 + 0x234) * 8) +
              0x110);
    pfVar11 = (float *)**(undefined8 **)(lVar10 + 0x1a8 + lVar21);
    fStack_144 = DAT_1402d1f38 * pfVar9[4];
    fVar31 = *pfVar9 - *pfVar11;
    fVar33 = pfVar9[2] - pfVar11[2];
    local_148 = DAT_1402d1f38 * pfVar9[3];
    fVar28 = pfVar9[1] - pfVar11[1];
    local_138._4_4_ = DAT_1402d2ca8 * pfVar11[4];
    local_138._0_4_ = DAT_1402d2ca8 * pfVar11[3];
    local_138._8_4_ = DAT_1402d2ca8 * pfVar11[5];
    local_138._12_4_ = 0;
    fStack_140 = DAT_1402d1f38 * pfVar9[5];
    FUN_140203050(&local_148,&local_148,local_138);
    _local_118 = ZEXT816(0);
    lVar1 = lVar10 + 0x268 + lVar21;
    _local_128 = ZEXT816(0);
    _local_108 = ZEXT816(0);
    _local_f8 = _local_118;
    FUN_140202920(local_128,lVar1);
    fVar26 = *(float *)(lVar10 + 0x260 + lVar21);
    fVar24 = *(float *)(lVar10 + 600 + lVar21);
    auVar23 = vshufps_avx(_local_128,_local_128,0x55);
    auVar35 = vshufps_avx(_local_108,_local_108,0x55);
    *(float *)(param_1 + 0x25c) =
         fVar33 * auVar35._0_4_ + fVar28 * (float)local_118._4_4_ + auVar23._0_4_ * fVar31 +
         (float)local_f8._4_4_ + *(float *)(lVar10 + 0x25c + lVar21);
    auVar23 = vshufps_avx(_local_128,_local_128,0xaa);
    auVar35 = vshufps_avx(_local_108,_local_108,0xaa);
    *(float *)(param_1 + 0x260) =
         fVar33 * auVar35._0_4_ + fVar28 * fStack_110 + auVar23._0_4_ * fVar31 + fStack_f0 + fVar26;
    auVar23 = vshufps_avx(_local_128,_local_128,0xff);
    auVar35 = vshufps_avx(_local_108,_local_108,0xff);
    *(float *)(param_1 + 0x264) =
         fVar33 * auVar35._0_4_ + fVar31 * auVar23._0_4_ + fVar28 * fStack_10c + fStack_ec;
    *(float *)(param_1 + 600) =
         fVar33 * local_108._0_4_ + fVar31 * local_128._0_4_ + fVar28 * (float)local_118._0_4_ +
         (float)local_f8._0_4_ + fVar24;
    FUN_140203050(param_1 + 0x268,lVar1,&local_148);
    fVar26 = auVar36._0_4_ - *(float *)(param_1 + 600);
    auVar35 = auVar36._0_16_;
    auVar23 = vshufps_avx(auVar35,auVar35,0x55);
    fVar24 = auVar23._0_4_ - *(float *)(param_1 + 0x25c);
    auVar23 = vshufps_avx(auVar35,auVar35,0xaa);
    fVar31 = auVar23._0_4_ - *(float *)(param_1 + 0x260);
    auVar23 = vshufps_avx(auVar35,auVar35,0xff);
    fVar33 = auVar23._0_4_ - *(float *)(param_1 + 0x264);
    *(float *)(param_1 + 0x2c8) =
         SQRT(fVar33 * fVar33 + fVar31 * fVar31 + fVar26 * fVar26 + fVar24 * fVar24);
  }
  if ((*(byte *)(param_1 + 0x2e9) & 2) != 0) {
    return;
  }
  if ((*(uint *)(param_1 + 0x1f0) & 0x2000) != 0) {
    return;
  }
  if ((*(uint *)(param_1 + 0x1f0) & 2) == 0) {
    return;
  }
  if (*(byte *)(param_1 + 0x236) == 0xff) {
    return;
  }
  if (*(byte *)(param_1 + 0x237) == 0xff) {
    return;
  }
  lVar22 = (ulonglong)*(byte *)(param_1 + 0x237) * 0x520;
  bVar6 = *(byte *)(param_1 + 0x235);
  lVar1 = *(longlong *)
           (*(longlong *)
             (**(longlong **)(param_1 + 0x180) + (ulonglong)*(byte *)(param_1 + 0x234) * 8) + 0x110)
  ;
  lVar10 = *(longlong *)
            (*(longlong *)
              (**(longlong **)(param_1 + 0x180) + (ulonglong)*(byte *)(param_1 + 0x236) * 8) + 0x110
            );
  lVar21 = *(longlong *)(lVar10 + 0x1b8 + lVar22);
  fVar26 = *(float *)(lVar10 + 600 + lVar22);
  auVar36 = ZEXT464((uint)fVar26);
  fVar24 = *(float *)(lVar10 + 0x264 + lVar22);
  auVar37 = ZEXT464((uint)fVar24);
  fVar31 = *(float *)(lVar10 + 0x25c + lVar22);
  auVar40 = ZEXT464((uint)fVar31);
  fVar33 = *(float *)(lVar10 + 0x260 + lVar22);
  auVar42 = ZEXT464((uint)fVar33);
  if ((lVar21 != 0) &&
     (plVar12 = *(longlong **)(*(longlong *)(param_1 + 0x1a0) + 0x20), plVar12 != (longlong *)0x0))
  {
    fVar34 = *(float *)(param_1 + 600);
    fVar28 = *(float *)(param_1 + 0x264);
    fVar41 = *(float *)(param_1 + 0x25c);
    fVar3 = *(float *)(param_1 + 0x260);
    fVar4 = *(float *)(lVar21 + 0x15d4);
    fVar31 = fVar31 - fVar41;
    fVar33 = fVar33 - fVar3;
    fVar5 = *(float *)(lVar21 + 0x15d0);
    auVar23 = vcvtdq2ps_avx(ZEXT116(*(byte *)(param_1 + 0x24a)));
    fVar30 = DAT_1402d22d0 / auVar23._0_4_;
    fVar26 = fVar26 - fVar34;
    fVar24 = fVar24 - fVar28;
    auVar35 = vcvtdq2ps_avx(ZEXT416(*(uint *)(*plVar12 + 0x44)));
    auVar23 = *(undefined1 (*) [16])(lVar10 + 600 + lVar22);
    fVar39 = DAT_1402d22d0 / (auVar35._0_4_ * DAT_1402d2360 * fVar30);
    fVar24 = SQRT(fVar24 * fVar24 + fVar33 * fVar33 + fVar31 * fVar31 + fVar26 * fVar26) * fVar39;
    fVar31 = (fVar24 * fVar5 + auVar23._0_4_) - fVar34;
    auVar35 = vshufps_avx(auVar23,auVar23,0x55);
    auVar15 = vshufps_avx(auVar23,auVar23,0xaa);
    fVar33 = (fVar24 * *(float *)(lVar21 + 0x15d8) + auVar15._0_4_) - fVar3;
    fVar16 = (fVar24 * fVar30 * fVar24 * fVar30 * DAT_1402d25a0 + fVar24 * fVar4 + auVar35._0_4_) -
             fVar41;
    auVar23 = vshufps_avx(auVar23,auVar23,0xff);
    fVar26 = *(float *)(lVar21 + 0x15d8);
    fVar24 = (fVar24 * *(float *)(lVar21 + 0x15dc) + auVar23._0_4_) - fVar28;
    auVar23 = *(undefined1 (*) [16])(lVar10 + 600 + lVar22);
    fVar24 = SQRT(fVar24 * fVar24 + fVar33 * fVar33 + fVar16 * fVar16 + fVar31 * fVar31) * fVar39;
    fVar31 = (fVar24 * fVar5 + auVar23._0_4_) - fVar34;
    auVar35 = vshufps_avx(auVar23,auVar23,0x55);
    auVar15 = vshufps_avx(auVar23,auVar23,0xaa);
    auVar23 = vshufps_avx(auVar23,auVar23,0xff);
    fVar33 = (fVar24 * fVar26 + auVar15._0_4_) - fVar3;
    fVar16 = (fVar24 * *(float *)(lVar21 + 0x15dc) + auVar23._0_4_) - fVar28;
    fVar24 = (fVar24 * fVar30 * fVar24 * fVar30 * DAT_1402d25a0 + fVar24 * fVar4 + auVar35._0_4_) -
             fVar41;
    auVar23 = *(undefined1 (*) [16])(lVar10 + 600 + lVar22);
    fVar24 = SQRT(fVar16 * fVar16 + fVar33 * fVar33 + fVar24 * fVar24 + fVar31 * fVar31) * fVar39;
    fVar34 = (fVar24 * fVar5 + auVar23._0_4_) - fVar34;
    auVar35 = vshufps_avx(auVar23,auVar23,0x55);
    auVar15 = vshufps_avx(auVar23,auVar23,0xaa);
    fVar3 = (fVar24 * fVar26 + auVar15._0_4_) - fVar3;
    auVar38 = ZEXT464(0);
    auVar23 = vshufps_avx(auVar23,auVar23,0xff);
    fVar41 = (fVar24 * fVar30 * fVar24 * fVar30 * DAT_1402d25a0 + fVar24 * fVar4 + auVar35._0_4_) -
             fVar41;
    fVar28 = (fVar24 * *(float *)(lVar21 + 0x15dc) + auVar23._0_4_) - fVar28;
    auVar23 = *(undefined1 (*) [16])(lVar10 + 600 + lVar22);
    fVar39 = SQRT(fVar28 * fVar28 + fVar3 * fVar3 + fVar41 * fVar41 + fVar34 * fVar34) * fVar39;
    auVar36 = ZEXT1664(CONCAT124(auVar23._4_12_,fVar39 * fVar5 + auVar23._0_4_));
    auVar35 = vshufps_avx(auVar23,auVar23,0x55);
    auVar15 = vshufps_avx(auVar23,auVar23,0xaa);
    auVar23 = vshufps_avx(auVar23,auVar23,0xff);
    auVar42 = ZEXT1664(CONCAT124(auVar15._4_12_,fVar39 * fVar26 + auVar15._0_4_));
    auVar40 = ZEXT1664(CONCAT124(auVar35._4_12_,
                                 fVar39 * fVar30 * fVar39 * fVar30 * DAT_1402d25a0 +
                                 fVar39 * fVar4 + auVar35._0_4_));
    auVar37 = ZEXT1664(CONCAT124(auVar23._4_12_,fVar39 * *(float *)(lVar21 + 0x15dc) + auVar23._0_4_
                                ));
    fVar34 = DAT_1402d1f38;
  }
  _local_128 = ZEXT816(0);
  _local_118 = ZEXT816(0);
  _local_108 = _local_128;
  _local_f8 = _local_118;
  FUN_140202920(local_128,param_1 + 0x268);
  auVar23 = _local_f8;
  fVar26 = (float)local_f8._0_4_ + *(float *)(param_1 + 600);
  fVar24 = (float)local_f8._4_4_ + *(float *)(param_1 + 0x25c);
  local_f8._0_4_ = fVar26;
  auVar35 = _local_f8;
  fStack_f0 = auVar23._8_4_;
  fStack_ec = auVar23._12_4_;
  local_f8 = auVar35._0_8_;
  fStack_f0 = fStack_f0 + *(float *)(param_1 + 0x260);
  local_f8._4_4_ = fVar24;
  FUN_14003a2e0(local_128);
  fVar41 = auVar42._0_4_;
  fVar33 = auVar37._0_4_;
  fVar31 = auVar36._0_4_;
  fVar28 = auVar40._0_4_;
  fVar26 = fVar33 * fStack_f0 + fVar41 * fStack_100 + fVar28 * fStack_110 + fVar31 * fStack_120;
  auVar40 = ZEXT464((uint)fVar26);
  fVar24 = fVar33 * (float)local_f8._0_4_ + fVar41 * (float)local_108._0_4_ +
           fVar28 * (float)local_118._0_4_ + fVar31 * (float)local_128._0_4_;
  auVar36 = ZEXT464((uint)fVar24);
  auVar37._0_8_ =
       FUN_140272370(fVar33 * (float)local_f8._4_4_ + fVar41 * (float)local_108._4_4_ +
                     fVar28 * (float)local_118._4_4_ + fVar31 * (float)local_128._4_4_,
                     SQRT(fVar24 * fVar24 + fVar26 * fVar26));
  auVar37._8_56_ = extraout_var_00;
  local_148 = (float)auVar37._0_8_;
  auVar37 = ZEXT1664(auVar37._0_16_);
  fStack_144 = (float)FUN_140272370(auVar36._0_8_,auVar40._0_8_);
  uVar25 = _DAT_1402d3760;
  fVar26 = DAT_1402d2420;
  fStack_144 = fStack_144 + DAT_1402d2420;
  fStack_140 = auVar38._0_4_;
  if (DAT_1402d2420 < fStack_144) {
    fStack_144 = fStack_144 - DAT_1402d249c;
  }
  pfVar9 = (float *)(param_1 + 0x278);
  lVar21 = **(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x1a0) + 8) + 0x10);
  *(float *)(param_1 + 0x288) = *pfVar9;
  *(undefined4 *)(param_1 + 0x28c) = *(undefined4 *)(param_1 + 0x27c);
  *(undefined4 *)(param_1 + 0x290) = *(undefined4 *)(param_1 + 0x280);
  *(undefined4 *)(param_1 + 0x294) = *(undefined4 *)(param_1 + 0x284);
  fVar24 = *pfVar9;
  bVar7 = *(byte *)(param_1 + 0x24a);
  fVar31 = *(float *)(param_1 + 0x27c);
  fVar28 = auVar37._0_4_;
  fVar41 = (fVar34 * *(float *)(lVar21 + 0x10)) / (float)bVar7;
  fVar33 = fVar28 - fVar24;
  auVar23 = ZEXT416((uint)fVar33);
  if (fVar24 * fVar28 < fStack_140) {
    auVar23 = vcmpss_avx(auVar37._0_16_,auVar38._0_16_,1);
    auVar23 = vblendvps_avx(ZEXT416((uint)(fVar28 - fVar26)),ZEXT416((uint)(fVar26 - fVar28)),
                            auVar23);
    fVar3 = auVar23._0_4_ - fVar24;
    auVar23 = vcmpss_avx(ZEXT416((uint)fVar3 & uVar25),ZEXT416((uint)fVar33 & uVar25),1);
    auVar23 = vblendvps_avx(ZEXT416((uint)fVar33),ZEXT416((uint)fVar3),auVar23);
  }
  auVar35._0_4_ = (uint)fVar41 ^ DAT_1402d3770;
  auVar35._4_4_ = _UNK_1402d3774;
  auVar35._8_4_ = _UNK_1402d3778;
  auVar35._12_4_ = _UNK_1402d377c;
  if (auVar23._0_4_ <= fStack_140) {
    auVar23 = vmaxss_avx(auVar35,auVar23);
    fVar33 = auVar23._0_4_;
  }
  else {
    auVar23 = vminss_avx(auVar23,ZEXT416((uint)fVar41));
    fVar33 = auVar23._0_4_;
  }
  fVar3 = fStack_144 - fVar31;
  auVar23 = ZEXT416((uint)fVar3);
  if (fVar31 * fStack_144 < fStack_140) {
    auVar23 = vcmpss_avx(ZEXT416((uint)fStack_144),auVar38._0_16_,1);
    auVar23 = vblendvps_avx(ZEXT416((uint)(fStack_144 - fVar26)),
                            ZEXT416((uint)(fVar26 - fStack_144)),auVar23);
    fVar26 = auVar23._0_4_ - fVar31;
    auVar23 = vcmpss_avx(ZEXT416((uint)fVar26 & uVar25),ZEXT416((uint)fVar3 & uVar25),1);
    auVar23 = vblendvps_avx(ZEXT416((uint)fVar3),ZEXT416((uint)fVar26),auVar23);
  }
  if (auVar23._0_4_ <= fStack_140) {
    auVar23 = vmaxss_avx(auVar35,auVar23);
    fVar26 = auVar23._0_4_;
  }
  else {
    auVar23 = vminss_avx(auVar23,ZEXT416((uint)fVar41));
    fVar26 = auVar23._0_4_;
  }
  fVar24 = fVar24 + fVar33;
  fVar31 = fVar31 + fVar26;
  *pfVar9 = fVar24;
  *(float *)(param_1 + 0x27c) = fVar31;
  if (fVar33 <= fStack_140) {
    if (fVar24 < fVar28) goto LAB_14011ec25;
  }
  else if (fVar28 < fVar24) {
LAB_14011ec25:
    *pfVar9 = fVar28;
    fVar24 = fVar28;
  }
  if (fVar26 <= fStack_140) {
    if (fStack_144 <= fVar31) goto LAB_14011ec51;
  }
  else if (fVar31 <= fStack_144) goto LAB_14011ec51;
  *(float *)(param_1 + 0x27c) = fStack_144;
  fVar31 = fStack_144;
LAB_14011ec51:
  fVar26 = (float)(int)*(short *)(lVar21 + 0xe) * fVar34;
  if (fVar24 < fVar26) {
    *pfVar9 = fVar26;
    fVar24 = fVar26;
  }
  fVar26 = (float)(int)*(short *)(lVar21 + 0xc) * fVar34;
  if (fVar26 < fVar24) {
    *pfVar9 = fVar26;
  }
  fVar26 = (float)(int)*(short *)(lVar21 + 10) * fVar34;
  if (fVar31 < fVar26) {
    *(float *)(param_1 + 0x27c) = fVar26;
    fVar31 = fVar26;
  }
  fVar34 = (float)(int)*(short *)(lVar21 + 8) * fVar34;
  if (fVar34 < fVar31) {
    *(float *)(param_1 + 0x27c) = fVar34;
  }
  *(int *)(param_1 + 0x2e0) = *(int *)(param_1 + 0x2e0) + 1;
  fStack_13c = fStack_140;
  FUN_140203050(&local_148,param_1 + 0x268);
  fVar34 = DAT_1402d241c;
  auVar15._4_4_ = fStack_144;
  auVar15._0_4_ = local_148;
  auVar15._8_4_ = fStack_140;
  auVar15._12_4_ = fStack_13c;
  auVar36 = ZEXT1664(auVar15);
  auVar23 = vshufps_avx(auVar15,auVar15,0xff);
  auVar37 = ZEXT1664(auVar23);
  uVar27 = auVar23._0_4_;
  auVar23 = vshufps_avx(auVar15,auVar15,0xaa);
  auVar40 = ZEXT1664(auVar23);
  uVar29 = auVar23._0_4_;
  puVar13 = *(undefined8 **)(*(longlong *)(param_1 + 0x1a0) + 0x20);
  auVar23 = vshufps_avx(auVar15,auVar15,0x55);
  auVar42 = ZEXT1664(auVar23);
  uVar32 = auVar23._0_4_;
  if (puVar13 != (undefined8 *)0x0) {
    uVar14 = *puVar13;
    *(undefined8 *)(param_1 + 0xd8) = uVar14;
    *(byte *)(param_1 + 0xe9) = bVar7;
    auVar23 = *(undefined1 (*) [16])(lVar10 + 600 + lVar22);
    *(int *)(param_1 + 0x110) = auVar23._0_4_;
    uVar8 = vextractps_avx(auVar23,1);
    *(undefined4 *)(param_1 + 0x114) = uVar8;
    uVar8 = vextractps_avx(auVar23,2);
    *(undefined4 *)(param_1 + 0x118) = uVar8;
    uVar8 = vextractps_avx(auVar23,3);
    *(undefined4 *)(param_1 + 0x11c) = uVar8;
    auVar23 = *(undefined1 (*) [16])(param_1 + 600);
    *(int *)(param_1 + 0xf0) = auVar23._0_4_;
    uVar8 = vextractps_avx(auVar23,1);
    *(undefined4 *)(param_1 + 0xf4) = uVar8;
    uVar8 = vextractps_avx(auVar23,2);
    *(undefined4 *)(param_1 + 0xf8) = uVar8;
    uVar8 = vextractps_avx(auVar23,3);
    *(undefined4 *)(param_1 + 0xfc) = uVar8;
    *(float *)(param_1 + 0x100) = local_148;
    *(undefined4 *)(param_1 + 0x104) = uVar32;
    *(undefined4 *)(param_1 + 0x108) = uVar29;
    *(undefined4 *)(param_1 + 0x10c) = uVar27;
    FUN_14013aa20(param_1 + 0xd8);
    cVar17 = FUN_14013ac40(param_1 + 0xd8);
    uVar27 = auVar37._0_4_;
    uVar29 = auVar40._0_4_;
    uVar32 = auVar42._0_4_;
    if (cVar17 != '\0') {
      local_138 = auVar36._0_16_;
      local_148 = (float)*(undefined8 *)(param_1 + 600);
      fStack_144 = (float)((ulonglong)*(undefined8 *)(param_1 + 600) >> 0x20);
      fStack_140 = (float)*(undefined8 *)(param_1 + 0x260);
      fStack_13c = (float)((ulonglong)*(undefined8 *)(param_1 + 0x260) >> 0x20);
      FUN_14013ace0(*(longlong *)(param_1 + 0x178) + 0xca0,&local_148,local_138,auVar38._0_8_,
                    *(undefined1 *)(param_1 + 0x234),*(undefined1 *)(param_1 + 0x235),uVar14,0);
      uVar27 = auVar37._0_4_;
      uVar29 = auVar40._0_4_;
      uVar32 = auVar42._0_4_;
      *(byte *)(param_1 + 0xe8) = *(byte *)(param_1 + 0xe8) | 1;
      *(uint *)(param_1 + 0x1fc) = *(uint *)(param_1 + 0x1fc) | 0x10;
      *(char *)(param_1 + 0x24d) = (char)(int)((float)*(byte *)(param_1 + 0x24a) * fVar34);
    }
  }
  auVar23 = auVar36._0_16_;
  puVar13 = *(undefined8 **)(*(longlong *)(param_1 + 0x1a0) + 0x28);
  if (puVar13 != (undefined8 *)0x0) {
    uVar14 = *puVar13;
    *(undefined8 *)(param_1 + 0x88) = uVar14;
    *(undefined1 *)(param_1 + 0x99) = *(undefined1 *)(param_1 + 0x24a);
    if ((*(char *)(param_1 + 0x236) == '\0') && (*(char *)(param_1 + 0x237) == '\0')) {
      uVar18 = *(undefined1 *)(*(longlong *)(*(longlong *)(lVar10 + 0x1b8 + lVar22) + 0xfe0) + 0xe);
    }
    else {
      uVar18 = 0;
    }
    *(undefined1 *)(param_1 + 0xd2) = uVar18;
    auVar23 = *(undefined1 (*) [16])(lVar10 + 600 + lVar22);
    *(int *)(param_1 + 0xc0) = auVar23._0_4_;
    uVar8 = vextractps_avx(auVar23,1);
    *(undefined4 *)(param_1 + 0xc4) = uVar8;
    uVar8 = vextractps_avx(auVar23,2);
    *(undefined4 *)(param_1 + 200) = uVar8;
    uVar8 = vextractps_avx(auVar23,3);
    *(undefined4 *)(param_1 + 0xcc) = uVar8;
    auVar23 = *(undefined1 (*) [16])(param_1 + 600);
    *(int *)(param_1 + 0xa0) = auVar23._0_4_;
    uVar8 = vextractps_avx(auVar23,1);
    *(undefined4 *)(param_1 + 0xa4) = uVar8;
    uVar8 = vextractps_avx(auVar23,2);
    *(undefined4 *)(param_1 + 0xa8) = uVar8;
    uVar8 = vextractps_avx(auVar23,3);
    *(undefined4 *)(param_1 + 0xac) = uVar8;
    *(int *)(param_1 + 0xb0) = auVar36._0_4_;
    *(undefined4 *)(param_1 + 0xb4) = uVar32;
    *(undefined4 *)(param_1 + 0xb8) = uVar29;
    *(undefined4 *)(param_1 + 0xbc) = uVar27;
    FUN_14013aa20(param_1 + 0x88);
    if (*(short *)(param_1 + 0xd0) != -1) {
      puVar2 = (uint *)(lVar10 + 0x1fc + lVar22);
      *puVar2 = *puVar2 | 0x8000000;
    }
    cVar17 = FUN_14013ac90(param_1 + 0x88);
    if (cVar17 != '\0') {
      puVar2 = (uint *)((ulonglong)bVar6 * 0x520 + lVar1 + 0x1fc);
      *puVar2 = *puVar2 | 8;
      puVar2 = (uint *)(lVar10 + 0x1fc + lVar22);
      *puVar2 = *puVar2 | 0x100;
    }
    cVar17 = FUN_14013ac40(param_1 + 0x88);
    auVar23 = auVar36._0_16_;
    if (cVar17 != '\0') {
      lVar1 = *(longlong *)(param_1 + 0x178);
      local_148 = (float)*(undefined8 *)(param_1 + 600);
      fStack_144 = (float)((ulonglong)*(undefined8 *)(param_1 + 600) >> 0x20);
      fStack_140 = (float)*(undefined8 *)(param_1 + 0x260);
      fStack_13c = (float)((ulonglong)*(undefined8 *)(param_1 + 0x260) >> 0x20);
      local_138 = auVar23;
      iVar19 = FUN_14013d140(lVar1,&local_148,local_138,auVar38._0_8_,
                             *(undefined1 *)(param_1 + 0x234),*(undefined1 *)(param_1 + 0x235),
                             *(undefined1 *)(lVar10 + 0x234 + lVar22),
                             *(undefined1 *)(lVar10 + 0x235 + lVar22),uVar14,2);
      auVar23 = auVar36._0_16_;
      if (-1 < iVar19) {
        *(undefined1 *)(lVar1 + 0x1fd90) = 0;
      }
      *(byte *)(param_1 + 0x98) = *(byte *)(param_1 + 0x98) | 1;
      uVar18 = *(undefined1 *)(param_1 + 0x235);
      *(uint *)(param_1 + 0x1fc) = *(uint *)(param_1 + 0x1fc) | 1;
      *(char *)(param_1 + 0x24d) = (char)(int)((float)*(byte *)(param_1 + 0x24a) * fVar34);
      *(undefined1 *)(lVar10 + 0x238 + lVar22) = *(undefined1 *)(param_1 + 0x234);
      *(undefined1 *)(lVar10 + 0x239 + lVar22) = uVar18;
    }
  }
  local_148 = (float)*(undefined8 *)(param_1 + 600);
  fStack_144 = (float)((ulonglong)*(undefined8 *)(param_1 + 600) >> 0x20);
  fStack_140 = (float)*(undefined8 *)(param_1 + 0x260);
  fStack_13c = (float)((ulonglong)*(undefined8 *)(param_1 + 0x260) >> 0x20);
  local_138 = auVar23;
  FUN_140125400(param_1,&local_148,local_138);
  return;
}

