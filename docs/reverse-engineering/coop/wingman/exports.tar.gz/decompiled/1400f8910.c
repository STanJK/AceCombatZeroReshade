/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f8910; RVA 0xf8910
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400f8910(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  uint *puVar2;
  uint uVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  byte bVar7;
  undefined1 auVar8 [16];
  float fVar9;
  longlong lVar10;
  longlong lVar11;
  int iVar12;
  longlong lVar13;
  undefined8 extraout_XMM0_Qa;
  undefined8 uVar14;
  float fVar15;
  undefined1 auVar16 [64];
  undefined2 local_res8 [4];
  undefined2 local_res10 [4];
  
  lVar4 = *param_2;
  lVar5 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar6 = *(longlong *)(lVar5 + 0x1b8);
  lVar10 = FUN_1401c56d0();
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x20;
  fVar15 = (float)*(int *)(param_1 + 0x378) / (float)*(byte *)(param_1 + 0x3d1);
  auVar16 = ZEXT1664(CONCAT124(SUB1612(ZEXT816(0),4),fVar15));
  if (*(char *)(param_1 + 0x402) == '\0') {
    if ((*(byte *)(lVar5 + 0x1f0) & 2) == 0) {
      lVar11 = FUN_140189320();
      lVar13 = 0x1a;
      if (*(char *)(lVar11 + 0x3e) == '\x01') {
        lVar13 = 3;
      }
      bVar7 = DAT_14031f8b1 & 1;
      (&DAT_140310a64)[(ulonglong)*(byte *)(lVar10 + 0xc) * 8] = 0x42fe0000;
      uVar14 = extraout_XMM0_Qa;
      if (bVar7 == 0) {
        lVar10 = (longlong)*(short *)(lVar10 + 4);
        if (((int)lVar13 < *(int *)(&DAT_14031f838 + lVar10 * 0x18)) &&
           (*(longlong *)(&DAT_14031f840 + lVar10 * 0x18) != 0)) {
          uVar14 = FUN_140186f20((&DAT_14033bc00)
                                 [(char)(&DAT_14031f8a8)[lVar10 + (ulonglong)DAT_14031f8b0 * 4]],
                                 &DAT_14031f438 + lVar10 * 0x100,
                                 *(undefined4 *)
                                  (*(longlong *)(&DAT_14031f840 + lVar10 * 0x18) + lVar13 * 4),0,
                                 (int)(char)(&DAT_14031f8a8)[lVar10 + (ulonglong)DAT_14031f8b0 * 4],
                                 0,0,1);
          *(int *)(&DAT_14031f898 + lVar10 * 4) = (int)lVar13;
        }
      }
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x48;
      *(ushort *)(param_1 + 0x3ba) = (ushort)*(byte *)(param_1 + 0x3d1) * 7;
      if ((*(byte *)(param_1 + 0x3d0) & 1) != 0) {
        *(byte *)(lVar6 + 0x1863) = *(byte *)(lVar6 + 0x1863) | 1;
        *(undefined4 *)(lVar6 + 0x185c) = 0;
      }
      lVar10 = *(longlong *)(param_1 + 800);
      *(undefined2 *)(param_1 + 0x3be) = 0;
      *(undefined1 *)(param_1 + 0x3cc) = 5;
      *(undefined4 *)(param_1 + 0x378) = 0;
      if (lVar10 != 0) {
        *(byte *)(lVar10 + 0x2b) = *(byte *)(lVar10 + 0x2b) | 2;
        if (*(longlong *)(lVar10 + 0x10) != 0) {
          puVar2 = (uint *)(*(longlong *)(lVar10 + 0x10) + 0x56c);
          *puVar2 = *puVar2 | 1;
        }
        if (*(longlong *)(lVar10 + 0x18) != 0) {
          pbVar1 = (byte *)(*(longlong *)(lVar10 + 0x18) + 0x23);
          *pbVar1 = *pbVar1 | 4;
        }
      }
      local_res8[0] = 0x16;
      local_res10[0] = 1;
      FUN_1401c6150(uVar14,local_res10,local_res8);
      fVar15 = auVar16._0_4_;
      *(undefined1 *)(param_1 + 0x3e6) = 4;
    }
  }
  else {
    lVar10 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
    puVar2 = (uint *)(*(longlong *)(lVar10 + 0x1b8) + 0x2058);
    *puVar2 = *puVar2 & 0xfeffffff;
    if ((*(byte *)(lVar10 + 0x1f0) & 2) == 0) {
      FUN_1400f73c0();
    }
    fVar15 = auVar16._0_4_;
    lVar10 = *(longlong *)(*(longlong *)(**(longlong **)(param_1 + 0x2f8) + 8) + 0x110);
    puVar2 = (uint *)(*(longlong *)(lVar10 + 0x1b8) + 0x2058);
    *puVar2 = *puVar2 & 0xfeffffff;
    if ((*(byte *)(lVar10 + 0x1f0) & 2) == 0) {
      FUN_1400f73c0();
      fVar15 = auVar16._0_4_;
    }
  }
  if ((*(float *)(param_1 + 0x354) < *(float *)(lVar5 + 0x260)) ||
     (*(float *)(lVar5 + 0x260) < *(float *)(param_1 + 0x34c) ||
      (*(float *)(param_1 + 0x350) < *(float *)(lVar5 + 600) ||
      *(float *)(lVar5 + 600) < *(float *)(param_1 + 0x348)))) {
    *(byte *)(lVar6 + 0x1863) = *(byte *)(lVar6 + 0x1863) | 1;
    *(undefined4 *)(lVar6 + 0x185c) = 0;
    *(undefined8 *)(lVar6 + 0x1d78) = 0;
    *(byte *)(lVar6 + 0x1da7) = *(byte *)(lVar6 + 0x1da7) | 1;
    uVar3 = *(uint *)(lVar6 + 0x2058);
    *(uint *)(lVar6 + 0x2058) = uVar3 | 0x20;
    if (*(char *)(param_1 + 0x402) == '\0') {
      *(undefined4 *)(lVar6 + 0x1d78) = 0xbe800000;
      *(undefined4 *)(lVar6 + 0x1d7c) = 0x3f800000;
      if ((uVar3 >> 0xd & 1) == 0) {
        *(uint *)(lVar6 + 0x2058) = uVar3 | 0x2020;
        *(undefined1 *)(lVar6 + 0x2095) = *(undefined1 *)(lVar6 + 0x2094);
      }
      *(undefined1 *)(lVar6 + 0x2096) = 1;
    }
  }
  if (*(char *)(param_1 + 0x3da) == '\x01') {
    *(uint *)(lVar4 + 0x40) = *(uint *)(lVar4 + 0x40) | 0x20;
  }
  fVar9 = DAT_1402d236c;
  lVar10 = *(longlong *)(param_1 + 0x308);
  if ((lVar10 != 0) && ((*(ushort *)(lVar10 + 0x90c) & 0x100) != 0)) {
    fVar15 = (float)*(byte *)(param_1 + 0x3d1);
    iVar12 = (int)(fVar15 * *(float *)(lVar4 + 0x28));
    *(int *)(param_1 + 0x378) = iVar12;
    if ((*(byte *)(lVar4 + 0x40) & 0x20) == 0) {
      iVar12 = iVar12 - (int)(fVar15 * fVar9);
      *(int *)(param_1 + 0x378) = iVar12;
    }
    *(ushort *)(lVar10 + 0x90c) = *(ushort *)(lVar10 + 0x90c) & 0xfeff;
    fVar15 = (float)iVar12 / fVar15;
  }
  if (((*(byte *)(lVar4 + 0x40) & 0x20) == 0) && (*(float *)(lVar4 + 0x28) - fVar9 <= fVar15)) {
    lVar10 = *(longlong *)(param_1 + 800);
    auVar8 = vminss_avx(ZEXT416((uint)((fVar15 - *(float *)(lVar4 + 0x28)) + fVar9)),
                        ZEXT416(DAT_1402d22d0));
    *(int *)(param_1 + 0x3a0) = auVar8._0_4_;
    if (lVar10 != 0) {
      *(byte *)(lVar10 + 0x2b) = *(byte *)(lVar10 + 0x2b) | 2;
      if (*(longlong *)(lVar10 + 0x10) != 0) {
        puVar2 = (uint *)(*(longlong *)(lVar10 + 0x10) + 0x56c);
        *puVar2 = *puVar2 | 1;
      }
      if (*(longlong *)(lVar10 + 0x18) != 0) {
        pbVar1 = (byte *)(*(longlong *)(lVar10 + 0x18) + 0x23);
        *pbVar1 = *pbVar1 | 4;
      }
      lVar10 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
      if (lVar10 != 0) {
        puVar2 = (uint *)(lVar10 + 0x40);
        *puVar2 = *puVar2 | 0x4000000;
      }
    }
  }
  if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
    *(int *)(param_1 + 0x378) = *(int *)(param_1 + 0x378) + 1;
    *(int *)(param_1 + 0x38c) = *(int *)(param_1 + 0x38c) + 1;
  }
  if ((int)((float)*(byte *)(param_1 + 0x3d1) * *(float *)(lVar4 + 0x28)) <=
      *(int *)(param_1 + 0x378)) {
    if ((*(byte *)(lVar4 + 0x40) & 1) == 0) {
      lVar4 = *(longlong *)(param_1 + 800);
      if (lVar4 != 0) {
        *(byte *)(lVar4 + 0x2b) = *(byte *)(lVar4 + 0x2b) & 0xfd;
        if (*(longlong *)(lVar4 + 0x10) != 0) {
          puVar2 = (uint *)(*(longlong *)(lVar4 + 0x10) + 0x56c);
          *puVar2 = *puVar2 & 0xfffffffe;
        }
        if (*(longlong *)(lVar4 + 0x18) != 0) {
          pbVar1 = (byte *)(*(longlong *)(lVar4 + 0x18) + 0x23);
          *pbVar1 = *pbVar1 & 0xfb;
        }
      }
      if ((*(uint *)(lVar6 + 0x2058) >> 0xd & 1) != 0) {
        *(uint *)(lVar6 + 0x2058) = *(uint *)(lVar6 + 0x2058) & 0xffffdfff;
        *(undefined1 *)(lVar6 + 0x2096) = *(undefined1 *)(lVar6 + 0x2095);
      }
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 2;
    }
    else {
      *(undefined1 *)(*(longlong *)(param_1 + 0x340) + 0xa8820) = 1;
      *(undefined1 *)(param_1 + 0x3cc) = 8;
      *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
    }
    *(undefined4 *)(param_1 + 0x378) = 0;
    *(undefined1 *)(param_1 + 0x3e2) = *(undefined1 *)(lVar5 + 0x428);
    *(undefined2 *)(param_1 + 0x3c2) = *(undefined2 *)(lVar6 + 0x208e);
    *(undefined1 *)(param_1 + 0x3e4) = *(undefined1 *)(lVar6 + 0x2099);
    *(undefined1 *)(param_1 + 0x3e5) = *(undefined1 *)(lVar6 + 0x209a);
  }
  return;
}

