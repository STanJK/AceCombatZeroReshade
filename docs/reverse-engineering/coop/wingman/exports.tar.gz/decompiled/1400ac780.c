/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400ac780; RVA 0xac780
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400ac780(longlong param_1)

{
  uint *puVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong lVar4;
  float fVar5;
  float fVar6;
  longlong lVar7;
  bool bVar8;
  float fVar9;
  float fVar10;
  int iVar11;
  float *pfVar12;
  longlong lVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  longlong lVar17;
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  
  if ((*(char *)(param_1 + 0xf8) == '\x02') &&
     (plVar3 = *(longlong **)(param_1 + 0x10), plVar3 != (longlong *)0x0)) {
    bVar8 = false;
    iVar11 = (**(code **)(*plVar3 + 0x18))(plVar3,0x4f);
    fVar10 = DAT_1402d2e2c;
    fVar9 = DAT_1402d2818;
    lVar17 = 0;
    lVar15 = (longlong)iVar11;
    lVar14 = 0;
    if (3 < lVar15) {
      lVar7 = -param_1;
      lVar13 = lVar7 + -0xdc;
      lVar16 = (lVar15 - 4U >> 2) + 1;
      lVar14 = lVar16 * 4;
      pfVar12 = (float *)(param_1 + 0xdc);
      do {
        fVar6 = *pfVar12 -
                fVar9 / ((float)*(byte *)(param_1 + 0x80) * (float)*(byte *)(param_1 + 0x80));
        *pfVar12 = fVar6;
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -0x11);
        auVar21 = vshufps_avx(auVar18,auVar18,0xff);
        fVar5 = auVar18._0_4_ + pfVar12[-1];
        auVar19 = vshufps_avx(auVar18,auVar18,0xaa);
        auVar18 = vshufps_avx(auVar18,auVar18,0x55);
        auVar18 = ZEXT416((uint)(fVar6 + auVar18._0_4_));
        auVar18 = vshufps_avx(auVar18,auVar18,0);
        auVar18 = vinsertps_avx(auVar18,ZEXT416((uint)(auVar19._0_4_ + pfVar12[1])),0x20);
        auVar18 = vinsertps_avx(auVar18,ZEXT416((uint)(auVar21._0_4_ + pfVar12[2])),0x30);
        auVar18._4_12_ = auVar18._4_12_;
        auVar18._0_4_ = fVar5;
        *(undefined1 (*) [16])(pfVar12 + -0x11) = auVar18;
        lVar4 = *(longlong *)(param_1 + 0x10);
        *(float *)(lVar17 + 0x518 + lVar4) = fVar5;
        uVar2 = vextractps_avx(auVar18,1);
        *(undefined4 *)(lVar17 + 0x51c + lVar4) = uVar2;
        uVar2 = vextractps_avx(auVar18,2);
        *(undefined4 *)(lVar17 + 0x520 + lVar4) = uVar2;
        uVar2 = vextractps_avx(auVar18,3);
        *(undefined4 *)(lVar17 + 0x524 + lVar4) = uVar2;
        lVar4 = *(longlong *)(param_1 + 0x10);
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -9);
        *(int *)((longlong)pfVar12 + lVar4 + 0x538 + lVar13) = auVar18._0_4_;
        uVar2 = vextractps_avx(auVar18,1);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + 0x53c + lVar13) = uVar2;
        uVar2 = vextractps_avx(auVar18,2);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + 0x540 + lVar13) = uVar2;
        uVar2 = vextractps_avx(auVar18,3);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + 0x544 + lVar13) = uVar2;
        fVar6 = pfVar12[4] -
                fVar9 / ((float)*(byte *)(param_1 + 0x80) * (float)*(byte *)(param_1 + 0x80));
        pfVar12[4] = fVar6;
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -0xd);
        auVar21 = vshufps_avx(auVar18,auVar18,0xff);
        fVar5 = auVar18._0_4_ + pfVar12[3];
        auVar19 = vshufps_avx(auVar18,auVar18,0xaa);
        auVar18 = vshufps_avx(auVar18,auVar18,0x55);
        auVar18 = ZEXT416((uint)(fVar6 + auVar18._0_4_));
        auVar18 = vshufps_avx(auVar18,auVar18,0);
        auVar18 = vinsertps_avx(auVar18,ZEXT416((uint)(auVar19._0_4_ + pfVar12[5])),0x20);
        auVar18 = vinsertps_avx(auVar18,ZEXT416((uint)(auVar21._0_4_ + pfVar12[6])),0x30);
        auVar21._4_12_ = auVar18._4_12_;
        auVar21._0_4_ = fVar5;
        *(undefined1 (*) [16])(pfVar12 + -0xd) = auVar21;
        lVar4 = *(longlong *)(param_1 + 0x10);
        if (fVar10 <= pfVar12[-0x10]) {
          bVar8 = true;
        }
        *(float *)((longlong)pfVar12 + lVar4 + lVar7 + 0x44c) = fVar5;
        uVar2 = vextractps_avx(auVar21,1);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x450) = uVar2;
        uVar2 = vextractps_avx(auVar21,2);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x454) = uVar2;
        uVar2 = vextractps_avx(auVar21,3);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x458) = uVar2;
        lVar4 = *(longlong *)(param_1 + 0x10);
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -5);
        *(int *)((longlong)pfVar12 + lVar4 + lVar7 + 0x46c) = auVar18._0_4_;
        uVar2 = vextractps_avx(auVar18,1);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x470) = uVar2;
        uVar2 = vextractps_avx(auVar18,2);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x474) = uVar2;
        uVar2 = vextractps_avx(auVar18,3);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x478) = uVar2;
        fVar5 = pfVar12[8] -
                fVar9 / ((float)*(byte *)(param_1 + 0x80) * (float)*(byte *)(param_1 + 0x80));
        pfVar12[8] = fVar5;
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -9);
        auVar21 = vshufps_avx(auVar18,auVar18,0xaa);
        if (fVar10 <= pfVar12[-0xc]) {
          bVar8 = true;
        }
        auVar19 = vshufps_avx(auVar18,auVar18,0xff);
        fVar6 = auVar18._0_4_ + pfVar12[7];
        pfVar12[-7] = auVar21._0_4_ + pfVar12[9];
        pfVar12[-6] = auVar19._0_4_ + pfVar12[10];
        auVar18 = vshufps_avx(auVar18,auVar18,0x55);
        pfVar12[-8] = fVar5 + auVar18._0_4_;
        auVar19._4_12_ = SUB1612(*(undefined1 (*) [16])(pfVar12 + -9),4);
        auVar19._0_4_ = fVar6;
        *(undefined1 (*) [16])(pfVar12 + -9) = auVar19;
        lVar4 = *(longlong *)(param_1 + 0x10);
        lVar17 = lVar17 + 0x40;
        *(float *)((longlong)pfVar12 + lVar4 + lVar7 + 0x45c) = fVar6;
        uVar2 = vextractps_avx(auVar19,1);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x460) = uVar2;
        uVar2 = vextractps_avx(auVar19,2);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x464) = uVar2;
        uVar2 = vextractps_avx(auVar19,3);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x468) = uVar2;
        lVar4 = *(longlong *)(param_1 + 0x10);
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -1);
        *(int *)((longlong)pfVar12 + lVar4 + lVar7 + 0x47c) = auVar18._0_4_;
        uVar2 = vextractps_avx(auVar18,1);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x480) = uVar2;
        uVar2 = vextractps_avx(auVar18,2);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x484) = uVar2;
        uVar2 = vextractps_avx(auVar18,3);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x488) = uVar2;
        fVar6 = pfVar12[0xc] -
                fVar9 / ((float)*(byte *)(param_1 + 0x80) * (float)*(byte *)(param_1 + 0x80));
        pfVar12[0xc] = fVar6;
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -5);
        auVar21 = vshufps_avx(auVar18,auVar18,0xff);
        fVar5 = auVar18._0_4_ + pfVar12[0xb];
        auVar19 = vshufps_avx(auVar18,auVar18,0xaa);
        pfVar12[-3] = auVar19._0_4_ + pfVar12[0xd];
        pfVar12[-2] = auVar21._0_4_ + pfVar12[0xe];
        if (fVar10 <= pfVar12[-8]) {
          bVar8 = true;
        }
        auVar18 = vshufps_avx(auVar18,auVar18,0x55);
        pfVar12[-4] = fVar6 + auVar18._0_4_;
        auVar20._4_12_ = SUB1612(*(undefined1 (*) [16])(pfVar12 + -5),4);
        auVar20._0_4_ = fVar5;
        *(undefined1 (*) [16])(pfVar12 + -5) = auVar20;
        lVar4 = *(longlong *)(param_1 + 0x10);
        *(float *)((longlong)pfVar12 + lVar4 + lVar7 + 0x46c) = fVar5;
        uVar2 = vextractps_avx(auVar20,1);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x470) = uVar2;
        uVar2 = vextractps_avx(auVar20,2);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x474) = uVar2;
        uVar2 = vextractps_avx(auVar20,3);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x478) = uVar2;
        auVar18 = *(undefined1 (*) [16])(pfVar12 + 3);
        lVar4 = *(longlong *)(param_1 + 0x10);
        *(int *)((longlong)pfVar12 + lVar4 + lVar7 + 0x48c) = auVar18._0_4_;
        uVar2 = vextractps_avx(auVar18,1);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x490) = uVar2;
        uVar2 = vextractps_avx(auVar18,2);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x494) = uVar2;
        uVar2 = vextractps_avx(auVar18,3);
        *(undefined4 *)((longlong)pfVar12 + lVar4 + lVar7 + 0x498) = uVar2;
        if (fVar10 <= pfVar12[-4]) {
          bVar8 = true;
        }
        lVar16 = lVar16 + -1;
        pfVar12 = pfVar12 + 0x10;
      } while (lVar16 != 0);
    }
    if (lVar14 < lVar15) {
      lVar17 = -param_1;
      lVar15 = lVar15 - lVar14;
      pfVar12 = (float *)(param_1 + 0xdc + lVar14 * 0x10);
      do {
        fVar6 = *pfVar12 -
                fVar9 / ((float)*(byte *)(param_1 + 0x80) * (float)*(byte *)(param_1 + 0x80));
        *pfVar12 = fVar6;
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -0x11);
        auVar21 = vshufps_avx(auVar18,auVar18,0xff);
        fVar5 = auVar18._0_4_ + pfVar12[-1];
        auVar19 = vshufps_avx(auVar18,auVar18,0xaa);
        auVar18 = vshufps_avx(auVar18,auVar18,0x55);
        auVar18 = ZEXT416((uint)(fVar6 + auVar18._0_4_));
        auVar18 = vshufps_avx(auVar18,auVar18,0);
        auVar18 = vinsertps_avx(auVar18,ZEXT416((uint)(auVar19._0_4_ + pfVar12[1])),0x20);
        auVar18 = vinsertps_avx(auVar18,ZEXT416((uint)(auVar21._0_4_ + pfVar12[2])),0x30);
        auVar22._4_12_ = auVar18._4_12_;
        auVar22._0_4_ = fVar5;
        *(undefined1 (*) [16])(pfVar12 + -0x11) = auVar22;
        lVar14 = *(longlong *)(param_1 + 0x10);
        *(float *)((longlong)pfVar12 + lVar14 + lVar17 + 0x43c) = fVar5;
        uVar2 = vextractps_avx(auVar22,1);
        *(undefined4 *)((longlong)pfVar12 + lVar14 + lVar17 + 0x440) = uVar2;
        uVar2 = vextractps_avx(auVar22,2);
        *(undefined4 *)((longlong)pfVar12 + lVar14 + lVar17 + 0x444) = uVar2;
        uVar2 = vextractps_avx(auVar22,3);
        *(undefined4 *)((longlong)pfVar12 + lVar14 + lVar17 + 0x448) = uVar2;
        auVar18 = *(undefined1 (*) [16])(pfVar12 + -9);
        lVar14 = *(longlong *)(param_1 + 0x10);
        *(int *)((longlong)pfVar12 + lVar14 + lVar17 + 0x45c) = auVar18._0_4_;
        uVar2 = vextractps_avx(auVar18,1);
        *(undefined4 *)((longlong)pfVar12 + lVar14 + lVar17 + 0x460) = uVar2;
        uVar2 = vextractps_avx(auVar18,2);
        *(undefined4 *)((longlong)pfVar12 + lVar14 + lVar17 + 0x464) = uVar2;
        uVar2 = vextractps_avx(auVar18,3);
        *(undefined4 *)((longlong)pfVar12 + lVar14 + lVar17 + 0x468) = uVar2;
        if (fVar10 <= pfVar12[-0x10]) {
          bVar8 = true;
        }
        lVar15 = lVar15 + -1;
        pfVar12 = pfVar12 + 4;
      } while (lVar15 != 0);
    }
    if (!bVar8) {
      *(undefined1 *)(param_1 + 0xf8) = 0;
      if (*(longlong *)(param_1 + 0x10) != 0) {
        puVar1 = (uint *)(*(longlong *)(param_1 + 0x10) + 0x558);
        *puVar1 = *puVar1 & 0xfffffdff;
      }
    }
  }
  return;
}

