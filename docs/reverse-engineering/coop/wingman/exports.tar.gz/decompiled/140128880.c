/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140128880; RVA 0x128880
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140128880(longlong param_1,ushort *param_2)

{
  longlong lVar1;
  byte *pbVar2;
  undefined8 *puVar3;
  ushort uVar4;
  char cVar5;
  byte bVar6;
  uint uVar7;
  undefined8 *puVar8;
  int iVar9;
  longlong lVar10;
  
  lVar1 = *(longlong *)(param_1 + 0x60);
  lVar10 = (ulonglong)*(byte *)(param_1 + 0xb0) * 0x10;
  puVar8 = (undefined8 *)(*(longlong *)(lVar1 + 8) + lVar10);
  pbVar2 = (byte *)*puVar8;
  if ((char)param_2[2] == '\x01') {
    lVar1 = (*(undefined8 **)(param_1 + 0x70))[3];
    if (((lVar1 == 0) ||
        (puVar3 = (undefined8 *)**(undefined8 **)(param_1 + 0x70), puVar3 == (undefined8 *)0x0)) ||
       (*(ushort *)*puVar3 <= *param_2)) {
      uVar4 = 0;
    }
    else {
      uVar4 = *(ushort *)(lVar1 + (ulonglong)*param_2 * 2);
    }
    if (uVar4 == param_2[1]) {
      bVar6 = *(char *)(param_1 + 0xaf) + 1;
      *(byte *)(param_1 + 0xaf) = bVar6;
      goto LAB_140128a04;
    }
    cVar5 = (char)param_2[3];
    iVar9 = (int)cVar5 + (uint)*(byte *)(param_1 + 0xaf);
    if ((iVar9 < 0) || ((int)(uint)*pbVar2 <= iVar9)) {
      cVar5 = '\x01';
    }
    bVar6 = *(byte *)(param_1 + 0xaf) + cVar5;
  }
  else {
    bVar6 = *(byte *)(param_1 + 0xaf);
    uVar7 = (uint)bVar6;
    if (*(byte *)(param_1 + 0xb1) == 0xff) {
      *(byte *)(param_1 + 0xb1) = bVar6;
      if (*(char *)((longlong)param_2 + 5) == '\0') {
LAB_140128962:
        cVar5 = '\x01';
      }
      else {
        *(char *)(param_1 + 0xb2) = *(char *)((longlong)param_2 + 5) + -1;
        cVar5 = (char)param_2[3];
        if (((int)((int)cVar5 + uVar7) < 0) ||
           ((int)(uint)**(byte **)(lVar10 + *(longlong *)(lVar1 + 8)) <= (int)((int)cVar5 + uVar7)))
        goto LAB_140128962;
      }
      bVar6 = bVar6 + cVar5;
    }
    else {
      if (*(byte *)(param_1 + 0xb1) == bVar6) {
        if (*(char *)(param_1 + 0xb2) == '\0') {
          bVar6 = bVar6 + 1;
          *(undefined1 *)(param_1 + 0xb1) = 0xff;
          *(byte *)(param_1 + 0xaf) = bVar6;
        }
        else {
          *(char *)(param_1 + 0xb2) = *(char *)(param_1 + 0xb2) + -1;
          cVar5 = (char)param_2[3];
          if (((int)((int)cVar5 + uVar7) < 0) || ((int)(uint)*pbVar2 <= (int)((int)cVar5 + uVar7)))
          {
            cVar5 = '\x01';
          }
          bVar6 = bVar6 + cVar5;
          *(byte *)(param_1 + 0xaf) = bVar6;
        }
        goto LAB_140128a04;
      }
      *(byte *)(param_1 + 0xb1) = bVar6;
      if (*(char *)((longlong)param_2 + 5) == '\0') {
        bVar6 = bVar6 + 1;
        *(byte *)(param_1 + 0xaf) = bVar6;
        goto LAB_140128a04;
      }
      *(char *)(param_1 + 0xb2) = *(char *)((longlong)param_2 + 5) + -1;
      iVar9 = (int)(char)param_2[3] + uVar7;
      if ((iVar9 < 0) || ((int)(uint)**(byte **)(lVar10 + *(longlong *)(lVar1 + 8)) <= iVar9)) {
        bVar6 = bVar6 + 1;
      }
      else {
        bVar6 = bVar6 + (char)param_2[3];
      }
    }
  }
  *(byte *)(param_1 + 0xaf) = bVar6;
LAB_140128a04:
  puVar8 = (undefined8 *)((ulonglong)bVar6 * 0x40 + puVar8[1]);
  if (*(char *)*puVar8 == '\x02') {
    if (puVar8[3] != 0) {
      FUN_140126b60(param_1);
      *(byte *)(param_1 + 0xae) = *(byte *)(param_1 + 0xae) | 1;
    }
  }
  else if ((*(char *)*puVar8 == '\x03') && (puVar8[4] != 0)) {
    FUN_140126ec0(param_1);
    *(byte *)(param_1 + 0xae) = *(byte *)(param_1 + 0xae) | 1;
    return;
  }
  return;
}

