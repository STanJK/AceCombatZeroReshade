/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400aa830; RVA 0xaa830
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined4 * FUN_1400aa830(undefined4 *param_1)

{
  undefined4 uVar1;
  
  param_1[5] = 0x4b00258;
  *(undefined8 *)(param_1 + 0x60) = 0;
  *(undefined2 *)(param_1 + 8) = 500;
  *(undefined8 *)(param_1 + 0x62) = 0;
  *(undefined8 *)(param_1 + 100) = 0;
  *(undefined8 *)(param_1 + 0x66) = 0;
  *(undefined8 *)(param_1 + 0x68) = 0;
  *(undefined8 *)(param_1 + 0x6a) = 0;
  *(undefined8 *)(param_1 + 0x6c) = 0;
  *(undefined8 *)(param_1 + 0x6e) = 0;
  *(undefined8 *)(param_1 + 0x70) = 0;
  *(undefined8 *)(param_1 + 0x72) = 0;
  *(undefined8 *)(param_1 + 0x74) = 0;
  *(undefined8 *)(param_1 + 0x76) = 0;
  *(undefined8 *)(param_1 + 0x78) = 0;
  *(undefined8 *)(param_1 + 0x7a) = 0;
  *(undefined8 *)(param_1 + 0x7c) = 0;
  *(undefined8 *)(param_1 + 0x7e) = 0;
  *(undefined8 *)(param_1 + 0x80) = 0;
  param_1[0x84] = 0;
  *(undefined8 *)(param_1 + 0x8c) = 0;
  *(undefined8 *)(param_1 + 0x8e) = 0;
  param_1[0x90] = 0;
  *(undefined1 *)(param_1 + 0x92) = 0;
  param_1[6] = 0xc800c8;
  param_1[7] = 0x51400fa;
  param_1[4] = 0x42480000;
  *param_1 = 0x3f800000;
  param_1[1] = 0x3f800000;
  param_1[2] = 0x3f800000;
  param_1[3] = 0x3f800000;
  *(undefined1 *)((longlong)param_1 + 0x22) = 0;
  param_1[0xc] = 0x25801f4;
  param_1[0xd] = 0x2bc028a;
  param_1[0xe] = 0x3e802ee;
  param_1[0xf] = 0x41b80000;
  param_1[0x10] = 0x41e80000;
  param_1[0x11] = 0x42080000;
  param_1[0x12] = 0x42640000;
  param_1[0x13] = 0x42640000;
  param_1[0x14] = 0x42380000;
  param_1[0x15] = 0x42200000;
  param_1[0x16] = 0x42080000;
  param_1[0x17] = 0x3f000000;
  param_1[0x18] = 0x3d4ccccd;
  param_1[0x19] = 0x40a00000;
  param_1[0x1a] = 0x40a00000;
  param_1[0x1c] = 0x25801f4;
  param_1[0x1d] = 0x2bc028a;
  param_1[0x1e] = 0x3e802ee;
  param_1[0x1f] = 0x42380000;
  param_1[0x20] = 0x42640000;
  param_1[0x21] = 0x428a0000;
  param_1[0x22] = 0x42e60000;
  param_1[0x23] = 0x42e60000;
  param_1[0x24] = 0x42b80000;
  param_1[0x25] = 0x42a00000;
  param_1[0x26] = 0x428a0000;
  param_1[0x27] = 0x40a00000;
  param_1[0x28] = 0x40a00000;
  param_1[0x2c] = 0x25801f4;
  param_1[0x2d] = 0x2bc028a;
  param_1[0x2e] = 0x3e802ee;
  param_1[0x2f] = 0x41300000;
  param_1[0x30] = 0x41600000;
  param_1[0x31] = 0x41880000;
  param_1[0x32] = 0x41e80000;
  param_1[0x33] = 0x41e80000;
  param_1[0x34] = 0x41b80000;
  param_1[0x35] = 0x41a00000;
  param_1[0x36] = 0x41880000;
  param_1[0x37] = 0x3d4ccccd;
  param_1[0x38] = 0x40a00000;
  param_1[0x39] = 0x40a00000;
  param_1[0x91] = 0x3c;
  uVar1 = FUN_140128d90(0);
  param_1[0x86] = uVar1;
  FUN_140129300(param_1);
  return param_1;
}

