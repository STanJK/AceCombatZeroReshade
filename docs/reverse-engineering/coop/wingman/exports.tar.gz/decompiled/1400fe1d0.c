/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fe1d0; RVA 0xfe1d0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400fe1d0(longlong param_1,longlong *param_2)

{
  undefined1 uVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  byte bVar10;
  longlong lVar11;
  uint uVar12;
  longlong lVar13;
  byte bVar14;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  
  lVar11 = *param_2;
  plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
  bVar14 = *(byte *)(lVar11 + 0x2e) & 4;
  lVar8 = *(longlong *)(*plVar7 + 0x110);
  lVar9 = *(longlong *)(lVar8 + 0x1b8);
  *(uint *)(lVar9 + 0x2058) = *(uint *)(lVar9 + 0x2058) | 0x1000;
  *(ushort *)(lVar9 + 0x1c20) = *(ushort *)(lVar9 + 0x1c20) | 1;
  FUN_1400f49d0(param_1,CONCAT71((int7)((ulonglong)plVar7 >> 8),1));
  if ((*(byte *)(lVar11 + 0x2f) == 0xff) || (*(byte *)(lVar11 + 0x30) == 0xff)) {
    lVar13 = 0;
  }
  else {
    lVar13 = (ulonglong)*(byte *)(lVar11 + 0x30) * 0x520 +
             *(longlong *)
              (*(longlong *)
                (**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar11 + 0x2f) * 8) + 0x110
              );
  }
  if (((bVar14 != 0) && (lVar13 != 0)) &&
     (plVar7 = *(longlong **)(lVar13 + 0x390), plVar7 != (longlong *)0x0)) {
    (**(code **)(*plVar7 + 0x90))(plVar7,0);
  }
  *(longlong *)(lVar9 + 0x2048) = lVar13;
  *(longlong *)(lVar9 + 0x1638) = lVar13;
  bVar10 = *(byte *)(lVar9 + 0x1677) | 2;
  if (bVar14 == 0) {
    bVar10 = *(byte *)(lVar9 + 0x1677) & 0xfd;
  }
  *(byte *)(lVar9 + 0x1677) = bVar10;
  *(byte *)(lVar9 + 0x1863) = *(byte *)(lVar9 + 0x1863) | 1;
  *(undefined4 *)(lVar9 + 0x185c) = 0xbf800000;
  *(undefined8 *)(lVar9 + 0x1d78) = 0;
  *(byte *)(lVar9 + 0x1da7) = *(byte *)(lVar9 + 0x1da7) | 1;
  uVar12 = *(uint *)(lVar9 + 0x2058) | 0x100;
  if (bVar14 == 0) {
    uVar12 = *(uint *)(lVar9 + 0x2058) & 0xfffffeff;
  }
  *(uint *)(lVar9 + 0x2058) = uVar12 & 0xffffffef | 0x20;
  uVar12 = *(uint *)(lVar9 + 0xd48) & 0xfffffeff | 0x200;
  if (bVar14 != 0) {
    uVar12 = *(uint *)(lVar9 + 0xd48) | 0x300;
  }
  *(uint *)(lVar9 + 0xd48) = uVar12;
  uVar4 = *(undefined2 *)(lVar9 + 0x2728);
  uVar5 = *(undefined2 *)(lVar9 + 0x272a);
  uVar1 = *(undefined1 *)(lVar9 + 0x272c);
  uVar2 = *(undefined1 *)(lVar9 + 0x272d);
  uVar3 = *(undefined1 *)(lVar9 + 0x272e);
  uVar6 = *(undefined4 *)(lVar9 + 0x2784);
  FUN_140102ab0(lVar9);
  *(undefined2 *)(lVar9 + 0x2728) = uVar4;
  *(undefined2 *)(lVar9 + 0x272a) = uVar5;
  *(undefined1 *)(lVar9 + 0x272c) = uVar1;
  *(undefined1 *)(lVar9 + 0x272d) = uVar2;
  *(undefined1 *)(lVar9 + 0x272e) = uVar3;
  *(undefined4 *)(lVar9 + 0x2784) = uVar6;
  FUN_140114c30(lVar8);
  *(undefined8 *)(lVar8 + 0x268) = 0;
  *(undefined8 *)(lVar8 + 0x270) = 0;
  if ((*(byte *)(lVar11 + 0x2f) == 0xff) || (*(byte *)(lVar11 + 0x30) == 0xff)) {
    lVar11 = 0;
  }
  else {
    lVar11 = (ulonglong)*(byte *)(lVar11 + 0x30) * 0x520 +
             *(longlong *)
              (*(longlong *)
                (**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar11 + 0x2f) * 8) + 0x110
              );
  }
  *(longlong *)(lVar9 + 0x2048) = lVar11;
  *(longlong *)(lVar9 + 0x1638) = lVar11;
  uVar12 = *(uint *)(lVar9 + 0x2058) | 0x100;
  if (bVar14 == 0) {
    uVar12 = *(uint *)(lVar9 + 0x2058) & 0xfffffeff;
  }
  *(uint *)(lVar9 + 0x2058) = uVar12;
  bVar10 = *(byte *)(lVar9 + 0x1677) | 2;
  if (bVar14 == 0) {
    bVar10 = *(byte *)(lVar9 + 0x1677) & 0xfd;
  }
  *(byte *)(lVar9 + 0x1677) = bVar10;
  *(uint *)(lVar8 + 0x1f0) = *(uint *)(lVar8 + 0x1f0) | 3;
  FUN_14010bb50(lVar9);
  local_58 = *(undefined8 *)(lVar8 + 0x268);
  uStack_50 = *(undefined8 *)(lVar8 + 0x270);
  local_48 = *(undefined8 *)(lVar8 + 600);
  uStack_40 = *(undefined8 *)(lVar8 + 0x260);
  FUN_14010a690(lVar9,&local_48,&local_58);
  *(undefined4 *)(lVar8 + 600) = *(undefined4 *)(lVar9 + 0x70);
  *(undefined4 *)(lVar8 + 0x25c) = *(undefined4 *)(lVar9 + 0x74);
  *(undefined4 *)(lVar8 + 0x260) = *(undefined4 *)(lVar9 + 0x78);
  *(undefined4 *)(lVar8 + 0x264) = *(undefined4 *)(lVar9 + 0x7c);
  *(undefined4 *)(lVar8 + 0x268) = *(undefined4 *)(lVar9 + 0x80);
  *(undefined4 *)(lVar8 + 0x26c) = *(undefined4 *)(lVar9 + 0x84);
  *(undefined4 *)(lVar8 + 0x270) = *(undefined4 *)(lVar9 + 0x88);
  *(undefined4 *)(lVar8 + 0x274) = *(undefined4 *)(lVar9 + 0x8c);
  *(undefined4 *)(param_1 + 0x378) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 2;
  return;
}

