/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f73c0; RVA 0xf73c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400f73c0(undefined8 param_1,longlong param_2)

{
  undefined1 auVar1 [16];
  longlong lVar2;
  undefined1 auVar3 [16];
  float fVar4;
  float fVar5;
  undefined4 uVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  
  lVar2 = *(longlong *)(param_2 + 0x1b8);
  fVar9 = *(float *)(param_2 + 0x25c);
  fVar11 = *(float *)(param_2 + 600);
  uVar6 = *(undefined4 *)(param_2 + 0x264);
  fVar7 = DAT_1402d2530;
  fVar5 = (float)FUN_140079410(*(undefined8 *)(lVar2 + 0x2030),fVar11,
                               *(undefined4 *)(param_2 + 0x260));
  if (fVar9 < fVar5) {
    fVar7 = (fVar5 - fVar9) * DAT_1402d1e94 + fVar7;
  }
  auVar1 = *(undefined1 (*) [16])(param_2 + 600);
  fVar7 = fVar7 * DAT_1402d287c;
  fVar5 = fVar7 + *(float *)(param_2 + 0x260);
  *(uint *)(lVar2 + 0x2058) = *(uint *)(lVar2 + 0x2058) | 0x1000000;
  auVar3 = vshufps_avx(auVar1,auVar1,0x55);
  fVar4 = auVar3._0_4_ - (fVar7 + fVar9);
  fVar12 = auVar1._0_4_ - (fVar7 + fVar11);
  auVar1 = vshufps_avx(auVar1,auVar1,0xaa);
  fVar10 = auVar1._0_4_ - fVar5;
  fVar8 = DAT_1402d22d0 / SQRT(fVar10 * fVar10 + fVar4 * fVar4 + fVar12 * fVar12);
  auVar1 = vmaxss_avx(ZEXT416((uint)(fVar8 * fVar4)),ZEXT416(DAT_1402d2d64));
  auVar1 = vminss_avx(auVar1,ZEXT416((uint)DAT_1402d22d0));
  *(float *)(lVar2 + 0x90) = fVar7 + fVar11;
  *(float *)(lVar2 + 0x94) = fVar7 + fVar9;
  *(float *)(lVar2 + 0x98) = fVar5;
  *(undefined4 *)(lVar2 + 0x9c) = uVar6;
  uVar6 = FUN_140272150(auVar1._0_8_);
  *(undefined4 *)(lVar2 + 0xa0) = uVar6;
  uVar6 = FUN_140272370(CONCAT44(_UNK_1402d3774,(uint)(fVar8 * fVar12) ^ DAT_1402d3770),
                        CONCAT44(_UNK_1402d3774,(uint)(fVar8 * fVar10) ^ DAT_1402d3770));
  *(undefined8 *)(lVar2 + 0xa8) = 0;
  *(undefined4 *)(lVar2 + 0xa4) = uVar6;
  return;
}

