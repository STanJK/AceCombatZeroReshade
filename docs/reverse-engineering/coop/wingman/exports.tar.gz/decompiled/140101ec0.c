/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140101ec0; RVA 0x101ec0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140101ec0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  uint *puVar1;
  longlong lVar2;
  char cVar3;
  
  lVar2 = *(longlong *)
           (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
  if (*(char *)(param_1 + 999) == '\0') {
    cVar3 = FUN_140101f20(param_1,param_2,param_4);
    if (cVar3 != '\0') {
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 8;
      *(undefined1 *)(param_1 + 999) = 1;
      puVar1 = (uint *)(lVar2 + 0x2058);
      *puVar1 = *puVar1 | 0x10;
    }
  }
  return;
}

