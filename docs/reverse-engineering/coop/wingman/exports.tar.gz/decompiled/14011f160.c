/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14011f160; RVA 0x11f160
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14011f160(longlong param_1)

{
  undefined1 auVar1 [16];
  byte bVar2;
  longlong lVar3;
  undefined8 *puVar4;
  uint *puVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  char cVar11;
  undefined1 uVar12;
  int iVar13;
  longlong lVar14;
  undefined4 uVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined1 auVar22 [64];
  float fVar23;
  float fVar24;
  float fVar25;
  uint uVar26;
  float fVar27;
  undefined1 auVar28 [64];
  float fVar29;
  undefined1 auVar30 [64];
  undefined8 local_128;
  undefined8 uStack_120;
  undefined8 local_118;
  undefined8 uStack_110;
  undefined1 local_108 [8];
  float fStack_100;
  float fStack_fc;
  undefined1 local_f8 [8];
  float fStack_f0;
  float fStack_ec;
  undefined1 local_e8 [8];
  float fStack_e0;
  float fStack_dc;
  undefined1 local_d8 [8];
  float fStack_d0;
  float fStack_cc;
  
  if (((((*(byte *)(param_1 + 0x1f0) & 1) != 0) && (*(longlong *)(param_1 + 0x1a0) != 0)) &&
      (lVar3 = *(longlong *)(*(longlong *)(param_1 + 0x1a0) + 8), lVar3 != 0)) &&
     ((puVar4 = *(undefined8 **)(lVar3 + 0x18), puVar4 != (undefined8 *)0x0 &&
      (puVar5 = (uint *)*puVar4, puVar5 != (uint *)0x0)))) {
    auVar1 = *(undefined1 (*) [16])(param_1 + 0x278);
    fVar27 = (float)puVar5[2];
    fVar20 = auVar1._0_4_ - *(float *)(param_1 + 600);
    auVar8 = vshufps_avx(auVar1,auVar1,0xaa);
    fVar17 = auVar8._0_4_ - *(float *)(param_1 + 0x260);
    auVar30 = ZEXT464(*puVar5);
    auVar8 = vshufps_avx(auVar1,auVar1,0x55);
    fVar25 = auVar8._0_4_ - *(float *)(param_1 + 0x25c);
    _local_108 = ZEXT816(0);
    _local_f8 = ZEXT816(0);
    auVar1 = vshufps_avx(auVar1,auVar1,0xff);
    fVar23 = auVar1._0_4_ - *(float *)(param_1 + 0x264);
    fVar21 = (float)puVar5[1];
    fVar29 = fVar23 * fVar23 + fVar17 * fVar17 + fVar25 * fVar25 + fVar20 * fVar20;
    _local_e8 = _local_108;
    _local_d8 = _local_f8;
    FUN_140202920(local_108,param_1 + 0x268);
    FUN_14003a2e0(local_108);
    fVar19 = fVar25 * fStack_ec + fVar20 * fStack_fc + fVar23 * fStack_cc + fVar17 * fStack_dc;
    fVar16 = fVar25 * fStack_f0 + fVar20 * fStack_100 + fVar23 * fStack_d0 + fVar17 * fStack_e0;
    fVar18 = fVar16 - DAT_1402d2544;
    fVar24 = fVar25 * (float)local_f8._4_4_ + fVar20 * (float)local_108._4_4_ +
             fVar23 * (float)local_d8._4_4_ + fVar17 * (float)local_e8._4_4_;
    fVar20 = fVar25 * (float)local_f8._0_4_ + fVar20 * (float)local_108._0_4_ +
             fVar17 * (float)local_e8._0_4_ + fVar23 * (float)local_d8._0_4_;
    fVar19 = SQRT(fVar19 * fVar19 + fVar18 * fVar18 + fVar20 * fVar20 + fVar24 * fVar24);
    fVar24 = 0.0;
    if (fVar19 != 0.0) {
      fVar19 = DAT_1402d22d0 / fVar19;
      fVar20 = fVar19 * fVar20;
      fVar18 = fVar19 * fVar18;
    }
    fVar17 = DAT_1402d22d0;
    fVar19 = (float)FUN_140272370(fVar20,fVar18);
    fVar19 = fVar19 + DAT_1402d2420;
    auVar1 = vcmpss_avx(ZEXT416((uint)DAT_1402d2420),ZEXT416((uint)fVar19),1);
    auVar1 = vblendvps_avx(ZEXT416((uint)fVar19),ZEXT416((uint)(fVar19 - DAT_1402d249c)),auVar1);
    auVar22 = ZEXT1664(auVar1);
    fVar19 = auVar1._0_4_;
    uVar26 = DAT_1402d3770;
    if ((fVar24 < *(float *)(param_1 + 0x218)) || (fVar24 < *(float *)(param_1 + 0x288))) {
      fVar20 = (auVar30._0_4_ / (float)*(byte *)(param_1 + 0x24a)) * DAT_1402d1f38;
      uStack_120 = CONCAT44(fVar24,fVar24);
      if (fVar24 <= fVar19) {
        auVar1 = vminss_avx(auVar1,ZEXT416((uint)fVar20));
        uVar15 = auVar1._0_4_;
      }
      else {
        auVar1 = vmaxss_avx(ZEXT416((uint)fVar20 ^ DAT_1402d3770),auVar1);
        uVar15 = auVar1._0_4_;
      }
      local_128 = CONCAT44(uVar15,fVar24);
      FUN_140203050(param_1 + 0x268,param_1 + 0x268,&local_128);
      fVar19 = auVar22._0_4_;
    }
    auVar1 = vcvtdq2ps_avx(ZEXT116(*(byte *)(param_1 + 0x24a)));
    fVar20 = auVar1._0_4_;
    fVar21 = ((fVar21 * DAT_1402d20dc) / fVar20) * DAT_1402d2478;
    fVar27 = (fVar27 / (fVar20 * fVar20)) * DAT_1402d2478;
    if ((*(byte *)(param_1 + 0x1f0) & 2) == 0) {
      if (*(float *)(param_1 + 0x288) <= fVar24) {
        *(undefined4 *)(param_1 + 0x288) = 0;
        fVar21 = 0.0;
      }
      else {
        fVar21 = *(float *)(param_1 + 0x288) - fVar27;
        *(float *)(param_1 + 0x288) = fVar21;
      }
    }
    else if ((DAT_1402d20f8 < fVar19) || (fVar19 < DAT_1402d2d10)) {
      if (*(float *)(param_1 + 0x288) <= fVar24) {
        *(undefined4 *)(param_1 + 0x288) = 0;
        fVar21 = 0.0;
      }
      else {
        fVar21 = *(float *)(param_1 + 0x288) - fVar27;
        *(float *)(param_1 + 0x288) = fVar21;
      }
    }
    else {
      fVar19 = *(float *)(param_1 + 0x288);
      if (DAT_1402d2a54 <= fVar29) {
        if (fVar21 - fVar27 <= fVar19) {
          *(float *)(param_1 + 0x288) = fVar21;
        }
        else {
          fVar21 = fVar19 + fVar27;
          *(float *)(param_1 + 0x288) = fVar21;
        }
      }
      else if (fVar16 <= fVar24) {
        if (*(float *)(param_1 + 0x218) < fVar19) {
          fVar19 = fVar19 - fVar27;
          *(float *)(param_1 + 0x288) = fVar19;
        }
        if (fVar19 < *(float *)(param_1 + 0x218)) {
          fVar19 = fVar19 + fVar27;
          *(float *)(param_1 + 0x288) = fVar19;
        }
        fVar21 = fVar19;
      }
      else if (fVar19 <= fVar24) {
        *(undefined4 *)(param_1 + 0x288) = 0;
        fVar21 = 0.0;
      }
      else {
        *(float *)(param_1 + 0x288) = fVar19 - fVar27;
        fVar21 = fVar19 - fVar27;
      }
    }
    fVar21 = (float)((uint)fVar21 ^ uVar26);
    FUN_140202920(local_108,param_1 + 0x268);
    auVar1 = *(undefined1 (*) [16])(param_1 + 600);
    auVar8 = vshufps_avx(_local_e8,_local_e8,0x55);
    auVar9 = vshufps_avx(auVar1,auVar1,0xaa);
    auVar10 = vshufps_avx(auVar1,auVar1,0x55);
    fVar19 = auVar8._0_4_ * fVar21 + auVar10._0_4_;
    auVar22 = ZEXT1664(CONCAT124(auVar10._4_12_,fVar19));
    auVar8 = vshufps_avx(_local_e8,_local_e8,0xaa);
    *(float *)(param_1 + 0x260) = auVar8._0_4_ * fVar21 + auVar9._0_4_;
    auVar8 = vshufps_avx(auVar1,auVar1,0xff);
    *(float *)(param_1 + 0x25c) = fVar19;
    fVar27 = local_e8._0_4_ * fVar21 + auVar1._0_4_;
    auVar28 = ZEXT1664(CONCAT124(auVar1._4_12_,fVar27));
    *(float *)(param_1 + 600) = fVar27;
    auVar1 = vshufps_avx(_local_e8,_local_e8,0xff);
    *(float *)(param_1 + 0x264) = auVar1._0_4_ * fVar21 + auVar8._0_4_;
    fVar21 = DAT_1402d26b4 / (float)*(byte *)(param_1 + 0x24a);
    auVar30 = ZEXT464((uint)fVar21);
    if ((*(byte *)(param_1 + 0x1f0) & 2) == 0) {
      *(float *)(param_1 + 0x25c) = fVar19 - fVar21;
    }
    else {
      fVar16 = 0.0;
      if (*(longlong *)(param_1 + 400) != 0) {
        fVar16 = (float)FUN_140079410(*(longlong *)(param_1 + 400),*(undefined4 *)(param_1 + 0x278),
                                      *(undefined4 *)(param_1 + 0x280));
        fVar27 = auVar28._0_4_;
        fVar21 = auVar30._0_4_;
        fVar19 = auVar22._0_4_;
      }
      auVar1 = vmaxss_avx(ZEXT416((uint)(fVar16 + DAT_1402d2698)),
                          ZEXT416(*(uint *)(param_1 + 0x27c)));
      fVar16 = auVar1._0_4_;
      if (fVar16 - fVar19 <= fVar21) {
        if (fVar16 - fVar19 < (float)((uint)fVar21 ^ uVar26)) {
          fVar16 = fVar19 - fVar21;
        }
      }
      else {
        fVar16 = fVar21 + fVar19;
      }
      *(float *)(param_1 + 0x25c) = fVar16;
      if ((*(byte *)(param_1 + 0x236) != 0xff) && (*(byte *)(param_1 + 0x237) != 0xff)) {
        lVar14 = (ulonglong)*(byte *)(param_1 + 0x237) * 0x520;
        bVar2 = *(byte *)(param_1 + 0x235);
        lVar3 = *(longlong *)
                 (*(longlong *)
                   (**(longlong **)(param_1 + 0x180) + (ulonglong)*(byte *)(param_1 + 0x234) * 8) +
                 0x110);
        lVar6 = *(longlong *)
                 (*(longlong *)
                   (**(longlong **)(param_1 + 0x180) + (ulonglong)*(byte *)(param_1 + 0x236) * 8) +
                 0x110);
        auVar1 = *(undefined1 (*) [16])(lVar6 + 600 + lVar14);
        auVar8 = vshufps_avx(auVar1,auVar1,0x55);
        fVar16 = auVar8._0_4_ - fVar16;
        auVar8 = vshufps_avx(auVar1,auVar1,0xaa);
        fVar21 = auVar8._0_4_ - *(float *)(param_1 + 0x260);
        fVar27 = auVar1._0_4_ - fVar27;
        _local_f8 = ZEXT816(0);
        _local_108 = ZEXT816(0);
        auVar1 = vshufps_avx(auVar1,auVar1,0xff);
        fVar19 = auVar1._0_4_ - *(float *)(param_1 + 0x264);
        _local_e8 = _local_108;
        _local_d8 = _local_f8;
        FUN_140202920(local_108,param_1 + 0x268);
        FUN_14003a2e0(local_108);
        fVar20 = DAT_1402d241c;
        fVar18 = SQRT(fVar19 * fVar19 + fVar21 * fVar21 + fVar27 * fVar27 + fVar16 * fVar16);
        if (fVar18 != fVar24) {
          fVar17 = fVar17 / fVar18;
          fVar27 = fVar27 * fVar17;
          fVar16 = fVar17 * fVar16;
          fVar21 = fVar21 * fVar17;
          fVar19 = fVar19 * fVar17;
        }
        if (fVar24 < (fVar19 * fStack_cc + fVar21 * fStack_dc +
                     fVar16 * fStack_ec + fVar27 * fStack_fc) -
                     (fVar19 * fStack_d0 + fVar21 * fStack_e0 +
                     fVar16 * fStack_f0 + fVar27 * fStack_100)) {
          puVar4 = *(undefined8 **)(*(longlong *)(param_1 + 0x1a0) + 0x20);
          if (puVar4 != (undefined8 *)0x0) {
            uVar7 = *puVar4;
            *(undefined8 *)(param_1 + 0xd8) = uVar7;
            *(undefined1 *)(param_1 + 0xe9) = *(undefined1 *)(param_1 + 0x24a);
            auVar1 = *(undefined1 (*) [16])(lVar6 + 600 + lVar14);
            *(int *)(param_1 + 0x110) = auVar1._0_4_;
            uVar15 = vextractps_avx(auVar1,1);
            *(undefined4 *)(param_1 + 0x114) = uVar15;
            uVar15 = vextractps_avx(auVar1,2);
            *(undefined4 *)(param_1 + 0x118) = uVar15;
            uVar15 = vextractps_avx(auVar1,3);
            *(undefined4 *)(param_1 + 0x11c) = uVar15;
            auVar1 = *(undefined1 (*) [16])(param_1 + 0x268);
            auVar8 = *(undefined1 (*) [16])(param_1 + 600);
            *(int *)(param_1 + 0xf0) = auVar8._0_4_;
            uVar15 = vextractps_avx(auVar8,1);
            *(undefined4 *)(param_1 + 0xf4) = uVar15;
            uVar15 = vextractps_avx(auVar8,2);
            *(undefined4 *)(param_1 + 0xf8) = uVar15;
            uVar15 = vextractps_avx(auVar8,3);
            *(undefined4 *)(param_1 + 0xfc) = uVar15;
            *(int *)(param_1 + 0x100) = auVar1._0_4_;
            uVar15 = vextractps_avx(auVar1,1);
            *(undefined4 *)(param_1 + 0x104) = uVar15;
            uVar15 = vextractps_avx(auVar1,2);
            *(undefined4 *)(param_1 + 0x108) = uVar15;
            uVar15 = vextractps_avx(auVar1,3);
            *(undefined4 *)(param_1 + 0x10c) = uVar15;
            FUN_14013aa20(param_1 + 0xd8);
            cVar11 = FUN_14013ac40(param_1 + 0xd8);
            if (cVar11 != '\0') {
              local_128 = *(undefined8 *)(param_1 + 0x268);
              uStack_120 = *(undefined8 *)(param_1 + 0x270);
              local_118 = *(undefined8 *)(param_1 + 600);
              uStack_110 = *(undefined8 *)(param_1 + 0x260);
              FUN_14013ace0(*(longlong *)(param_1 + 0x178) + 0xca0,&local_118,&local_128,0,
                            *(undefined1 *)(param_1 + 0x234),*(undefined1 *)(param_1 + 0x235),uVar7,
                            0);
              *(byte *)(param_1 + 0xe8) = *(byte *)(param_1 + 0xe8) | 1;
              *(uint *)(param_1 + 0x1fc) = *(uint *)(param_1 + 0x1fc) | 0x10;
              *(char *)(param_1 + 0x24d) = (char)(int)((float)*(byte *)(param_1 + 0x24a) * fVar20);
            }
          }
          puVar4 = *(undefined8 **)(*(longlong *)(param_1 + 0x1a0) + 0x28);
          if (puVar4 != (undefined8 *)0x0) {
            uVar7 = *puVar4;
            *(undefined8 *)(param_1 + 0x88) = uVar7;
            *(undefined1 *)(param_1 + 0x99) = *(undefined1 *)(param_1 + 0x24a);
            if ((*(char *)(param_1 + 0x236) == '\0') && (*(char *)(param_1 + 0x237) == '\0')) {
              uVar12 = *(undefined1 *)
                        (*(longlong *)(*(longlong *)(lVar6 + 0x1b8 + lVar14) + 0xfe0) + 0xe);
            }
            else {
              uVar12 = 0;
            }
            *(undefined1 *)(param_1 + 0xd2) = uVar12;
            auVar1 = *(undefined1 (*) [16])(lVar6 + 600 + lVar14);
            *(int *)(param_1 + 0xc0) = auVar1._0_4_;
            uVar15 = vextractps_avx(auVar1,1);
            *(undefined4 *)(param_1 + 0xc4) = uVar15;
            uVar15 = vextractps_avx(auVar1,2);
            *(undefined4 *)(param_1 + 200) = uVar15;
            uVar15 = vextractps_avx(auVar1,3);
            *(undefined4 *)(param_1 + 0xcc) = uVar15;
            auVar1 = *(undefined1 (*) [16])(param_1 + 0x268);
            auVar8 = *(undefined1 (*) [16])(param_1 + 600);
            *(int *)(param_1 + 0xa0) = auVar8._0_4_;
            uVar15 = vextractps_avx(auVar8,1);
            *(undefined4 *)(param_1 + 0xa4) = uVar15;
            uVar15 = vextractps_avx(auVar8,2);
            *(undefined4 *)(param_1 + 0xa8) = uVar15;
            uVar15 = vextractps_avx(auVar8,3);
            *(undefined4 *)(param_1 + 0xac) = uVar15;
            *(int *)(param_1 + 0xb0) = auVar1._0_4_;
            uVar15 = vextractps_avx(auVar1,1);
            *(undefined4 *)(param_1 + 0xb4) = uVar15;
            uVar15 = vextractps_avx(auVar1,2);
            *(undefined4 *)(param_1 + 0xb8) = uVar15;
            uVar15 = vextractps_avx(auVar1,3);
            *(undefined4 *)(param_1 + 0xbc) = uVar15;
            FUN_14013aa20(param_1 + 0x88);
            if (*(short *)(param_1 + 0xd0) != -1) {
              puVar5 = (uint *)(lVar6 + 0x1fc + lVar14);
              *puVar5 = *puVar5 | 0x8000000;
            }
            cVar11 = FUN_14013ac90(param_1 + 0x88);
            if (cVar11 != '\0') {
              puVar5 = (uint *)((ulonglong)bVar2 * 0x520 + lVar3 + 0x1fc);
              *puVar5 = *puVar5 | 8;
              puVar5 = (uint *)(lVar6 + 0x1fc + lVar14);
              *puVar5 = *puVar5 | 0x100;
            }
            cVar11 = FUN_14013ac40(param_1 + 0x88);
            if (cVar11 != '\0') {
              lVar3 = *(longlong *)(param_1 + 0x178);
              local_118 = *(undefined8 *)(param_1 + 0x268);
              uStack_110 = *(undefined8 *)(param_1 + 0x270);
              local_128 = *(undefined8 *)(param_1 + 600);
              uStack_120 = *(undefined8 *)(param_1 + 0x260);
              iVar13 = FUN_14013d140(lVar3,&local_128,&local_118,0,*(undefined1 *)(param_1 + 0x234),
                                     *(undefined1 *)(param_1 + 0x235),
                                     *(undefined1 *)(lVar6 + 0x234 + lVar14),
                                     *(undefined1 *)(lVar6 + 0x235 + lVar14),uVar7,2);
              if (-1 < iVar13) {
                *(undefined1 *)(lVar3 + 0x1fd90) = 0;
              }
              *(byte *)(param_1 + 0x98) = *(byte *)(param_1 + 0x98) | 1;
              uVar12 = *(undefined1 *)(param_1 + 0x235);
              *(uint *)(param_1 + 0x1fc) = *(uint *)(param_1 + 0x1fc) | 1;
              *(undefined1 *)(lVar6 + 0x238 + lVar14) = *(undefined1 *)(param_1 + 0x234);
              *(undefined1 *)(lVar6 + 0x239 + lVar14) = uVar12;
              *(char *)(param_1 + 0x24d) = (char)(int)((float)*(byte *)(param_1 + 0x24a) * fVar20);
            }
          }
        }
      }
    }
  }
  return;
}

