/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fcc20; RVA 0xfcc20
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400fcc20(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  byte bVar2;
  longlong lVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  uint uVar8;
  longlong lVar9;
  bool bVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  longlong local_res8;
  undefined2 local_res10 [4];
  uint in_stack_ffffffffffffffa8;
  
  lVar7 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar3 = *(longlong *)(lVar7 + 0x1b8);
  bVar2 = *(byte *)(*param_2 + 0x30);
  uVar8 = *(uint *)(param_1 + 0x3a8) & 0xfffffff7 | 0x20;
  if (*(char *)(param_1 + 0x3da) != '\0') {
    uVar8 = *(uint *)(param_1 + 0x3a8) & 0xffffffd7;
  }
  *(uint *)(param_1 + 0x3a8) = uVar8;
  if ((((uVar8 & 4) == 0) && ((bVar2 & 4) == 0)) && ((*(byte *)(lVar3 + 0x1676) & 1) != 0)) {
    bVar10 = false;
    if ((*(float *)(lVar7 + 600) < *(float *)(param_1 + 0x90)) ||
       (*(float *)(param_1 + 0xa0) < *(float *)(lVar7 + 600))) {
      bVar10 = true;
    }
    if ((*(float *)(lVar7 + 0x25c) < *(float *)(param_1 + 0x94)) ||
       (*(float *)(param_1 + 0xa4) < *(float *)(lVar7 + 0x25c))) {
      bVar10 = true;
    }
    if (((*(float *)(lVar7 + 0x260) < *(float *)(param_1 + 0x98)) ||
        (*(float *)(param_1 + 0xa8) < *(float *)(lVar7 + 0x260))) || (bVar10)) {
      local_res8 = 0;
      FUN_140118040(lVar7,&local_res8,0,1,in_stack_ffffffffffffffa8 & 0xffffff00,0,3);
      *(uint *)(lVar7 + 0x1fc) = *(uint *)(lVar7 + 0x1fc) | 0x20000000;
    }
  }
  bVar10 = (*(byte *)(lVar7 + 0x1f0) & 2) == 0;
  if (bVar10) {
    *(undefined2 *)(param_1 + 0x3be) = 0;
  }
  lVar6 = FUN_1401c56d0();
  fVar13 = DAT_1402d2504;
  if (*(int *)(param_1 + 900) < 1) {
    bVar10 = true;
    *(undefined1 *)(param_1 + 0x3e6) = 5;
  }
  else if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
    iVar5 = *(int *)(param_1 + 900) + -1;
    *(int *)(param_1 + 0x394) = *(int *)(param_1 + 0x394) + 1;
    *(int *)(param_1 + 900) = iVar5;
    iVar4 = (uint)*(byte *)(param_1 + 0x3d1) * 5;
    uVar8 = (uint)*(byte *)(param_1 + 0x3d1);
    if (iVar4 < iVar5) {
      if (((float)iVar5 <= (float)uVar8 * fVar13) && (iVar5 % (int)uVar8 == 0)) {
        local_res8 = (ulonglong)local_res8._2_6_ << 0x10;
        goto LAB_1400fcde5;
      }
    }
    else if (iVar5 % (int)uVar8 == 0) {
      local_res8 = CONCAT62(local_res8._2_6_,1);
LAB_1400fcde5:
      local_res10[0] = 1;
      FUN_1401c6150(iVar4,local_res10,&local_res8);
    }
  }
  if ((*(float *)(param_1 + 0x354) < *(float *)(lVar7 + 0x260)) ||
     (*(float *)(lVar7 + 0x260) < *(float *)(param_1 + 0x34c) ||
      (*(float *)(param_1 + 0x350) < *(float *)(lVar7 + 600) ||
      *(float *)(lVar7 + 600) < *(float *)(param_1 + 0x348)))) {
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a7df0(*(longlong *)(param_1 + 0x308),0);
    }
    lVar7 = FUN_140189320();
    lVar9 = 0x1a;
    if (*(char *)(lVar7 + 0x3e) == '\x01') {
      lVar9 = 3;
    }
    bVar2 = DAT_14031f8b1 & 1;
    (&DAT_140310a64)[(ulonglong)*(byte *)(lVar6 + 0xc) * 8] = 0x42fe0000;
    if (bVar2 == 0) {
      lVar7 = (longlong)*(short *)(lVar6 + 4);
      if (((int)lVar9 < *(int *)(&DAT_14031f838 + lVar7 * 0x18)) &&
         (*(longlong *)(&DAT_14031f840 + lVar7 * 0x18) != 0)) {
        FUN_140186f20((&DAT_14033bc00)[(char)(&DAT_14031f8a8)[lVar7 + (ulonglong)DAT_14031f8b0 * 4]]
                      ,&DAT_14031f438 + lVar7 * 0x100,
                      *(undefined4 *)(*(longlong *)(&DAT_14031f840 + lVar7 * 0x18) + lVar9 * 4),0,
                      (int)(char)(&DAT_14031f8a8)[lVar7 + (ulonglong)DAT_14031f8b0 * 4],0,0,1);
        *(int *)(&DAT_14031f898 + lVar7 * 4) = (int)lVar9;
      }
    }
  }
  else if (!bVar10) goto LAB_1400fcf4f;
  *(byte *)(param_1 + 0x3dc) = *(byte *)(param_1 + 0x3dc) | 1;
  *(undefined4 *)(param_1 + 0x378) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 5;
  if (*(char *)(param_1 + 0x3e6) != '\x05') {
    *(undefined1 *)(param_1 + 0x3e6) = 4;
  }
LAB_1400fcf4f:
  if (((*(byte *)(lVar3 + 0x1676) & 3) == 0) || ((*(byte *)(lVar3 + 0x1676) & 2) != 0)) {
    if ((*(ushort *)(param_1 + 0x3a8) & 0x1000) != 0) {
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffefff;
    }
  }
  else if ((*(ushort *)(param_1 + 0x3a8) & 0x1000) == 0) {
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x1000;
  }
  if (*(float *)(lVar3 + 0x1848) <= 0.0) {
    if (*(longlong *)(param_1 + 0x308) != 0) {
      fVar11 = (float)FUN_1401019d0(param_1);
      fVar12 = (float)*(int *)(param_1 + 0x3ac);
      if (fVar11 <= fVar12 * fVar13 + DAT_1402d27a0) {
        if (fVar11 <= fVar12 * fVar13 + DAT_1402d274c) {
          if (fVar11 <= fVar12 * fVar13 + DAT_1402d26d8) {
            *(char *)(param_1 + 0x3e9) = (fVar11 <= fVar12 * fVar13 + DAT_1402d264c) + '\x03';
          }
          else {
            *(undefined1 *)(param_1 + 0x3e9) = 2;
          }
        }
        else {
          *(undefined1 *)(param_1 + 0x3e9) = 1;
        }
      }
      else {
        *(undefined1 *)(param_1 + 0x3e9) = 0;
      }
    }
    lVar7 = *(longlong *)
             (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
    pbVar1 = (byte *)(lVar7 + 0x1863);
    *pbVar1 = *pbVar1 | 1;
    *(undefined4 *)(lVar7 + 0x185c) = 0xbf800000;
    *(undefined4 *)(param_1 + 0x378) = 0;
    *(undefined1 *)(param_1 + 0x3cc) = 4;
    *(undefined1 *)(param_1 + 0x3e6) = 3;
  }
  return;
}

