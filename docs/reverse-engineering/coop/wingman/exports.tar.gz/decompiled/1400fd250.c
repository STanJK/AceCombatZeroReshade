/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fd250; RVA 0xfd250
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400fd250(longlong param_1)

{
  uint uVar1;
  longlong lVar2;
  longlong lVar3;
  undefined1 auVar4 [16];
  float fVar5;
  undefined4 uVar6;
  undefined1 auVar7 [64];
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffbfff;
  uVar1 = *(uint *)(param_1 + 0x3a8);
  lVar2 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar3 = *(longlong *)(lVar2 + 0x1b8);
  *(undefined1 *)(param_1 + 0x3e6) = 4;
  *(uint *)(param_1 + 0x3a8) = uVar1 | 0x20;
  if (*(int *)(param_1 + 0x378) < (int)((uint)*(byte *)(param_1 + 0x3d1) << 3)) {
    if ((uVar1 & 4) == 0) {
      *(int *)(param_1 + 0x378) = *(int *)(param_1 + 0x378) + 1;
    }
    if (((*(float *)(param_1 + 0x354) < *(float *)(lVar2 + 0x260)) ||
        (*(float *)(lVar2 + 0x260) < *(float *)(param_1 + 0x34c) ||
         (*(float *)(param_1 + 0x350) < *(float *)(lVar2 + 600) ||
         *(float *)(lVar2 + 600) < *(float *)(param_1 + 0x348)))) &&
       ((*(byte *)(param_1 + 0x3d0) & 1) != 0)) {
      *(byte *)(lVar3 + 0x1da7) = *(byte *)(lVar3 + 0x1da7) | 1;
      *(undefined4 *)(lVar3 + 0x1d78) = 0xbe800000;
      *(undefined4 *)(lVar3 + 0x1d7c) = 0x3f800000;
      *(byte *)(lVar3 + 0x1863) = *(byte *)(lVar3 + 0x1863) | 1;
      *(undefined4 *)(lVar3 + 0x185c) = 0;
      if ((*(uint *)(lVar3 + 0x2058) >> 0xd & 1) == 0) {
        *(uint *)(lVar3 + 0x2058) = *(uint *)(lVar3 + 0x2058) | 0x2000;
        *(undefined1 *)(lVar3 + 0x2095) = *(undefined1 *)(lVar3 + 0x2094);
      }
      *(undefined1 *)(lVar3 + 0x2096) = 1;
    }
    auVar7 = ZEXT464((uint)DAT_1402d22d0);
    lVar2 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
    fVar9 = ((float)*(int *)(param_1 + 0x378) / (float)*(byte *)(param_1 + 0x3d1) + DAT_1402d24d0) *
            DAT_1402d287c;
    uVar6 = *(undefined4 *)(lVar2 + 0x264);
    fVar8 = *(float *)(lVar2 + 600) + fVar9;
    fVar10 = *(float *)(lVar2 + 0x25c) + fVar9;
    fVar9 = *(float *)(lVar2 + 0x260) + fVar9;
    fVar13 = *(float *)(lVar2 + 600) - fVar8;
    fVar11 = *(float *)(lVar2 + 0x25c) - fVar10;
    fVar14 = *(float *)(lVar2 + 0x260) - fVar9;
    fVar5 = SQRT(fVar14 * fVar14 + fVar11 * fVar11 + fVar13 * fVar13);
    fVar12 = DAT_1402d22d0 / fVar5;
    FUN_1401fbec0(fVar5);
    FUN_140014960(param_1 + 0xe0,lVar3 + 0x10b0);
    auVar4 = vmaxss_avx(ZEXT416((uint)(fVar12 * fVar11)),ZEXT416(DAT_1402d2d64));
    auVar4 = vminss_avx(auVar4,auVar7._0_16_);
    *(float *)(param_1 + 0x110) = fVar8;
    *(float *)(param_1 + 0x114) = fVar10;
    *(float *)(param_1 + 0x118) = fVar9;
    *(undefined4 *)(param_1 + 0x11c) = uVar6;
    uVar6 = FUN_140272150(auVar4._0_8_);
    *(undefined4 *)(param_1 + 0x120) = uVar6;
    uVar6 = FUN_140272370(CONCAT44(_UNK_1402d3774,(uint)(fVar12 * fVar13) ^ DAT_1402d3770),
                          CONCAT44(_UNK_1402d3774,(uint)(fVar12 * fVar14) ^ DAT_1402d3770));
    *(undefined8 *)(param_1 + 0x128) = 0;
    *(undefined4 *)(param_1 + 0x124) = uVar6;
    FUN_1401fbec0(param_1 + 0xe0);
    if ((*(byte *)(*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1f0) &
        2) == 0) {
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x48;
      *(byte *)(lVar3 + 0x1677) = *(byte *)(lVar3 + 0x1677) & 0xfe;
      *(byte *)(lVar3 + 0x1676) = *(byte *)(lVar3 + 0x1676) & 0xfc;
      *(byte *)(lVar3 + 0x1863) = *(byte *)(lVar3 + 0x1863) & 0xfb;
      *(uint *)(lVar3 + 0x2058) = *(uint *)(lVar3 + 0x2058) & 0xffffff7f;
    }
    if (*(char *)(param_1 + 0x3da) != '\x01') {
      if ((int)((uint)*(byte *)(param_1 + 0x3d1) * 7) <= *(int *)(param_1 + 0x378)) {
        *(float *)(param_1 + 0x3a0) =
             (float)*(int *)(param_1 + 0x378) / (float)*(byte *)(param_1 + 0x3d1) - DAT_1402d24b0;
        return;
      }
    }
  }
  else {
    if (*(char *)(param_1 + 0x3da) != '\x01') {
      lVar2 = *(longlong *)(param_1 + 0x340);
      *(undefined1 *)(param_1 + 0x3cc) = 0;
      if ((*(uint *)(lVar2 + 0xa8790) >> 0x1d & 1) != 0) {
        *(uint *)(lVar2 + 0xa8790) = *(uint *)(lVar2 + 0xa8790) & 0xdfffffff;
        FUN_1400c3910(lVar2 + 0x697b8);
      }
      *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
      return;
    }
    *(undefined1 *)(param_1 + 0x3cc) = 6;
  }
  return;
}

