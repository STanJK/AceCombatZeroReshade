/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14013b5c0; RVA 0x13b5c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14013b5c0(longlong *param_1)

{
  int *piVar1;
  uint *puVar2;
  byte bVar3;
  byte bVar4;
  undefined1 uVar5;
  ushort uVar6;
  uint uVar7;
  longlong *plVar8;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  int iVar11;
  char cVar12;
  undefined2 uVar13;
  int iVar14;
  int iVar15;
  undefined4 *puVar16;
  undefined1 *puVar17;
  undefined1 *puVar18;
  uint uVar19;
  uint uVar20;
  longlong lVar21;
  longlong lVar22;
  uint uVar23;
  longlong lVar24;
  ulonglong uVar25;
  ulonglong uVar26;
  ulonglong uVar27;
  longlong lVar28;
  longlong lVar29;
  bool bVar30;
  float fVar31;
  undefined8 uVar32;
  undefined1 auVar33 [16];
  undefined1 extraout_var [56];
  undefined1 extraout_var_00 [56];
  undefined1 extraout_var_01 [56];
  undefined1 extraout_var_02 [56];
  undefined1 extraout_var_03 [56];
  undefined1 extraout_var_04 [56];
  undefined1 extraout_var_05 [56];
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  undefined1 auVar38 [64];
  undefined1 auVar39 [64];
  float fVar40;
  undefined1 in_ZMM9 [64];
  undefined1 auVar41 [64];
  undefined1 auVar42 [64];
  undefined1 in_ZMM11 [64];
  undefined1 auVar43 [64];
  undefined1 auVar44 [64];
  float fVar45;
  undefined1 auVar46 [64];
  float fVar47;
  int local_res10 [2];
  undefined2 local_res18 [4];
  uint local_res20;
  undefined8 *in_stack_fffffffffffffdd8;
  longlong in_stack_fffffffffffffde0;
  undefined4 uVar48;
  undefined8 local_1e8;
  undefined8 uStack_1e0;
  longlong *local_1d8;
  undefined1 local_1d0 [8];
  float fStack_1c8;
  undefined4 uStack_1c4;
  float local_1c0;
  float fStack_1bc;
  float fStack_1b8;
  float fStack_1b4;
  undefined8 local_1b0;
  undefined8 uStack_1a8;
  int local_1a0;
  int local_198;
  undefined1 local_190 [4];
  undefined1 auStack_18c [20];
  undefined8 local_178;
  undefined8 uStack_170;
  undefined1 local_168 [8];
  undefined8 uStack_160;
  undefined8 local_158;
  undefined8 uStack_150;
  undefined1 local_148 [8];
  float fStack_140;
  float fStack_13c;
  float local_138;
  undefined4 local_128;
  float local_124;
  uint local_120;
  float local_11c;
  float local_118;
  float local_114;
  float local_110;
  float local_10c;
  uint local_108;
  float local_104;
  undefined4 local_100;
  float local_fc;
  float local_f8;
  float local_f4;
  float local_f0;
  float local_ec;
  ulonglong local_e8;
  longlong *local_e0;
  undefined1 local_98 [16];
  undefined1 local_78 [16];
  
  local_78 = in_ZMM9._0_16_;
  local_98 = in_ZMM11._0_16_;
  _local_1d0 = ZEXT816(0);
  local_198 = 0;
  uVar23 = 1;
  lVar28 = 0;
  fVar40 = 0.0;
  uVar20 = DAT_1402d3770;
  do {
    iVar14 = local_198;
    if ((*(uint *)(param_1 + 0xe7) & uVar23) != 0) {
      local_1c0 = *(float *)(lVar28 + 0x38 + (longlong)param_1);
      fStack_1bc = *(float *)(lVar28 + 0x3c + (longlong)param_1);
      fStack_1b4 = *(float *)(lVar28 + 0x44 + (longlong)param_1);
      fVar37 = *(float *)(lVar28 + 0x48 + (longlong)param_1);
      fVar45 = *(float *)(lVar28 + 0x4c + (longlong)param_1);
      fStack_1b8 = *(float *)(lVar28 + 0x40 + (longlong)param_1);
      fVar47 = *(float *)(lVar28 + 0x50 + (longlong)param_1);
      fVar35 = *(float *)(lVar28 + 0x54 + (longlong)param_1);
      uVar25 = (ulonglong)*(byte *)(lVar28 + 0x60 + (longlong)param_1);
      local_1e8._4_4_ = fStack_1bc + fVar45;
      local_1e8._0_4_ = local_1c0 + fVar37;
      uStack_1e0._0_4_ = fStack_1b8 + fVar47;
      uStack_1e0._4_4_ = fStack_1b4 + fVar35;
      local_1d8 = *(longlong **)param_1[1];
      fVar37 = SQRT(fVar35 * fVar35 + fVar47 * fVar47 + fVar45 * fVar45 + fVar37 * fVar37);
      local_138 = fVar37;
      local_e8 = uVar25;
      local_e0 = local_1d8;
      if (local_1d8 != local_1d8 + *(byte *)((longlong)param_1[1] + 0x34)) {
        do {
          uVar26 = 0;
          lVar29 = *local_1d8;
          if ((*(byte *)(lVar29 + 0x120) & 4) != 0) {
            bVar3 = *(byte *)(local_e0[uVar25] + 0x15d);
            if ((bVar3 == 0) || (bVar3 == 2)) {
              bVar30 = *(char *)(local_e0[uVar25] + 0x15c) == *(char *)(lVar29 + 0x15c);
            }
            else {
              bVar30 = (&DAT_1402accc0)[(ulonglong)*(byte *)(lVar29 + 0x15d) + (ulonglong)bVar3 * 8]
                       == '\0';
            }
            if (!bVar30) {
              lVar29 = (longlong)*(int *)(lVar29 + 0x118);
              _local_190 = lVar29;
              if (0 < lVar29) {
                bVar3 = (byte)iVar14 & 0x1f;
                uVar23 = 1 << bVar3 | 1U >> 0x20 - bVar3;
                uVar27 = uVar26;
                local_res20 = uVar23;
                do {
                  lVar22 = *(longlong *)(*local_1d8 + 0x110) + uVar27;
                  if ((*(byte *)(lVar22 + 0x1f0) & 1) != 0) {
                    bVar3 = *(byte *)(*local_1d8 + 0x15c);
                    bVar4 = *(byte *)(lVar28 + 0x60 + (longlong)param_1);
                    if ((bVar3 != bVar4) ||
                       ((uint)uVar26 != (uint)*(byte *)(lVar28 + 0x61 + (longlong)param_1))) {
                      lVar21 = (ulonglong)*(byte *)(lVar28 + 0x61 + (longlong)param_1) * 0x520;
                      lVar24 = *(longlong *)
                                (*(longlong *)(*(longlong *)param_1[1] + (ulonglong)bVar4 * 8) +
                                0x110);
                      cVar12 = *(char *)(**(longlong **)(lVar24 + 0x388 + lVar21) + 0x15d);
                      if ((((cVar12 != '\0') && (cVar12 != '\x02')) ||
                          (((*(char *)(lVar24 + 0x235 + lVar21) == '\0' || (bVar3 != bVar4)) ||
                           ((cVar12 = *(char *)(**(longlong **)(lVar22 + 0x388) + 0x15d),
                            cVar12 != '\0' && (cVar12 != '\x02')))))) ||
                         (*(char *)(lVar22 + 0x235) != '\0')) {
                        fVar47 = *(float *)(lVar22 + 0x25c) - fStack_1bc;
                        _local_1d0 = *(undefined1 (*) [16])(lVar22 + 600);
                        fVar35 = *(float *)(lVar22 + 0x260) - fStack_1b8;
                        fVar36 = *(float *)*(undefined1 (*) [16])(lVar22 + 600) - local_1c0;
                        fVar45 = *(float *)(lVar22 + 0x41c) + fVar37;
                        if (fVar35 * fVar35 + fVar47 * fVar47 + fVar36 * fVar36 <= fVar45 * fVar45)
                        {
                          cVar12 = *(char *)(**(longlong **)(lVar22 + 0x388) + 0x15d);
                          if (((cVar12 == '\0') || (cVar12 == '\x02')) &&
                             (*(char *)(lVar22 + 0x235) == '\0')) {
                            lVar24 = *(longlong *)(lVar22 + 0x1b8);
                            iVar14 = FUN_14014d070(&local_1c0,&local_1e8,local_1d0,
                                                   *(undefined4 *)
                                                    (*(longlong *)(lVar24 + 0x130) + 8));
                            if (iVar14 != 0) {
                              auVar41._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar22 + 0x26c));
                              auVar41._8_56_ = extraout_var;
                              auVar33 = vshufps_avx(auVar41._0_16_,auVar41._0_16_,1);
                              local_108 = (uint)auVar41._0_8_;
                              local_120 = local_108 ^ uVar20;
                              local_128 = auVar33._0_4_;
                              local_114 = DAT_1402d22d0;
                              local_ec = DAT_1402d22d0;
                              fVar45 = DAT_1402d22d0;
                              local_124 = fVar40;
                              local_11c = fVar40;
                              local_118 = fVar40;
                              local_110 = fVar40;
                              local_10c = fVar40;
                              local_104 = fVar40;
                              local_100 = local_128;
                              local_fc = fVar40;
                              local_f8 = fVar40;
                              local_f4 = fVar40;
                              local_f0 = fVar40;
                              auVar42._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar22 + 0x268));
                              auVar42._8_56_ = extraout_var_00;
                              auVar33 = vshufps_avx(auVar42._0_16_,auVar42._0_16_,1);
                              uStack_150._0_4_ = auVar33._0_4_;
                              local_168._4_4_ = (undefined4)uStack_150;
                              local_168._0_4_ = fVar40;
                              local_158 = CONCAT44((uint)auVar42._0_8_ ^ uVar20,fVar40);
                              local_178 = CONCAT44(fVar40,fVar45);
                              local_148._4_4_ = fVar40;
                              local_148._0_4_ = fVar40;
                              uStack_160._0_4_ = (uint)auVar42._0_8_;
                              fStack_140 = fVar40;
                              uStack_170 = CONCAT44(fVar40,fVar40);
                              fStack_13c = fVar45;
                              uStack_150._4_4_ = fVar40;
                              uStack_160._4_4_ = fVar40;
                              FUN_140005940(&local_128,&local_128,&local_178);
                              auVar43._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar22 + 0x270));
                              auVar43._8_56_ = extraout_var_01;
                              auVar33 = vshufps_avx(auVar43._0_16_,auVar43._0_16_,1);
                              local_168._4_4_ = auVar33._0_4_;
                              local_168._0_4_ = (uint)auVar43._0_8_ ^ uVar20;
                              local_178 = CONCAT44((uint)auVar43._0_8_,auVar33._0_4_);
                              local_158 = CONCAT44(fVar40,(undefined4)local_158);
                              uStack_160._0_4_ = fVar40;
                              uStack_150 = CONCAT44(uStack_150._4_4_,fVar45);
                              FUN_140005940(&local_128,&local_128,&local_178);
                              local_f8 = local_f8 + *(float *)(lVar22 + 600);
                              local_f4 = local_f4 + *(float *)(lVar22 + 0x25c);
                              local_f0 = local_f0 + *(float *)(lVar22 + 0x260);
                              if ((2 < *(uint *)(*(longlong *)(lVar24 + 0x630) + 4)) &&
                                 (*(int *)(*(longlong *)(lVar24 + 0x630) + 0x40) != 0)) {
                                in_stack_fffffffffffffdd8 = &local_1e8;
                                uStack_1c4 = DAT_1402d23c0;
                                iVar14 = FUN_14015f2a0(*(undefined8 *)(lVar24 + 0x6b0),local_1d0,
                                                       &local_128,&local_1c0,
                                                       in_stack_fffffffffffffdd8);
LAB_14013bba7:
                                if (iVar14 != 0) goto LAB_14013bbaf;
                              }
                            }
                          }
                          else {
                            plVar8 = *(longlong **)(lVar22 + 0x3a0);
                            lVar24 = **(longlong **)(lVar22 + 0x1a0);
                            iVar14 = FUN_14014d070(&local_1c0,&local_1e8,local_1d0,
                                                   *(float *)(lVar22 + 0x41c));
                            if (iVar14 != 0) {
                              if ((*(char *)(lVar24 + 0x6f) == '\x02') &&
                                 (plVar8 != (longlong *)0x0)) {
                                _local_168 = ZEXT816(0);
                                local_178 = 0;
                                uStack_170 = 0;
                                local_158 = 0;
                                uStack_150 = 0;
                                _local_148 = _local_168;
                                FUN_140202920(&local_178,lVar22 + 0x268);
                                auVar33 = _local_148;
                                fVar45 = (float)local_148._0_4_ + *(float *)(lVar22 + 600);
                                fVar47 = (float)local_148._4_4_ + *(float *)(lVar22 + 0x25c);
                                in_stack_fffffffffffffdd8 = &local_1e8;
                                local_148._0_4_ = fVar45;
                                auVar9 = _local_148;
                                fStack_140 = auVar33._8_4_;
                                fStack_13c = auVar33._12_4_;
                                local_148 = auVar9._0_8_;
                                fStack_140 = fStack_140 + *(float *)(lVar22 + 0x260);
                                local_148._4_4_ = fVar47;
                                iVar14 = (**(code **)(*plVar8 + 0x120))
                                                   (plVar8,local_1d0,&local_178,&local_1c0,
                                                    in_stack_fffffffffffffdd8);
                                goto LAB_14013bba7;
                              }
LAB_14013bbaf:
                              if (*(short *)(**(longlong **)(lVar22 + 0x1a0) + 0x6c) == 0x46) {
                                uVar23 = *(uint *)(lVar22 + 0x268);
                                auVar46 = ZEXT464(*(uint *)(lVar22 + 0x26c));
                                auVar44._0_8_ = FUN_14026f3b0(uVar23);
                                auVar44._8_56_ = extraout_var_02;
                                auVar33 = auVar44._0_16_;
                                auVar43 = ZEXT1664(auVar33);
                                auVar33 = vshufps_avx(auVar33,auVar33,1);
                                auVar42 = ZEXT1664(auVar33);
                                fVar45 = (float)((uint)auVar44._0_8_ ^ uVar20);
                                auVar38._0_8_ = FUN_14026f3b0(auVar46._0_8_);
                                auVar38._8_56_ = extraout_var_03;
                                auVar33 = auVar38._0_16_;
                                auVar41 = ZEXT1664(auVar33);
                                auVar33 = vshufps_avx(auVar33,auVar33,1);
                                auVar44 = ZEXT1664(auVar33);
                                fVar47 = (float)((uint)(float)auVar38._0_8_ ^ uVar20);
                                if (auVar42._0_4_ * auVar33._0_4_ * (fStack_1c8 - fStack_1b8) +
                                    ((float)local_1d0._0_4_ - local_1c0) *
                                    (float)auVar38._0_8_ * auVar42._0_4_ +
                                    ((float)local_1d0._4_4_ - fStack_1bc) * fVar45 < fVar40) {
                                  _local_190 = *(undefined1 (*) [16])
                                                (lVar28 + 0x48 + (longlong)param_1);
                                  auVar38 = ZEXT1664(_local_190);
                                  auVar39._0_8_ = FUN_14026f3b0(uVar23 ^ DAT_1402d3770);
                                  auVar39._8_56_ = extraout_var_04;
                                  auVar39 = ZEXT1664(auVar39._0_16_);
                                  auVar33._4_12_ = ZEXT812(0);
                                  auVar33._0_4_ = auVar46._0_4_ ^ DAT_1402d3770;
                                  auVar46._0_8_ = FUN_14026f3b0(auVar33._0_8_,0);
                                  auVar46._8_56_ = extraout_var_05;
                                  auVar33 = vshufps_avx(auVar46._0_16_,auVar46._0_16_,1);
                                  auVar9 = vshufps_avx(auVar38._0_16_,auVar38._0_16_,0xaa);
                                  fVar37 = auVar33._0_4_ * auVar38._0_4_ +
                                           auVar9._0_4_ * (float)auVar46._0_8_;
                                  auVar10 = vshufps_avx(auVar39._0_16_,auVar39._0_16_,1);
                                  fVar35 = auVar10._0_4_ * (float)auStack_18c._0_4_ +
                                           (float)((uint)(auVar39._0_4_ *
                                                         (auVar33._0_4_ * auVar9._0_4_ -
                                                         auVar38._0_4_ * (float)auVar46._0_8_)) ^
                                                  DAT_1402d3770);
                                  fVar34 = fVar37 * fVar40 + (float)auStack_18c._8_4_;
                                  fVar31 = SQRT(fVar34 * fVar34 +
                                                fVar35 * fVar35 + fVar37 * fVar37 + DAT_1402d271c);
                                  _local_190 = (undefined1  [12])auStack_18c._0_12_ << 0x20;
                                  fVar36 = DAT_1402d2df4;
                                  if (fVar31 != fVar40) {
                                    fVar31 = DAT_1402d22d0 / fVar31;
                                    fVar37 = fVar37 * fVar31;
                                    fVar35 = fVar31 * fVar35;
                                    fVar36 = fVar31 * DAT_1402d2df4;
                                    fVar34 = fVar34 * fVar31;
                                  }
                                  auStack_18c._8_4_ = fVar34;
                                  fVar34 = fVar35 * auVar43._0_4_ + auVar42._0_4_ * fVar36;
                                  auVar9._12_4_ = 0;
                                  auVar9._0_12_ = auStack_18c._0_12_;
                                  _local_190 = auVar9 << 0x20;
                                  *(float *)(lVar28 + 0x48 + (longlong)param_1) =
                                       (fVar37 * auVar44._0_4_ + auVar41._0_4_ * fVar34) * local_138
                                  ;
                                  *(float *)(lVar28 + 0x4c + (longlong)param_1) =
                                       (fVar35 * auVar42._0_4_ + fVar45 * fVar36) * local_138;
                                  *(float *)(lVar28 + 0x50 + (longlong)param_1) =
                                       (fVar37 * fVar47 + fVar34 * auVar44._0_4_) * local_138;
                                  *(undefined1 *)(lVar28 + 0x60 + (longlong)param_1) =
                                       *(undefined1 *)(lVar22 + 0x234);
                                  *(undefined1 *)(lVar28 + 0x61 + (longlong)param_1) =
                                       *(undefined1 *)(lVar22 + 0x235);
                                  fVar37 = local_138;
                                  goto LAB_14013bd8e;
                                }
                              }
                              if (*param_1 != 0) {
                                local_1b0 = local_1e8;
                                uStack_1a8 = uStack_1e0;
                                local_1a0 = 1;
                                FUN_140031f80(*(undefined8 *)(*param_1 + 0x66ee0),0x23,&local_1b0,0)
                                ;
                              }
                              lVar29 = *(longlong *)(lVar22 + 0x1b8);
                              uVar32 = FUN_1401c56d0();
                              if (lVar29 == 0) {
                                in_stack_fffffffffffffdd8 = &local_1b0;
                                in_stack_fffffffffffffde0 =
                                     CONCAT44((int)((ulonglong)in_stack_fffffffffffffde0 >> 0x20),
                                              fVar40);
                                local_1b0 = _DAT_1402d35f0;
                                uStack_1a8 = _UNK_1402d35f8;
                                cVar12 = FUN_1401c6a00(_DAT_1402d35f0,1,0x1a,&local_1e8,
                                                       in_stack_fffffffffffffdd8,
                                                       in_stack_fffffffffffffde0,fVar40,fVar40,
                                                       fVar40,0,0);
                                if ((((cVar12 != '\0') &&
                                     (lVar29 = FUN_1401c97a0(), '\x01' < *(char *)(lVar29 + 0x3dc2))
                                     ) && (uVar6 = *(ushort *)(lVar29 + 0x138),
                                          (~*(byte *)(*(longlong *)
                                                       (&DAT_14032d5a8 + (ulonglong)uVar6 * 0x18) +
                                                     0x832) & 1) != 0)) &&
                                   (puVar16 = (undefined4 *)FUN_1401c9e60(lVar29),
                                   puVar16 != (undefined4 *)0x0)) {
                                  *(ushort *)(puVar16 + 0x11) = uVar6;
                                  *(undefined2 *)((longlong)puVar16 + 0x46) = 0x1a;
                                  *puVar16 = (undefined4)local_1e8;
                                  puVar16[1] = local_1e8._4_4_;
                                  puVar16[2] = (undefined4)uStack_1e0;
                                  puVar16[3] = uStack_1e0._4_4_;
                                  *(undefined8 *)(puVar16 + 7) = 0x3f800000;
                                  *(undefined8 *)(puVar16 + 4) = 0;
                                  puVar16[6] = 0;
                                  *(undefined8 *)(puVar16 + 9) = 0;
                                  *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
                                  puVar16[0xb] = 0x3f800000;
                                  puVar16[0xf] = 0x3f800000;
                                  *(byte *)(puVar16 + 0x1c) = *(byte *)(puVar16 + 0x1c) & 0xee | 6;
                                  *(code **)(puVar16 + 0xc) = FUN_1401caa00;
                                }
                              }
                              else {
                                cVar12 = *(char *)(lVar29 + 0x2094);
                                if (cVar12 == '\0') {
                                  uVar13 = 0x55;
                                }
                                else if (cVar12 == '\x02') {
                                  uVar13 = 0x56;
                                }
                                else {
                                  if (cVar12 != '\x01') goto LAB_14013c218;
                                  uVar13 = 0x57;
                                }
                                local_res10[0] = CONCAT22(local_res10[0]._2_2_,uVar13);
                                local_res18[0] = 1;
                                FUN_1401c6150(uVar32,local_res18,local_res10);
                              }
LAB_14013c218:
                              puVar17 = operator_new((longlong)*(int *)(*local_1d8 + 0x118));
                              iVar14 = 0;
                              lVar29 = *local_1d8;
                              if (0 < *(int *)(lVar29 + 0x118)) {
                                puVar18 = puVar17;
                                do {
                                  *puVar18 = 0;
                                  puVar18 = puVar18 + 1;
                                  iVar14 = iVar14 + 1;
                                  lVar29 = *local_1d8;
                                } while (iVar14 < *(int *)(lVar29 + 0x118));
                              }
                              lVar24 = *(longlong *)
                                        (*(longlong *)param_1[1] +
                                        (ulonglong)*(byte *)(lVar28 + 0x60 + (longlong)param_1) * 8)
                              ;
                              bVar3 = *(byte *)(lVar24 + 0x15d);
                              lVar24 = (ulonglong)*(byte *)(lVar28 + 0x61 + (longlong)param_1) *
                                       0x520 + *(longlong *)(lVar24 + 0x110);
                              if (((&DAT_1402accc0)
                                   [(ulonglong)bVar3 + (ulonglong)*(byte *)(lVar29 + 0x15d) * 8] !=
                                   '\0') && (*(byte *)(lVar29 + 0x15d) != bVar3)) {
                                in_stack_fffffffffffffdd8 =
                                     (undefined8 *)
                                     ((ulonglong)in_stack_fffffffffffffdd8 & 0xffffffffffffff00);
                                in_stack_fffffffffffffde0 = lVar24;
                                FUN_140118040(lVar22,&local_1d8,puVar17,
                                              *(undefined1 *)
                                               (*(longlong *)(lVar28 + 0x58 + (longlong)param_1) +
                                               0x49),in_stack_fffffffffffffdd8,lVar24,3);
                              }
                              uVar23 = local_res20;
                              uVar5 = *(undefined1 *)(lVar22 + 0x235);
                              *(undefined1 *)(lVar24 + 0x242) = *(undefined1 *)(lVar22 + 0x234);
                              *(undefined1 *)(lVar24 + 0x243) = uVar5;
                              *(uint *)(param_1 + 0xe7) = *(uint *)(param_1 + 0xe7) & ~local_res20;
                              if (*param_1 != 0) {
                                lVar29 = *(longlong *)(*param_1 + 0x66ee0);
                                uVar20 = (uint)(*(ushort *)(lVar28 + 0x62 + (longlong)param_1) &
                                               0x3ff);
                                if (*(short *)(lVar28 + 0x62 + (longlong)param_1) == -1) {
                                  uVar20 = 0xffffffff;
                                }
                                lVar22 = (longlong)(short)uVar20 >> 5;
                                uVar19 = *(uint *)(lVar29 + 0x1bc48 + lVar22 * 4);
                                if ((uVar19 >> (uVar20 & 0x1f) & 1) != 0) {
                                  *(uint *)(lVar29 + 0x1bc48 + lVar22 * 4) =
                                       uVar19 & ~(1 << (uVar20 & 0x1f));
                                  piVar1 = (int *)(lVar29 + 0x1bc88);
                                  *piVar1 = *piVar1 + -1;
                                  if (*piVar1 < 0) {
                                    *(undefined4 *)(lVar29 + 0x1bc88) = 0;
                                  }
                                }
                              }
                              thunk_FUN_1402500f0(puVar17);
                              lVar29 = _local_190;
                              goto LAB_14013bd94;
                            }
                          }
LAB_14013bd8e:
                          uVar23 = local_res20;
                        }
                      }
                    }
                  }
LAB_14013bd94:
                  uVar26 = (ulonglong)((uint)uVar26 + 1);
                  uVar27 = uVar27 + 0x520;
                  lVar29 = lVar29 + -1;
                  _local_190 = lVar29;
                  uVar25 = local_e8;
                  iVar14 = local_198;
                  uVar20 = DAT_1402d3770;
                } while (lVar29 != 0);
              }
            }
          }
          local_1d8 = local_1d8 + 1;
        } while (local_1d8 !=
                 (longlong *)(*(longlong *)param_1[1] + (ulonglong)*(byte *)(param_1[1] + 0x34) * 8)
                );
      }
      local_res10[0] = 2;
      if (param_1[2] != 0) {
        in_stack_fffffffffffffdd8 = &local_1e8;
        iVar15 = FUN_1400782c0(param_1[2],local_1d0,local_res10,&local_1c0,in_stack_fffffffffffffdd8
                              );
        iVar11 = local_res10[0];
        if (iVar15 != 0) {
          *(uint *)(param_1 + 0xe7) = *(uint *)(param_1 + 0xe7) & ~uVar23;
          puVar2 = (uint *)(*(longlong *)
                             (*(longlong *)
                               (*(longlong *)param_1[1] +
                               (ulonglong)*(byte *)(lVar28 + 0x60 + (longlong)param_1) * 8) + 0x110)
                            + 0x1fc +
                           (ulonglong)*(byte *)(lVar28 + 0x61 + (longlong)param_1) * 0x520);
          *puVar2 = *puVar2 | 0x400000;
          if (*param_1 != 0) {
            lVar29 = *(longlong *)(*param_1 + 0x66ee0);
            uVar19 = (uint)(*(ushort *)(lVar28 + 0x62 + (longlong)param_1) & 0x3ff);
            if (*(short *)(lVar28 + 0x62 + (longlong)param_1) == -1) {
              uVar19 = 0xffffffff;
            }
            lVar22 = (longlong)(short)uVar19 >> 5;
            uVar7 = *(uint *)(lVar29 + 0x1bc48 + lVar22 * 4);
            if ((uVar7 >> (uVar19 & 0x1f) & 1) != 0) {
              *(uint *)(lVar29 + 0x1bc48 + lVar22 * 4) = uVar7 & ~(1 << (uVar19 & 0x1f));
              piVar1 = (int *)(lVar29 + 0x1bc88);
              *piVar1 = *piVar1 + -1;
              if (*piVar1 < 0) {
                *(undefined4 *)(lVar29 + 0x1bc88) = 0;
              }
            }
            uStack_1a8 = CONCAT44(DAT_1402d22d0,fStack_1c8);
            local_1b0 = local_1d0;
            local_1a0 = local_res10[0];
            FUN_140031f80(*(undefined8 *)(*param_1 + 0x66ee0),0x23,&local_1b0,0);
          }
          uVar48 = (undefined4)((ulonglong)in_stack_fffffffffffffde0 >> 0x20);
          if (iVar11 == 0) {
            FUN_1401c56d0();
            in_stack_fffffffffffffdd8 = &local_1b0;
            in_stack_fffffffffffffde0 = CONCAT44(uVar48,fVar40);
            local_1b0 = _DAT_1402d35f0;
            uStack_1a8 = _UNK_1402d35f8;
            cVar12 = FUN_1401c6a00(_DAT_1402d35f0,1,0x18,&local_1e8,in_stack_fffffffffffffdd8,
                                   in_stack_fffffffffffffde0,fVar40,fVar40,fVar40,0,0);
            if (((cVar12 != '\0') && (lVar29 = FUN_1401c97a0(), '\x01' < *(char *)(lVar29 + 0x3dc2))
                ) && ((uVar6 = *(ushort *)(lVar29 + 0x138),
                      (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar6 * 0x18) + 0x792) &
                      1) != 0 &&
                      (puVar16 = (undefined4 *)FUN_1401c9e60(lVar29), puVar16 != (undefined4 *)0x0))
                     )) {
              *(ushort *)(puVar16 + 0x11) = uVar6;
              *(undefined2 *)((longlong)puVar16 + 0x46) = 0x18;
              *puVar16 = (undefined4)local_1e8;
              puVar16[1] = local_1e8._4_4_;
              puVar16[2] = (undefined4)uStack_1e0;
              puVar16[3] = uStack_1e0._4_4_;
              *(undefined8 *)(puVar16 + 4) = 0;
              puVar16[6] = 0;
              *(undefined8 *)(puVar16 + 7) = 0x3f800000;
              *(undefined8 *)(puVar16 + 9) = 0;
              puVar16[0xb] = 0x3f800000;
              puVar16[0xf] = 0x3f800000;
              *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
              *(byte *)(puVar16 + 0x1c) = *(byte *)(puVar16 + 0x1c) & 0xee | 6;
              *(code **)(puVar16 + 0xc) = FUN_1401caa00;
            }
          }
          else if (iVar11 == 1) {
            FUN_1401c56d0();
            in_stack_fffffffffffffdd8 = &local_1b0;
            in_stack_fffffffffffffde0 = CONCAT44(uVar48,fVar40);
            local_1b0 = _DAT_1402d35f0;
            uStack_1a8 = _UNK_1402d35f8;
            cVar12 = FUN_1401c6a00(_DAT_1402d35f0,1,0x1a,&local_1e8,in_stack_fffffffffffffdd8,
                                   in_stack_fffffffffffffde0,fVar40,fVar40,fVar40,0,0);
            if ((((cVar12 != '\0') &&
                 (lVar29 = FUN_1401c97a0(), '\x01' < *(char *)(lVar29 + 0x3dc2))) &&
                (uVar6 = *(ushort *)(lVar29 + 0x138),
                (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar6 * 0x18) + 0x832) & 1) !=
                0)) && (puVar16 = (undefined4 *)FUN_1401c9e60(lVar29), puVar16 != (undefined4 *)0x0)
               ) {
              *(ushort *)(puVar16 + 0x11) = uVar6;
              *(undefined2 *)((longlong)puVar16 + 0x46) = 0x1a;
              *puVar16 = (undefined4)local_1e8;
              puVar16[1] = local_1e8._4_4_;
              puVar16[2] = (undefined4)uStack_1e0;
              puVar16[3] = uStack_1e0._4_4_;
              *(undefined8 *)(puVar16 + 4) = 0;
              puVar16[6] = 0;
              *(undefined8 *)(puVar16 + 7) = 0x3f800000;
              *(undefined8 *)(puVar16 + 9) = 0;
              puVar16[0xb] = 0x3f800000;
              puVar16[0xf] = 0x3f800000;
              *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
              *(byte *)(puVar16 + 0x1c) = *(byte *)(puVar16 + 0x1c) & 0xee | 6;
              *(code **)(puVar16 + 0xc) = FUN_1401caa00;
            }
          }
          else if (iVar11 == 2) {
            FUN_1401c56d0();
            in_stack_fffffffffffffdd8 = &local_1b0;
            in_stack_fffffffffffffde0 = CONCAT44(uVar48,fVar40);
            local_1b0 = _DAT_1402d35f0;
            uStack_1a8 = _UNK_1402d35f8;
            cVar12 = FUN_1401c6a00(_DAT_1402d35f0,1,0x19,&local_1e8,in_stack_fffffffffffffdd8,
                                   in_stack_fffffffffffffde0,fVar40,fVar40,fVar40,0,0);
            if (((cVar12 != '\0') && (lVar29 = FUN_1401c97a0(), '\x01' < *(char *)(lVar29 + 0x3dc2))
                ) && ((uVar6 = *(ushort *)(lVar29 + 0x138),
                      (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar6 * 0x18) + 0x7e2) &
                      1) != 0 &&
                      (puVar16 = (undefined4 *)FUN_1401c9e60(lVar29), puVar16 != (undefined4 *)0x0))
                     )) {
              *(ushort *)(puVar16 + 0x11) = uVar6;
              *(undefined2 *)((longlong)puVar16 + 0x46) = 0x19;
              *puVar16 = (undefined4)local_1e8;
              puVar16[1] = local_1e8._4_4_;
              puVar16[2] = (undefined4)uStack_1e0;
              puVar16[3] = uStack_1e0._4_4_;
              *(undefined8 *)(puVar16 + 4) = 0;
              puVar16[6] = 0;
              *(undefined8 *)(puVar16 + 7) = 0x3f800000;
              *(undefined8 *)(puVar16 + 9) = 0;
              puVar16[0xb] = 0x3f800000;
              puVar16[0xf] = 0x3f800000;
              *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
              *(byte *)(puVar16 + 0x1c) = *(byte *)(puVar16 + 0x1c) & 0xee | 6;
              *(code **)(puVar16 + 0xc) = FUN_1401caa00;
            }
          }
        }
      }
    }
    local_198 = iVar14 + 1;
    uVar23 = uVar23 << 1 | (uint)((int)uVar23 < 0);
    lVar28 = lVar28 + 0x38;
    if (0x1f < local_198) {
      return;
    }
  } while( true );
}

