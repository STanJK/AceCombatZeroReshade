/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400a47a0; RVA 0xa47a0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400a47a0(longlong *param_1,longlong param_2)

{
  ushort *puVar1;
  undefined1 uVar2;
  undefined8 uVar3;
  
  if ((DAT_14033bd60 == '\0') && ((undefined8 *)param_1[2] != (undefined8 *)0x0)) {
    puVar1 = (ushort *)
             (*(longlong *)(*(longlong *)(**(longlong **)param_1[2] + 0x110) + 0x1b8) + 0x2090);
    *puVar1 = *puVar1 | 2;
  }
  uVar2 = (**(code **)(*param_1 + 0x90))();
  FUN_1400a46f0(param_1,param_2,0,uVar2);
  uVar2 = (**(code **)(*param_1 + 0x90))(param_1);
  uVar3 = (**(code **)(*param_1 + 0xa0))(param_1);
  FUN_1400a4680(param_1,param_2 + 0x9e,param_2,uVar3,uVar2);
  uVar2 = (**(code **)(*param_1 + 0x90))(param_1);
  uVar3 = (**(code **)(*param_1 + 0xa8))(param_1);
  FUN_1400a4680(param_1,param_2 + 0x9c,param_2,uVar3,uVar2);
  return;
}

