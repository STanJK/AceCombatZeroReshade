0x1400fa7c0  MOV qword ptr [RSP + 0x20],RBX
0x1400fa7c5  MOV qword ptr [RSP + 0x8],RCX
0x1400fa7ca  PUSH RBP
0x1400fa7cb  PUSH RSI
0x1400fa7cc  PUSH RDI
0x1400fa7cd  PUSH R12
0x1400fa7cf  PUSH R13
0x1400fa7d1  PUSH R14
0x1400fa7d3  PUSH R15
0x1400fa7d5  SUB RSP,0x40
0x1400fa7d9  MOV RDX,qword ptr [RDX]
0x1400fa7dc  MOV RAX,qword ptr [RCX + 0x2f8]
0x1400fa7e3  MOV qword ptr [RSP + 0x90],RDX
0x1400fa7eb  LEA R12,[RDX + 0xb7]
0x1400fa7f2  MOV RCX,qword ptr [RAX]
0x1400fa7f5  MOV RAX,qword ptr [RCX]
0x1400fa7f8  MOV R13,qword ptr [RAX + 0x110]
0x1400fa7ff  MOVZX EAX,byte ptr [RDX + 0xb6]
0x1400fa806  MOV qword ptr [RSP + 0x88],R13
0x1400fa80e  MOV R13,qword ptr [R13 + 0x1b8]
0x1400fa815  CMP AL,0xff
0x1400fa817  JZ 0x1400fa837
0x1400fa819  MOVZX EDX,byte ptr [R12]
0x1400fa81e  CMP DL,0xff
0x1400fa821  JZ 0x1400fa837
0x1400fa823  MOV RCX,qword ptr [RCX + RAX*0x8]
0x1400fa827  IMUL RDX,RDX,0x520
0x1400fa82e  ADD RDX,qword ptr [RCX + 0x110]
0x1400fa835  JMP 0x1400fa839
0x1400fa837  XOR EDX,EDX
0x1400fa839  MOV qword ptr [R13 + 0x2048],RDX
0x1400fa840  MOV RCX,R13
0x1400fa843  MOV qword ptr [R13 + 0x1638],RDX
0x1400fa84a  MOV EAX,dword ptr [R13 + 0x2058]
0x1400fa851  AND byte ptr [R13 + 0x1677],0xfd
0x1400fa859  BTR EAX,0x8
0x1400fa85d  AND EAX,0xffffffef
0x1400fa860  MOV dword ptr [R13 + 0x2058],EAX
0x1400fa867  MOV EAX,dword ptr [R13 + 0xd48]
0x1400fa86e  BTR EAX,0x8
0x1400fa872  BTS EAX,0x9
0x1400fa876  MOV dword ptr [R13 + 0xd48],EAX
0x1400fa87d  MOVZX R15D,word ptr [R13 + 0x2728]
0x1400fa885  MOVZX R14D,word ptr [R13 + 0x272a]
0x1400fa88d  MOVZX EBP,byte ptr [R13 + 0x272c]
0x1400fa895  MOVZX ESI,byte ptr [R13 + 0x272d]
0x1400fa89d  MOVZX EDI,byte ptr [R13 + 0x272e]
0x1400fa8a5  MOV EBX,dword ptr [R13 + 0x2784]
0x1400fa8ac  CALL 0x140102ab0
0x1400fa8b1  MOV byte ptr [R13 + 0x272e],DIL
0x1400fa8b8  MOV RDI,qword ptr [RSP + 0x88]
0x1400fa8c0  MOV RCX,RDI
0x1400fa8c3  MOV word ptr [R13 + 0x2728],R15W
0x1400fa8cb  MOV word ptr [R13 + 0x272a],R14W
0x1400fa8d3  MOV byte ptr [R13 + 0x272c],BPL
0x1400fa8da  MOV byte ptr [R13 + 0x272d],SIL
0x1400fa8e1  MOV dword ptr [R13 + 0x2784],EBX
0x1400fa8e8  CALL 0x140114c30
0x1400fa8ed  MOV RBX,qword ptr [RSP + 0x80]
0x1400fa8f5  XOR ESI,ESI
0x1400fa8f7  MOV RCX,R13
0x1400fa8fa  MOV EAX,dword ptr [RBX + 0x404]
0x1400fa900  MOV dword ptr [RDI + 0x420],EAX
0x1400fa906  MOVZX EAX,byte ptr [RBX + 0x3e2]
0x1400fa90d  OR dword ptr [RDI + 0x1f0],0x3
0x1400fa914  MOV word ptr [RDI + 0x428],AX
0x1400fa91b  MOV qword ptr [RDI + 0x268],RSI
0x1400fa922  MOV qword ptr [RDI + 0x270],RSI
0x1400fa929  CALL 0x14010bb50
0x1400fa92e  VMOVUPS XMM0,xmmword ptr [RDI + 0x268]
0x1400fa936  VMOVUPS xmmword ptr [RSP + 0x20],XMM0
0x1400fa93c  VMOVUPS XMM0,xmmword ptr [RDI + 0x258]
0x1400fa944  LEA R8,[RSP + 0x20]
0x1400fa949  MOV RCX,R13
0x1400fa94c  LEA RDX,[RSP + 0x30]
0x1400fa951  VMOVUPS xmmword ptr [RSP + 0x30],XMM0
0x1400fa957  CALL 0x14010a690
0x1400fa95c  MOV EAX,dword ptr [R13 + 0x70]
0x1400fa960  MOV dword ptr [RDI + 0x258],EAX
0x1400fa966  MOV EAX,dword ptr [R13 + 0x74]
0x1400fa96a  MOV dword ptr [RDI + 0x25c],EAX
0x1400fa970  MOV EAX,dword ptr [R13 + 0x78]
0x1400fa974  MOV dword ptr [RDI + 0x260],EAX
0x1400fa97a  MOV EAX,dword ptr [R13 + 0x7c]
0x1400fa97e  MOV dword ptr [RDI + 0x264],EAX
0x1400fa984  MOV EAX,dword ptr [R13 + 0x80]
0x1400fa98b  MOV dword ptr [RDI + 0x268],EAX
0x1400fa991  MOV EAX,dword ptr [R13 + 0x84]
0x1400fa998  MOV dword ptr [RDI + 0x26c],EAX
0x1400fa99e  MOV EAX,dword ptr [R13 + 0x88]
0x1400fa9a5  MOV dword ptr [RDI + 0x270],EAX
0x1400fa9ab  MOV EAX,dword ptr [R13 + 0x8c]
0x1400fa9b2  MOV dword ptr [RDI + 0x274],EAX
0x1400fa9b8  OR byte ptr [R13 + 0x1863],0x1
0x1400fa9c0  MOV RAX,qword ptr [RSP + 0x90]
0x1400fa9c8  MOV dword ptr [R13 + 0x185c],0xbf800000
0x1400fa9d3  MOV qword ptr [R13 + 0x1d78],RSI
0x1400fa9da  OR byte ptr [R13 + 0x1da7],0x1
0x1400fa9e2  MOV R9D,dword ptr [R13 + 0x2058]
0x1400fa9e9  OR R9D,0x20
0x1400fa9ed  MOV dword ptr [R13 + 0x2058],R9D
0x1400fa9f4  MOVZX ECX,byte ptr [RAX + 0xb6]
0x1400fa9fb  CMP CL,0xff
0x1400fa9fe  JZ 0x1400faa2b
0x1400faa00  MOVZX R10D,byte ptr [R12]
0x1400faa05  CMP R10B,0xff
0x1400faa09  JZ 0x1400faa2b
0x1400faa0b  MOV RAX,qword ptr [RBX + 0x2f8]
0x1400faa12  MOV EDX,ECX
0x1400faa14  MOV RCX,qword ptr [RAX]
0x1400faa17  MOV R8,qword ptr [RCX + RDX*0x8]
0x1400faa1b  IMUL RCX,R10,0x520
0x1400faa22  ADD RCX,qword ptr [R8 + 0x110]
0x1400faa29  JMP 0x1400faa2e
0x1400faa2b  MOV RCX,RSI
0x1400faa2e  MOV qword ptr [R13 + 0x2048],RCX
0x1400faa35  BTR R9D,0x8
0x1400faa3a  MOV qword ptr [R13 + 0x1638],RCX
0x1400faa41  MOV dword ptr [R13 + 0x2058],R9D
0x1400faa48  AND byte ptr [R13 + 0x1677],0xfd
0x1400faa50  MOV dword ptr [RBX + 0x37c],ESI
0x1400faa56  MOV byte ptr [RBX + 0x3cc],0x16
0x1400faa5d  MOV RBX,qword ptr [RSP + 0x98]
0x1400faa65  ADD RSP,0x40
0x1400faa69  POP R15
0x1400faa6b  POP R14
0x1400faa6d  POP R13
0x1400faa6f  POP R12
0x1400faa71  POP RDI
0x1400faa72  POP RSI
0x1400faa73  POP RBP
0x1400faa74  RET
