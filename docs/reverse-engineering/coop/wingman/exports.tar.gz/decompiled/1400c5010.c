/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400c5010; RVA 0xc5010
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400c5010(longlong param_1)

{
  longlong lVar1;
  undefined1 uVar2;
  
  lVar1 = *(longlong *)(param_1 + 0xfd8);
  uVar2 = *(undefined1 *)(lVar1 + 0xe);
  if (*(char *)(lVar1 + 0xd) == '\x15') {
    uVar2 = 1;
  }
  FUN_1400b7750(param_1 + 0x1868,
                *(undefined1 *)
                 ((ulonglong)*(byte *)(param_1 + 0x279a) + 4 + *(longlong *)(param_1 + 0xff8)),uVar2
                ,*(undefined1 *)(lVar1 + 0xf),*(undefined8 *)(param_1 + 0x1fc8));
  return;
}

