/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140133cd0; RVA 0x133cd0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140133cd0(longlong param_1,char param_2)

{
  float *pfVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined1 auVar8 [16];
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  uint uVar20;
  longlong lVar21;
  float fVar22;
  float fVar23;
  undefined1 auVar24 [16];
  undefined1 extraout_var [56];
  float fVar25;
  float fVar26;
  float fVar27;
  undefined1 in_ZMM6 [64];
  undefined1 auVar28 [64];
  undefined1 auVar29 [64];
  float fVar30;
  undefined1 auVar31 [64];
  undefined1 in_ZMM9 [64];
  undefined1 auVar32 [64];
  undefined1 auVar33 [64];
  float fVar34;
  float fVar35;
  undefined1 auVar36 [64];
  float fVar37;
  float fVar38;
  int local_res18;
  int local_174;
  longlong local_140;
  undefined1 local_138 [8];
  float fStack_130;
  float fStack_12c;
  undefined8 local_128;
  undefined8 uStack_120;
  undefined8 local_118;
  undefined8 uStack_110;
  undefined8 local_108;
  undefined8 uStack_100;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined1 local_88 [16];
  undefined1 local_58 [16];
  
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_1 + 0x48);
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_1 + 0x4c);
  *(undefined4 *)(param_1 + 0x10) = *(undefined4 *)(param_1 + 0x50);
  *(undefined4 *)(param_1 + 0x14) = *(undefined4 *)(param_1 + 0x54);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x58);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_1 + 0x5c);
  *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_1 + 0x60);
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_1 + 0x50);
  *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_1 + 0x54);
  *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_1 + 0x48);
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_1 + 0x4c);
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_1 + 100);
  local_128 = 0;
  uStack_120 = 0;
  local_118 = 0;
  uStack_110 = 0;
  local_108 = 0;
  uStack_100 = 0;
  local_f8 = 0;
  uStack_f0 = 0;
  FUN_140202920(&local_128,param_1 + 0x18);
  fVar5 = (float)local_f8 + *(float *)(param_1 + 8);
  fVar6 = local_f8._4_4_ + *(float *)(param_1 + 0xc);
  fVar7 = (float)uStack_f0 + *(float *)(param_1 + 0x10);
  local_174 = 0;
  if (0 < *(int *)(param_1 + 0x118)) {
    fVar17 = (float)local_108;
    fVar13 = (float)local_118;
    fVar19 = (float)uStack_100;
    fVar18 = local_108._4_4_;
    auVar36 = ZEXT464(DAT_1402d235c);
    fVar16 = uStack_110._4_4_;
    fVar15 = (float)uStack_110;
    fVar14 = local_118._4_4_;
    fVar12 = uStack_120._4_4_;
    fVar11 = (float)uStack_120;
    fVar10 = local_128._4_4_;
    fVar9 = (float)local_128;
    local_58 = in_ZMM6._0_16_;
    local_res18 = 0;
    local_140 = 0;
    auVar33 = ZEXT864(0);
    local_88 = in_ZMM9._0_16_;
    fVar22 = (float)uStack_100;
    fVar30 = local_108._4_4_;
    fVar34 = DAT_1402d1f38;
    fVar35 = DAT_1402d2140;
    fVar37 = uStack_f0._4_4_;
    fVar38 = uStack_100._4_4_;
    do {
      lVar21 = local_140 + *(longlong *)(param_1 + 0x110);
      if (*(undefined8 **)(lVar21 + 0x1a8) != (undefined8 *)0x0) {
        pfVar1 = (float *)**(undefined8 **)(lVar21 + 0x1a8);
        plVar2 = *(longlong **)(lVar21 + 0x1a0);
        uVar20 = *(uint *)(lVar21 + 0x1f0);
        auVar32 = ZEXT1664(*(undefined1 (*) [16])(lVar21 + 600));
        if (param_2 == '\0') {
          if ((uVar20 & 2) == 0) goto LAB_1401343bf;
        }
        else {
          uVar20 = uVar20 & 0xfff7ffff | 0x2200003;
          *(uint *)(lVar21 + 0x1f0) = uVar20;
          if ((*(char *)(param_1 + 0x15d) != '\0') && (*(char *)(param_1 + 0x15d) != '\x02')) {
            *(ushort *)(lVar21 + 0x428) = (ushort)*(byte *)(*plVar2 + 0x6e);
          }
          if (*(longlong **)(lVar21 + 0x390) != (longlong *)0x0) {
            (**(code **)(**(longlong **)(lVar21 + 0x390) + 0x30))();
            uVar20 = *(uint *)(lVar21 + 0x1f0);
          }
          if (*(longlong **)(lVar21 + 0x398) != (longlong *)0x0) {
            (**(code **)(**(longlong **)(lVar21 + 0x398) + 0x30))();
            uVar20 = *(uint *)(lVar21 + 0x1f0);
          }
          *(undefined2 *)(lVar21 + 0x120) = 0xffff;
          *(undefined2 *)(lVar21 + 0xe0) = 0;
          *(undefined2 *)(lVar21 + 0x90) = 0;
          *(undefined2 *)(lVar21 + 0x130) = 0;
          *(undefined2 *)(lVar21 + 0xd0) = 0xffff;
          *(undefined2 *)(lVar21 + 0x170) = 0xffff;
        }
        *(undefined8 *)(lVar21 + 0x3a0) =
             *(undefined8 *)(lVar21 + ((ulonglong)(~uVar20 & 2) | 0xe4) * 4);
        fVar23 = auVar33._0_4_;
        if ((*(byte *)(param_1 + 0xf0) & 0x10) == 0) {
          fVar25 = *pfVar1;
          fVar26 = pfVar1[1];
          fVar27 = pfVar1[2];
          local_138._4_4_ = fVar34 * pfVar1[4];
          local_138._0_4_ = fVar34 * pfVar1[3];
          fStack_130 = fVar34 * pfVar1[5];
          fStack_12c = fVar23;
        }
        else {
          _local_138 = ZEXT816(0);
          fVar27 = (float)local_res18;
          fVar25 = fVar23;
          fVar26 = fVar23;
        }
        *(float *)(lVar21 + 600) = fVar26 * fVar13 + fVar25 * fVar9 + fVar27 * fVar17 + fVar5;
        *(float *)(lVar21 + 0x25c) = fVar26 * fVar14 + fVar25 * fVar10 + fVar27 * fVar30 + fVar6;
        *(float *)(lVar21 + 0x260) = fVar26 * fVar15 + fVar25 * fVar11 + fVar27 * fVar22 + fVar7;
        *(float *)(lVar21 + 0x264) = fVar26 * fVar16 + fVar25 * fVar12 + fVar27 * fVar38 + fVar37;
        FUN_140203050(lVar21 + 0x268,local_138,param_1 + 0x18);
        lVar3 = *(longlong *)(lVar21 + 0x360);
        if (lVar3 != 0) {
          auVar24 = vcvtdq2ps_avx(ZEXT116(*(byte *)(lVar3 + 0x49c)));
          auVar31 = ZEXT1664(auVar24);
          auVar8 = vcvtdq2ps_avx(ZEXT216(*(ushort *)(lVar3 + 0x26c)));
          auVar29 = ZEXT1664(auVar8);
          auVar28 = ZEXT464((uint)((fVar35 / auVar24._0_4_) * auVar8._0_4_));
          fVar22 = (float)FUN_140128d90(*(undefined4 *)(lVar3 + 0x3dc));
          *(float *)(lVar3 + 0x468) =
               auVar29._0_4_ * (auVar36._0_4_ / auVar31._0_4_) +
               -(auVar28._0_4_ * SQRT(fVar22 / *(float *)(lVar3 + 0x470))) + auVar28._0_4_;
          fVar22 = fVar19;
          fVar30 = fVar18;
          if (*(char *)(lVar3 + 0x54c) == '\x03') {
            *(undefined1 *)(lVar3 + 0x54d) = 0;
          }
        }
        if (*(char *)(param_1 + 0x160) != '\x01') {
          auVar24 = auVar33._0_16_;
          if (*(longlong **)(lVar21 + 0x3a0) != (longlong *)0x0) {
            auVar28._0_8_ = (**(code **)(**(longlong **)(lVar21 + 0x3a0) + 0xa8))();
            auVar28._8_56_ = extraout_var;
            auVar24 = auVar28._0_16_;
          }
          auVar28 = ZEXT1664(auVar24);
          *(float *)(lVar21 + 0x25c) = auVar24._0_4_ + *(float *)(lVar21 + 0x25c);
          if (((((param_2 != '\0') && (*(longlong *)(lVar21 + 0x368) != 0)) &&
               (*(longlong *)(lVar21 + 0x1a0) != 0)) &&
              ((lVar3 = *(longlong *)(*(longlong *)(lVar21 + 0x1a0) + 8), lVar3 != 0 &&
               (plVar4 = *(longlong **)(lVar3 + 0x10), plVar4 != (longlong *)0x0)))) &&
             ((lVar3 = *plVar4, lVar3 != 0 && ((*(byte *)(lVar3 + 0x16) & 2) != 0)))) {
            fVar23 = (float)FUN_140079410(*(undefined8 *)(param_1 + 0x148),
                                          *(undefined4 *)(lVar21 + 600),
                                          *(undefined4 *)(lVar21 + 0x260));
            *(float *)(lVar21 + 0x25c) = fVar23 + auVar28._0_4_;
          }
        }
        auVar24 = auVar32._0_16_;
        if (((*(char *)((longlong)pfVar1 + 0x1d) != -1) && (*(char *)(param_1 + 0x160) == '\x02'))
           && (*(longlong *)(lVar21 + 0x378) != 0)) {
          FUN_14011a8c0();
          auVar24 = auVar32._0_16_;
        }
        if (((undefined8 *)plVar2[1] != (undefined8 *)0x0) && (**(char **)plVar2[1] == '\0')) {
          lVar3 = *(longlong *)(lVar21 + 0x360);
          *(undefined4 *)(lVar3 + 0x3d8) = *(undefined4 *)(lVar21 + 600);
          *(undefined4 *)(lVar3 + 0x3dc) = *(undefined4 *)(lVar21 + 0x25c);
          *(undefined4 *)(lVar3 + 0x3e0) = *(undefined4 *)(lVar21 + 0x260);
          *(undefined4 *)(lVar3 + 0x3e4) = *(undefined4 *)(lVar21 + 0x264);
          *(undefined4 *)(lVar3 + 1000) = *(undefined4 *)(lVar21 + 0x268);
          *(undefined4 *)(lVar3 + 0x3ec) = *(undefined4 *)(lVar21 + 0x26c);
          *(undefined4 *)(lVar3 + 0x3f0) = *(undefined4 *)(lVar21 + 0x270);
          *(undefined4 *)(lVar3 + 0x3f4) = *(undefined4 *)(lVar21 + 0x274);
        }
        lVar3 = *(longlong *)(lVar21 + 0x1b8);
        if (lVar3 != 0) {
          *(undefined4 *)(lVar3 + 0x15f0) = *(undefined4 *)(lVar21 + 0x268);
          *(undefined4 *)(lVar3 + 0x15f4) = *(undefined4 *)(lVar21 + 0x26c);
          *(undefined4 *)(lVar3 + 0x15f8) = *(undefined4 *)(lVar21 + 0x270);
          *(undefined4 *)(lVar3 + 0x15fc) = *(undefined4 *)(lVar21 + 0x274);
        }
        if (param_2 == '\0') {
          if ((*(char *)(*plVar2 + 0x75) == '\x03') || (*(char *)(*plVar2 + 0x75) == '\x05')) {
            fVar23 = auVar24._0_4_ - *(float *)(lVar21 + 600);
            auVar8 = vshufps_avx(auVar24,auVar24,0xaa);
            fVar25 = auVar8._0_4_ - *(float *)(lVar21 + 0x260);
            auVar8 = vshufps_avx(auVar24,auVar24,0x55);
            fVar26 = auVar8._0_4_ - *(float *)(lVar21 + 0x25c);
            auVar24 = vshufps_avx(auVar24,auVar24,0xff);
            fVar27 = auVar24._0_4_ - *(float *)(lVar21 + 0x264);
            fVar23 = SQRT(fVar27 * fVar27 + fVar25 * fVar25 + fVar26 * fVar26 + fVar23 * fVar23);
          }
          else {
            fVar23 = auVar33._0_4_;
          }
          *(float *)(lVar21 + 0x1e4) = fVar23;
          plVar2 = *(longlong **)(lVar21 + 0x3a0);
          if (plVar2 != (longlong *)0x0) {
            (**(code **)(*plVar2 + 0x198))
                      (plVar2,*(undefined8 *)(lVar21 + 0x198),lVar21 + 600,lVar21 + 0x268,0);
          }
        }
      }
LAB_1401343bf:
      local_174 = local_174 + 1;
      local_res18 = local_res18 + 0x100;
      local_140 = local_140 + 0x520;
    } while (local_174 < *(int *)(param_1 + 0x118));
  }
  if (param_2 != '\0') {
    *(uint *)(param_1 + 0x120) = *(uint *)(param_1 + 0x120) & 0xfffffff7 | 3;
  }
  return;
}

