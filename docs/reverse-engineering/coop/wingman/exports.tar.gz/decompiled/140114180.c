/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140114180; RVA 0x114180
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140114180(longlong param_1,undefined8 *param_2,longlong *param_3,longlong param_4,
                  undefined1 param_5,undefined8 param_6,longlong param_7,longlong *param_8)

{
  byte bVar1;
  char cVar2;
  undefined1 uVar3;
  ushort uVar4;
  char *pcVar5;
  undefined8 *puVar6;
  byte *pbVar7;
  int iVar8;
  uint uVar9;
  undefined8 uVar10;
  longlong lVar11;
  ulonglong uVar12;
  longlong lVar13;
  undefined **ppuVar14;
  int iVar15;
  longlong *plVar16;
  longlong *plVar17;
  char *pcVar18;
  undefined8 local_48;
  undefined8 uStack_40;
  undefined1 local_38 [16];
  
  pcVar5 = (char *)**(undefined8 **)(param_1 + 0x1a0);
  bVar1 = pcVar5[0x74];
  if (bVar1 == 0) {
    if ((pcVar5[0x73] & 0x10U) == 0) {
      if (*(short *)(pcVar5 + 0x5e) == -1) {
        plVar16 = (longlong *)0x0;
        plVar17 = param_8;
      }
      else {
        uVar10 = *(undefined8 *)
                  (*(longlong *)(*param_3 + 0x168) + (longlong)*(short *)(pcVar5 + 0x5e) * 8);
        *param_8 = (longlong)&PTR_FUN_1402ab6b0;
        param_8[0x23] = (longlong)&PTR_FUN_1402ab8b0;
        *(undefined4 *)(param_8 + 0x28) = 0;
        param_8[0x2a] = (longlong)&PTR_FUN_1402ab8a0;
        param_8[0x2b] = 0;
        FUN_14014d2a0(param_8,uVar10);
        (**(code **)(*param_8 + 0x10))(param_8,param_8 + 0x3e);
        iVar15 = (**(code **)(*param_8 + 8))(param_8);
        plVar17 = (longlong *)((longlong)iVar15 + (longlong)(param_8 + 0x3e));
        plVar16 = param_8;
      }
      *(longlong **)(param_1 + 0x390) = plVar16;
      if (*(short *)(pcVar5 + 0x60) == -1) {
        plVar16 = (longlong *)0x0;
        param_8 = plVar17;
      }
      else {
        uVar10 = *(undefined8 *)
                  (*(longlong *)(*param_3 + 0x168) + (longlong)*(short *)(pcVar5 + 0x60) * 8);
        *plVar17 = (longlong)&PTR_FUN_1402ab6b0;
        plVar17[0x23] = (longlong)&PTR_FUN_1402ab8b0;
        *(undefined4 *)(plVar17 + 0x28) = 0;
        plVar17[0x2a] = (longlong)&PTR_FUN_1402ab8a0;
        plVar17[0x2b] = 0;
        FUN_14014d2a0(plVar17,uVar10);
        (**(code **)(*plVar17 + 0x10))(plVar17,plVar17 + 0x3e);
        iVar15 = (**(code **)(*plVar17 + 8))(plVar17);
        param_8 = (longlong *)((longlong)iVar15 + (longlong)(plVar17 + 0x3e));
        plVar16 = plVar17;
      }
      *(longlong **)(param_1 + 0x398) = plVar16;
      if (param_4 != 0) {
        uVar10 = FUN_14000ec70(param_8,param_6,param_1,param_4,*(undefined1 *)(param_1 + 0x235),
                               param_5);
        *(undefined8 *)(param_1 + 0x3c8) = uVar10;
        param_8 = param_8 + 0xa6;
      }
    }
    else {
      if (*(short *)(pcVar5 + 0x62) != -1) {
        lVar11 = *(longlong *)
                  (*(longlong *)(param_3[1] + 0x168) + (longlong)*(short *)(pcVar5 + 0x62) * 8);
        *(longlong *)(param_1 + 0x2f0) = lVar11;
        *(longlong *)(param_1 + 0x2f8) = lVar11;
        *(longlong *)(param_1 + 0x300) = lVar11 + 0x20;
      }
      if (*(short *)(pcVar5 + 100) != -1) {
        FUN_1402038c0(param_1 + 0x2a8,
                      *(undefined8 *)
                       (*(longlong *)(param_3[2] + 0x168) + (longlong)*(short *)(pcVar5 + 100) * 8))
        ;
        if (*(undefined2 **)(param_1 + 0x2b8) != (undefined2 *)0x0) {
          **(undefined2 **)(param_1 + 0x2b8) = 0x2400;
          if (*(undefined2 **)(param_1 + 0x2c0) != (undefined2 *)0x0) {
            **(undefined2 **)(param_1 + 0x2c0) = 0x3e00;
          }
          FUN_140203a40(param_1 + 0x2a8);
        }
      }
      if ((*(short *)(pcVar5 + 0x66) != -1) && (*(short *)(pcVar5 + 0x68) != -1)) {
        uVar10 = FUN_14017e000(param_8,*(undefined8 *)
                                        (*(longlong *)(param_3[3] + 0x168) +
                                        (longlong)*(short *)(pcVar5 + 0x68) * 8),
                               *(undefined8 *)
                                (*(longlong *)(param_3[3] + 0x168) +
                                (longlong)*(short *)(pcVar5 + 0x66) * 8),0,0);
        *(undefined8 *)(param_1 + 0x380) = uVar10;
        param_8 = param_8 + 0x3e;
      }
      lVar11 = *(longlong *)(param_1 + 0x2f8);
      iVar15 = 0;
      if (0 < *(int *)(lVar11 + 0xc)) {
        do {
          if ((iVar15 < 0) || (*(int *)(lVar11 + 0xc) <= iVar15)) {
LAB_14011431d:
            pcVar18 = (char *)0x0;
          }
          else {
            iVar8 = 0;
            pcVar18 = (char *)((ulonglong)*(uint *)(lVar11 + 0x10) + *(longlong *)(param_1 + 0x2f0))
            ;
            if (0 < iVar15) {
              do {
                if (*pcVar18 == '\0') {
                  iVar8 = iVar8 + 1;
                }
                else if (*pcVar18 < ' ') goto LAB_14011431d;
                pcVar18 = pcVar18 + 1;
              } while (iVar8 < iVar15);
            }
          }
          FUN_14017e5c0(*(undefined8 *)(param_1 + 0x380),iVar15,pcVar18);
          lVar11 = *(longlong *)(param_1 + 0x2f8);
          iVar15 = iVar15 + 1;
        } while (iVar15 < *(int *)(lVar11 + 0xc));
      }
      *(uint *)(param_1 + 0x1f0) = *(uint *)(param_1 + 0x1f0) | 0x4000000;
    }
  }
  else if (bVar1 == 2) {
    if (param_4 != 0) {
      if (*(short *)(pcVar5 + 0x62) != -1) {
        lVar11 = *(longlong *)
                  (*(longlong *)(*(longlong *)(param_4 + 8) + 0x168) +
                  (longlong)*(short *)(pcVar5 + 0x62) * 8);
        *(longlong *)(param_1 + 0x2f0) = lVar11;
        *(longlong *)(param_1 + 0x2f8) = lVar11;
        *(longlong *)(param_1 + 0x300) = lVar11 + 0x20;
      }
      if (*(short *)(pcVar5 + 100) != -1) {
        FUN_1401139f0(param_1 + 0x2a8,
                      *(undefined8 *)
                       (*(longlong *)(*(longlong *)(param_4 + 0x10) + 0x168) +
                       (longlong)*(short *)(pcVar5 + 100) * 8));
      }
      *(undefined8 *)(param_1 + 0x380) = 0;
      uVar10 = FUN_14000ec70(param_8,param_6,param_1,param_4,*(undefined1 *)(param_1 + 0x235),
                             param_5);
      param_8 = param_8 + 0xa6;
      *(undefined8 *)(param_1 + 0x3c8) = uVar10;
      *(uint *)(param_1 + 0x1f0) = *(uint *)(param_1 + 0x1f0) | 0x4000000;
    }
  }
  else if ((bVar1 == 3) && (param_4 != 0)) {
    uVar10 = FUN_14000ec70(param_8,param_6,param_1,param_4,*(undefined1 *)(param_1 + 0x235),param_5)
    ;
    *(undefined8 *)(param_1 + 0x3c8) = uVar10;
    param_8 = param_8 + 0xa6;
  }
  pcVar18 = pcVar5;
  do {
    cVar2 = *pcVar18;
    pcVar18[(param_1 - (longlong)pcVar5) + 0x414] = cVar2;
    pcVar18 = pcVar18 + 1;
  } while (cVar2 != '\0');
  bVar1 = pcVar5[0x75];
  if (bVar1 < 7) {
    pcVar18 = IMAGE_DOS_HEADER_140000000.e_magic +
              (&switchD_14011460c::switchdataD_140114be0)[bVar1];
    switch(bVar1) {
    case 0:
    case 1:
      *(undefined1 *)(param_1 + 0x42b) = 1;
      break;
    default:
      *(undefined1 *)(param_1 + 0x42b) = 2;
    }
  }
  else {
    *(undefined1 *)(param_1 + 0x42b) = 0;
  }
  puVar6 = (undefined8 *)(*(longlong **)(param_1 + 0x1a0))[1];
  uVar4 = *(ushort *)(**(longlong **)(param_1 + 0x1a0) + 0x6c);
  uVar12 = (ulonglong)uVar4;
  *(ushort *)(param_1 + 0x22e) = uVar4;
  uVar9 = FUN_140119f70(pcVar18,uVar12);
  plVar17 = param_8;
  if (uVar9 == 0xffffffff) {
    if ((puVar6 != (undefined8 *)0x0) && ((byte *)*puVar6 != (byte *)0x0)) {
      uVar9 = (uint)*(byte *)*puVar6;
      goto LAB_140114668;
    }
  }
  else {
LAB_140114668:
    plVar16 = (longlong *)0x0;
    if (uVar9 == 0) {
      plVar16 = (longlong *)FUN_1400aaab0(param_8);
      *(longlong **)(param_1 + 0x360) = plVar16;
      plVar17 = param_8 + 200;
      FUN_140128fe0(plVar16 + 0x4b,puVar6[1]);
      param_8 = plVar16;
LAB_140114818:
      plVar16 = param_8;
      if (param_8 != (longlong *)0x0) {
        uVar3 = *(undefined1 *)(param_1 + 0x234);
        *(undefined1 *)((longlong)param_8 + 0x235) = *(undefined1 *)(param_1 + 0x235);
        *(undefined1 *)((longlong)param_8 + 0x234) = uVar3;
        uVar3 = *(undefined1 *)(param_1 + 0x24a);
        *(undefined1 *)((longlong)param_8 + 0x24a) = uVar3;
        if (param_8[1] != 0) {
          *(undefined1 *)(param_8[1] + 0xb3) = uVar3;
        }
        if (param_8[2] != 0) {
          *(undefined1 *)(param_8[2] + 0xb3) = uVar3;
        }
        lVar11 = *(longlong *)(param_1 + 400);
        param_8[0x32] = lVar11;
        if (param_8[1] != 0) {
          *(longlong *)(param_8[1] + 0x80) = lVar11;
        }
        if (param_8[2] != 0) {
          *(longlong *)(param_8[2] + 0x80) = lVar11;
        }
      }
    }
    else {
      if (uVar9 == 1) {
        FUN_1400aa570(param_8);
        param_8[0x5a] = 0;
        *param_8 = (longlong)&PTR_FUN_1402ac9f0;
        param_8[0x4b] = 0;
        param_8[0x4c] = 0;
        param_8[0x4d] = 0;
        param_8[0x4e] = 0;
        param_8[0x4f] = 0;
        param_8[0x50] = 0;
        param_8[0x51] = 0;
        param_8[0x52] = 0;
        param_8[0x53] = 0;
        param_8[0x54] = 0;
        param_8[0x55] = 0;
        param_8[0x56] = 0;
        param_8[0x57] = 0;
        param_8[0x58] = 0;
        param_8[0x5b] = 0;
        FUN_14011dd30(param_8);
        *(longlong **)(param_1 + 0x368) = param_8;
        local_38 = ZEXT816(0);
        plVar17 = param_8 + 0x5e;
        local_48 = 0;
        uStack_40 = 0;
        (**(code **)(*param_8 + 8))(0,local_38,&local_48);
        goto LAB_140114818;
      }
      if (uVar9 == 2) {
        FUN_1400aa570(param_8);
        param_8[0x51] = 0;
        *param_8 = (longlong)&PTR_FUN_1402ac880;
        param_8[0x4b] = 0;
        param_8[0x4c] = 0;
        param_8[0x4d] = 0;
        param_8[0x4e] = 0;
        param_8[0x4f] = 0;
        param_8[0x50] = 0;
        *(longlong **)(param_1 + 0x370) = param_8;
        plVar17 = param_8 + 0x54;
        goto LAB_140114818;
      }
      if (((uVar9 == 3) && (puVar6 != (undefined8 *)0x0)) &&
         ((undefined1 *)*puVar6 != (undefined1 *)0x0)) {
        *(undefined1 *)*puVar6 = 3;
        plVar17 = (longlong *)FUN_14011a180(param_1,uVar12 & 0xffff,param_8);
        if (*(longlong *)(param_1 + 0x378) != 0) {
          *(undefined1 *)(*(longlong *)(param_1 + 0x378) + 0x234) = *(undefined1 *)(param_1 + 0x234)
          ;
          *(undefined1 *)(*(longlong *)(param_1 + 0x378) + 0x235) = *(undefined1 *)(param_1 + 0x235)
          ;
          *(undefined8 *)(*(longlong *)(param_1 + 0x378) + 0x1a0) = *(undefined8 *)(param_1 + 0x1a0)
          ;
        }
        if ((*(longlong *)(param_1 + 0x360) != 0) && (lVar11 = puVar6[1], lVar11 != 0)) {
          FUN_140149270(lVar11,lVar11);
        }
      }
    }
    *(longlong **)(param_1 + 0x358) = plVar16;
  }
  if (param_2 != (undefined8 *)0x0) {
    lVar11 = FUN_140113950(plVar17);
    *(longlong *)(param_1 + 8) = lVar11;
    pbVar7 = (byte *)*param_2;
    iVar15 = 0;
    *(longlong **)(lVar11 + 0x68) = plVar17 + 0x18;
    if (*pbVar7 != 0) {
      lVar13 = 0;
      do {
        iVar15 = iVar15 + 1;
        *(undefined1 *)(lVar13 + *(longlong *)(lVar11 + 0x68)) = 0;
        lVar13 = lVar13 + 1;
      } while (iVar15 < (int)(uint)*pbVar7);
    }
    *(undefined8 **)(lVar11 + 0x60) = param_2;
    uVar12 = 0;
    if ((byte *)*param_2 != (byte *)0x0) {
      uVar12 = (ulonglong)*(byte *)*param_2 + 0xf & 0xfffffffffffffff0;
    }
    plVar17 = (longlong *)((longlong)(plVar17 + 0x18) + uVar12);
  }
  plVar16 = (longlong *)(param_1 + 0x1a8);
  if (*(longlong *)(*plVar16 + 8) != 0) {
    lVar13 = FUN_140113950(plVar17);
    lVar11 = *plVar16;
    *(longlong *)(param_1 + 0x10) = lVar13;
    puVar6 = *(undefined8 **)(lVar11 + 8);
    if (puVar6 != (undefined8 *)0x0) {
      pbVar7 = (byte *)*puVar6;
      iVar15 = 0;
      *(longlong **)(lVar13 + 0x68) = plVar17 + 0x18;
      if (*pbVar7 != 0) {
        lVar11 = 0;
        do {
          iVar15 = iVar15 + 1;
          *(undefined1 *)(lVar11 + *(longlong *)(lVar13 + 0x68)) = 0;
          lVar11 = lVar11 + 1;
        } while (iVar15 < (int)(uint)*pbVar7);
        plVar16 = (longlong *)(param_1 + 0x1a8);
      }
    }
    *(undefined8 **)(lVar13 + 0x60) = puVar6;
    uVar12 = 0;
    if ((*(undefined8 **)(*plVar16 + 8) != (undefined8 *)0x0) &&
       (pbVar7 = (byte *)**(undefined8 **)(*plVar16 + 8), pbVar7 != (byte *)0x0)) {
      uVar12 = (ulonglong)*pbVar7 + 0xf & 0xfffffffffffffff0;
    }
    plVar17 = (longlong *)((longlong)(plVar17 + 0x18) + uVar12);
  }
  if ((*(longlong **)(param_1 + 0x1a0) == (longlong *)0x0) ||
     (lVar11 = **(longlong **)(param_1 + 0x1a0), lVar11 == 0)) goto LAB_140114b6e;
  cVar2 = *(char *)(lVar11 + 0x79);
  switch(cVar2) {
  case '\x01':
  case '\x02':
  case '\x03':
  case '\x04':
  case '\x05':
    ppuVar14 = &PTR_FUN_1402aca20;
    break;
  case '\x06':
  case '\a':
  case '\b':
  case '\t':
  case '\n':
  case '\v':
  case '\f':
  case '\r':
  case '\x0e':
  case '\x0f':
  case '\x10':
  case '\x11':
  case '\x12':
  case '\x13':
  case '\x14':
  case '\x15':
  case '\x16':
  case '\x17':
  case '\x18':
  case '\x19':
  case '\x1a':
  case '\x1b':
  case '\x1c':
  case '\x1d':
  case '\x1e':
    ppuVar14 = &PTR_FUN_1402ac7b8;
    break;
  default:
    goto switchD_140114a6d_default;
  }
  *(undefined8 *)((longlong)plVar17 + 0x4c) = 0;
  *(undefined8 *)((longlong)plVar17 + 0x54) = 0;
  *(undefined8 *)((longlong)plVar17 + 0x5c) = 0;
  *(undefined8 *)((longlong)plVar17 + 100) = 0;
  plVar17[5] = 0;
  plVar17[6] = 0;
  *(undefined4 *)(plVar17 + 7) = 0;
  *(undefined4 *)((longlong)plVar17 + 0x3c) = 0xe0f;
  *(undefined4 *)(plVar17 + 8) = 0x3000103;
  *(undefined1 *)((longlong)plVar17 + 0x44) = 1;
  plVar17[1] = 0;
  plVar17[2] = 0;
  plVar17[3] = 0;
  *(undefined4 *)(plVar17 + 4) = 0;
  *(undefined1 *)((longlong)plVar17 + 0x99) = 0;
  *(undefined4 *)(plVar17 + 0x12) = 0xffffffff;
  *(undefined4 *)((longlong)plVar17 + 0x94) = 0x50004;
  *plVar17 = (longlong)ppuVar14;
  *(longlong **)(param_1 + 0x340) = plVar17;
switchD_140114a6d_default:
  if (*(longlong *)(param_1 + 0x340) != 0) {
    if (cVar2 != '\x01') {
      if (cVar2 == '\x02') {
        param_7 = param_7 + 0x18;
      }
      else if (cVar2 == '\x03') {
        param_7 = param_7 + 0x30;
      }
      else if (cVar2 == '\x04') {
        param_7 = param_7 + 0x48;
      }
      else {
        if (cVar2 != '\x05') goto LAB_140114b6e;
        param_7 = param_7 + 0x60;
      }
    }
    *(longlong *)(*(longlong *)(param_1 + 0x340) + 0x28) = param_7;
  }
LAB_140114b6e:
  bVar1 = pcVar5[0x7b];
  if (bVar1 == 1) {
    *(uint *)(param_1 + 0x1f0) = *(uint *)(param_1 + 0x1f0) | 0x10000000;
    *(undefined4 *)(param_1 + 0x208) = *(undefined4 *)(pcVar5 + 0x4c);
    return;
  }
  if (bVar1 == 2) {
    *(uint *)(param_1 + 0x1f0) = *(uint *)(param_1 + 0x1f0) | 0x20000000;
    *(undefined4 *)(param_1 + 0x208) = *(undefined4 *)(pcVar5 + 0x4c);
    return;
  }
  if (bVar1 == 3) {
    *(uint *)(param_1 + 0x1f0) = *(uint *)(param_1 + 0x1f0) | 0x8000000;
  }
  return;
}

