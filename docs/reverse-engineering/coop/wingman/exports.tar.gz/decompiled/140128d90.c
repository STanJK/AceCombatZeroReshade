/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140128d90; RVA 0x128d90
 * Ghidra-generated research pseudocode, inferred types, not original source. */

float FUN_140128d90(void)

{
  undefined1 auVar1 [16];
  float fVar2;
  undefined1 in_ZMM0 [64];
  
  auVar1 = vmaxss_avx(in_ZMM0._0_16_,ZEXT816(0));
  fVar2 = auVar1._0_4_;
  if (DAT_1402d2b58 <= fVar2) {
    if (DAT_1402d2b80 <= fVar2) {
      fVar2 = (fVar2 - DAT_1402d2b80) * DAT_1402d2504 + DAT_1402d2ae4;
    }
    else {
      fVar2 = fVar2 + DAT_1402d2ec8;
    }
  }
  else {
    fVar2 = fVar2 * DAT_1402d1ef4;
  }
  fVar2 = (float)FUN_140274420(DAT_1402d23c0,fVar2 * DAT_1402d2c68);
  return fVar2 * DAT_1402d2014;
}

