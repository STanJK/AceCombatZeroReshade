/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140167c90; RVA 0x167c90
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140167c90(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (longlong)DAT_14030cab4;
  DAT_14030c8cc = 0;
  *(undefined4 *)(param_1 + 8) = 2;
  (&DAT_140328458)[lVar1] = FUN_140178fc0;
  return;
}

