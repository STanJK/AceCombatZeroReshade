/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f5800; RVA 0xf5800
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400f5800(longlong param_1)

{
  byte *pbVar1;
  uint *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  bool bVar5;
  char cVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong lVar9;
  int iVar10;
  uint uVar11;
  longlong lVar12;
  int iVar13;
  
  puVar3 = *(undefined8 **)(param_1 + 0x2d8);
  pbVar1 = (byte *)(param_1 + 0x3c9);
  bVar5 = false;
  if (((puVar3 == (undefined8 *)0x0) || (*(byte *)*puVar3 <= *pbVar1)) ||
     (puVar3 = (undefined8 *)(puVar3[1] + (ulonglong)*pbVar1 * 0x48), puVar3 == (undefined8 *)0x0))
  {
    cVar6 = -1;
  }
  else {
    cVar6 = *(char *)*puVar3;
  }
  uVar11 = *(uint *)(param_1 + 0x3a8);
  if ((uVar11 & 2) != 0) {
    if ((cVar6 == '\x05') || (cVar6 == '\x06')) {
      plVar8 = *(longlong **)(param_1 + 0x2f8);
      iVar13 = 1;
      if (1 < *(byte *)((longlong)plVar8 + 0x34)) {
        lVar12 = 8;
        do {
          lVar4 = *plVar8;
          iVar10 = 0;
          lVar7 = *(longlong *)(lVar12 + lVar4);
          if (0 < *(int *)(lVar7 + 0x118)) {
            lVar9 = 0;
            do {
              lVar9 = lVar9 + 0x520;
              iVar10 = iVar10 + 1;
              puVar2 = (uint *)(*(longlong *)(lVar7 + 0x110) + -0x330 + lVar9);
              *puVar2 = *puVar2 & 0xfffffffc;
              lVar7 = *(longlong *)(lVar12 + lVar4);
            } while (iVar10 < *(int *)(lVar7 + 0x118));
          }
          plVar8 = *(longlong **)(param_1 + 0x2f8);
          iVar13 = iVar13 + 1;
          lVar12 = lVar12 + 8;
        } while (iVar13 < (int)(uint)*(byte *)((longlong)plVar8 + 0x34));
        uVar11 = *(uint *)(param_1 + 0x3a8);
      }
    }
    bVar5 = false;
    if ((int)(uint)*pbVar1 < (int)(*(byte *)**(undefined8 **)(param_1 + 0x2d8) - 1)) {
      *(undefined1 *)(param_1 + 0x3cc) = 0;
      *pbVar1 = *pbVar1 + 1;
      *(undefined4 *)(param_1 + 0x378) = 0;
    }
    else if (*(char *)(param_1 + 0x3d2) == '\0') {
      *(uint *)(param_1 + 0x3a8) = uVar11 | 1;
      bVar5 = true;
    }
    else {
      *(undefined8 *)(param_1 + 0x2d8) = *(undefined8 *)(param_1 + 0x2e0);
      *pbVar1 = *(byte *)(param_1 + 0x3ca);
      *(undefined1 *)(param_1 + 0x3cc) = *(undefined1 *)(param_1 + 0x3cd);
      *(undefined1 *)(param_1 + 0x3d2) = 0;
      lVar12 = *(longlong *)
                (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
      *(byte *)(lVar12 + 0x1863) = *(byte *)(lVar12 + 0x1863) & 0xfe;
      *(undefined4 *)(lVar12 + 0x185c) = 0;
      *(undefined8 *)(lVar12 + 0x1d78) = 0;
      *(byte *)(lVar12 + 0x1da7) = *(byte *)(lVar12 + 0x1da7) & 0xfe;
      *(uint *)(lVar12 + 0x2058) = *(uint *)(lVar12 + 0x2058) & 0xffffffdf;
    }
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xfffffffd;
    if ((*(byte *)(param_1 + 0x3a8) & 1) == 0) {
      FUN_1400f5a10(param_1);
    }
  }
  if (*(char *)(param_1 + 0x3d2) == '\0') {
    *(byte *)(param_1 + 0x3ca) = *pbVar1;
    *(undefined1 *)(param_1 + 0x3cd) = *(undefined1 *)(param_1 + 0x3cc);
  }
  else {
    *(byte *)(param_1 + 0x3cb) = *pbVar1;
    *(undefined1 *)(param_1 + 0x3ce) = *(undefined1 *)(param_1 + 0x3cc);
  }
  if (bVar5) {
    if (*(char *)(param_1 + 0x3d2) == '\0') {
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 1;
      return;
    }
    *(undefined1 *)(param_1 + 0x3d2) = 0;
  }
  return;
}

