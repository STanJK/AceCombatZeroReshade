/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401013c0; RVA 0x1013c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1401013c0(longlong param_1,longlong *param_2)

{
  undefined1 auVar1 [16];
  char cVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 (*pauVar8) [16];
  float *pfVar9;
  undefined8 uVar10;
  byte bVar11;
  longlong lVar12;
  byte bVar13;
  float fVar14;
  float fVar15;
  uint uVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  undefined1 auVar20 [64];
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  undefined1 local_a8 [16];
  undefined1 local_98 [144];
  
  if (*(longlong *)(param_1 + 0x308) == 0) {
    return;
  }
  if (*(longlong **)(param_1 + 0x2f8) == (longlong *)0x0) {
    return;
  }
  if (param_2 == (longlong *)0x0) {
    return;
  }
  plVar3 = (longlong *)**(longlong **)(param_1 + 0x2f8);
  lVar4 = *(longlong *)(*plVar3 + 0x110);
  if (lVar4 == 0) {
    return;
  }
  lVar12 = *param_2;
  if (lVar12 == 0) {
    return;
  }
  lVar5 = *(longlong *)(lVar4 + 0x1b8);
  if (lVar5 == 0) {
    return;
  }
  lVar12 = *(longlong *)(plVar3[*(byte *)(lVar12 + 0x20)] + 0x110) +
           (ulonglong)*(byte *)(lVar12 + 0x21) * 0x520;
  if (lVar12 == 0) {
    return;
  }
  cVar2 = *(char *)(param_1 + 0x3cc);
  if (cVar2 == '\x01') {
    if (*(int *)(param_1 + 0x378) != 0) {
      return;
    }
    uVar10 = 0x1209;
LAB_1401019aa:
    FUN_1401a61a0(*(longlong *)(param_1 + 0x308),uVar10,0,0,0);
    return;
  }
  if (cVar2 != '\x02') {
    if (cVar2 == '\x03') {
      if (*(int *)(param_1 + 0x378) != 0) {
        return;
      }
      cVar2 = *(char *)(param_1 + 0x3e9);
      if (cVar2 == '\0') {
        uVar10 = 0x1210;
      }
      else if (cVar2 == '\x01') {
        uVar10 = 0x1211;
      }
      else if (cVar2 == '\x02') {
        uVar10 = 0x1212;
      }
      else if (cVar2 == '\x03') {
        uVar10 = 0x1213;
      }
      else {
        uVar10 = 0x1214;
      }
    }
    else {
      if (cVar2 != '\x04') {
        return;
      }
      if (*(int *)(param_1 + 0x378) != 0) {
        return;
      }
      if ((*(byte *)(lVar4 + 0x1f0) & 2) == 0) {
        return;
      }
      uVar10 = 0x1217;
    }
    goto LAB_1401019aa;
  }
  if (0 < *(int *)(param_1 + 0x390)) {
    *(int *)(param_1 + 0x390) = *(int *)(param_1 + 0x390) + -1;
  }
  fVar14 = (float)FUN_1400c35c0(lVar5 + 0x1430);
  auVar1 = *(undefined1 (*) [16])(lVar12 + 600);
  fVar19 = auVar1._0_4_ - *(float *)(lVar5 + 0x70);
  auVar6 = vcvtdq2ps_avx(ZEXT116(*(byte *)(param_1 + 0x3d1)));
  auVar7 = vshufps_avx(auVar1,auVar1,0xaa);
  fVar23 = auVar7._0_4_ - *(float *)(lVar5 + 0x78);
  auVar7 = vshufps_avx(auVar1,auVar1,0x55);
  fVar22 = auVar7._0_4_ - *(float *)(lVar5 + 0x74);
  auVar1 = vshufps_avx(auVar1,auVar1,0xff);
  fVar18 = auVar1._0_4_ - *(float *)(lVar5 + 0x7c);
  fVar18 = SQRT(fVar18 * fVar18 + fVar23 * fVar23 + fVar22 * fVar22 + fVar19 * fVar19);
  fVar24 = 0.0;
  if (fVar18 != 0.0) {
    fVar18 = DAT_1402d22d0 / fVar18;
    fVar19 = fVar19 * fVar18;
    fVar22 = fVar22 * fVar18;
    fVar23 = fVar23 * fVar18;
  }
  auVar20 = ZEXT464((uint)*(float *)(lVar5 + 0x84));
  fVar15 = (float)FUN_140275650(*(float *)(lVar5 + 0x84) + DAT_1402d2420);
  uVar16 = FUN_140272c30(auVar20._0_8_);
  fVar21 = (float)(uVar16 ^ DAT_1402d3770);
  auVar20 = ZEXT464(*(uint *)(lVar12 + 0x26c));
  fVar18 = (float)FUN_140275650(*(undefined4 *)(lVar12 + 0x268));
  fVar17 = (float)FUN_140275650(*(undefined4 *)(lVar5 + 0x80));
  fVar18 = fVar18 * fVar17;
  fVar17 = (float)FUN_140275650(auVar20._0_4_ + DAT_1402d2420);
  fVar18 = fVar15 * fVar17 + fVar18;
  uVar16 = FUN_140272c30(auVar20._0_8_);
  fVar18 = fVar21 * (float)(uVar16 ^ DAT_1402d3770) + fVar18;
  fVar21 = fVar15 * fVar19 + fVar23 * fVar21;
  pauVar8 = (undefined1 (*) [16])FUN_140101cc0(param_1,local_a8);
  pfVar9 = (float *)FUN_140101a80(param_1,local_98);
  auVar1 = *pauVar8;
  fVar19 = auVar1._0_4_ - *pfVar9;
  auVar7 = vshufps_avx(auVar1,auVar1,0xaa);
  fVar23 = auVar7._0_4_ - pfVar9[2];
  auVar7 = vshufps_avx(auVar1,auVar1,0x55);
  fVar15 = auVar7._0_4_ - pfVar9[1];
  auVar1 = vshufps_avx(auVar1,auVar1,0xff);
  fVar17 = auVar1._0_4_ - pfVar9[3];
  fVar19 = SQRT(fVar17 * fVar17 + fVar23 * fVar23 + fVar15 * fVar15 + fVar19 * fVar19);
  uVar16 = (uint)(fVar19 * DAT_1402d1dac);
  bVar13 = (byte)uVar16;
  if (*(byte *)(param_1 + 0x3d7) == 0) {
    bVar11 = (byte)(int)(fVar19 * DAT_1402d1f48);
    if ((fVar21 <= DAT_1402d2284) || (DAT_1402d20b8 <= (float)((uint)fVar22 & _DAT_1402d3760))) {
      if (*(int *)(param_1 + 0x390) == 0) {
        if ((*(ushort *)(lVar5 + 0x2090) & 0x40) == 0) {
          if ((char)*(ushort *)(lVar5 + 0x2090) < '\0') {
            uVar10 = 0x1221;
          }
          else if (fVar22 <= DAT_1402d20b8) {
            if (DAT_1402d2d00 <= fVar22) goto LAB_140101864;
            uVar10 = 0x121e;
          }
          else {
            uVar10 = 0x121d;
          }
        }
        else {
          uVar10 = 0x1222;
        }
        goto LAB_14010183d;
      }
    }
    else if (fVar24 < fVar18) {
      if (bVar11 < *(byte *)(param_1 + 0x3d8)) {
        if (bVar11 == 5) {
          uVar10 = 0x121c;
        }
        else if (bVar11 == 10) {
          uVar10 = 0x121b;
        }
        else {
          if (bVar11 != 0x32) goto LAB_140101791;
          uVar10 = 0x121a;
        }
        FUN_1401a61a0(*(undefined8 *)(param_1 + 0x308),uVar10,0,0,0);
      }
LAB_140101791:
      if ((*(int *)(param_1 + 0x390) == 0) && (bVar11 < 0x15)) {
        if (*(int *)(param_1 + 0x388) < 1) {
          fVar19 = -(fVar14 * auVar6._0_4_ * DAT_1402d21c8) + *(float *)(lVar5 + 0x1848);
          if (DAT_1402d2df4 <= fVar19) {
            if ((fVar19 <= DAT_1402d26d8) || (10 < bVar11)) goto LAB_140101864;
            uVar10 = 0x1220;
          }
          else {
            uVar10 = 0x121f;
          }
        }
        else {
          uVar10 = 0x120a;
        }
LAB_14010183d:
        FUN_1401a61a0(*(undefined8 *)(param_1 + 0x308),uVar10,0,0,0);
        *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1) * 5;
      }
    }
LAB_140101864:
    *(byte *)(param_1 + 0x3d8) = bVar11;
  }
  else if (DAT_1402d223c < fVar21) {
    if ((*(byte *)(param_1 + 0x3d7) <= bVar13) || (fVar18 <= fVar24)) {
      if (*(int *)(param_1 + 0x390) == 0) {
        if ((char)*(ushort *)(lVar5 + 0x2090) < '\0') {
          uVar10 = 0x1218;
        }
        else {
          if ((*(ushort *)(lVar5 + 0x2090) & 0x40) == 0) goto LAB_140101915;
          uVar10 = 0x1219;
        }
        FUN_1401a61a0(*(undefined8 *)(param_1 + 0x308),uVar10,0,0,0);
        *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1) * 10;
      }
    }
    else {
      uVar16 = uVar16 & 0xff;
      if (bVar13 == 0) {
        uVar10 = 0x120b;
      }
      else if (uVar16 == 1) {
        uVar10 = 0x120c;
      }
      else {
        if (uVar16 != 2) goto LAB_140101915;
        uVar10 = 0x120d;
      }
      FUN_1401a61a0(*(undefined8 *)(param_1 + 0x308),uVar10,0,0,0);
    }
  }
LAB_140101915:
  fVar19 = (float)FUN_1401019d0(param_1);
  if (fVar19 == DAT_1402d2690) {
    uVar10 = 0x120e;
  }
  else {
    fVar19 = (float)FUN_1401019d0(param_1);
    if (fVar19 != DAT_1402d2760) goto LAB_14010197d;
    uVar10 = 0x120f;
  }
  FUN_1401a61a0(*(undefined8 *)(param_1 + 0x308),uVar10,0,0,0);
LAB_14010197d:
  *(byte *)(param_1 + 0x3d7) = bVar13;
  return;
}

