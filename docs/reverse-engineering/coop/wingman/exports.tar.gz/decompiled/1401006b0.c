/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401006b0; RVA 0x1006b0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401006b0(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  uint *puVar2;
  byte bVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 *puVar8;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  int iVar11;
  float *pfVar12;
  char cVar13;
  int iVar14;
  longlong lVar15;
  longlong lVar16;
  float fVar17;
  undefined8 uVar18;
  float fVar19;
  float fVar20;
  undefined1 auVar21 [64];
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  undefined2 local_res8 [4];
  undefined2 local_res10 [4];
  undefined1 local_e8 [16];
  undefined1 local_d8 [8];
  float fStack_d0;
  undefined1 local_c8 [8];
  float fStack_c0;
  undefined1 local_b8 [8];
  float fStack_b0;
  undefined1 local_a8 [8];
  float fStack_a0;
  
  lVar16 = *param_2;
  _local_d8 = ZEXT816(0);
  _local_c8 = ZEXT816(0);
  lVar4 = *(longlong *)(*(longlong *)**(longlong **)(param_1 + 0x2f8) + 0x110);
  lVar5 = *(longlong *)(lVar4 + 0x1b8);
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x20;
  lVar16 = *(longlong *)
            (*(longlong *)
              (**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar16 + 0x20) * 8) + 0x110)
           + (ulonglong)*(byte *)(lVar16 + 0x21) * 0x520;
  *(undefined8 *)(lVar16 + 0x3a0) = *(undefined8 *)(lVar16 + 0x390);
  _local_b8 = _local_d8;
  _local_a8 = _local_c8;
  FUN_140202920(local_d8,lVar16 + 0x268);
  fVar19 = (float)local_a8._0_4_ + *(float *)(lVar16 + 600);
  fVar23 = fStack_a0 + *(float *)(lVar16 + 0x260);
  fVar26 = (float)local_a8._4_4_ + *(float *)(lVar16 + 0x25c);
  fVar24 = (float)*(byte *)(lVar5 + 0x1674);
  fVar22 = (float)*(ushort *)(lVar5 + 0x1444);
  auVar21 = ZEXT464((uint)((DAT_1402d2140 / fVar24) * fVar22));
  fVar17 = (float)FUN_140128d90(*(undefined4 *)(lVar5 + 0x15b4));
  fVar25 = *(float *)(lVar5 + 0x1640);
  fVar17 = fVar22 * (DAT_1402d235c / fVar24) +
           -(auVar21._0_4_ * SQRT(fVar17 / *(float *)(lVar5 + 0x1648))) + auVar21._0_4_;
  if (fVar25 <= fVar17 + DAT_1402d1f6c) {
    if (fVar25 < fVar17 - DAT_1402d1f6c) {
      fVar17 = fVar25 + DAT_1402d1f6c;
    }
  }
  else {
    fVar17 = fVar25 + DAT_1402d2cac;
  }
  *(float *)(lVar5 + 0x1640) = fVar17;
  plVar6 = *(longlong **)(lVar16 + 0x390);
  cVar13 = *(char *)(*(longlong *)(lVar5 + 0xff8) + 10);
  pfVar12 = (float *)(**(code **)(*plVar6 + 0x1b8))(plVar6,local_e8);
  fVar25 = *pfVar12;
  fVar17 = pfVar12[1];
  fVar22 = pfVar12[2];
  fVar24 = pfVar12[3];
  if (cVar13 == '\x01') {
    if ((*(int *)(param_1 + 0x378) < (int)((uint)*(byte *)(param_1 + 0x3d1) * 5)) ||
       ((int)((uint)*(byte *)(param_1 + 0x3d1) * 0xf) <= *(int *)(param_1 + 0x378))) {
      fVar22 = fVar22 + DAT_1402d250c;
    }
  }
  fVar20 = fVar23 * fVar24 + fVar22 * fStack_b0 + fVar25 * fStack_d0 + fVar17 * fStack_c0;
  fVar23 = fVar26 * fVar24 +
           fVar22 * (float)local_b8._4_4_ +
           fVar25 * (float)local_d8._4_4_ + fVar17 * (float)local_c8._4_4_;
  fVar25 = fVar19 * fVar24 +
           fVar22 * (float)local_b8._0_4_ +
           fVar25 * (float)local_d8._0_4_ + fVar17 * (float)local_c8._0_4_;
  if (((*(ushort *)(lVar5 + 0x1b8) < 0x51) || (*(ushort *)(lVar5 + 0x1bc) < 0x51)) ||
     (*(int *)(*(longlong *)(lVar5 + 0x1d0) + 0x40) == 0)) {
    fVar19 = 0.0;
    fVar26 = 0.0;
    fVar17 = 0.0;
  }
  else {
    lVar15 = (ulonglong)**(ushort **)(*(longlong *)(lVar5 + 0x1d8) + 0x80) * 800;
    lVar7 = *(longlong *)(lVar5 + 0x1b0);
    fVar19 = *(float *)(lVar15 + 0xc4 + lVar7);
    fVar26 = *(float *)(lVar15 + 200 + lVar7);
    fVar17 = *(float *)(lVar15 + 0xcc + lVar7);
  }
  _local_c8 = ZEXT816(0);
  _local_d8 = ZEXT816(0);
  _local_b8 = ZEXT816(0);
  _local_a8 = _local_c8;
  FUN_140202920(local_d8,lVar4 + 0x268);
  bVar3 = *(byte *)(param_1 + 0x3d1);
  iVar14 = *(int *)(param_1 + 0x378);
  fVar25 = fVar25 - (fVar17 * local_b8._0_4_ +
                     fVar26 * local_c8._0_4_ + fVar19 * (float)local_d8._0_4_ +
                    (float)local_a8._0_4_ + *(float *)(lVar4 + 600));
  auVar9 = vshufps_avx(_local_c8,_local_c8,0x55);
  auVar10 = vshufps_avx(_local_b8,_local_b8,0x55);
  fVar23 = fVar23 - (fVar17 * auVar10._0_4_ + fVar26 * auVar9._0_4_ + fVar19 * (float)local_d8._4_4_
                    + (float)local_a8._4_4_ + *(float *)(lVar4 + 0x25c));
  auVar9 = vshufps_avx(_local_b8,_local_b8,0xaa);
  auVar10 = vshufps_avx(_local_c8,_local_c8,0xaa);
  iVar11 = (uint)bVar3 * 5;
  fVar20 = fVar20 - (fVar17 * auVar9._0_4_ + fVar26 * auVar10._0_4_ + fVar19 * fStack_d0 +
                    fStack_a0 + *(float *)(lVar4 + 0x260));
  if (iVar14 < iVar11) {
    fVar19 = ((float)iVar14 / (float)iVar11) * ((float)iVar14 / (float)iVar11);
    *(float *)(lVar5 + 0x17f8) = fVar25 * fVar19 + *(float *)(lVar5 + 0x17f8);
    *(float *)(lVar5 + 0x17fc) = fVar23 * fVar19 + *(float *)(lVar5 + 0x17fc);
    *(float *)(lVar5 + 0x1800) = fVar20 * fVar19 + *(float *)(lVar5 + 0x1800);
    *(float *)(lVar5 + 0x1808) =
         fVar19 * (*(float *)(lVar16 + 0x268) - *(float *)(lVar4 + 0x268)) +
         *(float *)(lVar5 + 0x1808);
    *(float *)(lVar5 + 0x180c) =
         fVar19 * (*(float *)(lVar16 + 0x26c) - *(float *)(lVar4 + 0x26c)) +
         *(float *)(lVar5 + 0x180c);
    *(float *)(lVar5 + 0x1810) =
         fVar19 * (*(float *)(lVar16 + 0x270) - *(float *)(lVar4 + 0x270)) +
         *(float *)(lVar5 + 0x1810);
  }
  else if (iVar14 < (int)((uint)bVar3 * 10)) {
    if (cVar13 == '\x01') {
      fVar19 = (float)(int)(iVar14 + (uint)bVar3 * -5) / (float)iVar11;
      fVar19 = fVar19 * fVar19;
      *(float *)(lVar5 + 0x1800) = fVar19 * fVar20 + *(float *)(lVar5 + 0x1800);
      *(float *)(lVar5 + 0x17f8) = fVar19 * fVar25 + *(float *)(lVar5 + 0x17f8);
      *(float *)(lVar5 + 0x17fc) = fVar19 * fVar23 + *(float *)(lVar5 + 0x17fc);
      *(undefined4 *)(lVar5 + 0x1808) = *(undefined4 *)(lVar16 + 0x268);
      *(undefined4 *)(lVar5 + 0x180c) = *(undefined4 *)(lVar16 + 0x26c);
      *(undefined4 *)(lVar5 + 0x1810) = *(undefined4 *)(lVar16 + 0x270);
    }
    else {
      *(float *)(lVar5 + 0x17f8) = fVar25 + *(float *)(lVar5 + 0x17f8);
      *(float *)(lVar5 + 0x1800) = fVar20 + *(float *)(lVar5 + 0x1800);
      *(float *)(lVar5 + 0x17fc) = fVar23 + *(float *)(lVar5 + 0x17fc);
      *(undefined4 *)(lVar5 + 0x1808) = *(undefined4 *)(lVar16 + 0x268);
      *(undefined4 *)(lVar5 + 0x180c) = *(undefined4 *)(lVar16 + 0x26c);
      *(undefined4 *)(lVar5 + 0x1810) = *(undefined4 *)(lVar16 + 0x270);
      if (*(int *)(param_1 + 0x378) == (uint)*(byte *)(param_1 + 0x3d1) * 7) {
        (**(code **)(*plVar6 + 0x80))(plVar6);
        uVar18 = FUN_140019ef0();
        FUN_14001a7c0(uVar18,lVar16,4);
      }
    }
    if (*(int *)(param_1 + 0x378) == (uint)*(byte *)(param_1 + 0x3d1) * 9) {
      uVar18 = FUN_1401c56d0();
      cVar13 = *(char *)(lVar5 + 0x2094);
      if (cVar13 == '\0') {
        local_res8[0] = 0xdb;
      }
      else if (cVar13 == '\x02') {
        local_res8[0] = 0xdc;
      }
      else {
        if (cVar13 != '\x01') goto LAB_140100dbd;
        local_res8[0] = 0xdd;
      }
      local_res10[0] = 1;
      FUN_1401c6150(uVar18,local_res10,local_res8);
    }
  }
  else {
    if ((iVar14 < (int)((uint)bVar3 * 0xf)) || ((int)((uint)bVar3 * 0x14) <= iVar14)) {
      *(float *)(lVar5 + 0x17f8) = fVar25 + *(float *)(lVar5 + 0x17f8);
      *(float *)(lVar5 + 0x1800) = fVar20 + *(float *)(lVar5 + 0x1800);
      *(float *)(lVar5 + 0x17fc) = fVar23 + *(float *)(lVar5 + 0x17fc);
    }
    else {
      if (cVar13 != '\x01') {
        *(float *)(lVar5 + 0x17f8) = fVar25 + *(float *)(lVar5 + 0x17f8);
        *(float *)(lVar5 + 0x1800) = fVar20 + *(float *)(lVar5 + 0x1800);
        *(float *)(lVar5 + 0x17fc) = fVar23 + *(float *)(lVar5 + 0x17fc);
        *(undefined4 *)(lVar5 + 0x1808) = *(undefined4 *)(lVar16 + 0x268);
        *(undefined4 *)(lVar5 + 0x180c) = *(undefined4 *)(lVar16 + 0x26c);
        *(undefined4 *)(lVar5 + 0x1810) = *(undefined4 *)(lVar16 + 0x270);
        if (*(int *)(param_1 + 0x378) == (uint)*(byte *)(param_1 + 0x3d1) * 0x11) {
          (**(code **)(*plVar6 + 0x88))(plVar6);
          uVar18 = FUN_140019ef0();
          FUN_14001a7c0(uVar18,lVar16,5);
        }
        goto LAB_140100dbd;
      }
      fVar19 = (float)(int)(iVar14 + (uint)bVar3 * -0xf) / (float)iVar11;
      fVar19 = fVar19 * fVar19;
      *(float *)(lVar5 + 0x1800) = fVar19 * fVar20 + *(float *)(lVar5 + 0x1800);
      *(float *)(lVar5 + 0x17f8) = fVar19 * fVar25 + *(float *)(lVar5 + 0x17f8);
      *(float *)(lVar5 + 0x17fc) = fVar19 * fVar23 + *(float *)(lVar5 + 0x17fc);
    }
    *(undefined4 *)(lVar5 + 0x1808) = *(undefined4 *)(lVar16 + 0x268);
    *(undefined4 *)(lVar5 + 0x180c) = *(undefined4 *)(lVar16 + 0x26c);
    *(undefined4 *)(lVar5 + 0x1810) = *(undefined4 *)(lVar16 + 0x270);
  }
LAB_140100dbd:
  *(undefined4 *)(lVar4 + 600) = *(undefined4 *)(lVar5 + 0x17f8);
  *(undefined4 *)(lVar4 + 0x25c) = *(undefined4 *)(lVar5 + 0x17fc);
  *(undefined4 *)(lVar4 + 0x260) = *(undefined4 *)(lVar5 + 0x1800);
  *(undefined4 *)(lVar4 + 0x264) = *(undefined4 *)(lVar5 + 0x1804);
  *(undefined4 *)(lVar4 + 0x268) = *(undefined4 *)(lVar5 + 0x1808);
  *(undefined4 *)(lVar4 + 0x26c) = *(undefined4 *)(lVar5 + 0x180c);
  *(undefined4 *)(lVar4 + 0x270) = *(undefined4 *)(lVar5 + 0x1810);
  *(undefined4 *)(lVar4 + 0x274) = *(undefined4 *)(lVar5 + 0x1814);
  bVar3 = *(byte *)(param_1 + 0x3d1);
  iVar14 = *(int *)(param_1 + 0x378);
  if (iVar14 < (int)((uint)bVar3 * 0x16)) {
    if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
      iVar14 = iVar14 + 1;
      *(int *)(param_1 + 0x378) = iVar14;
    }
    if ((int)((uint)bVar3 * 0x15) <= iVar14) {
      *(float *)(param_1 + 0x3a0) = (float)iVar14 / (float)bVar3 - DAT_1402d2574;
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
    if (*(longlong *)(param_1 + 0x310) != 0) {
      puVar2 = (uint *)(*(longlong *)(param_1 + 0x310) + 0x56c);
      *puVar2 = *puVar2 & 0xfffffffd;
      lVar16 = *(longlong *)(param_1 + 0x310);
      *(undefined8 *)(lVar16 + 0x568) = 0;
      *(undefined4 *)(lVar16 + 0x40) = 0;
      *(undefined4 *)(lVar16 + 0x2a8) = 0;
      *(undefined2 *)(lVar16 + 0x2ac) = 0xffff;
      *(undefined4 *)(lVar16 + 0x2f8) = 0;
      *(undefined4 *)(lVar16 + 0x468) = 0;
    }
    lVar16 = *(longlong *)(param_1 + 0x318);
    if ((lVar16 != 0) && (puVar8 = *(undefined8 **)(param_1 + 0x2f8), puVar8 != (undefined8 *)0x0))
    {
      cVar13 = (char)*(int *)(*(longlong *)*puVar8 + 0x118) + -1;
      if (*(int *)(*(longlong *)*puVar8 + 0x118) < 1) {
        cVar13 = '\0';
      }
      *(char *)(lVar16 + 0x20) = cVar13;
      *(undefined1 *)(lVar16 + 0x22) = *(undefined1 *)(puVar8 + 0xd);
      *(byte *)(lVar16 + 0x21) = ~*(byte *)((longlong)puVar8 + 0x69) & 1;
      *(undefined8 *)(lVar16 + 0x18) = 0;
      *(undefined1 *)(lVar16 + 0x23) = 0;
    }
    if (*(longlong *)(param_1 + 800) != 0) {
      if ((*(longlong *)(param_1 + 0x308) != 0) && (*(longlong *)(param_1 + 0x2f8) != 0)) {
        FUN_1401a8b40();
      }
      lVar16 = *(longlong *)(param_1 + 800);
      *(byte *)(lVar16 + 0x2b) = *(byte *)(lVar16 + 0x2b) & 0xfd;
      if (*(longlong *)(lVar16 + 0x10) != 0) {
        puVar2 = (uint *)(*(longlong *)(lVar16 + 0x10) + 0x56c);
        *puVar2 = *puVar2 & 0xfffffffe;
      }
      if (*(longlong *)(lVar16 + 0x18) != 0) {
        pbVar1 = (byte *)(*(longlong *)(lVar16 + 0x18) + 0x23);
        *pbVar1 = *pbVar1 & 0xfb;
      }
      lVar16 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
      if (lVar16 != 0) {
        puVar2 = (uint *)(lVar16 + 0x40);
        *puVar2 = *puVar2 & 0xfbffffff;
      }
      lVar16 = *(longlong *)(param_1 + 800);
      *(undefined8 *)(lVar16 + 0x32) = 0;
      *(undefined2 *)(lVar16 + 0x3a) = 0;
      *(undefined1 *)(lVar16 + 0x3c) = 0;
    }
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a5f00();
    }
    if ((*(uint *)(param_1 + 0x3a8) >> 0xe & 1) == 0) {
      *(undefined1 *)(param_1 + 0x3cc) = 6;
      *(undefined1 *)(*(longlong *)(param_1 + 0x340) + 0xa8820) = 1;
    }
    else {
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffbfff | 2;
    }
  }
  if ((*(byte *)(lVar4 + 0x1f0) & 2) == 0) {
    *(byte *)(param_1 + 0x3dc) = *(byte *)(param_1 + 0x3dc) | 1;
    *(undefined1 *)(param_1 + 0x3cc) = 4;
    *(undefined4 *)(param_1 + 0x378) = 0;
    if (*(char *)(param_1 + 0x3e6) != '\x05') {
      *(undefined1 *)(param_1 + 0x3e6) = 4;
    }
  }
  return;
}

