/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f92b0; RVA 0xf92b0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400f92b0(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  uint *puVar2;
  undefined1 uVar3;
  undefined1 uVar4;
  undefined1 uVar5;
  undefined2 uVar6;
  undefined2 uVar7;
  undefined4 uVar8;
  uint uVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  undefined1 auVar13 [16];
  float fVar14;
  float fVar15;
  undefined1 auVar16 [16];
  float fVar17;
  float fVar18;
  float fVar19;
  int iVar20;
  longlong lVar21;
  undefined1 (*pauVar22) [16];
  int iVar23;
  float fVar24;
  undefined1 auVar25 [64];
  float fVar26;
  float fVar27;
  float fVar28;
  undefined8 local_c8;
  undefined8 uStack_c0;
  float local_b8;
  float fStack_b4;
  float fStack_b0;
  undefined4 uStack_ac;
  undefined1 local_a8 [8];
  float fStack_a0;
  float fStack_9c;
  float local_98;
  float fStack_94;
  float fStack_90;
  undefined4 uStack_8c;
  undefined1 local_88 [8];
  float fStack_80;
  float fStack_7c;
  
  lVar10 = *param_2;
  lVar11 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar12 = *(longlong *)(lVar11 + 0x1b8);
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xfffe3ff7 | 0x20;
  *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x394) = 0;
  *(undefined4 *)(param_1 + 0x348) = 0xc8333300;
  *(undefined4 *)(param_1 + 0x350) = 0x48333300;
  *(undefined4 *)(param_1 + 0x34c) = 0xc8333300;
  *(undefined4 *)(param_1 + 0x354) = 0x48333300;
  if (*(longlong *)(param_1 + 0x338) != 0) {
    lVar21 = *(longlong *)(*(longlong *)(param_1 + 0x338) + 0x66ee0);
    *(undefined8 *)(lVar21 + 0x1bc48) = 0;
    *(undefined8 *)(lVar21 + 0x1bc50) = 0;
    *(undefined8 *)(lVar21 + 0x1bc58) = 0;
    *(undefined8 *)(lVar21 + 0x1bc60) = 0;
    *(undefined8 *)(lVar21 + 0x1bc68) = 0;
    *(undefined8 *)(lVar21 + 0x1bc70) = 0;
    *(undefined8 *)(lVar21 + 0x1bc78) = 0;
    *(undefined8 *)(lVar21 + 0x1bc80) = 0;
    *(int *)(lVar21 + 0x1bc8c) = *(int *)(lVar21 + 0x1bc8c) + 1;
    *(undefined4 *)(lVar21 + 0x1bc88) = 0;
    if (0xe < *(int *)(lVar21 + 0x1bc8c)) {
      *(undefined4 *)(lVar21 + 0x1bc8c) = 0;
    }
  }
  *(undefined4 *)(param_1 + 0x90) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x94) = 0xc61c4000;
  *(undefined4 *)(param_1 + 0x98) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x9c) = 0x3f800000;
  *(undefined4 *)(param_1 + 0xa0) = 0x48800000;
  *(undefined4 *)(param_1 + 0xa4) = 0x461c4000;
  *(undefined4 *)(param_1 + 0xa8) = 0x48800000;
  *(undefined4 *)(param_1 + 0xac) = 0x3f800000;
  *(undefined2 *)(param_1 + 0x3c0) = 0xffff;
  fVar24 = *(float *)(lVar10 + 0x84);
  fVar26 = *(float *)(lVar10 + 0x78);
  auVar13 = vcmpss_avx(ZEXT416((uint)fVar26),ZEXT416((uint)fVar24),1);
  lVar21 = 0x84;
  if (fVar24 <= fVar26) {
    lVar21 = 0x78;
  }
  auVar13 = vblendvps_avx(ZEXT416((uint)fVar24),ZEXT416((uint)fVar26),auVar13);
  *(int *)(param_1 + 0x90) = auVar13._0_4_;
  *(undefined4 *)(param_1 + 0xa0) = *(undefined4 *)(lVar21 + lVar10);
  fVar24 = *(float *)(lVar10 + 0x88);
  fVar26 = *(float *)(lVar10 + 0x7c);
  auVar13 = vcmpss_avx(ZEXT416((uint)fVar26),ZEXT416((uint)fVar24),1);
  lVar21 = 0x88;
  if (fVar24 <= fVar26) {
    lVar21 = 0x7c;
  }
  auVar13 = vblendvps_avx(ZEXT416((uint)fVar24),ZEXT416((uint)fVar26),auVar13);
  *(int *)(param_1 + 0x94) = auVar13._0_4_;
  *(undefined4 *)(param_1 + 0xa4) = *(undefined4 *)(lVar21 + lVar10);
  fVar24 = *(float *)(lVar10 + 0x8c);
  fVar26 = *(float *)(lVar10 + 0x80);
  auVar13 = vminss_avx(ZEXT416((uint)fVar26),ZEXT416((uint)fVar24));
  *(int *)(param_1 + 0x98) = auVar13._0_4_;
  lVar21 = 0x8c;
  if (fVar24 <= fVar26) {
    lVar21 = 0x80;
  }
  *(undefined4 *)(param_1 + 0xa8) = *(undefined4 *)(lVar21 + lVar10);
  if (*(float *)(param_1 + 0x94) == 0.0) {
    *(undefined4 *)(param_1 + 0x94) = 0xc61c4000;
  }
  if (*(float *)(param_1 + 0xa4) == 0.0) {
    *(undefined4 *)(param_1 + 0xa4) = 0x461c4000;
  }
  if (*(longlong *)(param_1 + 0x340) != 0) {
    FUN_1400d1560(*(longlong *)(param_1 + 0x340),1);
  }
  lVar21 = 0;
  *(int *)(param_1 + 0x380) = (int)((float)*(byte *)(param_1 + 0x3d1) * *(float *)(lVar10 + 0x70));
  if (lVar12 != 0) {
    uVar3 = *(undefined1 *)(lVar12 + 0x272c);
    uVar8 = *(undefined4 *)(lVar12 + 0x2784);
    uVar4 = *(undefined1 *)(lVar12 + 0x272d);
    uVar5 = *(undefined1 *)(lVar12 + 0x272e);
    uVar6 = *(undefined2 *)(lVar12 + 0x2728);
    uVar7 = *(undefined2 *)(lVar12 + 0x272a);
    FUN_140102ab0();
    *(undefined1 *)(lVar12 + 0x272d) = uVar4;
    *(undefined2 *)(lVar12 + 0x2728) = uVar6;
    *(undefined2 *)(lVar12 + 0x272a) = uVar7;
    *(undefined1 *)(lVar12 + 0x272c) = uVar3;
    *(undefined1 *)(lVar12 + 0x272e) = uVar5;
    *(undefined4 *)(lVar12 + 0x2784) = uVar8;
    FUN_140114c30(lVar11);
    *(undefined4 *)(lVar11 + 0x420) = *(undefined4 *)(param_1 + 0x404);
    *(ushort *)(lVar11 + 0x428) = (ushort)*(byte *)(param_1 + 0x3e2);
    *(undefined2 *)(lVar12 + 0x208e) = *(undefined2 *)(param_1 + 0x3c2);
    *(undefined1 *)(lVar12 + 0x2099) = *(undefined1 *)(param_1 + 0x3e4);
    *(undefined1 *)(lVar12 + 0x209a) = *(undefined1 *)(param_1 + 0x3e5);
    *(byte *)(lVar12 + 0x1863) = *(byte *)(lVar12 + 0x1863) | 1;
    *(undefined4 *)(lVar12 + 0x185c) = 0;
    uVar9 = *(uint *)(lVar12 + 0x2058);
    *(byte *)(lVar12 + 0x1da7) = *(byte *)(lVar12 + 0x1da7) | 1;
    *(undefined8 *)(lVar12 + 0x1d78) = 0;
    *(ushort *)(lVar12 + 0x1c20) = *(ushort *)(lVar12 + 0x1c20) | 1;
    *(uint *)(lVar12 + 0x2058) = uVar9 & 0xffffffef | 0x1020;
    if ((*(byte *)(lVar10 + 0x90) == 0xff) || (*(byte *)(lVar10 + 0x91) == 0xff)) {
      lVar21 = 0;
    }
    else {
      lVar21 = (ulonglong)*(byte *)(lVar10 + 0x91) * 0x520 +
               *(longlong *)
                (*(longlong *)
                  (**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar10 + 0x90) * 8) +
                0x110);
    }
    *(longlong *)(lVar12 + 0x2048) = lVar21;
    *(longlong *)(lVar12 + 0x1638) = lVar21;
    *(uint *)(lVar12 + 0x2058) = uVar9 & 0xfffffeef | 0x1020;
    *(byte *)(lVar12 + 0x1677) = *(byte *)(lVar12 + 0x1677) & 0xfd;
    switch(*(undefined1 *)(param_1 + 0x3db)) {
    default:
      iVar23 = 1;
      break;
    case 2:
      iVar23 = 0x200;
      break;
    case 3:
    case 4:
    case 5:
      iVar23 = 0x800;
    }
    if (lVar21 != 0) {
      local_c8 = _DAT_1402d2f60;
      uStack_c0 = _UNK_1402d2f68;
      iVar20 = FUN_140242630();
      fVar28 = (float)(iVar20 % (iVar23 * 2) - iVar23);
      FUN_140203050(&local_c8,lVar21 + 0x268,&local_c8);
      _local_a8 = ZEXT816(0);
      local_b8 = 0.0;
      fStack_b4 = 0.0;
      fStack_b0 = 0.0;
      uStack_ac = 0;
      local_98 = 0.0;
      fStack_94 = 0.0;
      fStack_90 = 0.0;
      uStack_8c = 0;
      _local_88 = _local_a8;
      FUN_140202920(&local_b8,&local_c8);
      fVar19 = DAT_1402d2af8;
      fVar27 = DAT_1402d2a94 * (float)local_a8._4_4_;
      fVar17 = DAT_1402d2af8 * fStack_94;
      fVar24 = *(float *)(lVar21 + 0x25c);
      fVar14 = DAT_1402d2a94 * fStack_a0;
      fVar18 = DAT_1402d2af8 * fStack_90;
      auVar16._4_4_ = fStack_94;
      auVar16._0_4_ = local_98;
      auVar16._8_4_ = fStack_90;
      auVar16._12_4_ = uStack_8c;
      fVar26 = *(float *)(lVar21 + 0x260);
      auVar13._4_4_ = fStack_b4;
      auVar13._0_4_ = local_b8;
      auVar13._8_4_ = fStack_b0;
      auVar13._12_4_ = uStack_ac;
      fVar15 = DAT_1402d2a94 * fStack_9c;
      *(float *)(lVar11 + 600) =
           -(local_98 * DAT_1402d2af8) + local_b8 * fVar28 + DAT_1402d2a94 * (float)local_a8._0_4_ +
           (float)local_88._0_4_ + *(float *)(lVar21 + 600);
      *(float *)(lVar11 + 0x25c) =
           -fVar17 + fVar28 * fStack_b4 + fVar27 + (float)local_88._4_4_ + fVar24;
      *(float *)(lVar11 + 0x260) = -fVar18 + fVar28 * fStack_b0 + fVar14 + fStack_80 + fVar26;
      *(undefined8 *)(lVar11 + 0x268) = local_c8;
      *(undefined8 *)(lVar11 + 0x270) = uStack_c0;
      auVar13 = vshufps_avx(auVar13,auVar13,0xff);
      auVar16 = vshufps_avx(auVar16,auVar16,0xff);
      *(float *)(lVar11 + 0x264) =
           -(auVar16._0_4_ * fVar19) + auVar13._0_4_ * fVar28 + fVar15 + fStack_7c;
      *(uint *)(lVar12 + 0xd48) = *(uint *)(lVar12 + 0xd48) & 0xfffffcff;
      *(undefined4 *)(param_1 + 0x39c) = 0;
    }
    fVar27 = (float)*(byte *)(lVar12 + 0x1674);
    fVar26 = (float)*(ushort *)(lVar12 + 0x1444);
    auVar25 = ZEXT464((uint)((DAT_1402d2140 / fVar27) * fVar26));
    fVar24 = (float)FUN_140128d90(*(undefined4 *)(lVar12 + 0x15b4));
    *(float *)(lVar12 + 0x1640) =
         fVar26 * (DAT_1402d235c / fVar27) +
         -(auVar25._0_4_ * SQRT(fVar24 / *(float *)(lVar12 + 0x1648))) + auVar25._0_4_;
    FUN_14010baa0(lVar12);
    *(uint *)(lVar11 + 0x1f0) = *(uint *)(lVar11 + 0x1f0) | 3;
  }
  if (*(longlong *)(param_1 + 0x308) != 0) {
    FUN_1401a7df0(*(longlong *)(param_1 + 0x308),0);
    FUN_1401a5f00(*(undefined8 *)(param_1 + 0x308));
    *(byte *)(param_1 + 0x3d9) = *(byte *)(param_1 + 0x3d9) & 0xfb;
    if (lVar21 != 0) {
      pauVar22 = (undefined1 (*) [16])FUN_140101cc0(param_1,&local_c8);
      auVar13 = *pauVar22;
      fVar24 = auVar13._0_4_ - *(float *)(lVar21 + 600);
      auVar16 = vshufps_avx(auVar13,auVar13,0x55);
      fVar26 = auVar16._0_4_ - *(float *)(lVar21 + 0x25c);
      auVar16 = vshufps_avx(auVar13,auVar13,0xaa);
      fVar27 = auVar16._0_4_ - *(float *)(lVar21 + 0x260);
      auVar13 = vshufps_avx(auVar13,auVar13,0xff);
      fVar14 = auVar13._0_4_ - *(float *)(lVar21 + 0x264);
      *(char *)(param_1 + 0x3d7) =
           (char)(int)(SQRT(fVar14 * fVar14 + fVar27 * fVar27 + fVar24 * fVar24 + fVar26 * fVar26) *
                      DAT_1402d1dac);
    }
    *(uint *)(param_1 + 0x390) = (uint)*(byte *)(param_1 + 0x3d1);
    *(undefined1 *)(param_1 + 0x3d7) = 0xff;
    *(undefined1 *)(param_1 + 0x3d9) = 0;
  }
  lVar10 = *(longlong *)(param_1 + 800);
  if (lVar10 != 0) {
    *(byte *)(lVar10 + 0x2b) = *(byte *)(lVar10 + 0x2b) | 2;
    if (*(longlong *)(lVar10 + 0x10) != 0) {
      puVar2 = (uint *)(*(longlong *)(lVar10 + 0x10) + 0x56c);
      *puVar2 = *puVar2 | 1;
    }
    if (*(longlong *)(lVar10 + 0x18) != 0) {
      pbVar1 = (byte *)(*(longlong *)(lVar10 + 0x18) + 0x23);
      *pbVar1 = *pbVar1 | 4;
    }
    lVar10 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
    if (lVar10 != 0) {
      puVar2 = (uint *)(lVar10 + 0x40);
      *puVar2 = *puVar2 | 0x4000000;
    }
  }
  *(undefined4 *)(param_1 + 0x37c) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 0xd;
  return;
}

