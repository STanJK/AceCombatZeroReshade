/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400b4d10; RVA 0xb4d10
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 *
FUN_1400b4d10(longlong param_1,undefined8 *param_2,longlong param_3,undefined8 param_4,
             undefined8 param_5,char param_6,uint *param_7)

{
  undefined1 auVar1 [32];
  undefined1 auVar2 [32];
  byte bVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  float fVar10;
  uint *puVar11;
  char cVar12;
  int iVar13;
  int iVar14;
  undefined8 uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  undefined1 auVar24 [16];
  undefined1 auVar25 [16];
  undefined1 auVar26 [64];
  undefined1 auVar27 [16];
  float fVar28;
  undefined1 auVar29 [16];
  float fVar30;
  float fVar31;
  float fVar32;
  undefined1 auVar33 [64];
  float local_138;
  float local_134;
  float local_130;
  float local_12c;
  float local_128;
  float local_124;
  float local_120;
  float local_11c;
  undefined1 local_118 [8];
  float fStack_110;
  float fStack_10c;
  undefined8 local_108;
  undefined8 uStack_100;
  undefined1 local_f8 [16];
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined1 local_d8 [16];
  
  puVar11 = param_7;
  if (param_6 == '\0') {
    return param_2;
  }
  if (*(ushort *)(param_1 + 0x39c) == 0xffff) {
    if ((*(uint *)(param_1 + 0x34c) & 0x10001) == 0) goto LAB_1400b561a;
LAB_1400b4d71:
    _param_6 = *(undefined4 *)(param_1 + 0x1f8);
  }
  else {
    if ((*(uint *)(param_1 + 0x348) >> 0x1a & 1) == 0) {
      *(uint *)(param_1 + 0x348) = *(uint *)(param_1 + 0x348) | 0x4000000;
    }
    if ((*(ushort *)(param_1 + 0x39c) & 4) == 0) goto LAB_1400b4d71;
LAB_1400b561a:
    _param_6 = *(undefined4 *)(param_1 + 0x1b0);
  }
  _local_118 = ZEXT816(0);
  iVar13 = (**(code **)(**(longlong **)(param_1 + 0x308) + 0x28))
                     (*(longlong **)(param_1 + 0x308),local_118,*(undefined1 *)(param_1 + 0x3ca),0);
  if (iVar13 != 0) {
    return param_2;
  }
  auVar1 = *(undefined1 (*) [32])(param_3 + 0x130);
  auVar2 = *(undefined1 (*) [32])(param_3 + 0x110);
  auVar24 = auVar1._0_16_;
  auVar25 = auVar1._16_16_;
  auVar6 = vshufps_avx(auVar25,auVar25,0xff);
  auVar27 = auVar2._0_16_;
  auVar7 = vshufps_avx(auVar27,auVar27,0xff);
  auVar29 = auVar2._16_16_;
  auVar8 = vshufps_avx(auVar29,auVar29,0xff);
  auVar9 = vshufps_avx(auVar24,auVar24,0xff);
  local_124 = DAT_1402d2544 /
              ((float)local_118._4_4_ * auVar8._0_4_ + auVar7._0_4_ * (float)local_118._0_4_ +
              fStack_110 * auVar9._0_4_ + auVar6._0_4_ * fStack_10c);
  fVar30 = (fStack_110 * auVar1._0_4_ + auVar1._16_4_ * fStack_10c +
           (float)local_118._4_4_ * auVar2._16_4_ + auVar2._0_4_ * (float)local_118._0_4_) *
           local_124;
  auVar6 = vshufps_avx(auVar24,auVar24,0x55);
  auVar7 = vshufps_avx(auVar25,auVar25,0x55);
  auVar8 = vshufps_avx(auVar27,auVar27,0x55);
  auVar9 = vshufps_avx(auVar29,auVar29,0x55);
  fVar22 = (fStack_110 * auVar6._0_4_ + auVar7._0_4_ * fStack_10c +
           (float)local_118._4_4_ * auVar9._0_4_ + auVar8._0_4_ * (float)local_118._0_4_) *
           local_124;
  auVar6 = vshufps_avx(auVar25,auVar25,0xaa);
  auVar7 = vshufps_avx(auVar27,auVar27,0xaa);
  auVar8 = vshufps_avx(auVar24,auVar24,0xaa);
  auVar9 = vshufps_avx(auVar29,auVar29,0xaa);
  local_124 = (fStack_110 * auVar8._0_4_ + auVar6._0_4_ * fStack_10c +
              (float)local_118._4_4_ * auVar9._0_4_ + auVar7._0_4_ * (float)local_118._0_4_) *
              local_124;
  local_138 = (float)local_118._0_4_;
  local_134 = (float)local_118._4_4_;
  local_130 = fStack_110;
  local_12c = fStack_10c;
  auVar33 = ZEXT464((uint)DAT_1402d2544);
  local_120 = fVar22;
  local_11c = fVar30;
  iVar13 = FUN_140202ed0(param_3 + 0x150,&local_138);
  fVar21 = DAT_1402d29e8;
  fVar28 = DAT_1402d29f0;
  fVar31 = DAT_1402d1fbc;
  fVar32 = DAT_1402d22d0;
  if (iVar13 == 0) {
    fVar22 = (fVar22 * DAT_1402d1fbc + (float)(int)puVar11[1]) - DAT_1402d29f0;
    fVar30 = (fVar30 * DAT_1402d1fbc + (float)(int)*puVar11) - DAT_1402d29e8;
    auVar26 = ZEXT464((uint)fVar30);
    uVar15 = FUN_1400bff50(param_2,fVar30 - DAT_1402d253c,fVar22,fVar30 + DAT_1402d253c,
                           fVar22 + DAT_1402d22d0,&param_6);
    param_2 = (undefined8 *)
              FUN_1400bff50(uVar15,auVar26._0_8_,fVar22 - DAT_1402d2528,auVar26._0_4_ + fVar32,
                            fVar22 + DAT_1402d2528,&param_6);
  }
  plVar4 = *(longlong **)(param_1 + 0x308);
  bVar3 = *(byte *)(param_1 + 0x3ca);
  cVar12 = (**(code **)(*plVar4 + 0x30))(plVar4,(ulonglong)bVar3,0);
  fVar20 = auVar33._0_4_;
  fVar30 = 0.0;
  fVar22 = DAT_1402d2504;
  if (cVar12 == '\0') {
    local_f8 = ZEXT816(0);
    lVar5 = *(longlong *)(*(longlong *)(*(longlong *)plVar4[2] + (ulonglong)bVar3 * 8) + 0x110);
    fVar20 = *(float *)(*(longlong *)(lVar5 + 0x1b8) + 0x1848) * DAT_1402d2d8c;
    local_108 = 0;
    uStack_100 = 0;
    local_e8 = 0;
    uStack_e0 = 0;
    local_d8 = local_f8;
    FUN_140202920(&local_108,lVar5 + 0x268);
    auVar6 = *(undefined1 (*) [16])(lVar5 + 600);
    auVar24._8_8_ = uStack_e0;
    auVar24._0_8_ = local_e8;
    local_138 = (fVar20 * (float)local_e8 + local_d8._0_4_) * DAT_1402d23e8 + auVar6._0_4_;
    auVar7 = vshufps_avx(auVar24,auVar24,0x55);
    auVar8 = vshufps_avx(local_d8,local_d8,0x55);
    auVar9 = vshufps_avx(auVar6,auVar6,0x55);
    local_134 = (fVar20 * auVar7._0_4_ + auVar8._0_4_) * DAT_1402d23e8 + auVar9._0_4_;
    auVar7 = vshufps_avx(auVar24,auVar24,0xaa);
    auVar8 = vshufps_avx(local_d8,local_d8,0xaa);
    auVar9 = vshufps_avx(auVar6,auVar6,0xaa);
    local_130 = (fVar20 * auVar7._0_4_ + auVar8._0_4_) * DAT_1402d23e8 + auVar9._0_4_;
    auVar7 = vshufps_avx(local_d8,local_d8,0xff);
    auVar8 = vshufps_avx(auVar24,auVar24,0xff);
    auVar6 = vshufps_avx(auVar6,auVar6,0xff);
    local_12c = (fVar20 * auVar8._0_4_ + auVar7._0_4_) * DAT_1402d23e8 + auVar6._0_4_;
    iVar13 = FUN_1400934e0(plVar4,&local_138,bVar3,0,fVar30,1);
    fVar20 = auVar33._0_4_;
    if (iVar13 == 0) {
      auVar1 = *(undefined1 (*) [32])(param_3 + 0x110);
      auVar2 = *(undefined1 (*) [32])(param_3 + 0x130);
      auVar24 = auVar2._0_16_;
      auVar6 = vshufps_avx(auVar24,auVar24,0xff);
      auVar25 = auVar2._16_16_;
      auVar7 = vshufps_avx(auVar25,auVar25,0xff);
      auVar27 = auVar1._0_16_;
      auVar8 = vshufps_avx(auVar27,auVar27,0xff);
      auVar29 = auVar1._16_16_;
      auVar9 = vshufps_avx(auVar29,auVar29,0xff);
      fVar20 = fVar20 / (local_12c * auVar7._0_4_ + auVar6._0_4_ * local_130 +
                        local_134 * auVar9._0_4_ + auVar8._0_4_ * local_138);
      local_128 = (local_12c * auVar2._16_4_ + auVar2._0_4_ * local_130 +
                  local_134 * auVar1._16_4_ + auVar1._0_4_ * local_138) * fVar20;
      auVar6 = vshufps_avx(auVar24,auVar24,0x55);
      auVar7 = vshufps_avx(auVar25,auVar25,0x55);
      auVar8 = vshufps_avx(auVar27,auVar27,0x55);
      auVar9 = vshufps_avx(auVar29,auVar29,0x55);
      fVar23 = (local_12c * auVar7._0_4_ + auVar6._0_4_ * local_130 +
               local_134 * auVar9._0_4_ + auVar8._0_4_ * local_138) * fVar20;
      auVar33 = ZEXT1664(auVar33._0_16_);
      iVar13 = FUN_140202ed0(param_3 + 0x150,&local_138);
      fVar20 = auVar33._0_4_;
      fVar28 = DAT_1402d29f0;
      fVar21 = DAT_1402d29e8;
      if (iVar13 == 0) {
        fVar20 = (fVar31 * local_128 + (float)(int)*puVar11) - DAT_1402d29e8;
        auVar26 = ZEXT464((uint)fVar20);
        fVar23 = (fVar23 * fVar31 + (float)(int)puVar11[1]) - DAT_1402d29f0;
        uVar15 = FUN_1400bff50(param_2,fVar20 - fVar22,fVar23,fVar20 + fVar22,fVar23 + fVar32,
                               &param_6);
        param_2 = (undefined8 *)
                  FUN_1400bff50(uVar15,auVar26._0_8_,fVar23 - DAT_1402d24bc,auVar26._0_4_ + fVar32,
                                fVar23 + DAT_1402d24bc,&param_6);
        fVar20 = auVar33._0_4_;
      }
    }
  }
  if (local_124 <= fVar30) {
    return param_2;
  }
  auVar6 = vcvtdq2ps_avx(ZEXT416(*(uint *)(param_1 + 0x390)));
  lVar5 = *(longlong *)(*(longlong *)(param_1 + 0x10) + 0x60);
  auVar7 = vcvtdq2ps_avx(ZEXT416(*(uint *)(param_1 + 0x394)));
  fVar23 = auVar6._0_4_ + *(float *)(lVar5 + 0x28);
  fVar19 = auVar7._0_4_ + *(float *)(lVar5 + 0x2c);
  auVar6 = vcvtdq2ps_avx(ZEXT416(puVar11[1]));
  fVar10 = ((fVar31 * local_120 + auVar6._0_4_) - fVar28) - fVar19;
  auVar6 = vcvtdq2ps_avx(ZEXT416(*puVar11));
  fVar28 = ((fVar31 * local_11c + auVar6._0_4_) - fVar21) - fVar23;
  fVar21 = SQRT(fVar10 * fVar10 + fVar28 * fVar28);
  fVar28 = (fVar32 / fVar21) * fVar28;
  fVar10 = (fVar32 / fVar21) * fVar10;
  if (*(ushort *)(param_1 + 0x39c) == 0xffff) {
    if ((*(uint *)(param_1 + 0x34c) & 0x10001) == 0) goto LAB_1400b5635;
  }
  else {
    if ((*(uint *)(param_1 + 0x348) >> 0x1a & 1) == 0) {
      *(uint *)(param_1 + 0x348) = *(uint *)(param_1 + 0x348) | 0x4000000;
    }
    if ((*(ushort *)(param_1 + 0x39c) & 4) != 0) {
LAB_1400b5635:
      uVar18 = *(uint *)(param_1 + 0x1b0);
      goto LAB_1400b53d5;
    }
  }
  uVar18 = *(uint *)(param_1 + 0x1f8);
LAB_1400b53d5:
  fVar32 = DAT_1402d2e08;
  fVar31 = DAT_1402d1fa8;
  uVar16 = (uint)(fVar23 * fVar20 + DAT_1402d2b1c);
  iVar13 = (int)(fVar19 * fVar20 + DAT_1402d2b2c);
  if (fVar30 < fVar21) {
    fVar23 = fVar21 * DAT_1402d2cb8;
    do {
      iVar14 = 10;
      if (fVar21 < fVar30 + fVar22) {
        iVar14 = (int)(fVar21 - fVar30);
      }
      fVar19 = (float)iVar14;
      uVar17 = uVar16 - (int)(fVar28 * fVar19 * fVar32);
      iVar14 = iVar13 - (int)(fVar10 * fVar19 * fVar32);
      if ((((uVar16 - 0x7001 < 0x1fff) && (uVar17 - 0x7001 < 0x1fff)) && (iVar13 - 0x7201U < 0x1bff)
          ) && (iVar14 - 0x7201U < 0x1bff)) {
        *param_2 = 0x10000004;
        *(uint *)(param_2 + 4) = iVar13 << 0x10 | uVar16;
        *(undefined4 *)(param_2 + 1) = 0;
        *(undefined4 *)((longlong)param_2 + 0xc) = 0x50000004;
        *(undefined4 *)(param_2 + 2) = 0x8001;
        *(undefined4 *)((longlong)param_2 + 0x14) = 0x3020c000;
        param_2[3] = 0xeee;
        *(uint *)(param_2 + 8) = iVar14 * 0x10000 | uVar17;
        *(undefined4 *)((longlong)param_2 + 0x24) = 0xfffffff;
        *(undefined4 *)(param_2 + 5) = 5;
        *(uint *)(param_2 + 6) =
             (((uVar18 >> 0x18) << 8 | uVar18 >> 0x10 & 0xff) << 8 | uVar18 >> 8 & 0xff) << 8 |
             uVar18 & 0xff;
        *(undefined4 *)((longlong)param_2 + 0x34) = 0x3f800000;
        *(undefined4 *)(param_2 + 7) = 1;
        *(undefined4 *)((longlong)param_2 + 0x44) = 0xfffffff;
        *(undefined4 *)(param_2 + 9) = 5;
        param_2 = param_2 + 10;
      }
      fVar30 = fVar30 + fVar21 * fVar31 + fVar19;
      uVar16 = uVar17 - (int)(fVar23 * fVar28 * fVar20);
      iVar13 = iVar14 - (int)(fVar23 * fVar10 * fVar20);
    } while (fVar30 < fVar21);
  }
  return param_2;
}

