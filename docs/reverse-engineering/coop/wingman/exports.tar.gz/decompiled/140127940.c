/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140127940; RVA 0x127940
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140127940(undefined1 (*param_1) [16],undefined8 *param_2)

{
  undefined1 auVar1 [16];
  uint uVar2;
  float *pfVar3;
  undefined8 *puVar4;
  int *piVar5;
  float fVar6;
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  bool bVar9;
  bool bVar10;
  short sVar11;
  longlong lVar12;
  byte bVar13;
  longlong *plVar14;
  int iVar15;
  ulonglong uVar16;
  longlong lVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  undefined8 uVar26;
  undefined1 auVar27 [64];
  float fVar28;
  float fVar29;
  undefined1 auVar30 [64];
  float fVar31;
  float fVar32;
  undefined1 auVar33 [64];
  float fVar34;
  float fVar35;
  undefined1 auVar36 [64];
  undefined1 auVar37 [64];
  uint uVar38;
  float fVar39;
  float local_138;
  float local_134;
  float local_130;
  float local_12c;
  float local_128;
  float local_124;
  float local_120;
  float local_11c;
  undefined1 local_118 [16];
  undefined1 local_108 [16];
  undefined1 local_f8 [8];
  float fStack_f0;
  float fStack_ec;
  undefined1 local_e8 [8];
  float fStack_e0;
  float fStack_dc;
  
  pfVar3 = (float *)*param_2;
  bVar10 = false;
  bVar9 = false;
  *(float *)(param_1[9] + 4) = pfVar3[8];
  fVar24 = 0.0;
  auVar30 = ZEXT864(0);
  auVar27 = ZEXT864(0);
  auVar33 = ZEXT864(0);
  if ((*(byte *)((longlong)pfVar3 + 0x36) & 8) != 0) {
    if (*pfVar3 <= (float)*(uint *)(param_1[10] + 4) / (float)(byte)param_1[0xb][3]) {
      bVar10 = true;
      bVar9 = true;
    }
    else {
      *(uint *)(param_1[10] + 4) = *(uint *)(param_1[10] + 4) + 1;
    }
  }
  uVar16 = 1;
  if ((*(ushort *)((longlong)pfVar3 + 0x36) & 0x10) != 0) {
    lVar12 = (*(undefined8 **)param_1[7])[3];
    if (lVar12 == 0) {
LAB_140127a2b:
      sVar11 = 0;
    }
    else {
      puVar4 = (undefined8 *)**(undefined8 **)param_1[7];
      if (puVar4 == (undefined8 *)0x0) {
        sVar11 = 0;
      }
      else {
        if (*(ushort *)*puVar4 <= *(ushort *)(pfVar3 + 0xc)) goto LAB_140127a2b;
        sVar11 = *(short *)(lVar12 + (ulonglong)*(ushort *)(pfVar3 + 0xc) * 2);
      }
    }
    bVar9 = bVar10;
    if (sVar11 == *(short *)((longlong)pfVar3 + 0x32)) {
      bVar9 = true;
    }
  }
  auVar36 = ZEXT464((uint)DAT_1402d22d0);
  if (*(char *)(pfVar3 + 0xe) == '\0') {
    fVar19 = pfVar3[3] + *(float *)param_1[9];
    fVar25 = pfVar3[2];
    fVar21 = pfVar3[4];
    if (((*(ushort *)((longlong)pfVar3 + 0x36) & 1) != 0) && (*(longlong *)param_1[8] != 0)) {
      fVar18 = (float)FUN_140079410(*(longlong *)param_1[8],fVar25,fVar21);
      fVar19 = fVar18 + fVar19;
    }
    fVar25 = fVar25 - *(float *)*param_1;
    auVar30 = ZEXT464((uint)fVar25);
    fVar19 = fVar19 - *(float *)(*param_1 + 4);
    auVar27 = ZEXT464((uint)fVar19);
    fVar21 = fVar21 - *(float *)(*param_1 + 8);
    auVar33 = ZEXT464((uint)fVar21);
    if (fVar24 < pfVar3[1]) {
      if (SQRT(*(float *)(*param_1 + 0xc) * *(float *)(*param_1 + 0xc) +
               fVar21 * fVar21 + fVar19 * fVar19 + fVar25 * fVar25) < pfVar3[1]) {
        bVar9 = true;
      }
    }
  }
  else if (*(char *)(pfVar3 + 0xe) == '\x01') {
    if (*(byte *)((longlong)pfVar3 + 0x39) == 0xff) {
      fVar25 = DAT_1402d2edc;
      fVar21 = DAT_1402d2a54;
      fVar19 = DAT_1402d2edc;
      fVar18 = DAT_1402d22d0;
    }
    else {
      lVar12 = *(longlong *)
                (**(longlong **)(param_1[7] + 8) + (ulonglong)*(byte *)((longlong)pfVar3 + 0x39) * 8
                );
      if ((*(byte *)(lVar12 + 0x120) & 2) == 0) {
        bVar9 = true;
      }
      if (*(byte *)((longlong)pfVar3 + 0x3a) == 0xff) {
        fVar25 = *(float *)(lVar12 + 8);
        fVar21 = *(float *)(lVar12 + 0xc);
        fVar19 = *(float *)(lVar12 + 0x10);
        fVar18 = *(float *)(lVar12 + 0x14);
      }
      else {
        lVar12 = *(longlong *)(lVar12 + 0x110);
        lVar17 = (ulonglong)*(byte *)((longlong)pfVar3 + 0x3a) * 0x520;
        fVar25 = *(float *)(lVar17 + 600 + lVar12);
        fVar21 = *(float *)(lVar17 + 0x25c + lVar12);
        fVar19 = *(float *)(lVar17 + 0x260 + lVar12);
        fVar18 = *(float *)(lVar17 + 0x264 + lVar12);
        if ((*(byte *)(lVar17 + 0x1f0 + lVar12) & 2) == 0) {
          bVar9 = true;
        }
      }
    }
    fVar25 = fVar25 - *(float *)param_1[2];
    auVar30 = ZEXT464((uint)fVar25);
    fVar21 = fVar21 - *(float *)(param_1[2] + 4);
    auVar27 = ZEXT464((uint)fVar21);
    fVar19 = fVar19 - *(float *)(param_1[2] + 8);
    auVar33 = ZEXT464((uint)fVar19);
    fVar18 = fVar18 - *(float *)(param_1[2] + 0xc);
    if (SQRT(fVar18 * fVar18 + fVar19 * fVar19 + fVar21 * fVar21 + fVar25 * fVar25) < pfVar3[1]) {
      bVar9 = true;
    }
  }
  fVar25 = DAT_1402d2478;
  fVar21 = auVar33._0_4_;
  uVar26 = auVar27._0_8_;
  uVar2 = *(uint *)(param_1[10] + 8);
  if ((uVar2 & 0x20) != 0) {
    fVar39 = *(float *)(param_1[3] + 4) -
             (DAT_1402d2478 * pfVar3[6]) /
             ((float)(byte)param_1[0xb][3] * (float)(byte)param_1[0xb][3]);
    *(float *)(param_1[3] + 4) = fVar39;
    auVar1 = *param_1;
    fVar19 = auVar1._0_4_ + *(float *)param_1[3];
    auVar36 = ZEXT464((uint)fVar19);
    auVar7 = vshufps_avx(auVar1,auVar1,0x55);
    auVar8 = vshufps_avx(auVar1,auVar1,0xaa);
    fVar18 = auVar8._0_4_ + *(float *)(param_1[3] + 8);
    auVar37 = ZEXT464((uint)fVar18);
    fVar39 = fVar39 + auVar7._0_4_;
    auVar1 = vshufps_avx(auVar1,auVar1,0xff);
    *(float *)(*param_1 + 0xc) = auVar1._0_4_ + *(float *)(param_1[3] + 0xc);
    *(float *)*param_1 = fVar19;
    *(float *)(*param_1 + 4) = fVar39;
    *(float *)(*param_1 + 8) = fVar18;
    lVar12 = *(longlong *)param_1[8];
    if ((lVar12 != 0) && ((*(byte *)((longlong)pfVar3 + 0x36) & 0x40) != 0)) {
      fVar20 = *(float *)param_1[9];
      fVar39 = fVar39 + fVar20;
      fVar19 = (float)FUN_140079410(lVar12,fVar19,fVar18);
      fVar21 = auVar33._0_4_;
      uVar26 = auVar27._0_8_;
      if (fVar39 < fVar19) {
        fVar19 = (float)FUN_140079410(lVar12,auVar36._0_8_,auVar37._0_8_);
        fVar21 = auVar33._0_4_;
        uVar26 = auVar27._0_8_;
        *(float *)(*param_1 + 4) = fVar19 + fVar20;
        bVar9 = true;
      }
    }
    auVar36 = ZEXT464((uint)DAT_1402d22d0);
  }
  uVar38 = DAT_1402d3770;
  fVar19 = DAT_1402d1f38;
  if (((*(char *)((longlong)pfVar3 + 0x3b) == '\b') && (param_2[1] == 0)) || (bVar9)) {
    lVar17 = (ulonglong)(byte)param_1[0xb][0] * 0x10;
    lVar12 = *(longlong *)(*(longlong *)param_1[6] + 8);
    if ((int)(uint)(byte)param_1[10][0xf] < (int)(**(byte **)(lVar17 + lVar12) - 1)) {
      bVar13 = param_1[10][0xf] + 1;
      param_1[10][0xf] = bVar13;
      FUN_140126b00(param_1,(ulonglong)bVar13 * 0x40 + *(longlong *)(lVar17 + 8 + lVar12));
      return;
    }
    return;
  }
  if ((uVar2 & 0x20) != 0) {
    return;
  }
  if (*(char *)((longlong)pfVar3 + 0x3b) == '\b') {
    puVar4 = (undefined8 *)param_2[1];
    piVar5 = (int *)*puVar4;
    fVar25 = (float)piVar5[1];
    fVar21 = (float)piVar5[3] +
             *(float *)(*(longlong *)(*(longlong *)**(undefined8 **)(param_1[7] + 8) + 0x110) +
                       0x260);
    if (fVar21 <= (float)piVar5[2]) {
      fVar19 = *(float *)(*param_1 + 8);
      if (DAT_1402d2e20 <= fVar21 - fVar19) {
        if (DAT_1402d23c0 < fVar21 - fVar19) {
          fVar21 = fVar19 - DAT_1402d24d0;
        }
      }
      else {
        fVar21 = fVar19 - DAT_1402d2638;
      }
    }
    else {
      fVar21 = (float)piVar5[3] + *(float *)(*(longlong *)puVar4[1] + 8);
    }
    plVar14 = (longlong *)puVar4[1];
    if (fVar21 < *(float *)(*plVar14 + 8)) {
      if (1 < *piVar5) {
        lVar12 = 1;
        do {
          plVar14 = plVar14 + 3;
          if (*(float *)(*plVar14 + 8) <= fVar21) goto LAB_140127e32;
          uVar16 = (ulonglong)((int)uVar16 + 1);
          lVar12 = lVar12 + 1;
        } while (lVar12 < *piVar5);
      }
      lVar17 = (ulonglong)(byte)param_1[0xb][0] * 0x10;
      lVar12 = *(longlong *)(*(longlong *)param_1[6] + 8);
      if ((int)(uint)(byte)param_1[10][0xf] < (int)(**(byte **)(lVar17 + lVar12) - 1)) {
        bVar13 = param_1[10][0xf] + 1;
        param_1[10][0xf] = bVar13;
        FUN_140126b00(param_1,(ulonglong)bVar13 * 0x40 + *(longlong *)(lVar17 + 8 + lVar12));
        return;
      }
      return;
    }
    uVar16 = 0;
LAB_140127e32:
    iVar15 = (int)uVar16;
    *(int *)param_1[10] = iVar15;
    pfVar3 = *(float **)(puVar4[1] + uVar16 * 0x18);
    fVar19 = pfVar3[1];
    if (iVar15 == 0) {
      fVar24 = *pfVar3;
      *(float *)(*param_1 + 8) = pfVar3[2];
      *(float *)(*param_1 + 4) = fVar19;
      *(float *)*param_1 = fVar24;
      *(undefined4 *)(*param_1 + 0xc) = 0x3f800000;
      fVar24 = pfVar3[5];
      fVar25 = pfVar3[3];
      *(float *)(param_1[1] + 4) = pfVar3[4];
      *(float *)(param_1[1] + 8) = fVar24;
      *(float *)param_1[1] = fVar25;
      *(undefined4 *)(param_1[1] + 0xc) = 0;
      return;
    }
    fVar18 = pfVar3[2];
    local_124 = pfVar3[4];
    fVar39 = *pfVar3;
    local_128 = pfVar3[3];
    local_120 = pfVar3[5];
    pfVar3 = *(float **)(puVar4[1] + (ulonglong)(iVar15 - 1) * 0x18);
    fVar20 = pfVar3[2];
    local_134 = pfVar3[4];
    local_138 = pfVar3[3];
    fVar23 = *pfVar3;
    fVar29 = pfVar3[1];
    fVar31 = (fVar21 - fVar20) / (fVar18 - fVar20);
    local_130 = pfVar3[5];
    fVar21 = fVar20;
    local_12c = fVar24;
    local_11c = fVar24;
    FUN_140203270(param_1 + 1,&local_138,&local_128,fVar31);
    fVar24 = fVar25 * DAT_1402d2d18;
    fVar25 = fVar25 * DAT_1402d2104;
    local_108 = ZEXT816(0);
    local_118 = ZEXT816(0);
    _local_f8 = ZEXT816(0);
    _local_e8 = local_108;
    FUN_140202920(local_118,&local_138);
    fVar35 = fVar24 * fStack_ec + fStack_dc;
    fVar34 = fVar24 * fStack_f0 + fVar21 + fStack_e0;
    fVar28 = fVar24 * (float)local_f8._4_4_ + fVar29 + (float)local_e8._4_4_;
    fVar22 = fVar24 * (float)local_f8._0_4_ + fVar23 + (float)local_e8._0_4_;
    local_e8._4_4_ = fVar29 + (float)local_e8._4_4_;
    local_e8._0_4_ = fVar23 + (float)local_e8._0_4_;
    fStack_e0 = fVar21 + fStack_e0;
    FUN_140202920(local_118,&local_128);
    fVar21 = DAT_1402d22d0 - fVar31;
    fVar24 = fVar21 * fVar21 * fVar21;
    fVar32 = fVar21 * DAT_1402d241c * fVar21 * fVar31;
    fVar6 = fVar21 * DAT_1402d241c * fVar31 * fVar31;
    fVar31 = fVar31 * fVar31 * fVar31;
    *(float *)*param_1 =
         fVar39 * fVar31 +
         (fVar25 * (float)local_f8._0_4_ + fVar39 + (float)local_e8._0_4_) * fVar6 +
         fVar24 * fVar23 + fVar22 * fVar32;
    fVar21 = fVar6 * (fVar25 * fStack_ec + fStack_dc) + fVar32 * fVar35 + fVar24 + fVar31;
    *(float *)(*param_1 + 4) =
         fVar19 * fVar31 +
         fVar6 * (fVar25 * (float)local_f8._4_4_ + fVar19 + (float)local_e8._4_4_) +
         fVar24 * fVar29 + fVar28 * fVar32;
    *(float *)(*param_1 + 8) =
         fVar31 * fVar18 +
         fVar6 * (fVar25 * fStack_f0 + fStack_e0 + fVar18) + fVar24 * fVar20 + fVar34 * fVar32;
    goto LAB_140128460;
  }
  if ((uVar2 & 8) == 0) {
    fVar25 = (float)FUN_140272370(uVar26,SQRT(auVar30._0_4_ * auVar30._0_4_ + fVar21 * fVar21));
    local_138 = fVar25;
    local_134 = (float)FUN_140272370(auVar30._0_8_);
    local_134 = local_134 + DAT_1402d2420;
    local_130 = 0.0;
    local_12c = 0.0;
    if (DAT_1402d2420 < local_134) {
      local_134 = local_134 - DAT_1402d249c;
    }
    if ((uVar2 & 4) != 0) {
      fVar21 = *(float *)(param_1[1] + 4);
      fVar39 = local_134 - fVar21;
      auVar1 = vcvtdq2ps_avx(ZEXT116((byte)param_1[0xb][3]));
      fVar20 = auVar36._0_4_ / auVar1._0_4_;
      fVar18 = fVar19 * pfVar3[5] * fVar20;
      auVar1 = vcmpss_avx(ZEXT416((uint)DAT_1402d2420),ZEXT416((uint)fVar39),1);
      auVar1 = vblendvps_avx(ZEXT416((uint)fVar39),ZEXT416((uint)(fVar39 - DAT_1402d249c)),auVar1);
      auVar7 = vcmpss_avx(auVar1,ZEXT416(DAT_1402d2db4),1);
      auVar1 = vblendvps_avx(auVar1,ZEXT416((uint)(auVar1._0_4_ + DAT_1402d249c)),auVar7);
      if (auVar1._0_4_ <= fVar18) {
        if ((float)((uint)fVar18 ^ uVar38) <= auVar1._0_4_) {
          *(float *)(param_1[9] + 8) = (float)(int)*(short *)(pfVar3 + 0xd) * DAT_1402d2360 * fVar20
          ;
          goto LAB_1401282ba;
        }
        local_134 = fVar21 - fVar18;
      }
      else {
        local_134 = fVar18 + fVar21;
      }
      *(undefined4 *)(param_1[9] + 8) = 0;
    }
  }
  else {
    fVar18 = (float)(byte)param_1[0xb][3];
    fVar21 = (((float)(int)*(short *)(pfVar3 + 0xd) * DAT_1402d20dc) / fVar18) * fVar25;
    if (*(float *)(param_1[9] + 8) < fVar21) {
      fVar21 = (pfVar3[6] / (fVar18 * fVar18)) * fVar25 + *(float *)(param_1[9] + 8);
    }
    *(float *)(param_1[9] + 8) = fVar21;
    local_134 = *(float *)(param_1[1] + 4);
    local_130 = *(float *)(param_1[1] + 8);
    local_12c = *(float *)(param_1[1] + 0xc);
    fVar21 = auVar36._0_4_ / (float)(byte)param_1[0xb][3];
    if (fVar21 * DAT_1402d2894 <= *(float *)(param_1[9] + 8)) {
      fVar25 = DAT_1402d2174;
      if (*(float *)param_1[1] < DAT_1402d2174) {
        fVar25 = fVar21 * DAT_1402d2054 + *(float *)param_1[1];
      }
      local_138 = fVar25;
    }
    else {
      fVar25 = 0.0;
      local_138 = 0.0;
    }
  }
LAB_1401282ba:
  local_118 = ZEXT816(0);
  local_108 = ZEXT816(0);
  fVar23 = local_134;
  fVar29 = local_130;
  fVar32 = local_12c;
  _local_f8 = local_118;
  _local_e8 = local_108;
  FUN_140202920(local_118,&local_138);
  fVar20 = (float)(*(uint *)(param_1[9] + 8) ^ uVar38);
  fVar18 = fVar20 * (float)local_f8._0_4_;
  fVar21 = fVar20 * fStack_ec;
  fVar39 = fVar20 * fStack_f0;
  fVar20 = fVar20 * (float)local_f8._4_4_;
  if (*(char *)((longlong)pfVar3 + 0x3b) == '\x06') {
    auVar1 = param_1[3];
    *(float *)param_1[3] = fVar18 + auVar1._0_4_;
    auVar7 = vshufps_avx(auVar1,auVar1,0x55);
    auVar8 = vshufps_avx(auVar1,auVar1,0xaa);
    *(float *)(param_1[3] + 4) = fVar20 + auVar7._0_4_;
    auVar1 = vshufps_avx(auVar1,auVar1,0xff);
    *(float *)(param_1[3] + 8) = fVar39 + auVar8._0_4_;
    *(float *)(param_1[3] + 0xc) = fVar21 + auVar1._0_4_;
  }
  if ((*(byte *)((longlong)pfVar3 + 0x36) & 0x80) != 0) {
    local_124 = fVar19 * pfVar3[10];
    local_128 = fVar19 * pfVar3[9];
    local_120 = fVar19 * pfVar3[0xb];
    fVar25 = pfVar3[2] - *(float *)param_1[4];
    fVar19 = pfVar3[4] - *(float *)(param_1[4] + 8);
    fVar23 = pfVar3[3] - *(float *)(param_1[4] + 4);
    local_11c = fVar24;
    FUN_140203270(&local_138,param_1 + 5,&local_128,
                  (auVar36._0_4_ /
                  SQRT(*(float *)(param_1[4] + 0xc) * *(float *)(param_1[4] + 0xc) +
                       fVar19 * fVar19 + fVar23 * fVar23 + fVar25 * fVar25)) *
                  SQRT(*(float *)(param_1[3] + 0xc) * *(float *)(param_1[3] + 0xc) +
                       *(float *)(param_1[3] + 8) * *(float *)(param_1[3] + 8) +
                       *(float *)(param_1[3] + 4) * *(float *)(param_1[3] + 4) +
                       *(float *)param_1[3] * *(float *)param_1[3]));
    fVar25 = local_138;
    fVar23 = local_134;
    fVar29 = local_130;
    fVar32 = local_12c;
  }
  auVar1 = *param_1;
  *(float *)*param_1 = auVar1._0_4_ + fVar18;
  auVar7 = vshufps_avx(auVar1,auVar1,0x55);
  auVar8 = vshufps_avx(auVar1,auVar1,0xaa);
  *(float *)(*param_1 + 4) = fVar20 + auVar7._0_4_;
  auVar1 = vshufps_avx(auVar1,auVar1,0xff);
  *(float *)(*param_1 + 8) = fVar39 + auVar8._0_4_;
  fVar21 = fVar21 + auVar1._0_4_;
  *(float *)param_1[1] = fVar25;
  *(float *)(param_1[1] + 4) = fVar23;
  *(float *)(param_1[1] + 8) = fVar29;
  *(float *)(param_1[1] + 0xc) = fVar32;
LAB_140128460:
  *(float *)(*param_1 + 0xc) = fVar21;
  return;
}

