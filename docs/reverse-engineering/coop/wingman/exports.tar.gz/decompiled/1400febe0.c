/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400febe0; RVA 0xfebe0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400febe0(longlong param_1)

{
  byte *pbVar1;
  uint *puVar2;
  byte bVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong lVar7;
  char cVar8;
  int iVar9;
  uint uVar10;
  longlong lVar11;
  float fVar12;
  
  lVar7 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  uVar10 = *(uint *)(param_1 + 0x3a8);
  lVar11 = *(longlong *)(lVar7 + 0x1b8);
  *(uint *)(param_1 + 0x3a8) = uVar10 | 0x20;
  if ((*(byte *)(lVar7 + 0x1f0) & 2) == 0) {
    *(undefined4 *)(param_1 + 0x378) = 0;
    *(undefined1 *)(param_1 + 0x3cc) = 5;
    if (*(char *)(param_1 + 0x3e6) != '\x05') {
      *(undefined1 *)(param_1 + 0x3e6) = 4;
    }
  }
  if ((uVar10 & 4) == 0) {
    *(float *)(lVar7 + 0x25c) = *(float *)(lVar7 + 0x25c) + DAT_1402d22d0;
  }
  iVar9 = *(int *)(param_1 + 0x378);
  if (iVar9 < (int)((uint)*(byte *)(param_1 + 0x3d1) * 9)) {
    if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
      iVar9 = iVar9 + 1;
      *(int *)(param_1 + 0x378) = iVar9;
    }
    fVar12 = ((float)iVar9 / (float)*(byte *)(param_1 + 0x3d1)) * DAT_1402d1fb4;
    *(float *)(lVar11 + 0x1d7c) = fVar12 + DAT_1402d20b0;
    *(float *)(lVar11 + 0x1d78) = fVar12;
    bVar3 = *(byte *)(param_1 + 0x3d1);
    fVar12 = 0.0;
    if ((int)((uint)bVar3 * 8) <= *(int *)(param_1 + 0x378)) {
      fVar12 = (float)(int)(*(int *)(param_1 + 0x378) + (uint)bVar3 * -8) / (float)bVar3;
    }
    *(float *)(param_1 + 0x3a0) = fVar12;
  }
  else {
    lVar4 = *(longlong *)(param_1 + 0x310);
    if (lVar4 != 0) {
      *(undefined8 *)(lVar4 + 0x568) = 0;
      *(undefined4 *)(lVar4 + 0x40) = 0;
      *(undefined4 *)(lVar4 + 0x2a8) = 0;
      *(undefined2 *)(lVar4 + 0x2ac) = 0xffff;
      *(undefined4 *)(lVar4 + 0x2f8) = 0;
      *(undefined4 *)(lVar4 + 0x468) = 0;
      puVar2 = (uint *)(*(longlong *)(param_1 + 0x310) + 0x56c);
      *puVar2 = *puVar2 & 0xfffffffd;
    }
    lVar4 = *(longlong *)(param_1 + 0x318);
    if ((lVar4 != 0) && (puVar5 = *(undefined8 **)(param_1 + 0x2f8), puVar5 != (undefined8 *)0x0)) {
      cVar8 = (char)*(int *)(*(longlong *)*puVar5 + 0x118) + -1;
      if (*(int *)(*(longlong *)*puVar5 + 0x118) < 1) {
        cVar8 = '\0';
      }
      *(char *)(lVar4 + 0x20) = cVar8;
      *(undefined1 *)(lVar4 + 0x22) = *(undefined1 *)(puVar5 + 0xd);
      *(byte *)(lVar4 + 0x21) = ~*(byte *)((longlong)puVar5 + 0x69) & 1;
      *(undefined8 *)(lVar4 + 0x18) = 0;
      *(undefined1 *)(lVar4 + 0x23) = 0;
    }
    lVar4 = *(longlong *)(param_1 + 800);
    if (lVar4 != 0) {
      *(byte *)(lVar4 + 0x2b) = *(byte *)(lVar4 + 0x2b) & 0xfd;
      if (*(longlong *)(lVar4 + 0x10) != 0) {
        puVar2 = (uint *)(*(longlong *)(lVar4 + 0x10) + 0x56c);
        *puVar2 = *puVar2 & 0xfffffffe;
      }
      if (*(longlong *)(lVar4 + 0x18) != 0) {
        pbVar1 = (byte *)(*(longlong *)(lVar4 + 0x18) + 0x23);
        *pbVar1 = *pbVar1 & 0xfb;
      }
      lVar4 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
      if (lVar4 != 0) {
        puVar2 = (uint *)(lVar4 + 0x40);
        *puVar2 = *puVar2 & 0xfbffffff;
      }
    }
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a5f00();
    }
    uVar10 = *(uint *)(lVar11 + 0x2058);
    if ((uVar10 >> 0xd & 1) != 0) {
      uVar10 = uVar10 & 0xffffdfff;
      *(undefined1 *)(lVar11 + 0x2096) = *(undefined1 *)(lVar11 + 0x2095);
    }
    *(byte *)(lVar11 + 0x1da7) = *(byte *)(lVar11 + 0x1da7) & 0xfe;
    *(undefined8 *)(lVar11 + 0x1d78) = 0;
    iVar9 = 1;
    *(byte *)(lVar11 + 0x1677) = *(byte *)(lVar11 + 0x1677) & 0xfe;
    *(byte *)(lVar11 + 0x1676) = *(byte *)(lVar11 + 0x1676) & 0xfc;
    *(byte *)(lVar11 + 0x1863) = *(byte *)(lVar11 + 0x1863) & 0xfb;
    *(uint *)(lVar11 + 0x2058) = uVar10 & 0xffffff7f;
    *(ushort *)(lVar7 + 0x428) = (ushort)*(byte *)(lVar7 + 0x42a);
    plVar6 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
    lVar7 = *plVar6;
    if (1 < *(int *)(lVar7 + 0x118)) {
      lVar11 = 0x520;
      do {
        lVar7 = *(longlong *)(*(longlong *)(lVar7 + 0x110) + 0x1c0 + lVar11);
        if (lVar7 != 0) {
          (**(code **)(**(longlong **)(lVar7 + 0x10) + 0x1c8))();
        }
        lVar7 = *plVar6;
        iVar9 = iVar9 + 1;
        lVar11 = lVar11 + 0x520;
      } while (iVar9 < *(int *)(lVar7 + 0x118));
    }
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 2;
  }
  return;
}

