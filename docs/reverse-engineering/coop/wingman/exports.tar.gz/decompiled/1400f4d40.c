/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f4d40; RVA 0xf4d40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400f4d40(longlong param_1)

{
  byte *pbVar1;
  uint *puVar2;
  byte bVar3;
  uint uVar4;
  undefined8 *puVar5;
  char *pcVar6;
  ushort *puVar7;
  longlong lVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  undefined1 auVar11 [16];
  char cVar12;
  undefined1 uVar13;
  char cVar14;
  ushort uVar15;
  undefined8 uVar16;
  longlong lVar17;
  char *pcVar18;
  longlong lVar19;
  uint uVar20;
  ulonglong uVar21;
  int iVar22;
  bool bVar23;
  float fVar24;
  undefined1 auVar25 [64];
  
  uVar4 = *(uint *)(param_1 + 0x3a8);
  cVar12 = *(char *)(param_1 + 0x3d3);
  uVar20 = uVar4 & 0xffffffbf;
  *(undefined1 *)(param_1 + 0x3dc) = 0;
  *(uint *)(param_1 + 0x3a8) = uVar20;
  if (cVar12 == -1) {
    cVar12 = *(char *)(param_1 + 0x3d2);
  }
  else {
    *(char *)(param_1 + 0x3d2) = cVar12;
    if (cVar12 != '\0') {
      *(undefined1 *)(param_1 + 0x3cb) = 0;
      *(char *)(param_1 + 0x3ce) = '\0';
    }
    *(undefined1 *)(param_1 + 0x3d3) = 0xff;
  }
  cVar14 = *(char *)(param_1 + 0x3cf);
  if (cVar14 != -1) {
    if (cVar12 == '\0') {
      *(char *)(param_1 + 0x3cd) = cVar14;
    }
    else {
      *(char *)(param_1 + 0x3ce) = cVar14;
    }
    *(undefined1 *)(param_1 + 0x3cf) = 0xff;
  }
  if (cVar12 == '\0') {
    *(undefined8 *)(param_1 + 0x2d8) = *(undefined8 *)(param_1 + 0x2e0);
    *(undefined1 *)(param_1 + 0x3c9) = *(undefined1 *)(param_1 + 0x3ca);
    uVar13 = *(undefined1 *)(param_1 + 0x3cd);
LAB_1400f4e1d:
    *(undefined1 *)(param_1 + 0x3cc) = uVar13;
  }
  else {
    if (cVar12 == '\x01') {
      uVar16 = *(undefined8 *)(param_1 + 0x2e8);
LAB_1400f4e06:
      *(undefined8 *)(param_1 + 0x2d8) = uVar16;
      *(undefined1 *)(param_1 + 0x3c9) = *(undefined1 *)(param_1 + 0x3cb);
      uVar13 = *(undefined1 *)(param_1 + 0x3ce);
      goto LAB_1400f4e1d;
    }
    if (cVar12 == '\x02') {
      uVar16 = *(undefined8 *)(param_1 + 0x2f0);
      goto LAB_1400f4e06;
    }
  }
  if (*(longlong *)(param_1 + 0x2d8) == 0) {
    return;
  }
  lVar17 = *(longlong *)(*(longlong *)(param_1 + 0x2d8) + 8);
  if (lVar17 == 0) {
    return;
  }
  uVar21 = (ulonglong)*(byte *)(param_1 + 0x3c9);
  if ((uVar4 & 1) != 0) {
    return;
  }
  iVar22 = 1;
  cVar12 = **(char **)(lVar17 + uVar21 * 0x48);
  auVar25 = ZEXT464(DAT_1402d22d0);
  if (cVar12 == '\0') {
    FUN_1400f5b60(param_1,*(undefined8 *)(lVar17 + 8 + uVar21 * 0x48));
  }
  else if (cVar12 == '\x04') {
    FUN_1400fbda0(param_1,*(undefined8 *)(lVar17 + 0x10 + uVar21 * 0x48));
  }
  else if (cVar12 == '\x05') {
    plVar10 = *(longlong **)(lVar17 + 0x18 + uVar21 * 0x48);
    *(undefined1 *)(param_1 + 0x3e6) = 0;
    if ((plVar10 != (longlong *)0x0) && (*(undefined8 **)(param_1 + 0x2f8) != (undefined8 *)0x0)) {
      cVar14 = *(char *)(param_1 + 0x3cc);
      lVar17 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
      lVar8 = *(longlong *)(lVar17 + 0x1b8);
      if (cVar14 == '\0') {
        FUN_1400fdd50(param_1,plVar10);
      }
      else if (cVar14 == '\x01') {
        FUN_1400fe1d0(param_1,plVar10);
      }
      else if (cVar14 == '\x02') {
        FUN_1400fe530(param_1,plVar10);
      }
      else if (cVar14 == '\x03') {
        FUN_1400fe730(param_1,plVar10);
      }
      else if (cVar14 == '\x04') {
        FUN_1400febe0(param_1);
      }
      else if (cVar14 == '\x05') {
        FUN_1400feeb0(param_1);
      }
      FUN_1400ff220(param_1,0);
      lVar19 = *(longlong *)
                (*(longlong *)
                  (**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(*plVar10 + 0x2f) * 8) +
                0x110) + (ulonglong)*(byte *)(*plVar10 + 0x30) * 0x520;
      fVar24 = DAT_1402d287c;
      if (lVar19 != 0) {
        fVar24 = DAT_1402d287c + *(float *)(lVar19 + 0x25c);
      }
      *(bool *)(lVar8 + 0x1dad) = *(float *)(lVar17 + 0x25c) < fVar24;
    }
  }
  else if (cVar12 == '\x06') {
    FUN_1400ff3f0(param_1,*(undefined8 *)(lVar17 + 0x20 + uVar21 * 0x48));
  }
  else if (cVar12 == '\x01') {
    puVar9 = *(undefined8 **)(lVar17 + 0x28 + uVar21 * 0x48);
    puVar5 = *(undefined8 **)(param_1 + 0x2f8);
    lVar17 = *(longlong *)(*(longlong *)(*(longlong *)*puVar5 + 0x110) + 0x1b8);
    if ((puVar9 != (undefined8 *)0x0) && (puVar5 != (undefined8 *)0x0)) {
      uVar20 = uVar4 & 0xfffe7fbf;
      pcVar6 = (char *)*puVar9;
      *(uint *)(param_1 + 0x3a8) = uVar20;
      if (*(char *)(param_1 + 0x3cc) == '\0') {
        if ((uVar20 >> 0xe & 1) != 0) {
          pcVar18 = &DAT_14030c8d9;
          do {
            if ((pcVar18[-1] == *(char *)(param_1 + 0x3d6)) && (*pcVar18 == *pcVar6)) {
              FUN_1401023b0(param_1);
              goto LAB_1400f52e2;
            }
            pcVar18 = pcVar18 + 2;
          } while ((longlong)pcVar18 < 0x14030c8db);
        }
        *(undefined4 *)(param_1 + 0x3a0) = 0;
        *(uint *)(param_1 + 0x3a8) = uVar4 & 0xfffe3fb7 | 0x20;
        *(byte *)(lVar17 + 0x1863) = *(byte *)(lVar17 + 0x1863) | 1;
        *(undefined4 *)(lVar17 + 0x185c) = 0;
        *(undefined8 *)(lVar17 + 0x1d78) = 0;
        *(byte *)(lVar17 + 0x1da7) = *(byte *)(lVar17 + 0x1da7) | 1;
        *(uint *)(lVar17 + 0x2058) = *(uint *)(lVar17 + 0x2058) & 0xffffffdf;
        if (*(longlong *)(param_1 + 0x340) != 0) {
          FUN_1400d1560(*(longlong *)(param_1 + 0x340),(pcVar6[1] & 1U) != 0);
        }
        auVar11 = vpcmpeqd_avx(ZEXT116(pcVar6[1] & 2),SUB6416(ZEXT464(0),0));
        auVar11 = vblendvps_avx(auVar25._0_16_,ZEXT816(0),auVar11);
        *(int *)(param_1 + 0x398) = auVar11._0_4_;
        cVar14 = *pcVar6;
        *(undefined1 *)(param_1 + 0x3cc) = 1;
        if (cVar14 == '\0') {
          cVar14 = '\x01';
        }
        *(char *)(param_1 + 0x3d5) = cVar14 + -1;
      }
      else if (*(char *)(param_1 + 0x3cc) == '\x01') {
        *(undefined1 *)(param_1 + 0x3cc) = 2;
        *(uint *)(param_1 + 0x3a8) = uVar20 | 0x20;
        if ((*(byte *)(param_1 + 0x3c9) == 0) && (*(char *)(param_1 + 0x3d4) == '\0')) {
          FUN_1401363c0(puVar5,0);
        }
      }
    }
  }
  else if (cVar12 == '\x02') {
    puVar9 = *(undefined8 **)(lVar17 + 0x30 + uVar21 * 0x48);
    cVar14 = *(char *)(param_1 + 0x3cc);
    uVar20 = uVar4 & 0xfffe7fbf;
    *(uint *)(param_1 + 0x3a8) = uVar20;
    plVar10 = DAT_14032c8c0;
    if (cVar14 == '\0') {
      *(undefined4 *)(param_1 + 0x3a0) = 0;
      *(uint *)(param_1 + 0x3a8) = uVar4 & 0xfffe3fb7 | 0x60;
      FUN_1400cbac0(*(undefined8 *)(param_1 + 0x340),*(undefined1 *)*puVar9);
      *(char *)(param_1 + 0x3cc) = '\x01';
    }
    else if (cVar14 == '\x01') {
      *(uint *)(param_1 + 0x3a8) = uVar20 | 0x20;
      if (((char)plVar10[0x10] != -1) &&
         (bVar3 = *(byte *)((longlong)*(char *)(*plVar10 + 0x2e) * 0x1b + 0x10 + (longlong)plVar10),
         (*(uint *)(*plVar10 + 0x40 + (ulonglong)(bVar3 >> 5) * 4) >> (bVar3 & 0x1f) & 1) != 0)) {
        *(undefined1 *)(*(longlong *)(param_1 + 0x340) + 0xa891d) = 1;
      }
      if (*(char *)(*(longlong *)(param_1 + 0x340) + 0xa891c) != '\0') {
        *(undefined1 *)(param_1 + 0x3cc) = 2;
      }
    }
    else if (cVar14 == '\x02') {
      *(uint *)(param_1 + 0x3a8) = uVar20 | 2;
    }
  }
  else if (cVar12 == '\x03') {
    *(uint *)(param_1 + 0x3a8) = uVar4 & 0xfffe3fbf | 0x20;
    if (*(char *)(param_1 + 0x3cc) == '\0') {
      *(undefined1 *)(param_1 + 0x3cc) = 1;
    }
  }
  else if (cVar12 == '\a') {
    puVar7 = (ushort *)**(undefined8 **)(lVar17 + 0x40 + uVar21 * 0x48);
    lVar17 = (*(undefined8 **)(param_1 + 0x300))[3];
    if (lVar17 == 0) {
LAB_1400f52a1:
      uVar15 = 0;
    }
    else {
      puVar9 = (undefined8 *)**(undefined8 **)(param_1 + 0x300);
      if (puVar9 == (undefined8 *)0x0) {
        uVar15 = 0;
      }
      else {
        if (*(ushort *)*puVar9 <= *puVar7) goto LAB_1400f52a1;
        uVar15 = *(ushort *)(lVar17 + (ulonglong)*puVar7 * 2);
      }
    }
    cVar14 = (char)puVar7[2];
    bVar23 = false;
    if (cVar14 == '\0') {
      bVar23 = uVar15 == puVar7[1];
LAB_1400f52bc:
      *(uint *)(param_1 + 0x3a8) = uVar20 | 2;
      if (!bVar23) goto LAB_1400f52e2;
    }
    else {
      if (cVar14 == '\x01') {
        bVar23 = (short)uVar15 <= (short)puVar7[1];
        goto LAB_1400f52bc;
      }
      if ((cVar14 != '\x02') || ((short)uVar15 < (short)puVar7[1])) goto LAB_1400f52bc;
    }
    *(uint *)(param_1 + 0x3a8) = uVar20 | 0x100003;
    *(undefined1 *)(param_1 + 0x3eb) = *(undefined1 *)((longlong)puVar7 + 5);
  }
LAB_1400f52e2:
  fVar24 = auVar25._0_4_;
  if (DAT_14033bd60 == '\0') {
    uVar16 = FUN_140019ef0();
    FUN_14001a850(uVar16,param_1);
    fVar24 = auVar25._0_4_;
  }
  if (((*(uint *)(param_1 + 0x3a8) & 0x4002) != 0x4000) || (cVar12 == '\x02')) goto LAB_1400f57a6;
  if (*(float *)(param_1 + 0x3a4) < fVar24) {
    *(float *)(param_1 + 0x3a4) =
         fVar24 / (float)*(byte *)(param_1 + 0x3d1) + *(float *)(param_1 + 0x3a4);
    goto LAB_1400f57a6;
  }
  *(undefined4 *)(param_1 + 0x3a4) = 0x3f800000;
  lVar17 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar8 = *(longlong *)(lVar17 + 0x1b8);
  *(undefined4 *)(lVar8 + 0x1640) = 0x41a00000;
  if (cVar12 == '\x01') goto LAB_1400f57a6;
  puVar9 = *(undefined8 **)(param_1 + 0x2d8);
  if ((((puVar9 == (undefined8 *)0x0) || (*(byte *)*puVar9 <= *(byte *)(param_1 + 0x3c9))) ||
      (puVar9 = (undefined8 *)(puVar9[1] + (ulonglong)*(byte *)(param_1 + 0x3c9) * 0x48),
      puVar9 == (undefined8 *)0x0)) || (*(char *)*puVar9 != '\0')) {
LAB_1400f5487:
    lVar19 = *(longlong *)(param_1 + 0x310);
    if (lVar19 != 0) {
      *(undefined8 *)(lVar19 + 0x568) = 0;
      *(undefined4 *)(lVar19 + 0x40) = 0;
      *(undefined4 *)(lVar19 + 0x2a8) = 0;
      *(undefined2 *)(lVar19 + 0x2ac) = 0xffff;
      *(undefined4 *)(lVar19 + 0x2f8) = 0;
      *(undefined4 *)(lVar19 + 0x468) = 0;
      puVar2 = (uint *)(*(longlong *)(param_1 + 0x310) + 0x56c);
      *puVar2 = *puVar2 & 0xfffffffd;
    }
    lVar19 = *(longlong *)(param_1 + 0x318);
    if ((lVar19 != 0) && (puVar9 = *(undefined8 **)(param_1 + 0x2f8), puVar9 != (undefined8 *)0x0))
    {
      if (*(int *)(*(longlong *)*puVar9 + 0x118) < 1) {
        cVar14 = '\0';
      }
      else {
        cVar14 = (char)*(int *)(*(longlong *)*puVar9 + 0x118) + -1;
      }
      *(char *)(lVar19 + 0x20) = cVar14;
      *(undefined1 *)(lVar19 + 0x22) = *(undefined1 *)(puVar9 + 0xd);
      *(byte *)(lVar19 + 0x21) = ~*(byte *)((longlong)puVar9 + 0x69) & 1;
      *(undefined8 *)(lVar19 + 0x18) = 0;
      *(undefined1 *)(lVar19 + 0x23) = 0;
    }
    lVar19 = *(longlong *)(param_1 + 800);
    if (lVar19 != 0) {
      if ((*(longlong *)(param_1 + 0x308) != 0) && (*(longlong *)(param_1 + 0x2f8) != 0)) {
        FUN_1401a8b40(lVar19,*(longlong *)(param_1 + 0x2f8));
      }
      lVar19 = *(longlong *)(param_1 + 800);
      *(byte *)(lVar19 + 0x2b) = *(byte *)(lVar19 + 0x2b) & 0xfd;
      if (*(longlong *)(lVar19 + 0x10) != 0) {
        puVar2 = (uint *)(*(longlong *)(lVar19 + 0x10) + 0x56c);
        *puVar2 = *puVar2 & 0xfffffffe;
      }
      if (*(longlong *)(lVar19 + 0x18) != 0) {
        pbVar1 = (byte *)(*(longlong *)(lVar19 + 0x18) + 0x23);
        *pbVar1 = *pbVar1 & 0xfb;
      }
      lVar19 = *(longlong *)(param_1 + 800);
      *(undefined8 *)(lVar19 + 0x32) = 0;
      *(undefined2 *)(lVar19 + 0x3a) = 0;
      *(undefined1 *)(lVar19 + 0x3c) = 0;
    }
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a5f00();
    }
    *(undefined4 *)(param_1 + 0x3a4) = 0;
    if (cVar12 == '\x04') {
      lVar17 = *(longlong *)(param_1 + 0x340);
      if ((*(uint *)(lVar17 + 0xa8790) >> 0x1d & 1) != 0) {
        *(uint *)(lVar17 + 0xa8790) = *(uint *)(lVar17 + 0xa8790) & 0xdfffffff;
        FUN_1400c3910(lVar17 + 0x697b8);
      }
    }
    else if (cVar12 == '\x06') {
      *(undefined1 *)(lVar8 + 0xc39) = 0;
      *(undefined4 *)(lVar8 + 0xcbc) = 0x42480000;
      *(uint *)(lVar8 + 0x2058) = *(uint *)(lVar8 + 0x2058) & 0xfffffbff;
      bVar3 = *(byte *)(param_1 + 0x3e2);
      *(uint *)(lVar17 + 0x1f0) = *(uint *)(lVar17 + 0x1f0) | 3;
      *(ushort *)(lVar17 + 0x428) = (ushort)bVar3;
      *(undefined2 *)(lVar8 + 0x208e) = *(undefined2 *)(param_1 + 0x3c2);
      *(undefined1 *)(lVar8 + 0x2099) = *(undefined1 *)(param_1 + 0x3e4);
      *(undefined1 *)(lVar8 + 0x209a) = *(undefined1 *)(param_1 + 0x3e5);
      *(float *)(lVar17 + 0x25c) = *(float *)(lVar17 + 0x25c) + DAT_1402d2aac;
    }
    else if (cVar12 == '\x05') {
      *(undefined1 *)(lVar8 + 0xc38) = 0;
      *(undefined8 *)(lVar8 + 0xccc) = 0;
      *(undefined8 *)(lVar8 + 0xcd4) = 0;
      *(undefined4 *)(lVar8 + 0xcdc) = 0;
      *(undefined4 *)(lVar8 + 0xce4) = 0x42480000;
      *(undefined4 *)(lVar8 + 0xce0) = 0x42480000;
      *(byte *)(lVar8 + 0x1677) = *(byte *)(lVar8 + 0x1677) & 0xfe;
      *(byte *)(lVar8 + 0x1676) = *(byte *)(lVar8 + 0x1676) & 0xfc;
      *(byte *)(lVar8 + 0x1863) = *(byte *)(lVar8 + 0x1863) & 0xfb;
      *(uint *)(lVar8 + 0x2058) = *(uint *)(lVar8 + 0x2058) & 0xffffff7f;
      bVar3 = *(byte *)(param_1 + 0x3e2);
      *(uint *)(lVar17 + 0x1f0) = *(uint *)(lVar17 + 0x1f0) | 3;
      *(ushort *)(lVar17 + 0x428) = (ushort)bVar3;
      *(undefined2 *)(lVar8 + 0x208e) = *(undefined2 *)(param_1 + 0x3c2);
      *(undefined1 *)(lVar8 + 0x2099) = *(undefined1 *)(param_1 + 0x3e4);
      *(undefined1 *)(lVar8 + 0x209a) = *(undefined1 *)(param_1 + 0x3e5);
      *(float *)(lVar17 + 0x25c) = *(float *)(lVar17 + 0x25c) + DAT_1402d2aac;
      plVar10 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
      lVar17 = *plVar10;
      if (1 < *(int *)(lVar17 + 0x118)) {
        lVar19 = 0x520;
        do {
          lVar17 = *(longlong *)(*(longlong *)(lVar17 + 0x110) + 0x1c0 + lVar19);
          if (lVar17 != 0) {
            (**(code **)(**(longlong **)(lVar17 + 0x10) + 0x1c8))();
          }
          lVar17 = *plVar10;
          iVar22 = iVar22 + 1;
          lVar19 = lVar19 + 0x520;
        } while (iVar22 < *(int *)(lVar17 + 0x118));
      }
    }
    if ((*(uint *)(lVar8 + 0x2058) >> 0xd & 1) != 0) {
      *(uint *)(lVar8 + 0x2058) = *(uint *)(lVar8 + 0x2058) & 0xffffdfff;
      *(undefined1 *)(lVar8 + 0x2096) = *(undefined1 *)(lVar8 + 0x2095);
    }
    *(undefined1 *)(lVar8 + 0x1dad) = 0;
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffbfff | 2;
    goto LAB_1400f57a6;
  }
  if (((*(char *)(param_1 + 0x3cc) == '\v') || ((byte)(*(char *)(param_1 + 0x3cc) - 0xcU) < 10)) ||
     ((cVar14 = *(char *)(param_1 + 0x3cc), cVar14 == '\x16' || ((byte)(cVar14 - 0x17U) < 3)))) {
    cVar14 = *(char *)(param_1 + 0x3cc);
    if (cVar14 != '\f') goto LAB_1400f5431;
LAB_1400f5457:
    uVar13 = 0x12;
  }
  else {
    if (cVar14 != '\x1a') goto LAB_1400f5487;
    cVar14 = '\x1a';
LAB_1400f5431:
    if ((byte)(cVar14 - 0xdU) < 5) goto LAB_1400f5457;
    if ((*(char *)(param_1 + 0x3cc) != '\x14') && (4 < (byte)(*(char *)(param_1 + 0x3cc) - 0x15U)))
    goto LAB_1400f57a6;
    *(undefined4 *)(param_1 + 0x3a4) = 0;
    uVar13 = 0x1a;
  }
  *(float *)(param_1 + 0x3a0) = fVar24;
  *(undefined1 *)(param_1 + 0x3cc) = uVar13;
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffbfff;
  *(undefined4 *)(param_1 + 0x37c) = 0;
LAB_1400f57a6:
  *(char *)(param_1 + 0x3ec) = cVar12;
  FUN_1400f5800(param_1);
  return;
}

