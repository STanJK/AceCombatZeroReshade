/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140100070; RVA 0x100070
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140100070(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  float fVar4;
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  int iVar9;
  float *pfVar10;
  longlong lVar11;
  uint uVar12;
  byte bVar13;
  longlong lVar14;
  float fVar15;
  undefined8 uVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  undefined2 local_res8 [4];
  undefined2 local_res10 [4];
  undefined1 local_118 [16];
  undefined1 local_108 [8];
  float fStack_100;
  float fStack_fc;
  undefined1 local_f8 [8];
  float fStack_f0;
  float fStack_ec;
  undefined1 local_e8 [8];
  float fStack_e0;
  float fStack_dc;
  undefined1 local_d8 [8];
  float fStack_d0;
  float fStack_cc;
  
  lVar11 = *param_2;
  lVar1 = *(longlong *)(*(longlong *)**(longlong **)(param_1 + 0x2f8) + 0x110);
  lVar2 = *(longlong *)(lVar1 + 0x1b8);
  uVar12 = *(uint *)(param_1 + 0x3a8) | 0x20;
  if (*(char *)(param_1 + 0x3da) != '\0') {
    uVar12 = *(uint *)(param_1 + 0x3a8) & 0xffffffdf;
  }
  *(uint *)(param_1 + 0x3a8) = uVar12;
  if ((uVar12 & 4) == 0) {
    *(int *)(param_1 + 0x378) = *(int *)(param_1 + 0x378) + 1;
    *(int *)(param_1 + 0x394) = *(int *)(param_1 + 0x394) + 1;
  }
  lVar14 = (ulonglong)*(byte *)(lVar11 + 0x21) * 0x520;
  lVar11 = *(longlong *)
            (*(longlong *)
              (**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar11 + 0x20) * 8) + 0x110);
  *(undefined8 *)(lVar11 + 0x3a0 + lVar14) = *(undefined8 *)(lVar11 + 0x390 + lVar14);
  if ((*(byte *)(param_1 + 0x3a8) & 4) != 0) {
    return;
  }
  _local_108 = ZEXT816(0);
  _local_f8 = ZEXT816(0);
  _local_e8 = _local_108;
  _local_d8 = _local_f8;
  FUN_140202920(local_108,lVar11 + 0x268 + lVar14);
  plVar3 = *(longlong **)(lVar11 + 0x390 + lVar14);
  fVar20 = (float)local_d8._0_4_ + *(float *)(lVar11 + 600 + lVar14);
  fVar19 = (float)local_d8._4_4_ + *(float *)(lVar11 + 0x25c + lVar14);
  fVar18 = fStack_d0 + *(float *)(lVar11 + 0x260 + lVar14);
  pfVar10 = (float *)(**(code **)(*plVar3 + 0x1b8))(plVar3,local_118);
  fVar22 = *pfVar10;
  fVar15 = pfVar10[1];
  fVar17 = pfVar10[3];
  fVar4 = pfVar10[2] + DAT_1402d250c;
  fVar21 = fVar18 * fVar17 + fVar4 * fStack_e0 + fVar15 * fStack_f0 + fVar22 * fStack_100;
  fVar18 = fVar19 * fVar17 +
           fVar4 * (float)local_e8._4_4_ +
           fVar15 * (float)local_f8._4_4_ + fVar22 * (float)local_108._4_4_;
  fVar19 = fVar17 * fStack_cc + fVar4 * fStack_dc + fVar15 * fStack_ec + fVar22 * fStack_fc;
  fVar22 = fVar20 * fVar17 +
           fVar4 * (float)local_e8._0_4_ +
           fVar15 * (float)local_f8._0_4_ + fVar22 * (float)local_108._0_4_;
  if (((*(ushort *)(lVar2 + 0x1b8) < 0x51) || (*(ushort *)(lVar2 + 0x1bc) < 0x51)) ||
     (*(int *)(*(longlong *)(lVar2 + 0x1d0) + 0x40) == 0)) {
    fVar15 = 0.0;
    fVar17 = 0.0;
    fVar20 = 0.0;
  }
  else {
    lVar14 = (ulonglong)**(ushort **)(*(longlong *)(lVar2 + 0x1d8) + 0x80) * 800;
    lVar11 = *(longlong *)(lVar2 + 0x1b0);
    fVar15 = *(float *)(lVar14 + 0xc4 + lVar11);
    fVar17 = *(float *)(lVar14 + 200 + lVar11);
    fVar20 = *(float *)(lVar14 + 0xcc + lVar11);
  }
  _local_f8 = ZEXT416(0);
  _local_108 = ZEXT816(0);
  _local_e8 = ZEXT816(0);
  _local_d8 = _local_f8;
  FUN_140202920(local_108,lVar1 + 0x268);
  fVar22 = fVar22 - (local_e8._0_4_ * fVar20 +
                     local_f8._0_4_ * fVar17 + fVar15 * (float)local_108._0_4_ +
                    (float)local_d8._0_4_ + *(float *)(lVar1 + 600));
  auVar5 = vshufps_avx(_local_f8,_local_f8,0x55);
  auVar6 = vshufps_avx(_local_e8,_local_e8,0x55);
  auVar7 = vshufps_avx(_local_f8,_local_f8,0xaa);
  auVar8 = vshufps_avx(_local_e8,_local_e8,0xaa);
  fVar18 = fVar18 - (auVar6._0_4_ * fVar20 + auVar5._0_4_ * fVar17 + fVar15 * (float)local_108._4_4_
                    + (float)local_d8._4_4_ + *(float *)(lVar1 + 0x25c));
  fVar21 = fVar21 - (auVar8._0_4_ * fVar20 + auVar7._0_4_ * fVar17 + fVar15 * fStack_100 +
                    fStack_d0 + *(float *)(lVar1 + 0x260));
  auVar5 = vshufps_avx(_local_f8,_local_f8,0xff);
  auVar6 = vshufps_avx(_local_e8,_local_e8,0xff);
  fVar19 = fVar19 - (auVar5._0_4_ * fVar17 + fVar15 * fStack_fc + auVar6._0_4_ * fVar20 + fStack_cc)
  ;
  if (DAT_1402d273c <= SQRT(fVar19 * fVar19 + fVar21 * fVar21 + fVar18 * fVar18 + fVar22 * fVar22))
  {
    *(undefined4 *)(param_1 + 0x388) = 0;
  }
  else {
    *(int *)(param_1 + 0x388) = *(int *)(param_1 + 0x388) + 1;
  }
  fVar22 = DAT_1402d2504;
  bVar13 = ~(byte)(*(uint *)(lVar1 + 0x1f0) >> 1) & 1;
  if (*(int *)(param_1 + 900) < 1) {
    bVar13 = 1;
    *(undefined1 *)(param_1 + 0x3e6) = 5;
  }
  else if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
    iVar9 = *(int *)(param_1 + 900) + -1;
    *(int *)(param_1 + 900) = iVar9;
    uVar12 = (uint)*(byte *)(param_1 + 0x3d1);
    if ((int)((uint)*(byte *)(param_1 + 0x3d1) * 5) < iVar9) {
      if (((float)iVar9 <= (float)uVar12 * fVar22) && (iVar9 % (int)uVar12 == 0)) {
        uVar16 = FUN_1401c56d0();
        local_res8[0] = 0;
        goto LAB_1401004dc;
      }
    }
    else if (iVar9 % (int)uVar12 == 0) {
      uVar16 = FUN_1401c56d0();
      local_res8[0] = 1;
LAB_1401004dc:
      local_res10[0] = 1;
      FUN_1401c6150(uVar16,local_res10,local_res8);
    }
  }
  if ((*(float *)(param_1 + 0x354) < *(float *)(lVar1 + 0x260)) ||
     (*(float *)(lVar1 + 0x260) < *(float *)(param_1 + 0x34c) ||
      (*(float *)(param_1 + 0x350) < *(float *)(lVar1 + 600) ||
      *(float *)(lVar1 + 600) < *(float *)(param_1 + 0x348)))) {
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a7df0(*(longlong *)(param_1 + 0x308),0);
    }
    lVar11 = FUN_1401c56d0();
    if ((DAT_14031f8b1 & 1) == 0) {
      FUN_140187110((int)(char)(&DAT_14031f8a8)
                               [(longlong)*(short *)(lVar11 + 4) + (ulonglong)DAT_14031f8b0 * 4],
                    1000);
    }
  }
  else if (bVar13 == 0) goto LAB_1401005b9;
  *(byte *)(param_1 + 0x3dc) = *(byte *)(param_1 + 0x3dc) | 1;
  *(undefined1 *)(param_1 + 0x3cc) = 4;
  *(undefined4 *)(param_1 + 0x378) = 0;
  if (*(char *)(param_1 + 0x3e6) != '\x05') {
    *(undefined1 *)(param_1 + 0x3e6) = 4;
  }
LAB_1401005b9:
  if ((int)((uint)*(byte *)(param_1 + 0x3d1) * 2) < *(int *)(param_1 + 0x388)) {
    fVar15 = (float)FUN_1401019d0(param_1);
    fVar17 = (float)*(int *)(param_1 + 0x3ac);
    if (fVar15 <= fVar17 * fVar22 + DAT_1402d27c8) {
      if (fVar15 <= fVar17 * fVar22 + DAT_1402d27a0) {
        if (fVar15 <= fVar17 * fVar22 + DAT_1402d2760) {
          *(char *)(param_1 + 0x3e9) = (fVar15 <= fVar17 * fVar22 + DAT_1402d2690) + '\x03';
        }
        else {
          *(undefined1 *)(param_1 + 0x3e9) = 2;
        }
      }
      else {
        *(undefined1 *)(param_1 + 0x3e9) = 1;
      }
    }
    else {
      *(undefined1 *)(param_1 + 0x3e9) = 0;
    }
    *(byte *)(lVar2 + 0x1863) = *(byte *)(lVar2 + 0x1863) | 1;
    *(undefined4 *)(lVar2 + 0x185c) = 0;
    *(undefined4 *)(param_1 + 0x378) = 0;
    *(undefined1 *)(param_1 + 0x3cc) = 3;
    *(undefined1 *)(lVar2 + 0x1dad) = 2;
    *(undefined1 *)(param_1 + 0x3e6) = 3;
  }
  return;
}

