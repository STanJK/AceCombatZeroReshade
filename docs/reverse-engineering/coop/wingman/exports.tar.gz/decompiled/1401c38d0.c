/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401c38d0; RVA 0x1c38d0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401c38d0(longlong *param_1)

{
  longlong lVar1;
  int iVar2;
  int iVar3;
  longlong *plVar4;
  int *piVar5;
  undefined *puVar6;
  
  puVar6 = &DAT_140316e78;
  if (DAT_14031cf18 == '\0') {
    puVar6 = &DAT_140310ec0;
  }
  piVar5 = &DAT_140291a28;
  *(undefined4 *)(param_1 + 0x17) = 0;
  do {
    iVar2 = piVar5[-2];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[-1];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = *piVar5;
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[1];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[2];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[3];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[4];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[5];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[6];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[7];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[8];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    iVar2 = piVar5[9];
    if ((puVar6[(longlong)iVar2 * 5 + 300] != '\0') &&
       (*(int *)(*(longlong *)(param_1[3] + 0x6c8) + 0xc + (longlong)iVar2 * 0x18) != 0)) {
      *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar2;
      *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
    }
    piVar5 = piVar5 + 0xc;
  } while ((longlong)piVar5 < 0x140291ab8);
  lVar1 = param_1[1];
  iVar2 = (**(code **)(*param_1 + 0x20))(param_1);
  if ((int)lVar1 == -1) {
    if (0 < iVar2) {
      *(undefined4 *)(param_1 + 1) = 0;
    }
    iVar2 = 0;
    if ((int)param_1[0x17] < 1) {
LAB_1401c3c36:
      *(undefined4 *)((longlong)param_1 + 0xc4) = 0;
    }
    else {
      plVar4 = param_1 + 5;
      do {
        if ((int)*plVar4 == *(int *)(puVar6 + (longlong)(int)param_1[4] * 4 + 0x24c)) {
          iVar3 = (**(code **)(*param_1 + 0x20))(param_1);
          if (iVar2 < iVar3) {
            *(int *)(param_1 + 1) = iVar2;
          }
          goto LAB_1401c3c36;
        }
        iVar2 = iVar2 + 1;
        plVar4 = (longlong *)((longlong)plVar4 + 4);
      } while (iVar2 < (int)param_1[0x17]);
      *(undefined4 *)((longlong)param_1 + 0xc4) = 0;
    }
  }
  else if (iVar2 <= (int)lVar1) {
    iVar2 = (**(code **)(*param_1 + 0x20))(param_1);
    if (0 < iVar2) {
      *(undefined4 *)(param_1 + 1) = 0;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0001401c3c6c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x10))(param_1);
  return;
}

