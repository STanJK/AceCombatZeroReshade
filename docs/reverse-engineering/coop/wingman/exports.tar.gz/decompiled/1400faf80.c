/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400faf80; RVA 0xfaf80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400faf80(longlong param_1)

{
  byte *pbVar1;
  uint *puVar2;
  byte bVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong lVar6;
  int iVar7;
  uint uVar8;
  longlong lVar9;
  float fVar10;
  
  lVar6 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  uVar8 = *(uint *)(param_1 + 0x3a8);
  lVar9 = *(longlong *)(lVar6 + 0x1b8);
  *(uint *)(param_1 + 0x3a8) = uVar8 | 0x20;
  if ((*(byte *)(lVar6 + 0x1f0) & 2) == 0) {
    *(undefined4 *)(param_1 + 0x37c) = 0;
    *(undefined1 *)(param_1 + 0x3cc) = 0x19;
    if (*(char *)(param_1 + 0x3e6) != '\x05') {
      *(undefined1 *)(param_1 + 0x3e6) = 4;
    }
  }
  fVar10 = DAT_1402d22d0;
  if ((uVar8 & 4) == 0) {
    *(float *)(lVar6 + 0x25c) = DAT_1402d22d0 + *(float *)(lVar6 + 0x25c);
  }
  iVar7 = *(int *)(param_1 + 0x37c);
  if (iVar7 < (int)((uint)*(byte *)(param_1 + 0x3d1) * 9)) {
    if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
      iVar7 = iVar7 + 1;
      *(int *)(param_1 + 0x37c) = iVar7;
    }
    fVar10 = ((float)iVar7 / (float)*(byte *)(param_1 + 0x3d1)) * DAT_1402d1fb4;
    *(float *)(lVar9 + 0x1d7c) = fVar10 + DAT_1402d20b0;
    *(float *)(lVar9 + 0x1d78) = fVar10;
    bVar3 = *(byte *)(param_1 + 0x3d1);
    fVar10 = 0.0;
    if ((int)((uint)bVar3 * 8) <= *(int *)(param_1 + 0x37c)) {
      fVar10 = (float)(int)(*(int *)(param_1 + 0x37c) + (uint)bVar3 * -8) / (float)bVar3;
    }
    *(float *)(param_1 + 0x3a0) = fVar10;
    return;
  }
  lVar4 = *(longlong *)(param_1 + 800);
  if (lVar4 != 0) {
    *(byte *)(lVar4 + 0x2b) = *(byte *)(lVar4 + 0x2b) & 0xfd;
    if (*(longlong *)(lVar4 + 0x10) != 0) {
      puVar2 = (uint *)(*(longlong *)(lVar4 + 0x10) + 0x56c);
      *puVar2 = *puVar2 & 0xfffffffe;
    }
    if (*(longlong *)(lVar4 + 0x18) != 0) {
      pbVar1 = (byte *)(*(longlong *)(lVar4 + 0x18) + 0x23);
      *pbVar1 = *pbVar1 & 0xfb;
    }
    lVar4 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
    if (lVar4 != 0) {
      puVar2 = (uint *)(lVar4 + 0x40);
      *puVar2 = *puVar2 & 0xfbffffff;
    }
  }
  uVar8 = *(uint *)(lVar9 + 0x2058);
  if ((uVar8 >> 0xd & 1) != 0) {
    uVar8 = uVar8 & 0xffffdfff;
    *(undefined1 *)(lVar9 + 0x2096) = *(undefined1 *)(lVar9 + 0x2095);
  }
  *(byte *)(lVar9 + 0x1da7) = *(byte *)(lVar9 + 0x1da7) & 0xfe;
  *(undefined8 *)(lVar9 + 0x1d78) = 0;
  iVar7 = 1;
  *(byte *)(lVar9 + 0x1677) = *(byte *)(lVar9 + 0x1677) & 0xfe;
  *(byte *)(lVar9 + 0x1676) = *(byte *)(lVar9 + 0x1676) & 0xfc;
  *(byte *)(lVar9 + 0x1863) = *(byte *)(lVar9 + 0x1863) & 0xfb;
  *(uint *)(lVar9 + 0x2058) = uVar8 & 0xffffff7f;
  *(ushort *)(lVar6 + 0x428) = (ushort)*(byte *)(lVar6 + 0x42a);
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x2f8);
  lVar6 = *plVar5;
  if (1 < *(int *)(lVar6 + 0x118)) {
    lVar9 = 0x520;
    do {
      lVar6 = *(longlong *)(*(longlong *)(lVar6 + 0x110) + 0x1c0 + lVar9);
      if (lVar6 != 0) {
        (**(code **)(**(longlong **)(lVar6 + 0x10) + 0x1c8))();
      }
      lVar6 = *plVar5;
      iVar7 = iVar7 + 1;
      lVar9 = lVar9 + 0x520;
    } while (iVar7 < *(int *)(lVar6 + 0x118));
  }
  *(undefined1 *)(param_1 + 0x3cc) = 0x1a;
  *(float *)(param_1 + 0x3a0) = fVar10;
  return;
}

