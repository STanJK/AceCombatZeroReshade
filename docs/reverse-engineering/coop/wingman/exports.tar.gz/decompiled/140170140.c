/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140170140; RVA 0x170140
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140170140(undefined8 param_1,longlong *param_2)

{
  int iVar1;
  undefined8 *puVar2;
  int *piVar3;
  uint uVar4;
  longlong lVar5;
  uint uVar6;
  uint uVar7;
  undefined **ppuVar8;
  
  if (*(char *)(DAT_14032c8f8 + 0x28) != -1) {
    *(char *)(DAT_14032c8f8 + 0x28) = *(char *)(DAT_14032c8f8 + 0x28) + '\x01';
  }
  iVar1 = (int)DAT_140316e20;
  if (DAT_14031cf18 != '\0') {
    iVar1 = (int)DAT_14031cdd8;
  }
  if (iVar1 < 0x13) {
    piVar3 = (int *)(&DAT_1402a9ac4 + (longlong)iVar1 * 8);
  }
  else {
    piVar3 = (int *)&DAT_00000004;
  }
  iVar1 = *piVar3;
  if (iVar1 != 0) {
    if (iVar1 == 1) {
      DAT_14030ffc4 = 0x16f;
      goto LAB_140170254;
    }
    if (iVar1 == 2) {
      DAT_14030ffc4 = 0x170;
      goto LAB_140170254;
    }
  }
  ppuVar8 = &PTR_PTR_140317918;
  if (DAT_14031cf18 == '\0') {
    ppuVar8 = (undefined **)&DAT_140311960;
  }
  uVar7 = 0;
  do {
    uVar6 = 0;
    do {
      uVar4 = 0;
      piVar3 = (int *)((longlong)ppuVar8 +
                      ((longlong)(int)uVar7 * 0x13 + 0x22 + (longlong)(int)uVar6) * 0xc);
      do {
        if (*piVar3 != 0) goto LAB_140170241;
        uVar4 = uVar4 + 1;
        piVar3 = piVar3 + 1;
      } while (uVar4 < 3);
      uVar6 = uVar6 + 1;
    } while (uVar6 < 0x12);
    if (*(int *)((longlong)(int)uVar7 * 0xe4 + 0x270 + (longlong)ppuVar8) == 0) {
      DAT_14030ffc4 = 0x171;
      goto LAB_140170254;
    }
LAB_140170241:
    uVar7 = uVar7 + 1;
  } while (uVar7 < 6);
  DAT_14030ffc4 = 0x16e;
LAB_140170254:
  FUN_1401c0050(&PTR_PTR_14030f860);
  puVar2 = &DAT_14031cdd8;
  DAT_14033bba8 = 1;
  if (DAT_14031cf18 == '\0') {
    puVar2 = &DAT_140316e20;
  }
  if (DAT_14031ce34 != 1) {
    *(undefined4 *)((longlong)puVar2 + 4) = 0xffffffff;
  }
  puVar2 = (undefined8 *)FUN_140200de0(DAT_14032c8f8,0x18,0x10);
  DAT_14030cab4 = DAT_14030cab4 + 1;
  DAT_14030c8cc = 0;
  lVar5 = (longlong)DAT_14030cab4;
  *puVar2 = &PTR_FUN_1402ba0f0;
  puVar2[1] = 0;
  (&DAT_140328458)[lVar5] = FUN_140179740;
  puVar2[2] = 0;
                    /* WARNING: Could not recover jumptable at 0x000140170307. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_2 + 0x18))(param_2,puVar2);
  return;
}

