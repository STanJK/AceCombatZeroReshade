/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f9bd0; RVA 0xf9bd0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400f9bd0(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  uint uVar5;
  longlong lVar6;
  bool bVar7;
  float fVar8;
  undefined8 local_res8;
  
  lVar6 = *param_2;
  lVar2 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar3 = *(longlong *)(lVar2 + 0x1b8);
  uVar5 = *(uint *)(param_1 + 0x3a8) & 0xfffffff7 | 0x20;
  if (*(char *)(param_1 + 0x3da) != '\0') {
    uVar5 = *(uint *)(param_1 + 0x3a8) & 0xffffffd7;
  }
  *(uint *)(param_1 + 0x3a8) = uVar5;
  if (((uVar5 & 4) == 0) && ((*(byte *)(lVar3 + 0x1676) & 1) != 0)) {
    bVar7 = false;
    if ((*(float *)(lVar2 + 600) < *(float *)(param_1 + 0x90)) ||
       (*(float *)(param_1 + 0xa0) < *(float *)(lVar2 + 600))) {
      bVar7 = true;
    }
    if ((*(float *)(lVar2 + 0x25c) < *(float *)(param_1 + 0x94)) ||
       (*(float *)(param_1 + 0xa4) < *(float *)(lVar2 + 0x25c))) {
      bVar7 = true;
    }
    if (((*(float *)(lVar2 + 0x260) < *(float *)(param_1 + 0x98)) ||
        (*(float *)(param_1 + 0xa8) < *(float *)(lVar2 + 0x260))) || (bVar7)) {
      local_res8 = 0;
      FUN_140118040(lVar2,&local_res8,0,1,0,0,3);
      *(uint *)(lVar2 + 0x1fc) = *(uint *)(lVar2 + 0x1fc) | 0x20000000;
    }
  }
  bVar7 = (*(byte *)(lVar2 + 0x1f0) & 2) != 0;
  if (!bVar7) {
    *(undefined2 *)(param_1 + 0x3be) = 0;
  }
  FUN_1401c56d0();
  if ((*(float *)(param_1 + 0x354) < *(float *)(lVar2 + 0x260)) ||
     (*(float *)(lVar2 + 0x260) < *(float *)(param_1 + 0x34c) ||
      (*(float *)(param_1 + 0x350) < *(float *)(lVar2 + 600) ||
      *(float *)(lVar2 + 600) < *(float *)(param_1 + 0x348)))) {
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a7df0(*(longlong *)(param_1 + 0x308),0);
    }
  }
  else if (bVar7) goto LAB_1400f9d80;
  *(byte *)(param_1 + 0x3dc) = *(byte *)(param_1 + 0x3dc) | 1;
  *(undefined4 *)(param_1 + 0x37c) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 0x11;
  if (*(char *)(param_1 + 0x3e6) != '\x05') {
    *(undefined1 *)(param_1 + 0x3e6) = 4;
  }
LAB_1400f9d80:
  if (((*(byte *)(lVar3 + 0x1676) & 3) == 0) || ((*(byte *)(lVar3 + 0x1676) & 2) != 0)) {
    if ((*(ushort *)(param_1 + 0x3a8) & 0x1000) != 0) {
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffefff;
    }
  }
  else if ((*(ushort *)(param_1 + 0x3a8) & 0x1000) == 0) {
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x1000;
  }
  if (*(float *)(lVar3 + 0x1848) <= 0.0) {
    lVar4 = *(longlong *)
             (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
    pbVar1 = (byte *)(lVar4 + 0x1863);
    *pbVar1 = *pbVar1 | 1;
    *(undefined4 *)(lVar4 + 0x185c) = 0xbf800000;
    *(undefined4 *)(param_1 + 0x37c) = 0;
    *(undefined1 *)(param_1 + 0x3cc) = 0x10;
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a5f00();
    }
    *(undefined1 *)(param_1 + 0x3e6) = 3;
  }
  lVar6 = *(longlong *)
           (*(longlong *)(**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar6 + 0x90) * 8)
           + 0x110) + (ulonglong)*(byte *)(lVar6 + 0x91) * 0x520;
  fVar8 = DAT_1402d287c;
  if (lVar6 != 0) {
    fVar8 = DAT_1402d287c + *(float *)(lVar6 + 0x25c);
  }
  *(bool *)(lVar3 + 0x1dad) = *(float *)(lVar2 + 0x25c) < fVar8;
  return;
}

