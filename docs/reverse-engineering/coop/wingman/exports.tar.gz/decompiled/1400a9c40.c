/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400a9c40; RVA 0xa9c40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400a9c40(longlong *param_1)

{
  int *piVar1;
  short *psVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  char cVar9;
  byte bVar10;
  byte bVar11;
  byte bVar12;
  ushort uVar13;
  ushort uVar14;
  uint uVar15;
  int iVar16;
  byte *pbVar17;
  byte *pbVar18;
  byte *pbVar19;
  float *pfVar20;
  ushort *puVar21;
  short *psVar22;
  float fVar23;
  int iVar24;
  int iVar25;
  int iVar26;
  ulonglong uVar27;
  longlong lVar28;
  char cVar29;
  uint *puVar30;
  longlong lVar31;
  int iVar32;
  longlong lVar33;
  longlong lVar34;
  bool bVar35;
  bool bVar36;
  bool bVar37;
  float fVar38;
  float fVar39;
  float fVar40;
  float fVar41;
  float fVar42;
  float fVar43;
  float fVar44;
  float fVar45;
  int local_res8;
  longlong local_res10;
  longlong local_res20;
  
  if (((undefined8 *)*param_1 != (undefined8 *)0x0) &&
     (uVar27 = (ulonglong)**(ushort **)*param_1, uVar27 != 0)) {
    lVar33 = 0;
    local_res20 = 0;
    fVar44 = 0.0;
    cVar29 = (char)local_res8;
    fVar45 = DAT_1402d22d0;
    fVar43 = DAT_1402d271c;
    do {
      local_res8 = 0;
      local_res10 = 0;
      pbVar17 = *(byte **)(*(longlong *)(*param_1 + 0x10) + local_res20 * 0x10);
      if (*pbVar17 != 0) {
LAB_1400a9d29:
        if ((*(byte *)(param_1[4] + lVar33) & 1) != 0) goto switchD_1400a9d9e_default;
        iVar26 = 1;
        lVar34 = 1;
        pbVar18 = *(byte **)(*(longlong *)(*(longlong *)(*param_1 + 0x10) + 8 + local_res20 * 0x10)
                            + local_res10 * 0x10);
        if (*pbVar18 < 2) {
LAB_1400aa3b0:
          if (cVar29 != '\0') {
            psVar22 = (short *)**(undefined8 **)
                                 (*(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(*param_1 + 0x10) + 8 + local_res20 * 0x10) + 8 +
                                   local_res10 * 0x10) + 8);
            if ((*(byte *)((longlong)psVar22 + 3) & 1) == 0) {
              *(byte *)(param_1[4] + lVar33) = *(byte *)(param_1[4] + lVar33) | 1;
            }
            if ((*(byte *)((longlong)psVar22 + 3) & 2) == 0) {
              cVar9 = (char)psVar22[1];
              if (cVar9 == '\0') {
                *(short *)(param_1[3] + local_res20 * 2) = *psVar22;
              }
              else if (cVar9 == '\x01') {
                psVar2 = (short *)(param_1[3] + local_res20 * 2);
                *psVar2 = *psVar2 + *psVar22;
              }
              else if (cVar9 == '\x02') {
                FUN_140189320();
                iVar26 = FUN_140242630();
                *(short *)(param_1[3] + local_res20 * 2) = (short)(iVar26 % (int)*psVar22) + 1;
              }
            }
            else if ((char)psVar22[1] == '\x01') {
              piVar1 = (int *)(*(longlong *)
                                (*(longlong *)(**(longlong **)param_1[1] + 0x110) + 0x1b8) + 0x2784)
              ;
              *piVar1 = *piVar1 + (int)*psVar22;
            }
          }
          goto switchD_1400a9d9e_default;
        }
LAB_1400a9d67:
        cVar29 = '\0';
        lVar31 = *(longlong *)
                  (*(longlong *)(*(longlong *)(*param_1 + 0x10) + 8 + local_res20 * 0x10) + 8 +
                  local_res10 * 0x10);
        switch(**(undefined1 **)(lVar31 + lVar34 * 0x48)) {
        case 1:
          pfVar20 = (float *)**(undefined8 **)(lVar31 + 0x10 + lVar34 * 0x48);
          cVar9 = *(char *)(pfVar20 + 1);
          if (((cVar9 == *(char *)(param_1[2] + 0x20)) &&
              (fVar38 = *pfVar20,
              (int)((float)*(byte *)(param_1 + 5) * fVar38) <=
              *(int *)(*(longlong *)(param_1[2] + 0x10) + 0x38c))) &&
             ((cVar9 != '\0' || (fVar44 < fVar38)))) {
LAB_1400a9df1:
            cVar29 = true;
            goto LAB_1400aa378;
          }
          goto switchD_1400a9d9e_default;
        case 2:
          puVar21 = (ushort *)**(undefined8 **)(lVar31 + 0x18 + lVar34 * 0x48);
          uVar13 = *(ushort *)(param_1[3] + (ulonglong)*puVar21 * 2);
          cVar9 = (char)puVar21[2];
          uVar14 = puVar21[1];
          if (cVar9 == '\0') {
            cVar29 = uVar13 == uVar14;
          }
          else if (cVar9 == '\x01') {
            cVar29 = (short)uVar13 < (short)uVar14;
          }
          else {
            if (cVar9 != '\x02') goto switchD_1400a9d9e_default;
            bVar37 = SBORROW2(uVar13,uVar14);
            bVar36 = (short)(uVar13 - uVar14) < 0;
            bVar35 = uVar13 == uVar14;
LAB_1400aa36d:
            cVar29 = !bVar35 && bVar37 == bVar36;
          }
          break;
        case 3:
          lVar28 = *(longlong *)(*(longlong *)(**(longlong **)param_1[1] + 0x110) + 0x1b8);
          if (lVar28 == 0) goto switchD_1400a9d9e_default;
          iVar16 = *(int *)(lVar28 + 0x2780);
          psVar22 = (short *)**(undefined8 **)(lVar31 + 0x20 + lVar34 * 0x48);
          cVar9 = (char)psVar22[1];
          iVar25 = (int)*psVar22;
          if (cVar9 == '\0') {
            cVar29 = iVar25 == iVar16;
          }
          else {
            if (cVar9 == '\x01') {
              bVar37 = SBORROW4(iVar25,iVar16);
              bVar36 = iVar25 - iVar16 < 0;
              bVar35 = iVar25 == iVar16;
              goto LAB_1400aa36d;
            }
            if (cVar9 == '\x02') {
              cVar29 = iVar25 < iVar16;
            }
            else {
              if (cVar9 != '\x03') {
                if (cVar9 != '\x04') {
                  if ((cVar9 == '\x05') && (0x28 < iVar16)) {
                    cVar29 = true;
                    goto LAB_1400aa378;
                  }
                  goto switchD_1400a9d9e_default;
                }
                if (0x50 < iVar16 + 0x28U) goto switchD_1400a9d9e_default;
                cVar29 = true;
                goto LAB_1400aa378;
              }
              cVar29 = iVar16 < -0x28;
            }
          }
          break;
        case 4:
          pbVar19 = (byte *)**(undefined8 **)(lVar31 + 0x28 + lVar34 * 0x48);
          lVar31 = FUN_140189320();
          bVar10 = *pbVar19;
          bVar11 = *(byte *)(lVar31 + 0x2f);
          bVar12 = pbVar19[1];
          if (bVar12 == 0) {
            cVar29 = bVar11 == bVar10;
          }
          else if (bVar12 == 1) {
            cVar29 = bVar11 < bVar10;
          }
          else {
            if (bVar12 != 2) {
LAB_1400aa391:
              cVar29 = '\0';
              goto switchD_1400a9d9e_default;
            }
            cVar29 = bVar10 < bVar11;
          }
          break;
        case 5:
          pbVar19 = (byte *)**(undefined8 **)(lVar31 + 0x30 + lVar34 * 0x48);
          bVar10 = *pbVar19;
          if (bVar10 == 0xff) goto switchD_1400a9d9e_default;
          if (pbVar19[1] != 0xff) {
            lVar31 = (ulonglong)pbVar19[1] * 0x520 +
                     *(longlong *)
                      (*(longlong *)(*(longlong *)param_1[1] + (ulonglong)bVar10 * 8) + 0x110);
            if ((pbVar19[3] & 1) == 0) {
              if ((*(byte *)(lVar31 + 500) & 8) != 0) goto switchD_1400a9d9e_default;
            }
            else if ((*(byte *)(lVar31 + 500) & 8) == 0) goto switchD_1400a9d9e_default;
            bVar10 = *(byte *)(**(longlong **)(lVar31 + 0x1a0) + 0x6e);
            if ((int)(uint)pbVar19[2] <=
                (int)(((float)(int)((uint)bVar10 - (int)*(short *)(lVar31 + 0x428)) / (float)bVar10)
                     * fVar43)) {
              cVar29 = true;
              goto LAB_1400aa378;
            }
            goto switchD_1400a9d9e_default;
          }
          lVar31 = *(longlong *)(*(longlong *)param_1[1] + (ulonglong)bVar10 * 8);
          iVar25 = 0;
          iVar16 = *(int *)(lVar31 + 0x118);
          lVar28 = (longlong)iVar16;
          if (iVar16 < 1) goto switchD_1400a9d9e_default;
          puVar30 = (uint *)(*(longlong *)(lVar31 + 0x110) + 0x1f0);
          iVar32 = 0;
          do {
            uVar15 = *puVar30;
            puVar30 = puVar30 + 0x148;
            iVar24 = iVar32 + 1;
            if ((uVar15 & 2) == 0) {
              iVar24 = iVar32;
            }
            iVar32 = iVar25 + 1;
            if ((uVar15 & 1) == 0) {
              iVar32 = iVar25;
            }
            iVar25 = iVar32;
            lVar28 = lVar28 + -1;
            iVar32 = iVar24;
          } while (lVar28 != 0);
          if ((iVar25 == 0) ||
             ((int)((((float)iVar16 - (float)iVar24) / (float)iVar16) * fVar43) <
              (int)(uint)pbVar19[2])) goto switchD_1400a9d9e_default;
          cVar29 = true;
          goto LAB_1400aa378;
        case 6:
          pfVar20 = (float *)**(undefined8 **)(lVar31 + 0x38 + lVar34 * 0x48);
          fVar38 = *pfVar20;
          fVar3 = pfVar20[1];
          fVar4 = pfVar20[2];
          fVar41 = pfVar20[4];
          fVar42 = pfVar20[5];
          fVar5 = pfVar20[6];
          fVar39 = fVar45;
          if (((uint)pfVar20[8] & 2) != 0) {
            if ((*(byte *)((longlong)pfVar20 + 0x1e) == 0xff) ||
               (lVar31 = *(longlong *)
                          (*(longlong *)param_1[1] +
                          (ulonglong)*(byte *)((longlong)pfVar20 + 0x1e) * 8),
               (*(byte *)(lVar31 + 0x120) & 1) == 0)) goto switchD_1400a9d9e_default;
            if (*(byte *)((longlong)pfVar20 + 0x1f) == 0xff) {
              fVar40 = *(float *)(lVar31 + 8);
              fVar6 = *(float *)(lVar31 + 0xc);
              fVar7 = *(float *)(lVar31 + 0x10);
              fVar39 = *(float *)(lVar31 + 0x14);
            }
            else {
              lVar28 = (ulonglong)*(byte *)((longlong)pfVar20 + 0x1f) * 0x520;
              lVar31 = *(longlong *)(lVar31 + 0x110);
              if ((*(byte *)(lVar28 + 0x1f0 + lVar31) & 1) == 0) goto switchD_1400a9d9e_default;
              fVar40 = *(float *)(lVar28 + 600 + lVar31);
              fVar6 = *(float *)(lVar28 + 0x25c + lVar31);
              fVar7 = *(float *)(lVar28 + 0x260 + lVar31);
              fVar39 = *(float *)(lVar28 + 0x264 + lVar31);
            }
            fVar38 = fVar40 + fVar38;
            fVar3 = fVar6 + fVar3;
            fVar4 = fVar7 + fVar4;
            fVar39 = fVar39 + fVar45;
            fVar41 = fVar40 + fVar41;
            fVar42 = fVar6 + fVar42;
            fVar5 = fVar7 + fVar5;
          }
          if ((*(byte *)(pfVar20 + 7) == 0xff) ||
             (lVar31 = *(longlong *)
                        (*(longlong *)param_1[1] + (ulonglong)*(byte *)(pfVar20 + 7) * 8),
             (*(byte *)(lVar31 + 0x120) & 1) == 0)) goto switchD_1400a9d9e_default;
          if (*(byte *)((longlong)pfVar20 + 0x1d) == 0xff) {
            fVar6 = *(float *)(lVar31 + 8);
            fVar7 = *(float *)(lVar31 + 0xc);
            fVar40 = *(float *)(lVar31 + 0x10);
            fVar8 = *(float *)(lVar31 + 0x14);
          }
          else {
            lVar28 = (ulonglong)*(byte *)((longlong)pfVar20 + 0x1d) * 0x520;
            lVar31 = *(longlong *)(lVar31 + 0x110);
            if ((*(byte *)(lVar28 + 0x1f0 + lVar31) & 1) == 0) goto switchD_1400a9d9e_default;
            fVar6 = *(float *)(lVar28 + 600 + lVar31);
            fVar7 = *(float *)(lVar28 + 0x25c + lVar31);
            fVar40 = *(float *)(lVar28 + 0x260 + lVar31);
            fVar8 = *(float *)(lVar28 + 0x264 + lVar31);
          }
          fVar23 = pfVar20[8];
          if (((uint)fVar23 & 4) == 0) {
            fVar38 = SQRT((fVar39 - fVar8) * (fVar39 - fVar8) +
                          (fVar4 - fVar40) * (fVar4 - fVar40) +
                          (fVar38 - fVar6) * (fVar38 - fVar6) + (fVar3 - fVar7) * (fVar3 - fVar7));
            if (((uint)fVar23 & 1) != 0) {
              if (pfVar20[3] <= fVar38) {
                cVar29 = true;
                goto LAB_1400aa378;
              }
              goto switchD_1400a9d9e_default;
            }
            if (pfVar20[3] < fVar38) goto switchD_1400a9d9e_default;
            cVar29 = true;
          }
          else {
            fVar39 = fVar41;
            if (fVar41 <= fVar38) {
              fVar39 = fVar38;
              fVar38 = fVar41;
            }
            fVar41 = fVar42;
            if (fVar42 <= fVar3) {
              fVar41 = fVar3;
              fVar3 = fVar42;
            }
            fVar42 = fVar5;
            if (fVar5 <= fVar4) {
              fVar42 = fVar4;
              fVar4 = fVar5;
            }
            if (((uint)fVar23 & 1) == 0) {
              bVar35 = true;
              if ((fVar6 < fVar38) || (fVar39 < fVar6)) {
                bVar35 = false;
              }
              if ((fVar7 < fVar3) || (fVar41 < fVar7)) {
                bVar35 = false;
              }
              if ((fVar40 < fVar4) || (fVar42 < fVar40)) goto switchD_1400a9d9e_default;
            }
            else {
              bVar35 = false;
              if ((fVar6 < fVar38) || (fVar39 < fVar6)) {
                bVar35 = true;
              }
              if ((fVar7 < fVar3) || (fVar41 < fVar7)) {
                bVar35 = true;
              }
              if (fVar40 < fVar4) goto LAB_1400a9df1;
              if (fVar42 < fVar40) {
                cVar29 = true;
                goto LAB_1400aa378;
              }
            }
            if (!bVar35) goto switchD_1400a9d9e_default;
            cVar29 = true;
          }
          goto LAB_1400aa378;
        case 7:
          if (param_1[1] == 0) goto switchD_1400a9d9e_default;
          piVar1 = (int *)**(undefined8 **)(lVar31 + 0x40 + lVar34 * 0x48);
          cVar29 = (char)piVar1[1];
          iVar16 = *piVar1;
          iVar25 = FUN_140138280(param_1[1],0);
          if (cVar29 == '\0') {
            cVar29 = iVar25 == iVar16;
          }
          else {
            if (cVar29 != '\x01') {
              if (cVar29 != '\x02') goto LAB_1400aa391;
              bVar37 = SBORROW4(iVar25,iVar16);
              bVar36 = iVar25 - iVar16 < 0;
              bVar35 = iVar25 == iVar16;
              goto LAB_1400aa36d;
            }
            cVar29 = iVar25 < iVar16;
          }
          break;
        default:
          goto switchD_1400a9d9e_default;
        }
        if ((bool)cVar29 == false) goto switchD_1400a9d9e_default;
LAB_1400aa378:
        iVar26 = iVar26 + 1;
        lVar34 = lVar34 + 1;
        if ((int)(uint)*pbVar18 <= iVar26) goto LAB_1400aa3b0;
        goto LAB_1400a9d67;
      }
LAB_1400aa4b1:
      local_res20 = local_res20 + 1;
    } while (local_res20 < (longlong)uVar27);
  }
  return;
switchD_1400a9d9e_default:
  local_res8 = local_res8 + 1;
  local_res10 = local_res10 + 1;
  lVar33 = lVar33 + 1;
  if ((int)(uint)*pbVar17 <= local_res8) goto LAB_1400aa4b1;
  goto LAB_1400a9d29;
}

