/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fe730; RVA 0xfe730
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400fe730(longlong param_1,longlong *param_2)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  bool bVar5;
  uint uVar6;
  longlong lVar7;
  longlong lVar8;
  byte bVar9;
  longlong lVar10;
  undefined8 uVar11;
  ulonglong local_res8;
  undefined2 local_res10 [4];
  uint in_stack_ffffffffffffffa8;
  
  lVar7 = *param_2;
  lVar8 = 0;
  lVar3 = *(longlong *)(*(longlong *)**(longlong **)(param_1 + 0x2f8) + 0x110);
  lVar4 = *(longlong *)(lVar3 + 0x1b8);
  if (*(byte *)(lVar7 + 0x2f) == 0xff) {
    return;
  }
  plVar2 = (longlong *)**(longlong **)(param_1 + 0x2f8) + *(byte *)(lVar7 + 0x2f);
  if (*(byte *)(lVar7 + 0x30) != 0xff) {
    lVar8 = (ulonglong)*(byte *)(lVar7 + 0x30) * 0x520 + *(longlong *)(*plVar2 + 0x110);
  }
  if (plVar2 == (longlong *)0x0) {
    return;
  }
  if (lVar8 == 0) {
    return;
  }
  bVar9 = *(byte *)(lVar7 + 0x2e);
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x20;
  if (((*(byte *)(param_1 + 0x3a8) & 4) == 0) && ((bVar9 & 4) == 0)) {
    if ((*(byte *)(lVar4 + 0x1676) & 1) != 0) {
      if ((*(float *)(lVar3 + 600) < *(float *)(param_1 + 0x90)) ||
         (bVar5 = false, *(float *)(param_1 + 0xa0) < *(float *)(lVar3 + 600))) {
        bVar5 = true;
      }
      if ((*(float *)(lVar3 + 0x25c) < *(float *)(param_1 + 0x94)) ||
         (*(float *)(param_1 + 0xa4) < *(float *)(lVar3 + 0x25c))) {
        bVar5 = true;
      }
      if (((*(float *)(lVar3 + 0x260) < *(float *)(param_1 + 0x98)) ||
          (*(float *)(param_1 + 0xa8) < *(float *)(lVar3 + 0x260))) || (bVar5)) {
        local_res8 = 0;
        FUN_140118040(lVar3,&local_res8,0,1,in_stack_ffffffffffffffa8 & 0xffffff00,0,3);
      }
      goto LAB_1400fe879;
    }
LAB_1400fe88b:
    if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
      *(int *)(param_1 + 0x388) = *(int *)(param_1 + 0x388) + 1;
    }
  }
  else {
LAB_1400fe879:
    if ((*(byte *)(lVar4 + 0x1676) & 1) == 0) goto LAB_1400fe88b;
    *(undefined4 *)(param_1 + 0x388) = 0;
  }
  uVar6 = *(uint *)(param_1 + 0x3a8);
  if ((uVar6 & 4) == 0) {
    *(int *)(param_1 + 0x378) = *(int *)(param_1 + 0x378) + 1;
  }
  if (((*(byte *)(lVar4 + 0x1676) & 0x40) != 0) && ((uVar6 >> 0xb & 1) == 0)) {
    uVar6 = uVar6 | 0x800;
    *(uint *)(param_1 + 0x3a8) = uVar6;
  }
  bVar9 = ~(byte)(*(uint *)(lVar3 + 0x1f0) >> 1) & 1;
  if (*(int *)(param_1 + 900) < 1) {
    bVar9 = 1;
    *(undefined1 *)(param_1 + 0x3e6) = 5;
  }
  else if ((uVar6 & 4) == 0) {
    iVar1 = *(int *)(param_1 + 900) + -1;
    *(int *)(param_1 + 900) = iVar1;
    uVar6 = (uint)*(byte *)(param_1 + 0x3d1);
    if ((int)((uint)*(byte *)(param_1 + 0x3d1) * 5) < iVar1) {
      if (((float)iVar1 <= (float)uVar6 * DAT_1402d2504) && (iVar1 % (int)uVar6 == 0)) {
        uVar11 = FUN_1401c56d0();
        local_res8 = local_res8 & 0xffffffffffff0000;
        goto LAB_1400fe951;
      }
    }
    else if (iVar1 % (int)uVar6 == 0) {
      uVar11 = FUN_1401c56d0();
      local_res8 = CONCAT62(local_res8._2_6_,1);
LAB_1400fe951:
      local_res10[0] = 1;
      FUN_1401c6150(uVar11,local_res10,&local_res8);
    }
  }
  if ((*(float *)(param_1 + 0x354) < *(float *)(lVar3 + 0x260)) ||
     (*(float *)(lVar3 + 0x260) < *(float *)(param_1 + 0x34c) ||
      (*(float *)(param_1 + 0x350) < *(float *)(lVar3 + 600) ||
      *(float *)(lVar3 + 600) < *(float *)(param_1 + 0x348)))) {
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a7df0(*(longlong *)(param_1 + 0x308),0);
    }
    lVar8 = FUN_140189320();
    lVar10 = 0x1a;
    if (*(char *)(lVar8 + 0x3e) == '\x01') {
      lVar10 = 3;
    }
    lVar8 = FUN_1401c56d0();
    bVar9 = DAT_14031f8b1 & 1;
    (&DAT_140310a64)[(ulonglong)*(byte *)(lVar8 + 0xc) * 8] = 0x42fe0000;
    if (bVar9 == 0) {
      lVar8 = (longlong)*(short *)(lVar8 + 4);
      if (((int)lVar10 < *(int *)(&DAT_14031f838 + lVar8 * 0x18)) &&
         (*(longlong *)(&DAT_14031f840 + lVar8 * 0x18) != 0)) {
        FUN_140186f20((&DAT_14033bc00)[(char)(&DAT_14031f8a8)[lVar8 + (ulonglong)DAT_14031f8b0 * 4]]
                      ,&DAT_14031f438 + lVar8 * 0x100,
                      *(undefined4 *)(*(longlong *)(&DAT_14031f840 + lVar8 * 0x18) + lVar10 * 4),0,
                      (int)(char)(&DAT_14031f8a8)[lVar8 + (ulonglong)DAT_14031f8b0 * 4],0,0,1);
        *(int *)(&DAT_14031f898 + lVar8 * 4) = (int)lVar10;
      }
    }
  }
  else if (bVar9 == 0) goto LAB_1400feacf;
  *(undefined4 *)(param_1 + 0x378) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 5;
  if (*(char *)(param_1 + 0x3e6) != '\x05') {
    *(undefined1 *)(param_1 + 0x3e6) = 4;
  }
LAB_1400feacf:
  if (((int)((uint)*(byte *)(param_1 + 0x3d1) * 3) < *(int *)(param_1 + 0x388)) &&
     (*(float *)(**(longlong **)(*plVar2 + 0x130) + 8) < *(float *)(lVar3 + 0x25c))) {
    *(undefined4 *)(param_1 + 0x378) = 0;
    *(undefined1 *)(param_1 + 0x3cc) = 4;
    *(undefined1 *)(lVar4 + 0xc38) = 3;
    *(byte *)(lVar4 + 0x1863) = *(byte *)(lVar4 + 0x1863) | 1;
    *(undefined4 *)(lVar4 + 0x185c) = 0x3f800000;
    *(byte *)(lVar4 + 0x1da7) = *(byte *)(lVar4 + 0x1da7) | 1;
    *(undefined8 *)(lVar4 + 0x1d78) = 0;
    if ((*(uint *)(lVar4 + 0x2058) >> 0xd & 1) == 0) {
      *(uint *)(lVar4 + 0x2058) = *(uint *)(lVar4 + 0x2058) | 0x2000;
      *(undefined1 *)(lVar4 + 0x2095) = *(undefined1 *)(lVar4 + 0x2094);
    }
    *(undefined1 *)(lVar4 + 0x2096) = 1;
    FUN_14010bbb0(lVar4);
    *(undefined4 *)(lVar4 + 0x164c) = 0;
    if ((*(byte *)(lVar7 + 0x2e) & 0x20) != 0) {
      lVar7 = FUN_1401c56d0();
      if ((DAT_14031f8b1 & 1) == 0) {
        FUN_140187110((int)(char)(&DAT_14031f8a8)
                                 [(longlong)*(short *)(lVar7 + 4) + (ulonglong)DAT_14031f8b0 * 4],
                      5000);
      }
      *(undefined1 *)(param_1 + 0x3e6) = 3;
    }
  }
  return;
}

