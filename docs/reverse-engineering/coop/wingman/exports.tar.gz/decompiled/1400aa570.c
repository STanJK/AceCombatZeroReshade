/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400aa570; RVA 0xaa570
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 * FUN_1400aa570(undefined8 *param_1)

{
  *(undefined4 *)((longlong)param_1 + 0x4c) = 0x3f800000;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  *(undefined2 *)(param_1 + 10) = 0x3c00;
  *(undefined2 *)(param_1 + 9) = 0;
  param_1[0xb] = 0;
  *(undefined4 *)((longlong)param_1 + 100) = 0x3f800000;
  *(undefined2 *)(param_1 + 0xd) = 0x3c00;
  *(undefined2 *)(param_1 + 0xc) = 0;
  param_1[0xe] = 0;
  *(undefined4 *)((longlong)param_1 + 0x7c) = 0x3f800000;
  *(undefined2 *)(param_1 + 0x10) = 0x3c00;
  *(undefined2 *)(param_1 + 0xf) = 0;
  param_1[0x11] = 0;
  *(undefined4 *)((longlong)param_1 + 0x94) = 0x3f800000;
  *(undefined2 *)(param_1 + 0x13) = 0x3c00;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  *(undefined1 *)((longlong)param_1 + 0xd2) = 0;
  *(undefined2 *)(param_1 + 0x12) = 0;
  param_1[0x1b] = 0;
  *(undefined4 *)((longlong)param_1 + 0xe4) = 0x3f800000;
  *(undefined2 *)(param_1 + 0x1d) = 0x3c00;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  *(undefined1 *)((longlong)param_1 + 0x122) = 0;
  *(undefined2 *)(param_1 + 0x1c) = 0;
  param_1[0x25] = 0;
  *(undefined4 *)((longlong)param_1 + 0x134) = 0x3f800000;
  *(undefined2 *)(param_1 + 0x27) = 0x3c00;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  *(undefined1 *)((longlong)param_1 + 0x172) = 0;
  *(undefined2 *)(param_1 + 0x26) = 0;
  *param_1 = &PTR_FUN_1402ab460;
  *(undefined2 *)(param_1 + 0x1a) = 0xffff;
  *(undefined2 *)(param_1 + 0x24) = 0xffff;
  *(undefined2 *)(param_1 + 0x2e) = 0xffff;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  *(undefined4 *)((longlong)param_1 + 0x232) = 0;
  *(undefined2 *)((longlong)param_1 + 0x22e) = 0;
  param_1[0x2f] = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  *(undefined4 *)((longlong)param_1 + 0x246) = 0;
  param_1[0x3d] = 0x47480000;
  *(undefined8 *)((longlong)param_1 + 0x20c) = 0;
  param_1[0x3b] = 0;
  *(undefined4 *)((longlong)param_1 + 0x222) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined2 *)((longlong)param_1 + 0x24a) = 0x3c;
  *(undefined2 *)((longlong)param_1 + 0x226) = 0;
  *(undefined4 *)((longlong)param_1 + 0x214) = 0xffffffff;
  param_1[0x40] = 0;
  *(undefined1 *)(param_1 + 0x46) = 0;
  *(undefined8 *)((longlong)param_1 + 0x23a) = 0xffffffffffffffff;
  *(undefined4 *)((longlong)param_1 + 0x236) = 0xffffffff;
  *(undefined4 *)((longlong)param_1 + 0x242) = 0xffffffff;
  param_1[0x3e] = 0;
  *(undefined2 *)((longlong)param_1 + 0x24d) = 0;
  param_1[0x3f] = 0;
  param_1[0x43] = 0;
  return param_1;
}

