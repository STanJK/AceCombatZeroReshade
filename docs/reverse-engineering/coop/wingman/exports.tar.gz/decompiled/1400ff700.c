/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400ff700; RVA 0xff700
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400ff700(longlong param_1,undefined8 *param_2)

{
  byte *pbVar1;
  uint *puVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  byte bVar6;
  undefined1 uVar7;
  undefined1 uVar8;
  undefined1 uVar9;
  char cVar10;
  undefined2 uVar11;
  undefined2 uVar12;
  undefined4 uVar13;
  longlong *plVar14;
  longlong lVar15;
  longlong *plVar16;
  longlong lVar17;
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  int iVar20;
  float *pfVar21;
  uint uVar22;
  longlong lVar23;
  int iVar24;
  longlong lVar25;
  longlong lVar26;
  int iVar27;
  float fVar28;
  float fVar29;
  undefined1 auVar30 [64];
  float fVar31;
  float fVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  float fVar39;
  undefined1 auVar40 [64];
  undefined1 auVar41 [64];
  undefined4 *puVar42;
  float local_140;
  float local_13c;
  float local_138;
  undefined4 local_134;
  undefined1 local_128 [8];
  float fStack_120;
  float fStack_11c;
  undefined8 local_118;
  undefined8 uStack_110;
  undefined1 local_108 [8];
  float fStack_100;
  float fStack_fc;
  undefined8 local_f8;
  undefined8 uStack_f0;
  
  pfVar21 = (float *)*param_2;
  plVar14 = (longlong *)**(longlong **)(param_1 + 0x2f8);
  bVar6 = *(byte *)(pfVar21 + 8);
  lVar26 = *(longlong *)(*plVar14 + 0x110);
  lVar15 = *(longlong *)(lVar26 + 0x1b8);
  if ((bVar6 != 0xff) && (*(byte *)((longlong)pfVar21 + 0x21) != 0xff)) {
    lVar23 = (ulonglong)*(byte *)((longlong)pfVar21 + 0x21) * 0x520 +
             *(longlong *)(plVar14[bVar6] + 0x110);
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xfffe3ff7 | 0x20;
    *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
    *(undefined4 *)(param_1 + 0x388) = 0;
    *(undefined4 *)(param_1 + 0x394) = 0;
    *(undefined4 *)(param_1 + 0x348) = 0xc8480000;
    *(undefined4 *)(param_1 + 0x350) = 0x48480000;
    *(undefined4 *)(param_1 + 0x34c) = 0xc8480000;
    *(undefined4 *)(param_1 + 0x354) = 0x48480000;
    if (*(longlong *)(param_1 + 0x338) != 0) {
      FUN_1400c27f0();
    }
    if (*(longlong *)(param_1 + 0x340) != 0) {
      FUN_1400d1560(*(longlong *)(param_1 + 0x340),(*(byte *)((longlong)pfVar21 + 0x22) & 1) != 0);
    }
    auVar41 = ZEXT464(DAT_1402d22d0);
    auVar18 = vpcmpeqd_avx(ZEXT116(*(byte *)((longlong)pfVar21 + 0x22) & 2),SUB6416(ZEXT464(0),0));
    auVar19._12_4_ = 0;
    auVar19._0_12_ = ZEXT812(0);
    auVar40 = ZEXT1264(ZEXT812(0)) << 0x20;
    auVar18 = vblendvps_avx(ZEXT416(DAT_1402d22d0),auVar19 << 0x20,auVar18);
    *(int *)(param_1 + 0x398) = auVar18._0_4_;
    *(int *)(param_1 + 900) = (int)((float)*(byte *)(param_1 + 0x3d1) * *pfVar21);
    uVar11 = *(undefined2 *)(lVar15 + 0x2728);
    uVar12 = *(undefined2 *)(lVar15 + 0x272a);
    uVar7 = *(undefined1 *)(lVar15 + 0x272c);
    uVar8 = *(undefined1 *)(lVar15 + 0x272d);
    uVar9 = *(undefined1 *)(lVar15 + 0x272e);
    uVar13 = *(undefined4 *)(lVar15 + 0x2784);
    FUN_140102ab0(lVar15);
    *(undefined1 *)(lVar15 + 0x272d) = uVar8;
    *(undefined2 *)(lVar15 + 0x2728) = uVar11;
    *(undefined2 *)(lVar15 + 0x272a) = uVar12;
    *(undefined1 *)(lVar15 + 0x272c) = uVar7;
    *(undefined1 *)(lVar15 + 0x272e) = uVar9;
    *(undefined4 *)(lVar15 + 0x2784) = uVar13;
    FUN_140114c30(lVar26);
    FUN_1400f49d0(param_1,1);
    *(uint *)(lVar26 + 0x1f0) = *(uint *)(lVar26 + 0x1f0) | 3;
    fVar33 = (float)*(byte *)(lVar15 + 0x1674);
    fVar31 = (float)*(ushort *)(lVar15 + 0x1444);
    auVar30 = ZEXT464((uint)((DAT_1402d20f4 / fVar33) * fVar31));
    fVar28 = (float)FUN_140128d90(*(undefined4 *)(lVar15 + 0x15b4));
    _local_128 = ZEXT416(0);
    local_118 = 0;
    uStack_110 = 0;
    local_f8 = 0;
    uStack_f0 = 0;
    *(short *)(**(longlong **)
                 (*(longlong *)
                   (*(longlong *)(*(longlong *)(*(longlong *)(plVar14[bVar6] + 0x130) + 8) + 8) + 8)
                 + 0x58) + 0x34) =
         (short)(int)((fVar31 * (DAT_1402d22d4 / fVar33) +
                      -(auVar30._0_4_ * SQRT(fVar28 / *(float *)(lVar15 + 0x1648))) + auVar30._0_4_)
                     * (float)*(byte *)(param_1 + 0x3d1));
    _local_108 = _local_128;
    FUN_140202920(local_128,(undefined4 *)(lVar23 + 0x268));
    fVar28 = (float)local_f8 + *(float *)(lVar23 + 600);
    fVar31 = local_f8._4_4_ + *(float *)(lVar23 + 0x25c);
    fVar33 = (float)uStack_f0 + *(float *)(lVar23 + 0x260);
    plVar16 = *(longlong **)(lVar23 + 0x390);
    *(ushort *)(lVar15 + 0x1c20) = *(ushort *)(lVar15 + 0x1c20) | 1;
    *(uint *)(lVar15 + 0x2058) = *(uint *)(lVar15 + 0x2058) & 0xffffffef | 0x1400;
    cVar10 = *(char *)(*(longlong *)(lVar15 + 0xff8) + 10);
    if (cVar10 == '\0') {
      (**(code **)(*plVar16 + 0x1b0))(plVar16);
    }
    else if (cVar10 == '\x01') {
      (**(code **)(*plVar16 + 0x1a8))(plVar16);
    }
    pfVar21 = (float *)(**(code **)(*plVar16 + 0x1b8))(plVar16,&local_140);
    fVar29 = *pfVar21;
    fVar32 = pfVar21[1];
    fVar35 = pfVar21[2];
    fVar36 = pfVar21[3];
    *(undefined1 *)(lVar15 + 0xc39) = 1;
    *(undefined4 *)(lVar15 + 0xcbc) = 0x42480000;
    FUN_140155ec0(lVar15 + 0x110);
    FUN_140156b40(lVar15 + 0x110);
    pfVar21 = (float *)FUN_1400f40f0(lVar15 + 0x110,&local_140);
    fVar34 = *pfVar21;
    fVar37 = pfVar21[1];
    fVar38 = pfVar21[2];
    fVar39 = pfVar21[3];
    switch(*(undefined1 *)(param_1 + 0x3db)) {
    default:
      iVar24 = 1;
      break;
    case 2:
      iVar24 = 0xc0;
      break;
    case 3:
    case 4:
    case 5:
      iVar24 = 0x300;
    }
    iVar27 = 1;
    iVar20 = FUN_140242630();
    puVar42 = (undefined4 *)(lVar26 + 0x268);
    fVar32 = fVar32 - fVar37;
    fVar34 = ((float)(iVar20 % (iVar24 * 2) - iVar24) + fVar29) - fVar34;
    fVar38 = (fVar35 + DAT_1402d2a90) - fVar38;
    fVar39 = (fVar36 + auVar41._0_4_) - fVar39;
    *(float *)(lVar26 + 600) =
         fVar39 * fVar28 +
         local_108._0_4_ * fVar38 + local_128._0_4_ * fVar34 + fVar32 * (float)local_118;
    auVar18 = vshufps_avx(_local_128,_local_128,0x55);
    auVar19 = vshufps_avx(_local_108,_local_108,0x55);
    *(float *)(lVar26 + 0x25c) =
         fVar39 * fVar31 +
         auVar19._0_4_ * fVar38 + auVar18._0_4_ * fVar34 + fVar32 * local_118._4_4_;
    auVar18 = vshufps_avx(_local_128,_local_128,0xaa);
    auVar19 = vshufps_avx(_local_108,_local_108,0xaa);
    *(float *)(lVar26 + 0x260) =
         fVar39 * fVar33 +
         auVar19._0_4_ * fVar38 + auVar18._0_4_ * fVar34 + fVar32 * (float)uStack_110;
    auVar18 = vshufps_avx(_local_108,_local_108,0xff);
    fVar31 = fVar39 * uStack_f0._4_4_ + fVar38 * auVar18._0_4_;
    auVar18 = vshufps_avx(_local_128,_local_128,0xff);
    fVar28 = auVar18._0_4_ * fVar34 + fVar32 * uStack_110._4_4_;
    *(float *)(lVar26 + 0x264) = fVar31 + fVar28;
    *puVar42 = *(undefined4 *)(lVar23 + 0x268);
    *(undefined4 *)(lVar26 + 0x26c) = *(undefined4 *)(lVar23 + 0x26c);
    *(undefined4 *)(lVar26 + 0x270) = *(undefined4 *)(lVar23 + 0x270);
    uVar13 = *(undefined4 *)(lVar23 + 0x274);
    *(uint *)(lVar26 + 0x1f0) = *(uint *)(lVar26 + 0x1f0) | 3;
    *(undefined4 *)(lVar26 + 0x274) = uVar13;
    _local_128 = ZEXT816(0);
    local_118 = 0;
    uStack_110 = 0;
    *(uint *)(*plVar14 + 0x120) = *(uint *)(*plVar14 + 0x120) | 3;
    _local_108 = ZEXT816(0);
    local_f8 = 0;
    uStack_f0 = 0;
    FUN_140202920(local_128,puVar42,fVar28,fVar31,puVar42);
    fVar28 = (float)local_f8 + *(float *)(lVar26 + 600);
    lVar23 = *plVar14;
    fVar31 = local_f8._4_4_ + *(float *)(lVar26 + 0x25c);
    fVar33 = (float)uStack_f0 + *(float *)(lVar26 + 0x260);
    if (1 < *(int *)(lVar23 + 0x118)) {
      lVar25 = 0x10;
      local_134 = auVar40._0_4_;
      lVar26 = 0x520;
      fVar29 = DAT_1402d1f38;
      fVar32 = uStack_f0._4_4_;
      fVar35 = fStack_fc;
      fVar36 = fStack_100;
      fVar34 = (float)local_108._4_4_;
      fVar37 = (float)local_108._0_4_;
      fVar38 = uStack_110._4_4_;
      fVar39 = (float)uStack_110;
      do {
        lVar17 = *(longlong *)(lVar23 + 0x110);
        pfVar21 = *(float **)(lVar25 + *(longlong *)(*(longlong *)(lVar23 + 0x130) + 0x10));
        fVar3 = *pfVar21;
        fVar4 = pfVar21[1];
        fVar5 = pfVar21[2];
        local_140 = fVar29 * pfVar21[3];
        local_13c = fVar29 * pfVar21[4];
        local_138 = fVar29 * pfVar21[5];
        *(float *)(lVar17 + 600 + lVar26) =
             fVar4 * (float)local_118 + fVar3 * (float)local_128._0_4_ + fVar37 * fVar5 + fVar28;
        *(float *)(lVar17 + 0x25c + lVar26) =
             fVar4 * local_118._4_4_ + fVar3 * (float)local_128._4_4_ + fVar34 * fVar5 + fVar31;
        *(float *)(lVar17 + 0x260 + lVar26) =
             fVar39 * fVar4 + fVar3 * fStack_120 + fVar36 * fVar5 + fVar33;
        *(float *)(lVar17 + 0x264 + lVar26) =
             fVar38 * fVar4 + fVar3 * fStack_11c + fVar35 * fVar5 + fVar32;
        FUN_140203050(lVar17 + 0x268 + lVar26,puVar42,&local_140);
        puVar2 = (uint *)(lVar17 + 0x1f0 + lVar26);
        *puVar2 = *puVar2 | 3;
        lVar26 = lVar26 + 0x520;
        lVar23 = *plVar14;
        lVar25 = lVar25 + 0x10;
        iVar27 = iVar27 + 1;
      } while (iVar27 < *(int *)(lVar23 + 0x118));
    }
    auVar18 = vcvtdq2ps_avx(ZEXT116(*(byte *)(lVar15 + 0x1674)));
    auVar41 = ZEXT1664(auVar18);
    auVar19 = vcvtdq2ps_avx(ZEXT216(*(ushort *)(lVar15 + 0x1444)));
    auVar40 = ZEXT1664(auVar19);
    auVar30 = ZEXT464((uint)((DAT_1402d2140 / auVar18._0_4_) * auVar19._0_4_));
    fVar28 = (float)FUN_140128d90(*(undefined4 *)(lVar15 + 0x15b4));
    *(float *)(lVar15 + 0x1640) =
         auVar40._0_4_ * (DAT_1402d235c / auVar41._0_4_) +
         -(auVar30._0_4_ * SQRT(fVar28 / *(float *)(lVar15 + 0x1648))) + auVar30._0_4_;
    if (*(longlong *)(param_1 + 0x308) != 0) {
      FUN_1401a7df0();
      FUN_1401a5fc0(*(undefined8 *)(param_1 + 0x308));
    }
    if (*(longlong *)(param_1 + 0x310) != 0) {
      puVar2 = (uint *)(*(longlong *)(param_1 + 0x310) + 0x56c);
      *puVar2 = *puVar2 | 2;
    }
    lVar26 = *(longlong *)(param_1 + 800);
    if (lVar26 != 0) {
      *(byte *)(lVar26 + 0x2b) = *(byte *)(lVar26 + 0x2b) | 2;
      if (*(longlong *)(lVar26 + 0x10) != 0) {
        puVar2 = (uint *)(*(longlong *)(lVar26 + 0x10) + 0x56c);
        *puVar2 = *puVar2 | 1;
      }
      if (*(longlong *)(lVar26 + 0x18) != 0) {
        pbVar1 = (byte *)(*(longlong *)(lVar26 + 0x18) + 0x23);
        *pbVar1 = *pbVar1 | 4;
      }
      lVar26 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
      if (lVar26 != 0) {
        puVar2 = (uint *)(lVar26 + 0x40);
        *puVar2 = *puVar2 | 0x4000000;
      }
    }
    *(undefined1 *)(param_1 + 0x3e9) = 4;
    *(byte *)(lVar15 + 0x1863) = *(byte *)(lVar15 + 0x1863) | 1;
    *(undefined4 *)(lVar15 + 0x185c) = 0;
    *(byte *)(lVar15 + 0x1da7) = *(byte *)(lVar15 + 0x1da7) | 1;
    *(undefined8 *)(lVar15 + 0x1d78) = 0;
    uVar22 = *(uint *)(lVar15 + 0x2058);
    if ((uVar22 >> 0xd & 1) == 0) {
      uVar22 = uVar22 | 0x2000;
      *(undefined1 *)(lVar15 + 0x2095) = *(undefined1 *)(lVar15 + 0x2094);
    }
    *(undefined1 *)(lVar15 + 0x2096) = 1;
    *(uint *)(lVar15 + 0x2058) = uVar22 | 0x20;
    *(undefined4 *)(param_1 + 0x378) = 0;
    *(undefined1 *)(param_1 + 0x3cc) = 1;
  }
  return;
}

