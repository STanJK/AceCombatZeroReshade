/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140113ca0; RVA 0x113ca0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140113ca0(longlong param_1,undefined8 *param_2,longlong param_3,longlong param_4,
                       undefined1 param_5,int *param_6)

{
  char cVar1;
  ushort uVar2;
  longlong lVar3;
  byte *pbVar4;
  undefined8 *puVar5;
  int iVar6;
  uint uVar7;
  ulonglong uVar8;
  int iVar9;
  uint uVar10;
  longlong *plVar11;
  IMAGE_DOS_HEADER *pIVar12;
  undefined1 auStack_258 [32];
  undefined **local_238 [35];
  undefined **local_120;
  undefined4 local_f8;
  undefined **local_e8;
  undefined8 local_e0;
  ulonglong local_48;
  
  local_48 = DAT_140309040 ^ (ulonglong)auStack_258;
  uVar10 = 0;
  iVar9 = 0;
  lVar3 = **(longlong **)(param_1 + 0x1a0);
  cVar1 = *(char *)(lVar3 + 0x74);
  if (cVar1 == '\0') {
    if ((*(byte *)(lVar3 + 0x73) & 0x10) == 0) {
      if (*(short *)(lVar3 + 0x5e) != -1) {
        local_120 = &PTR_FUN_1402ab8b0;
        local_238[0] = &PTR_FUN_1402ab6b0;
        local_f8 = 0;
        local_e8 = &PTR_FUN_1402ab8a0;
        local_e0 = 0;
        FUN_14014d2a0(local_238,
                      *(undefined8 *)
                       (*(longlong *)(param_3 + 0x168) + (longlong)*(short *)(lVar3 + 0x5e) * 8));
        iVar9 = FUN_14014d480(local_238);
        iVar9 = iVar9 + 0x1f0;
      }
      if (*(short *)(lVar3 + 0x60) != -1) {
        local_120 = &PTR_FUN_1402ab8b0;
        local_238[0] = &PTR_FUN_1402ab6b0;
        local_f8 = 0;
        local_e8 = &PTR_FUN_1402ab8a0;
        local_e0 = 0;
        FUN_14014d2a0(local_238,
                      *(undefined8 *)
                       (*(longlong *)(param_3 + 0x168) + (longlong)*(short *)(lVar3 + 0x60) * 8));
        iVar6 = FUN_14014d480(local_238);
        iVar9 = iVar9 + 0x1f0 + iVar6;
      }
      if (param_4 != 0) {
        iVar9 = iVar9 + 0x530;
        goto LAB_140113df7;
      }
    }
    else {
      iVar9 = 0x1f0;
    }
  }
  else if ((cVar1 == '\x02') || (cVar1 == '\x03')) {
    iVar9 = 0x530;
LAB_140113df7:
    iVar6 = FUN_140010480(param_4,param_5);
    *param_6 = *param_6 + iVar6;
  }
  plVar11 = *(longlong **)(param_1 + 0x1a0);
  pIVar12 = &IMAGE_DOS_HEADER_140000000;
  uVar2 = *(ushort *)(*plVar11 + 0x6c);
  if (uVar2 < 0x23d) {
    if (uVar2 == 0x23c) {
      iVar6 = 0x2a0;
    }
    else {
      switch(uVar2) {
      case 0x163:
      case 0x165:
        goto switchD_140113e4b_caseD_163;
      case 0x164:
        iVar6 = 800;
        break;
      default:
        goto switchD_140113e4b_caseD_166;
      case 0x208:
        iVar6 = 0x290;
        break;
      case 0x209:
      case 0x239:
        goto switchD_140113e4b_caseD_209;
      case 0x23a:
        iVar6 = 0x2d0;
        break;
      case 0x23b:
        iVar6 = 0x310;
      }
    }
  }
  else {
    switch(uVar2) {
    case 0x42c:
    case 0x4c9:
    case 0x4cd:
    case 0x4cf:
switchD_140113e4b_caseD_209:
      iVar6 = 0x2c0;
      break;
    default:
switchD_140113e4b_caseD_166:
      iVar6 = 0;
      break;
    case 0x4ce:
    case 0x4d0:
    case 0x4d1:
switchD_140113e4b_caseD_163:
      iVar6 = 0x2b0;
    }
  }
  iVar9 = iVar9 + iVar6;
  uVar7 = FUN_140119f70();
  if (uVar7 == 0xffffffff) {
    if (((undefined8 *)plVar11[1] == (undefined8 *)0x0) ||
       (pbVar4 = *(byte **)plVar11[1], pbVar4 == (byte *)0x0)) goto LAB_140113ef0;
    uVar7 = (uint)*pbVar4;
  }
  if (uVar7 == 0) {
    iVar9 = iVar9 + 0x640;
  }
  else if (uVar7 == 1) {
    iVar9 = iVar9 + 0x2f0;
  }
  else if (uVar7 == 2) {
    iVar9 = iVar9 + 0x2a0;
  }
LAB_140113ef0:
  uVar7 = 0;
  if ((param_2 != (undefined8 *)0x0) && ((byte *)*param_2 != (byte *)0x0)) {
    uVar7 = *(byte *)*param_2 + 0xf & 0xfffffff0;
  }
  uVar7 = uVar7 + 0xc0 + iVar9;
  puVar5 = *(undefined8 **)(*(longlong *)(param_1 + 0x1a8) + 8);
  if (puVar5 != (undefined8 *)0x0) {
    pbVar4 = (byte *)*puVar5;
    if (pbVar4 != (byte *)0x0) {
      uVar10 = *pbVar4 + 0xf & 0xfffffff0;
    }
    uVar7 = uVar7 + 0xc0 + uVar10;
  }
  uVar10 = *(byte *)(lVar3 + 0x79) - 1;
  if (uVar10 < 0x1e) {
                    /* WARNING: Could not recover jumptable at 0x000140113f5a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar8 = (*(code *)(pIVar12->e_magic +
                      *(uint *)(pIVar12[0xd77].e_program +
                               (ulonglong)pIVar12[0xd77].e_program[(longlong)(int)uVar10 + 0x88] * 4
                               + 0x84)))
                      (pIVar12->e_magic +
                       *(uint *)(pIVar12[0xd77].e_program +
                                (ulonglong)pIVar12[0xd77].e_program[(longlong)(int)uVar10 + 0x88] *
                                4 + 0x84));
    return uVar8;
  }
  return (ulonglong)uVar7;
}

