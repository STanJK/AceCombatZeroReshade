/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140101a80; RVA 0x101a80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

float * FUN_140101a80(longlong param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  byte bVar4;
  byte bVar5;
  longlong lVar6;
  longlong *plVar7;
  float fVar8;
  float *pfVar9;
  longlong lVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined1 local_c8 [16];
  undefined1 local_b8 [8];
  float fStack_b0;
  float fStack_ac;
  undefined1 local_a8 [8];
  float fStack_a0;
  float fStack_9c;
  undefined1 local_98 [8];
  float fStack_90;
  float fStack_8c;
  undefined1 local_88 [8];
  float fStack_80;
  float fStack_7c;
  
  if (((*(longlong *)(param_1 + 0x2d8) != 0) &&
      (lVar6 = *(longlong *)(*(longlong *)(param_1 + 0x2d8) + 8), lVar6 != 0)) &&
     ((*(byte *)(param_1 + 0x3a8) & 1) == 0)) {
    lVar6 = **(longlong **)(lVar6 + 0x20 + (ulonglong)*(byte *)(param_1 + 0x3c9) * 0x48);
    bVar4 = *(byte *)(lVar6 + 0x20);
    bVar5 = *(byte *)(lVar6 + 0x21);
    if ((bVar4 != 0xff) && (bVar5 != 0xff)) {
      _local_b8 = ZEXT816(0);
      _local_a8 = ZEXT816(0);
      lVar6 = *(longlong *)
               (*(longlong *)(**(longlong **)(param_1 + 0x2f8) + (ulonglong)bVar4 * 8) + 0x110);
      lVar10 = (ulonglong)bVar5 * 0x520;
      _local_98 = _local_b8;
      _local_88 = _local_a8;
      FUN_140202920(local_b8,lVar6 + 0x268 + lVar10);
      plVar7 = *(longlong **)(lVar6 + 0x390 + lVar10);
      fVar13 = (float)local_88._0_4_ + *(float *)(lVar6 + 600 + lVar10);
      fVar12 = (float)local_88._4_4_ + *(float *)(lVar6 + 0x25c + lVar10);
      fVar11 = fStack_80 + *(float *)(lVar6 + 0x260 + lVar10);
      pfVar9 = (float *)(**(code **)(*plVar7 + 0x1b8))(plVar7,local_c8);
      fVar1 = *pfVar9;
      fVar2 = pfVar9[1];
      fVar3 = pfVar9[3];
      fVar8 = pfVar9[2] + DAT_1402d250c;
      *param_2 = fVar13 * fVar3 +
                 fVar8 * (float)local_98._0_4_ +
                 fVar2 * (float)local_a8._0_4_ + fVar1 * (float)local_b8._0_4_;
      param_2[1] = fVar12 * fVar3 +
                   fVar8 * (float)local_98._4_4_ +
                   fVar2 * (float)local_a8._4_4_ + fVar1 * (float)local_b8._4_4_;
      param_2[2] = fVar11 * fVar3 + fVar8 * fStack_90 + fVar2 * fStack_a0 + fVar1 * fStack_b0;
      param_2[3] = fVar3 * fStack_7c + fVar8 * fStack_8c + fVar2 * fStack_9c + fVar1 * fStack_ac;
      return param_2;
    }
  }
  param_2[3] = 1.0;
  param_2[0] = 0.0;
  param_2[1] = 0.0;
  param_2[2] = 0.0;
  return param_2;
}

