/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140164c20; RVA 0x164c20
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140164c20(longlong *param_1)

{
  longlong lVar1;
  longlong *plVar2;
  undefined4 *puVar3;
  int iVar4;
  longlong *plVar5;
  
  lVar1 = DAT_14032c8f8;
  if (*(char *)(DAT_14032c8f8 + 0x28) != -1) {
    *(char *)(DAT_14032c8f8 + 0x28) = *(char *)(DAT_14032c8f8 + 0x28) + '\x01';
  }
  if (DAT_14032c488 == 0) {
    DAT_14032c488 = FUN_140200de0(lVar1,0x200000,0x10);
    FUN_1401d7b70();
  }
  plVar5 = param_1 + 2;
  iVar4 = 0;
  if (param_1 == (longlong *)0x0) {
    plVar5 = (longlong *)0x0;
  }
  plVar2 = &DAT_14031dfd0;
  do {
    if (*plVar2 == 0) {
      (&DAT_14031dfd0)[iVar4] = plVar5;
      break;
    }
    iVar4 = iVar4 + 1;
    plVar2 = plVar2 + 1;
  } while ((longlong)plVar2 < 0x14031e050);
  (**(code **)(*param_1 + 0x30))(param_1,0);
  FUN_1402037e0(param_1 + 0x13,0x380,param_1 + 0x78);
  FUN_140164290(&DAT_140310e60);
  puVar3 = &DAT_1403170cc;
  if (DAT_14031cf18 == '\0') {
    puVar3 = &DAT_140311114;
  }
  *puVar3 = 0;
  *(undefined4 *)(param_1 + 0x7a) = 1;
  _DAT_14031e07c = 0;
  DAT_14031e084 = 0;
  DAT_14031e078 = 1;
  return;
}

