/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140133ae0; RVA 0x133ae0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140133ae0(longlong param_1)

{
  char cVar1;
  char cVar2;
  ushort uVar3;
  longlong lVar4;
  undefined4 *puVar5;
  longlong lVar6;
  longlong *plVar7;
  byte bVar8;
  uint uVar9;
  uint uVar10;
  longlong lVar11;
  longlong lVar12;
  int iVar13;
  undefined4 uVar14;
  
  uVar3 = *(ushort *)(param_1 + 0xf0);
  iVar13 = 0;
  if (0 < *(int *)(param_1 + 0x118)) {
    lVar11 = 0;
    do {
      lVar4 = *(longlong *)(param_1 + 0x110);
      uVar10 = *(uint *)(lVar11 + 0x1f0 + lVar4);
      uVar9 = uVar10 | 0x800;
      if ((uVar3 & 1) == 0) {
        uVar9 = uVar10 & 0xfffff7ff;
      }
      uVar10 = uVar9 | 0x400;
      if ((uVar3 & 2) == 0) {
        uVar10 = uVar9 & 0xfffffbff;
      }
      *(uint *)(lVar11 + 0x1f0 + lVar4) = uVar10;
      puVar5 = *(undefined4 **)(lVar11 + 8 + lVar4);
      if (puVar5 != (undefined4 *)0x0) {
        bVar8 = (byte)uVar3 >> 4 & 1;
        if ((uVar3 & 4) != 0) {
          bVar8 = 1;
        }
        if (((uVar3 & 8) == 0) && (bVar8 == 0)) {
          puVar5[0x2a] = puVar5[0x2a] & 0xfffffbff;
        }
        else if (((uint)puVar5[0x2a] >> 10 & 1) == 0) {
          lVar12 = (ulonglong)*(byte *)(param_1 + 0xf7) * 0x40;
          lVar6 = *(longlong *)
                   (*(longlong *)(*(longlong *)(param_1 + 0xa8) + 8) + 8 +
                   (ulonglong)*(byte *)(param_1 + 0xf8) * 0x10);
          if (**(char **)(lVar6 + lVar12) == '\x02') {
            if (*(longlong *)(lVar6 + 0x18 + lVar12) != 0) {
              FUN_140126b60(puVar5);
              goto LAB_140133c0b;
            }
          }
          else if ((**(char **)(lVar6 + lVar12) == '\x03') &&
                  (*(longlong *)(lVar6 + 0x20 + lVar12) != 0)) {
            FUN_140126ec0(puVar5);
LAB_140133c0b:
            *(byte *)((longlong)puVar5 + 0xae) = *(byte *)((longlong)puVar5 + 0xae) | 1;
          }
          cVar1 = *(char *)(param_1 + 0xf8);
          cVar2 = *(char *)(param_1 + 0xf7);
          puVar5[0x2a] = puVar5[0x2a] | 0x400;
          if (cVar1 != -1) {
            *(char *)(puVar5 + 0x2c) = cVar1;
          }
          if (cVar2 != -1) {
            *(char *)((longlong)puVar5 + 0xaf) = cVar2;
          }
          *puVar5 = *(undefined4 *)(lVar11 + 600 + lVar4);
          puVar5[1] = *(undefined4 *)(lVar11 + 0x25c + lVar4);
          puVar5[2] = *(undefined4 *)(lVar11 + 0x260 + lVar4);
          puVar5[3] = *(undefined4 *)(lVar11 + 0x264 + lVar4);
          plVar7 = *(longlong **)(lVar11 + 0x390 + lVar4);
          if (plVar7 != (longlong *)0x0) {
            uVar14 = (**(code **)(*plVar7 + 0xa8))();
            puVar5[0x24] = uVar14;
          }
        }
      }
      iVar13 = iVar13 + 1;
      lVar11 = lVar11 + 0x520;
    } while (iVar13 < *(int *)(param_1 + 0x118));
  }
  return;
}

