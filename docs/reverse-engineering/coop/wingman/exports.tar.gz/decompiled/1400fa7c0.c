/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fa7c0; RVA 0xfa7c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400fa7c0(longlong param_1,longlong *param_2)

{
  byte bVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  undefined1 uVar4;
  undefined2 uVar5;
  undefined2 uVar6;
  undefined4 uVar7;
  uint uVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  
  lVar11 = *param_2;
  lVar9 = *(longlong *)(*(longlong *)**(longlong **)(param_1 + 0x2f8) + 0x110);
  lVar10 = *(longlong *)(lVar9 + 0x1b8);
  if ((*(byte *)(lVar11 + 0xb6) == 0xff) || (bVar1 = *(byte *)(lVar11 + 0xb7), bVar1 == 0xff)) {
    lVar12 = 0;
  }
  else {
    lVar12 = (ulonglong)bVar1 * 0x520 +
             *(longlong *)
              (((longlong *)**(longlong **)(param_1 + 0x2f8))[*(byte *)(lVar11 + 0xb6)] + 0x110);
  }
  *(longlong *)(lVar10 + 0x2048) = lVar12;
  *(longlong *)(lVar10 + 0x1638) = lVar12;
  *(byte *)(lVar10 + 0x1677) = *(byte *)(lVar10 + 0x1677) & 0xfd;
  *(uint *)(lVar10 + 0x2058) = *(uint *)(lVar10 + 0x2058) & 0xfffffeef;
  *(uint *)(lVar10 + 0xd48) = *(uint *)(lVar10 + 0xd48) & 0xfffffeff | 0x200;
  uVar5 = *(undefined2 *)(lVar10 + 0x2728);
  uVar6 = *(undefined2 *)(lVar10 + 0x272a);
  uVar2 = *(undefined1 *)(lVar10 + 0x272c);
  uVar3 = *(undefined1 *)(lVar10 + 0x272d);
  uVar4 = *(undefined1 *)(lVar10 + 0x272e);
  uVar7 = *(undefined4 *)(lVar10 + 0x2784);
  FUN_140102ab0(lVar10);
  *(undefined1 *)(lVar10 + 0x272e) = uVar4;
  *(undefined2 *)(lVar10 + 0x2728) = uVar5;
  *(undefined2 *)(lVar10 + 0x272a) = uVar6;
  *(undefined1 *)(lVar10 + 0x272c) = uVar2;
  *(undefined1 *)(lVar10 + 0x272d) = uVar3;
  *(undefined4 *)(lVar10 + 0x2784) = uVar7;
  FUN_140114c30(lVar9);
  *(undefined4 *)(lVar9 + 0x420) = *(undefined4 *)(param_1 + 0x404);
  bVar1 = *(byte *)(param_1 + 0x3e2);
  *(uint *)(lVar9 + 0x1f0) = *(uint *)(lVar9 + 0x1f0) | 3;
  *(ushort *)(lVar9 + 0x428) = (ushort)bVar1;
  *(undefined8 *)(lVar9 + 0x268) = 0;
  *(undefined8 *)(lVar9 + 0x270) = 0;
  FUN_14010bb50(lVar10);
  local_58 = *(undefined8 *)(lVar9 + 0x268);
  uStack_50 = *(undefined8 *)(lVar9 + 0x270);
  local_48 = *(undefined8 *)(lVar9 + 600);
  uStack_40 = *(undefined8 *)(lVar9 + 0x260);
  FUN_14010a690(lVar10,&local_48,&local_58);
  *(undefined4 *)(lVar9 + 600) = *(undefined4 *)(lVar10 + 0x70);
  *(undefined4 *)(lVar9 + 0x25c) = *(undefined4 *)(lVar10 + 0x74);
  *(undefined4 *)(lVar9 + 0x260) = *(undefined4 *)(lVar10 + 0x78);
  *(undefined4 *)(lVar9 + 0x264) = *(undefined4 *)(lVar10 + 0x7c);
  *(undefined4 *)(lVar9 + 0x268) = *(undefined4 *)(lVar10 + 0x80);
  *(undefined4 *)(lVar9 + 0x26c) = *(undefined4 *)(lVar10 + 0x84);
  *(undefined4 *)(lVar9 + 0x270) = *(undefined4 *)(lVar10 + 0x88);
  *(undefined4 *)(lVar9 + 0x274) = *(undefined4 *)(lVar10 + 0x8c);
  *(byte *)(lVar10 + 0x1863) = *(byte *)(lVar10 + 0x1863) | 1;
  *(undefined4 *)(lVar10 + 0x185c) = 0xbf800000;
  *(undefined8 *)(lVar10 + 0x1d78) = 0;
  *(byte *)(lVar10 + 0x1da7) = *(byte *)(lVar10 + 0x1da7) | 1;
  uVar8 = *(uint *)(lVar10 + 0x2058);
  *(uint *)(lVar10 + 0x2058) = uVar8 | 0x20;
  if ((*(byte *)(lVar11 + 0xb6) == 0xff) || (bVar1 = *(byte *)(lVar11 + 0xb7), bVar1 == 0xff)) {
    lVar11 = 0;
  }
  else {
    lVar11 = (ulonglong)bVar1 * 0x520 +
             *(longlong *)
              (*(longlong *)
                (**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar11 + 0xb6) * 8) + 0x110
              );
  }
  *(longlong *)(lVar10 + 0x2048) = lVar11;
  *(longlong *)(lVar10 + 0x1638) = lVar11;
  *(uint *)(lVar10 + 0x2058) = uVar8 & 0xfffffeff | 0x20;
  *(byte *)(lVar10 + 0x1677) = *(byte *)(lVar10 + 0x1677) & 0xfd;
  *(undefined4 *)(param_1 + 0x37c) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 0x16;
  return;
}

