/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400faa80; RVA 0xfaa80
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400faa80(longlong param_1,longlong *param_2)

{
  uint *puVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  uint uVar5;
  int iVar6;
  longlong lVar7;
  float fVar8;
  
  lVar2 = *param_2;
  lVar7 = 0;
  lVar3 = *(longlong *)
           (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
  *(uint *)(lVar3 + 0x2058) = *(uint *)(lVar3 + 0x2058) | 0x1000;
  *(ushort *)(lVar3 + 0x1c20) = *(ushort *)(lVar3 + 0x1c20) | 1;
  if (*(byte *)(lVar2 + 0xb6) == 0xff) {
    plVar4 = _DAT_00000000;
  }
  else {
    plVar4 = (longlong *)(**(longlong **)(param_1 + 0x2f8) + (ulonglong)*(byte *)(lVar2 + 0xb6) * 8)
    ;
    if (*(byte *)(lVar2 + 0xb7) != 0xff) {
      lVar7 = (ulonglong)*(byte *)(lVar2 + 0xb7) * 0x520 + *(longlong *)(*plVar4 + 0x110);
    }
  }
  if ((plVar4 != (longlong *)0x0) && (lVar7 != 0)) {
    uVar5 = *(uint *)(param_1 + 0x3a8);
    iVar6 = *(int *)(param_1 + 0x37c);
    fVar8 = (float)*(byte *)(param_1 + 0x3d1);
    *(uint *)(param_1 + 0x3a8) = uVar5 | 0x10020;
    if (iVar6 < (int)((int)(fVar8 * *(float *)(lVar2 + 0x98)) & 0xffffU)) {
      if ((uVar5 & 4) == 0) {
        iVar6 = iVar6 + 1;
        *(int *)(param_1 + 0x37c) = iVar6;
      }
      if (iVar6 < (int)(uint)*(byte *)(param_1 + 0x3d1)) {
        *(float *)(param_1 + 0x3a0) = DAT_1402d22d0 - (float)iVar6 / fVar8;
      }
      FUN_140101ec0(param_1,0);
      *(uint *)(lVar3 + 0x2058) = *(uint *)(lVar3 + 0x2058) | 0x2000000;
      return;
    }
    *(uint *)(param_1 + 0x3a8) = uVar5 & 0xfffffff7 | 0x10020;
    puVar1 = (uint *)(*(longlong *)
                       (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) +
                       0x1b8) + 0x2058);
    *puVar1 = *puVar1 & 0xffffffef;
    *(byte *)(lVar3 + 0x1863) = *(byte *)(lVar3 + 0x1863) & 0xfe;
    *(undefined4 *)(lVar3 + 0x185c) = 0;
    *(byte *)(lVar3 + 0x1da7) = *(byte *)(lVar3 + 0x1da7) & 0xfe;
    *(undefined8 *)(lVar3 + 0x1d78) = 0;
    uVar5 = *(uint *)(lVar3 + 0x2058);
    if ((uVar5 >> 0xd & 1) != 0) {
      uVar5 = uVar5 & 0xffffdfff;
      *(undefined1 *)(lVar3 + 0x2096) = *(undefined1 *)(lVar3 + 0x2095);
    }
    *(uint *)(lVar3 + 0x2058) = uVar5 & 0xfdffffff;
    *(undefined4 *)(param_1 + 0x37c) = 0;
    *(undefined1 *)(param_1 + 0x3cc) = 0x17;
    *(undefined1 *)(param_1 + 0x3e6) = 1;
    *(undefined4 *)(param_1 + 0x3a0) = 0;
  }
  return;
}

