/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140119040; RVA 0x119040
 * Ghidra-generated research pseudocode, inferred types, not original source. */

ulonglong FUN_140119040(longlong param_1)

{
  float fVar1;
  undefined1 auVar2 [16];
  uint uVar3;
  int iVar4;
  undefined1 auVar5 [16];
  float fVar6;
  float fVar7;
  char cVar8;
  longlong *in_RAX;
  longlong lVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  
  if ((*(uint *)(param_1 + 0x424) & 0x1000000) == 0) {
    uVar3 = *(uint *)(param_1 + 0x1f0);
    in_RAX = (longlong *)(ulonglong)uVar3;
    if ((((uVar3 & 2) != 0) && ((uVar3 >> 0x12 & 1) != 0)) &&
       (plVar10 = *(longlong **)(param_1 + 0x388), plVar10 != (longlong *)0x0)) {
      lVar13 = param_1;
      cVar8 = FUN_140119e60();
      fVar7 = DAT_1402aa334;
      fVar6 = DAT_1402aa330;
      if (cVar8 == '\0') {
        if (((*(char *)(*plVar10 + 0x15d) == '\x01') ||
            (in_RAX = (longlong *)FUN_140119e90(), (char)in_RAX != '\0')) &&
           ((in_RAX = (longlong *)FUN_140119e90(), (char)in_RAX != '\0' ||
            (*(longlong *)(param_1 + 0x360) != 0)))) {
          in_RAX = (longlong *)**(undefined8 **)(param_1 + 0x180);
          plVar10 = in_RAX + *(byte *)((longlong)*(undefined8 **)(param_1 + 0x180) + 0x34);
          if (in_RAX != plVar10) {
            do {
              lVar11 = *in_RAX;
              if (((*(char *)(lVar11 + 0x15d) == '\x04') || (*(char *)(lVar11 + 0x15d) == '\x05'))
                 && ((*(byte *)(lVar11 + 0x120) & 2) != 0)) {
                lVar12 = 0;
                if (0 < *(int *)(lVar11 + 0x118)) {
                  lVar9 = *(longlong *)(lVar11 + 0x110);
                  do {
                    if (((lVar9 != 0) && ((*(byte *)(lVar9 + 0x1f0) & 2) != 0)) &&
                       (*(longlong *)(lVar9 + 0x360) != 0)) {
                      auVar2 = *(undefined1 (*) [16])(lVar13 + 600);
                      fVar6 = auVar2._0_4_ - *(float *)(lVar9 + 600);
                      auVar5 = vshufps_avx(auVar2,auVar2,0x55);
                      fVar7 = auVar5._0_4_ - *(float *)(lVar9 + 0x25c);
                      auVar2 = vshufps_avx(auVar2,auVar2,0xaa);
                      fVar1 = auVar2._0_4_ - *(float *)(lVar9 + 0x260);
                      if (fVar1 * fVar1 + fVar7 * fVar7 + fVar6 * fVar6 <= DAT_1402aa32c) {
                        *(uint *)(lVar13 + 0x424) = *(uint *)(lVar13 + 0x424) | 0x1000000;
                        return CONCAT71((int7)((ulonglong)in_RAX >> 8),1);
                      }
                    }
                    lVar12 = lVar12 + 1;
                    lVar9 = lVar9 + 0x520;
                  } while (lVar12 < *(int *)(lVar11 + 0x118));
                }
              }
              in_RAX = in_RAX + 1;
            } while (in_RAX != plVar10);
            return (ulonglong)in_RAX & 0xffffffffffffff00;
          }
        }
      }
      else {
        plVar10 = *(longlong **)(param_1 + 0x180);
        in_RAX = (longlong *)*plVar10;
        if (in_RAX != in_RAX + *(byte *)((longlong)plVar10 + 0x34)) {
          do {
            lVar11 = *in_RAX;
            if (((byte)(*(char *)(lVar11 + 0x15d) - 4U) < 2) &&
               ((*(byte *)(lVar11 + 0x120) & 2) != 0)) {
              iVar4 = *(int *)(lVar11 + 0x118);
              lVar11 = 0;
              if (0 < (longlong)iVar4) {
                lVar12 = 0;
                do {
                  lVar9 = *(longlong *)(*in_RAX + 0x110) + lVar12;
                  if (((lVar9 != 0) && ((*(byte *)(lVar9 + 0x1f0) & 2) != 0)) &&
                     ((*(longlong *)(lVar9 + 0x360) != 0 &&
                      (fVar1 = *(float *)(lVar9 + 0x20c), fVar1 <= fVar6)))) {
                    uVar3 = *(uint *)(lVar13 + 0x424);
                    *(uint *)(lVar13 + 0x424) = uVar3 | 0x800000;
                    if (fVar1 <= fVar7) {
                      *(uint *)(lVar13 + 0x424) = uVar3 | 0x1800000;
                      return CONCAT71((int7)((ulonglong)in_RAX >> 8),1);
                    }
                  }
                  lVar11 = lVar11 + 1;
                  lVar12 = lVar12 + 0x520;
                } while (lVar11 < iVar4);
              }
            }
            in_RAX = in_RAX + 1;
          } while (in_RAX != (longlong *)
                             (*plVar10 + (ulonglong)*(byte *)((longlong)plVar10 + 0x34) * 8));
        }
      }
    }
  }
  return (ulonglong)in_RAX & 0xffffffffffffff00;
}

