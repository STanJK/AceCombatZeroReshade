/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400a2a30; RVA 0xa2a30
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400a2a30(longlong param_1)

{
  ushort *puVar1;
  char cVar2;
  float *pfVar3;
  undefined2 uVar4;
  short sVar5;
  float *pfVar6;
  uint uVar7;
  longlong lVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined4 uVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  undefined8 local_d8;
  undefined8 uStack_d0;
  float local_c8;
  float local_c4;
  float local_c0;
  undefined4 local_bc;
  float local_b8;
  float local_b4;
  float local_b0;
  float local_ac;
  undefined8 local_a8;
  undefined8 uStack_a0;
  
  pfVar6 = (float *)(param_1 + 0xa8);
  uVar7 = 1;
  lVar8 = 0x10;
  fVar10 = DAT_1402d2478;
  fVar11 = DAT_1402d24b0;
  fVar12 = DAT_1402d241c;
  uVar13 = DAT_1402d24a8;
  fVar14 = DAT_1402d22d0;
  fVar15 = DAT_1402d206c;
  fVar16 = DAT_1402d2b48;
  do {
    if ((*(uint *)(param_1 + 0x5c) & uVar7) != 0) {
      cVar2 = *(char *)(pfVar6 + 0x16);
      if (cVar2 == '\0') {
        local_b8 = pfVar6[-10] + pfVar6[-2];
        pfVar6[-10] = local_b8;
        local_b4 = pfVar6[-9] + pfVar6[-1];
        pfVar6[-9] = local_b4;
        local_b0 = *pfVar6 + pfVar6[-8];
        pfVar6[-8] = local_b0;
        pfVar6[-7] = pfVar6[-7] + pfVar6[1];
        local_a8 = *(undefined8 *)(pfVar6 + 0x10);
        uStack_a0 = *(undefined8 *)(pfVar6 + 0x12);
        local_ac = fVar14;
        uVar4 = FUN_140035b10(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),100,&local_b8,
                              *(undefined2 *)(pfVar6 + 0xd),0xffff);
        *(undefined2 *)(pfVar6 + 0xd) = uVar4;
        pfVar6[0xb] = fVar14 / (float)*(byte *)(param_1 + 0x30) + pfVar6[0xb];
        fVar9 = SQRT(pfVar6[1] * pfVar6[1] +
                     *pfVar6 * *pfVar6 + pfVar6[-1] * pfVar6[-1] + pfVar6[-2] * pfVar6[-2]) +
                pfVar6[8];
        pfVar6[8] = fVar9;
        if (fVar16 < fVar9 * fVar15) {
          *(uint *)(param_1 + 0x5c) = *(uint *)(param_1 + 0x5c) & ~uVar7;
        }
        pfVar3 = *(float **)(pfVar6 + 6);
        fVar9 = pfVar6[-9];
        if ((fVar9 < fVar10 * pfVar3[1]) && (fVar10 * *pfVar3 < fVar9)) {
          *(undefined1 *)(pfVar6 + 0x16) = 1;
          local_d8 = CONCAT44(fVar9,pfVar6[-10]);
          local_c8 = fVar10 * pfVar3[2];
          uStack_d0 = CONCAT44(pfVar6[-7],pfVar6[-8]);
          local_c0 = 0.0;
          local_c4 = fVar12;
          uVar4 = FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x65,&local_d8
                                ,0);
          *(undefined2 *)(pfVar6 + 0x14) = uVar4;
          *(short *)(pfVar6 + 0x15) = (short)(int)((float)*(byte *)(param_1 + 0x30) * fVar12);
        }
      }
      else if (cVar2 == '\x01') {
        *(short *)(pfVar6 + 0x15) = *(short *)(pfVar6 + 0x15) + -1;
        if (*(short *)(pfVar6 + 0x15) < 1) {
          local_d8 = *(undefined8 *)(pfVar6 + -10);
          uStack_d0 = *(undefined8 *)(pfVar6 + -8);
          *(undefined1 *)(pfVar6 + 0x16) = 2;
          local_c4 = fVar10 * *(float *)(*(longlong *)(pfVar6 + 6) + 8);
          local_c8 = 0.0;
          local_c0 = fVar11;
          local_bc = uVar13;
          uVar4 = FUN_140031f80(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x66ee0),0x66,&local_d8
                                ,0);
          *(undefined2 *)((longlong)pfVar6 + 0x52) = uVar4;
          *(short *)((longlong)pfVar6 + 0x56) =
               (short)(int)((float)*(byte *)(param_1 + 0x30) * fVar11);
          *(undefined1 *)((longlong)pfVar6 + 0x59) = 1;
          if (DAT_14033bd60 == '\0') {
            puVar1 = (ushort *)
                     (*(longlong *)
                       (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x10) + 0x110) +
                       0x1b8) + 0x2090);
            *puVar1 = *puVar1 | 1;
          }
        }
      }
      else if (cVar2 == '\x02') {
        sVar5 = *(short *)((longlong)pfVar6 + 0x56) + -1;
        *(short *)((longlong)pfVar6 + 0x56) = sVar5;
        if (sVar5 < 1) {
          *(uint *)(param_1 + 0x5c) = *(uint *)(param_1 + 0x5c) & ~uVar7;
        }
        else {
          fVar9 = (float)*(byte *)(param_1 + 0x30);
          if ((float)(int)sVar5 <= fVar9 * fVar11 - (fVar9 + fVar9)) {
            *(undefined1 *)((longlong)pfVar6 + 0x59) = 0;
          }
        }
      }
    }
    uVar7 = uVar7 << 1 | (uint)((int)uVar7 < 0);
    pfVar6 = pfVar6 + 0x22;
    lVar8 = lVar8 + -1;
  } while (lVar8 != 0);
  return;
}

