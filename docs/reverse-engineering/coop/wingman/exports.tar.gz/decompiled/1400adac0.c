/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400adac0; RVA 0xadac0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400adac0(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  ushort *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  uVar5 = 0;
  *(undefined4 *)(param_1 + 0xe8) = 1;
  *(undefined8 *)(param_1 + 0xb8) = 0;
  *(undefined8 *)(param_1 + 0xc0) = 0;
  *(undefined8 *)(param_1 + 200) = 0;
  *(undefined8 *)(param_1 + 0xb0) = 0;
  *(undefined8 *)(param_1 + 0xd0) = 0;
  *(undefined8 *)(param_1 + 0xd8) = 0;
  *(undefined8 *)(param_1 + 0xe0) = 0;
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *(undefined1 *)(param_1 + 0xec) = 1;
  FUN_1402038c0(param_1 + 0xb0);
  if (*(undefined2 **)(param_1 + 0xc0) != (undefined2 *)0x0) {
    **(undefined2 **)(param_1 + 0xc0) = 0x3a00;
    if (*(undefined2 **)(param_1 + 200) != (undefined2 *)0x0) {
      **(undefined2 **)(param_1 + 200) = 0x3800;
    }
    puVar1 = *(ushort **)(param_1 + 0xc0);
    if (puVar1 != (ushort *)0x0) {
      iVar3 = 1;
      iVar4 = 1;
      uVar6 = 0;
      uVar2 = 0;
      do {
        if ((int)(uint)puVar1[6] <= iVar4) {
          uVar6 = uVar2;
          break;
        }
        iVar4 = iVar4 * 2;
        uVar2 = uVar2 + 1;
      } while ((int)uVar2 < 0xc);
      uVar2 = 0;
      do {
        if ((int)(uint)puVar1[7] <= iVar3) {
          uVar5 = uVar2;
          break;
        }
        iVar3 = iVar3 * 2;
        uVar2 = uVar2 + 1;
      } while ((int)uVar2 < 0xc);
      *(uint *)(param_1 + 0xb0) =
           (((uVar5 << 4 | uVar6) << 6 | (uint)*(byte *)((longlong)puVar1 + 3)) << 6 |
           (uint)(byte)puVar1[1]) << 0xe | (uint)*puVar1;
      uVar5 = ((uint)*(byte *)(param_1 + 0xe9) * 2 | (uint)*(byte *)(param_1 + 0xe8)) << 2 |
              uVar5 >> 2;
      *(uint *)(param_1 + 0xb4) = uVar5;
      if (*(longlong *)(param_1 + 0xd8) != 0) {
        *(uint *)(param_1 + 0xb4) =
             ((((uint)*(byte *)(param_1 + 0xec) << 5 | (uint)*(ushort *)(param_1 + 0xea)) << 5 |
              (uint)*(byte *)((longlong)*(ushort **)(param_1 + 200) + 3)) << 0xe |
             (uint)**(ushort **)(param_1 + 200)) << 5 |
             (*(uint *)(*(longlong *)(param_1 + 0xb8) + 4) & 2) << 0x16 | uVar5;
      }
    }
  }
  *(undefined8 *)(param_1 + 0x110) = param_3;
  return;
}

