/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140101cc0; RVA 0x101cc0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

float * FUN_140101cc0(longlong param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  longlong lVar3;
  longlong lVar4;
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  longlong lVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined1 local_88 [8];
  float fStack_80;
  float fStack_7c;
  undefined1 local_78 [16];
  undefined1 local_68 [16];
  undefined1 local_58 [8];
  float fStack_50;
  float fStack_4c;
  
  lVar3 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar4 = *(longlong *)(lVar3 + 0x1b8);
  if (((*(ushort *)(lVar4 + 0x1b8) < 0x51) || (*(ushort *)(lVar4 + 0x1bc) < 0x51)) ||
     (*(int *)(*(longlong *)(lVar4 + 0x1d0) + 0x40) == 0)) {
    fVar10 = 0.0;
    fVar11 = 0.0;
    fVar12 = 0.0;
  }
  else {
    lVar9 = (ulonglong)**(ushort **)(*(longlong *)(lVar4 + 0x1d8) + 0x80) * 800;
    lVar4 = *(longlong *)(lVar4 + 0x1b0);
    fVar10 = *(float *)(lVar9 + 0xc4 + lVar4);
    fVar11 = *(float *)(lVar9 + 200 + lVar4);
    fVar12 = *(float *)(lVar9 + 0xcc + lVar4);
  }
  *param_2 = fVar10;
  _local_88 = ZEXT816(0);
  param_2[1] = fVar11;
  local_78 = ZEXT816(0);
  param_2[3] = 1.0;
  param_2[2] = fVar12;
  local_68 = _local_88;
  _local_58 = local_78;
  FUN_140202920(local_88,lVar3 + 0x268);
  fVar10 = *param_2;
  fVar11 = param_2[1];
  fVar12 = param_2[3];
  fVar1 = param_2[2];
  *param_2 = fVar12 * ((float)local_58._0_4_ + *(float *)(lVar3 + 600)) +
             local_68._0_4_ * fVar1 + local_78._0_4_ * fVar11 + fVar10 * (float)local_88._0_4_;
  auVar5 = vshufps_avx(local_78,local_78,0x55);
  auVar6 = vshufps_avx(local_68,local_68,0x55);
  fVar2 = *(float *)(lVar3 + 0x25c);
  auVar7 = vshufps_avx(local_78,local_78,0xaa);
  auVar8 = vshufps_avx(local_68,local_68,0xaa);
  param_2[2] = fVar12 * (fStack_50 + *(float *)(lVar3 + 0x260)) +
               auVar8._0_4_ * fVar1 + auVar7._0_4_ * fVar11 + fVar10 * fStack_80;
  auVar7 = vshufps_avx(local_78,local_78,0xff);
  auVar8 = vshufps_avx(local_68,local_68,0xff);
  param_2[3] = fVar12 * fStack_4c + fVar1 * auVar8._0_4_ +
               auVar7._0_4_ * fVar11 + fVar10 * fStack_7c;
  param_2[1] = fVar12 * ((float)local_58._4_4_ + fVar2) +
               auVar6._0_4_ * fVar1 + auVar5._0_4_ * fVar11 + fVar10 * (float)local_88._4_4_;
  return param_2;
}

