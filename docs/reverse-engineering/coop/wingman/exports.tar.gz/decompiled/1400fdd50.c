/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400fdd50; RVA 0xfdd50
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400fdd50(longlong param_1,undefined8 *param_2)

{
  byte *pbVar1;
  uint *puVar2;
  float fVar3;
  float fVar4;
  short sVar5;
  float *pfVar6;
  longlong lVar7;
  longlong lVar8;
  byte bVar9;
  undefined1 auVar10 [16];
  longlong lVar11;
  longlong *plVar12;
  longlong lVar13;
  float *pfVar14;
  int iVar15;
  longlong lVar16;
  int iVar17;
  longlong unaff_GS_OFFSET;
  
  pfVar6 = (float *)*param_2;
  lVar16 = *(longlong *)
            (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xfffe3ff7 | 0x20;
  *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
  if ((*(uint *)(lVar16 + 0x2058) >> 0xd & 1) == 0) {
    *(uint *)(lVar16 + 0x2058) = *(uint *)(lVar16 + 0x2058) | 0x2000;
    *(undefined1 *)(lVar16 + 0x2095) = *(undefined1 *)(lVar16 + 0x2094);
  }
  *(undefined1 *)(lVar16 + 0x2096) = 1;
  plVar12 = *(longlong **)(param_1 + 0x2f8);
  iVar17 = 0;
  if (*(char *)((longlong)plVar12 + 0x34) != '\0') {
    lVar16 = 0;
    do {
      lVar7 = *plVar12;
      iVar15 = 0;
      lVar11 = *(longlong *)(lVar16 + lVar7);
      if (0 < *(int *)(lVar11 + 0x118)) {
        lVar13 = 0;
        do {
          lVar11 = *(longlong *)(lVar11 + 0x110);
          lVar8 = *(longlong *)(lVar11 + 0x10 + lVar13);
          if (lVar8 != 0) {
            puVar2 = (uint *)(lVar8 + 0xa8);
            *puVar2 = *puVar2 | 0x8000;
          }
          lVar11 = *(longlong *)(lVar11 + 8 + lVar13);
          if (lVar11 != 0) {
            puVar2 = (uint *)(lVar11 + 0xa8);
            *puVar2 = *puVar2 | 0x8000;
          }
          lVar11 = *(longlong *)(lVar16 + lVar7);
          iVar15 = iVar15 + 1;
          lVar13 = lVar13 + 0x520;
        } while (iVar15 < *(int *)(lVar11 + 0x118));
      }
      *(uint *)(lVar11 + 0xf0) = *(uint *)(lVar11 + 0xf0) | 0x8000;
      iVar17 = iVar17 + 1;
      plVar12 = *(longlong **)(param_1 + 0x2f8);
      lVar16 = lVar16 + 8;
    } while (iVar17 < (int)(uint)*(byte *)((longlong)plVar12 + 0x34));
  }
  *(undefined4 *)(param_1 + 0x348) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x350) = 0x48800000;
  *(undefined4 *)(param_1 + 0x34c) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x354) = 0x48800000;
  if (*(longlong *)(param_1 + 0x338) != 0) {
    lVar16 = *(longlong *)(*(longlong *)(param_1 + 0x338) + 0x66ee0);
    *(undefined8 *)(lVar16 + 0x1bc48) = 0;
    *(undefined8 *)(lVar16 + 0x1bc50) = 0;
    *(undefined8 *)(lVar16 + 0x1bc58) = 0;
    *(undefined8 *)(lVar16 + 0x1bc60) = 0;
    *(undefined8 *)(lVar16 + 0x1bc68) = 0;
    *(undefined8 *)(lVar16 + 0x1bc70) = 0;
    *(undefined8 *)(lVar16 + 0x1bc78) = 0;
    *(undefined8 *)(lVar16 + 0x1bc80) = 0;
    *(int *)(lVar16 + 0x1bc8c) = *(int *)(lVar16 + 0x1bc8c) + 1;
    *(undefined4 *)(lVar16 + 0x1bc88) = 0;
    if (0xe < *(int *)(lVar16 + 0x1bc8c)) {
      *(undefined4 *)(lVar16 + 0x1bc8c) = 0;
    }
  }
  *(undefined4 *)(param_1 + 0x90) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x94) = 0xc61c4000;
  *(undefined4 *)(param_1 + 0x98) = 0xc8800000;
  *(undefined4 *)(param_1 + 0x9c) = 0x3f800000;
  *(undefined4 *)(param_1 + 0xa0) = 0x48800000;
  *(undefined4 *)(param_1 + 0xa4) = 0x461c4000;
  *(undefined4 *)(param_1 + 0xa8) = 0x48800000;
  *(undefined4 *)(param_1 + 0xac) = 0x3f800000;
  fVar3 = pfVar6[5];
  fVar4 = pfVar6[8];
  auVar10 = vminss_avx(ZEXT416((uint)fVar4),ZEXT416((uint)fVar3));
  *(int *)(param_1 + 0x90) = auVar10._0_4_;
  pfVar14 = pfVar6 + 8;
  if (fVar4 <= fVar3) {
    pfVar14 = pfVar6 + 5;
  }
  *(float *)(param_1 + 0xa0) = *pfVar14;
  fVar3 = pfVar6[6];
  fVar4 = pfVar6[9];
  auVar10 = vminss_avx(ZEXT416((uint)fVar4),ZEXT416((uint)fVar3));
  *(int *)(param_1 + 0x94) = auVar10._0_4_;
  pfVar14 = pfVar6 + 9;
  if (fVar4 <= fVar3) {
    pfVar14 = pfVar6 + 6;
  }
  *(float *)(param_1 + 0xa4) = *pfVar14;
  auVar10 = vminss_avx(ZEXT416((uint)pfVar6[7]),ZEXT416((uint)pfVar6[10]));
  lVar16 = 0x28;
  if (pfVar6[10] <= pfVar6[7]) {
    lVar16 = 0x1c;
  }
  *(int *)(param_1 + 0x98) = auVar10._0_4_;
  *(undefined4 *)(param_1 + 0xa8) = *(undefined4 *)(lVar16 + (longlong)pfVar6);
  if (*(longlong *)(param_1 + 0x340) != 0) {
    FUN_1400d1560(*(longlong *)(param_1 + 0x340),(*(byte *)((longlong)pfVar6 + 0x2e) & 1) != 0);
  }
  auVar10 = vpcmpeqd_avx(ZEXT116(*(byte *)((longlong)pfVar6 + 0x2e) & 8),SUB6416(ZEXT464(0),0));
  auVar10 = vblendvps_avx(ZEXT416(DAT_1402d22d0),ZEXT816(0),auVar10);
  *(int *)(param_1 + 0x398) = auVar10._0_4_;
  *(int *)(param_1 + 900) = (int)((float)*(byte *)(param_1 + 0x3d1) * *pfVar6);
  if ((*(byte *)((longlong)pfVar6 + 0x2e) & 0x10) == 0) {
    if ((*(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4) < DAT_1437dad18) &&
       (FUN_14022d540(&DAT_1437dad18), DAT_1437dad18 == -1)) {
      _DAT_1437daef0 = 0;
      _DAT_1437daee0 = _DAT_1402d3500;
      uRam00000001437daee8 = _UNK_1402d3508;
      DAT_1437daef4 = 0;
      _Init_thread_footer(&DAT_1437dad18);
    }
    sVar5 = *(short *)(pfVar6 + 0xb);
    bVar9 = DAT_14031f8b1 & 1;
    (&DAT_140310a64)[(uRam00000001437daee8 >> 0x20 & 0xff) * 8] = 0x42fe0000;
    if (bVar9 == 0) {
      lVar16 = (longlong)DAT_1437daee4;
      if (((-1 < sVar5) && ((int)sVar5 < *(int *)(&DAT_14031f838 + lVar16 * 0x18))) &&
         (*(longlong *)(&DAT_14031f840 + lVar16 * 0x18) != 0)) {
        FUN_140186f20((&DAT_14033bc00)
                      [(char)(&DAT_14031f8a8)[lVar16 + (ulonglong)DAT_14031f8b0 * 4]],
                      &DAT_14031f438 + lVar16 * 0x100,
                      *(undefined4 *)
                       (*(longlong *)(&DAT_14031f840 + lVar16 * 0x18) + (longlong)sVar5 * 4),0,
                      (int)(char)(&DAT_14031f8a8)[lVar16 + (ulonglong)DAT_14031f8b0 * 4],0,0,1);
        *(int *)(&DAT_14031f898 + lVar16 * 4) = (int)sVar5;
      }
    }
  }
  if (*(longlong *)(param_1 + 0x308) != 0) {
    FUN_1401a7df0(*(longlong *)(param_1 + 0x308),0);
    FUN_1401a5fc0(*(undefined8 *)(param_1 + 0x308));
  }
  lVar16 = *(longlong *)(param_1 + 800);
  if (lVar16 != 0) {
    *(byte *)(lVar16 + 0x2b) = *(byte *)(lVar16 + 0x2b) & 0xfd;
    if (*(longlong *)(lVar16 + 0x10) != 0) {
      puVar2 = (uint *)(*(longlong *)(lVar16 + 0x10) + 0x56c);
      *puVar2 = *puVar2 | 1;
    }
    if (*(longlong *)(lVar16 + 0x18) != 0) {
      pbVar1 = (byte *)(*(longlong *)(lVar16 + 0x18) + 0x23);
      *pbVar1 = *pbVar1 | 4;
    }
    lVar16 = *(longlong *)(*(longlong *)(param_1 + 800) + 0x10);
    if (lVar16 != 0) {
      puVar2 = (uint *)(lVar16 + 0x40);
      *puVar2 = *puVar2 | 0x4000000;
    }
  }
  *(undefined4 *)(param_1 + 0x378) = 0;
  *(undefined1 *)(param_1 + 999) = 0;
  *(undefined1 *)(param_1 + 0x3cc) = 1;
  return;
}

