/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f43c0; RVA 0xf43c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400f43c0(longlong param_1,longlong *param_2)

{
  uint *puVar1;
  char cVar2;
  char cVar3;
  char cVar4;
  char cVar5;
  char cVar6;
  longlong lVar7;
  bool bVar8;
  longlong lVar9;
  int iVar10;
  longlong *plVar11;
  longlong lVar12;
  int iVar13;
  longlong lVar14;
  
  plVar11 = *(longlong **)(param_1 + 0x2f8);
  if (plVar11 == (longlong *)0x0) {
    return;
  }
  if (param_2 == (longlong *)0x0) {
    return;
  }
  if ((*(byte *)(*param_2 + 0x40) & 8) != 0) {
    return;
  }
  iVar10 = 0;
  if (*(char *)((longlong)plVar11 + 0x34) != '\0') {
    lVar14 = 0;
    do {
      lVar7 = *plVar11;
      lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
      if (*(longlong **)(lVar9 + 0x130) != (longlong *)0x0) {
        cVar2 = *(char *)(**(longlong **)(lVar9 + 0x130) + 0xd);
        if (cVar2 == '\0') {
          if (lVar14 == 0) {
            *(undefined1 *)(lVar9 + 0x15d) = 0;
          }
          else if (lVar14 == 1) {
            *(undefined1 *)(lVar9 + 0x15d) = 2;
          }
        }
        else if (cVar2 == '\x01') {
          *(undefined1 *)(lVar9 + 0x15d) = 1;
        }
        else if (cVar2 == '\x03') {
          *(undefined1 *)(lVar9 + 0x15d) = 3;
        }
        else if (cVar2 == '\x04') {
          cVar2 = *(char *)(*param_2 + 0x60);
          if (cVar2 == '\0') {
            *(undefined1 *)(lVar9 + 0x15d) = 1;
          }
          else if (cVar2 == '\x01') {
            *(undefined1 *)(lVar9 + 0x15d) = 4;
          }
          else if (cVar2 == '\x02') {
            *(undefined1 *)(lVar9 + 0x15d) = 5;
          }
          else if (cVar2 == '\x03') {
            *(undefined1 *)(lVar9 + 0x15d) = 6;
          }
          else if (cVar2 == '\x04') {
            *(undefined1 *)(lVar9 + 0x15d) = 7;
          }
          iVar13 = 0;
          lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
          if ((*(byte *)(*param_2 + 100) & 1) == 0) {
            if (0 < *(int *)(lVar9 + 0x118)) {
              lVar12 = 0;
              do {
                lVar12 = lVar12 + 0x520;
                iVar13 = iVar13 + 1;
                puVar1 = (uint *)(*(longlong *)(lVar9 + 0x110) + -0x330 + lVar12);
                *puVar1 = *puVar1 & 0xffffefff;
                lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
              } while (iVar13 < *(int *)(lVar9 + 0x118));
            }
          }
          else if (0 < *(int *)(lVar9 + 0x118)) {
            lVar12 = 0;
            do {
              lVar12 = lVar12 + 0x520;
              iVar13 = iVar13 + 1;
              puVar1 = (uint *)(*(longlong *)(lVar9 + 0x110) + -0x330 + lVar12);
              *puVar1 = *puVar1 | 0x1000;
              lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
            } while (iVar13 < *(int *)(lVar9 + 0x118));
          }
        }
        else if (cVar2 == '\x05') {
          cVar2 = *(char *)(*param_2 + 0x61);
          if (cVar2 == '\0') {
            *(undefined1 *)(lVar9 + 0x15d) = 1;
          }
          else if (cVar2 == '\x01') {
            *(undefined1 *)(lVar9 + 0x15d) = 4;
          }
          else if (cVar2 == '\x02') {
            *(undefined1 *)(lVar9 + 0x15d) = 5;
          }
          else if (cVar2 == '\x03') {
            *(undefined1 *)(lVar9 + 0x15d) = 6;
          }
          else if (cVar2 == '\x04') {
            *(undefined1 *)(lVar9 + 0x15d) = 7;
          }
          iVar13 = 0;
          lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
          if ((*(byte *)(*param_2 + 0x65) & 1) == 0) {
            if (0 < *(int *)(lVar9 + 0x118)) {
              lVar12 = 0;
              do {
                lVar12 = lVar12 + 0x520;
                iVar13 = iVar13 + 1;
                puVar1 = (uint *)(*(longlong *)(lVar9 + 0x110) + -0x330 + lVar12);
                *puVar1 = *puVar1 & 0xffffefff;
                lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
              } while (iVar13 < *(int *)(lVar9 + 0x118));
            }
          }
          else if (0 < *(int *)(lVar9 + 0x118)) {
            lVar12 = 0;
            do {
              lVar12 = lVar12 + 0x520;
              iVar13 = iVar13 + 1;
              puVar1 = (uint *)(*(longlong *)(lVar9 + 0x110) + -0x330 + lVar12);
              *puVar1 = *puVar1 | 0x1000;
              lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
            } while (iVar13 < *(int *)(lVar9 + 0x118));
          }
        }
        else if (cVar2 == '\x06') {
          cVar2 = *(char *)(*param_2 + 0x62);
          if (cVar2 == '\0') {
            *(undefined1 *)(lVar9 + 0x15d) = 1;
          }
          else if (cVar2 == '\x01') {
            *(undefined1 *)(lVar9 + 0x15d) = 4;
          }
          else if (cVar2 == '\x02') {
            *(undefined1 *)(lVar9 + 0x15d) = 5;
          }
          else if (cVar2 == '\x03') {
            *(undefined1 *)(lVar9 + 0x15d) = 6;
          }
          else if (cVar2 == '\x04') {
            *(undefined1 *)(lVar9 + 0x15d) = 7;
          }
          iVar13 = 0;
          lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
          if ((*(byte *)(*param_2 + 0x66) & 1) == 0) {
            if (0 < *(int *)(lVar9 + 0x118)) {
              lVar12 = 0;
              do {
                lVar12 = lVar12 + 0x520;
                iVar13 = iVar13 + 1;
                puVar1 = (uint *)(*(longlong *)(lVar9 + 0x110) + -0x330 + lVar12);
                *puVar1 = *puVar1 & 0xffffefff;
                lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
              } while (iVar13 < *(int *)(lVar9 + 0x118));
            }
          }
          else if (0 < *(int *)(lVar9 + 0x118)) {
            lVar12 = 0;
            do {
              lVar12 = lVar12 + 0x520;
              iVar13 = iVar13 + 1;
              puVar1 = (uint *)(*(longlong *)(lVar9 + 0x110) + -0x330 + lVar12);
              *puVar1 = *puVar1 | 0x1000;
              lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
            } while (iVar13 < *(int *)(lVar9 + 0x118));
          }
        }
        else if (cVar2 == '\a') {
          cVar2 = *(char *)(*param_2 + 99);
          if (cVar2 == '\0') {
            *(undefined1 *)(lVar9 + 0x15d) = 1;
          }
          else if (cVar2 == '\x01') {
            *(undefined1 *)(lVar9 + 0x15d) = 4;
          }
          else if (cVar2 == '\x02') {
            *(undefined1 *)(lVar9 + 0x15d) = 5;
          }
          else if (cVar2 == '\x03') {
            *(undefined1 *)(lVar9 + 0x15d) = 6;
          }
          else if (cVar2 == '\x04') {
            *(undefined1 *)(lVar9 + 0x15d) = 7;
          }
          iVar13 = 0;
          lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
          if ((*(byte *)(*param_2 + 0x67) & 1) == 0) {
            if (0 < *(int *)(lVar9 + 0x118)) {
              lVar12 = 0;
              do {
                lVar12 = lVar12 + 0x520;
                iVar13 = iVar13 + 1;
                puVar1 = (uint *)(*(longlong *)(lVar9 + 0x110) + -0x330 + lVar12);
                *puVar1 = *puVar1 & 0xffffefff;
                lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
              } while (iVar13 < *(int *)(lVar9 + 0x118));
            }
          }
          else if (0 < *(int *)(lVar9 + 0x118)) {
            lVar12 = 0;
            do {
              lVar12 = lVar12 + 0x520;
              iVar13 = iVar13 + 1;
              puVar1 = (uint *)(*(longlong *)(lVar9 + 0x110) + -0x330 + lVar12);
              *puVar1 = *puVar1 | 0x1000;
              lVar9 = *(longlong *)(lVar7 + lVar14 * 8);
            } while (iVar13 < *(int *)(lVar9 + 0x118));
          }
        }
      }
      plVar11 = *(longlong **)(param_1 + 0x2f8);
      iVar10 = iVar10 + 1;
      lVar14 = lVar14 + 1;
    } while (iVar10 < (int)(uint)*(byte *)((longlong)plVar11 + 0x34));
  }
  lVar14 = *param_2;
  bVar8 = false;
  cVar2 = *(char *)(param_1 + 0x3de);
  cVar3 = *(char *)(lVar14 + 0x60);
  cVar4 = *(char *)(lVar14 + 0x61);
  cVar5 = *(char *)(lVar14 + 0x62);
  cVar6 = *(char *)(lVar14 + 99);
  if (cVar2 == -1) {
LAB_1400f48d5:
    *(char *)(param_1 + 0x3de) = cVar3;
  }
  else if (cVar2 != cVar3) {
    if ((byte)(cVar2 - 1U) < 2) {
      bVar8 = false;
      if (cVar3 == '\0') {
        bVar8 = true;
      }
    }
    if ((cVar2 == '\0') && ((byte)(cVar3 - 1U) < 2)) {
      bVar8 = true;
    }
    goto LAB_1400f48d5;
  }
  cVar2 = *(char *)(param_1 + 0x3df);
  if (cVar2 == -1) {
LAB_1400f490e:
    *(char *)(param_1 + 0x3df) = cVar4;
  }
  else if (cVar2 != cVar4) {
    if (((byte)(cVar2 - 1U) < 2) && (cVar4 == '\0')) {
      bVar8 = true;
    }
    if ((cVar2 == '\0') && ((byte)(cVar4 - 1U) < 2)) {
      bVar8 = true;
    }
    goto LAB_1400f490e;
  }
  cVar2 = *(char *)(param_1 + 0x3e0);
  if (cVar2 == -1) {
LAB_1400f4948:
    *(char *)(param_1 + 0x3e0) = cVar5;
  }
  else if (cVar2 != cVar5) {
    if (((byte)(cVar2 - 1U) < 2) && (cVar5 == '\0')) {
      bVar8 = true;
    }
    if ((cVar2 == '\0') && ((byte)(cVar5 - 1U) < 2)) {
      bVar8 = true;
    }
    goto LAB_1400f4948;
  }
  cVar2 = *(char *)(param_1 + 0x3e1);
  if (cVar2 != -1) {
    if (cVar2 == cVar6) goto LAB_1400f4989;
    if (((byte)(cVar2 - 1U) < 2) && (cVar6 == '\0')) {
      bVar8 = true;
    }
    if ((cVar2 == '\0') && ((byte)(cVar6 - 1U) < 2)) {
      bVar8 = true;
    }
  }
  *(char *)(param_1 + 0x3e1) = cVar6;
LAB_1400f4989:
  if (bVar8) {
    lVar14 = *(longlong *)
              (*(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110) + 0x1b8);
    FUN_1400c1030(lVar14 + 0x1e38);
    *(undefined2 *)(lVar14 + 0x1eec) = 0xffff;
  }
  return;
}

