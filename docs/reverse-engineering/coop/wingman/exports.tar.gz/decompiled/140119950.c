/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140119950; RVA 0x119950
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140119950(longlong param_1,longlong param_2)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = *(uint *)(param_1 + 0x1f0) | 0x8000;
  if ((*(uint *)(param_2 + 0xa8) & 0x2000) == 0) {
    uVar1 = *(uint *)(param_1 + 0x1f0) & 0xffff7fff;
  }
  *(uint *)(param_1 + 0x1f0) = uVar1;
  uVar2 = uVar1 | 0x10000;
  if ((*(uint *)(param_2 + 0xa8) & 0x1000) == 0) {
    uVar2 = uVar1 & 0xfffeffff;
  }
  *(uint *)(param_1 + 0x1f0) = uVar2;
  uVar1 = *(uint *)(param_1 + 500);
  if ((uVar1 & 8) != 0) {
    *(uint *)(param_1 + 500) = uVar1 & 0xffffffbc;
    return;
  }
  uVar2 = uVar1 | 1;
  if ((*(uint *)(param_2 + 0xa8) & 0x10000) == 0) {
    uVar2 = uVar1 & 0xfffffffe;
  }
  *(uint *)(param_1 + 500) = uVar2;
  uVar1 = uVar2 | 2;
  if ((*(uint *)(param_2 + 0xa8) & 0x20000) == 0) {
    uVar1 = uVar2 & 0xfffffffd;
  }
  *(uint *)(param_1 + 500) = uVar1;
  uVar2 = uVar1 | 0x40;
  if ((*(uint *)(param_2 + 0xa8) & 0x80000) == 0) {
    uVar2 = uVar1 & 0xffffffbf;
  }
  *(uint *)(param_1 + 500) = uVar2;
  uVar1 = uVar2 & 0xfffffffb;
  if ((*(uint *)(param_2 + 0xa8) & 0x40000) != 0) {
    uVar1 = uVar2 | 4;
  }
  *(uint *)(param_1 + 500) = uVar1;
  return;
}

