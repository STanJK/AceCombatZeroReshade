/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14017d280; RVA 0x17d280
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_14017d280(longlong param_1,ulonglong param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  undefined **ppuVar4;
  undefined1 *puVar5;
  int iVar6;
  undefined *puVar7;
  byte bStack_29;
  undefined5 local_28;
  undefined1 uStack_23;
  undefined2 uStack_22;
  undefined8 uStack_20;
  undefined1 local_18;
  undefined4 local_17;
  ulonglong local_10;
  
  local_10 = DAT_140309040 ^ (ulonglong)&local_28;
  puVar7 = &DAT_140316e78;
  if (DAT_14031cf18 == '\0') {
    puVar7 = &DAT_140310ec0;
  }
  iVar6 = (int)param_2;
  switch(param_3) {
  case 0:
    return *(uint *)(&DAT_14031ce60 + (param_2 & 0xffffffff) * 4);
  case 1:
    return *(uint *)(&DAT_14031ce68 + (param_2 & 0xffffffff) * 4);
  case 2:
    return *(uint *)(&DAT_14031ce70 + (param_2 & 0xffffffff) * 4);
  case 3:
    return *(uint *)(&DAT_14031ce58 + (param_2 & 0xffffffff) * 4);
  case 4:
    return (int)*(char *)((param_2 & 0xff) + 0x82 + DAT_14032c8c0);
  case 5:
    ppuVar4 = &PTR_PTR_140316e70;
    if (DAT_14031cf18 == '\0') {
      ppuVar4 = &PTR_PTR_140310eb8;
    }
    uVar3 = 0;
    piVar2 = &DAT_140291a20;
    break;
  case 6:
    uStack_20 = _UNK_1402d3528;
    iVar1 = 0x10;
    puVar5 = &local_18;
    do {
      *puVar5 = (char)iVar1;
      puVar5 = puVar5 + 1;
      iVar1 = iVar1 + 1;
    } while (iVar1 < 0x15);
    local_17 = 0x12111207;
    uStack_22 = (undefined2)((ulonglong)_DAT_1402d3520 >> 0x30);
    _local_28 = CONCAT15(5,(int5)_DAT_1402d3520);
    return (uint)(&bStack_29)
                 [*(byte *)(*(longlong *)
                             (param_1 + 0x7c0 +
                             (longlong)*(int *)(puVar7 + (longlong)iVar6 * 4 + 0x24c) * 0x18) + 4 +
                           (longlong)*(int *)(puVar7 + (longlong)iVar6 * 4 + 0x25c))];
  default:
    return 0;
  }
  do {
    if (*piVar2 == *(int *)((longlong)ppuVar4 + (longlong)iVar6 * 4 + 0x254)) {
      return uVar3;
    }
    uVar3 = uVar3 + 1;
    piVar2 = piVar2 + 1;
  } while ((longlong)piVar2 < 0x140291ab0);
  return 0;
}

