/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14013c630; RVA 0x13c630
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_14013c630(longlong *param_1)

{
  float *pfVar1;
  int *piVar2;
  uint *puVar3;
  uint uVar4;
  longlong lVar5;
  bool bVar6;
  bool bVar7;
  undefined2 uVar8;
  uint uVar9;
  float *pfVar10;
  uint uVar11;
  longlong lVar12;
  byte bVar13;
  longlong lVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  
  pfVar10 = (float *)(param_1 + 10);
  bVar7 = false;
  bVar6 = false;
  bVar13 = 0xff;
  if (DAT_14033bd60 != '\0') {
    bVar13 = DAT_14033d9d2;
  }
  uVar11 = 1;
  lVar14 = 0x20;
  fVar16 = DAT_1402d2478;
  fVar17 = DAT_1402d22d0;
  fVar18 = DAT_1402d2654;
  do {
    if ((*(uint *)(param_1 + 0xe7) & uVar11) != 0) {
      if (bVar13 != 0xff) {
        bVar6 = bVar7;
        if (*(byte *)(pfVar10 + 4) == bVar13) {
          bVar6 = true;
          bVar7 = true;
        }
      }
      pfVar1 = pfVar10 + -6;
      fVar15 = fVar17 / (float)*(uint *)((longlong)param_1 + 0x73c);
      fVar15 = -(fVar15 * fVar15 * fVar18) + pfVar10[-1];
      pfVar10[-1] = fVar15;
      *pfVar1 = *pfVar1 + pfVar10[-2];
      pfVar10[-5] = fVar15 + pfVar10[-5];
      pfVar10[-4] = pfVar10[-4] + *pfVar10;
      pfVar10[-3] = pfVar10[-3] + pfVar10[1];
      if (*param_1 != 0) {
        uVar8 = FUN_140035b10(*(undefined8 *)(*param_1 + 0x66ee0),0x20,pfVar1,
                              *(undefined2 *)((longlong)pfVar10 + 0x12),0xffff);
        *(undefined2 *)((longlong)pfVar10 + 0x12) = uVar8;
      }
      fVar15 = SQRT(pfVar10[1] * pfVar10[1] +
                    *pfVar10 * *pfVar10 + pfVar10[-2] * pfVar10[-2] + pfVar10[-1] * pfVar10[-1]) +
               pfVar10[5];
      pfVar10[5] = fVar15;
      if (fVar16 * *(float *)(*(longlong *)(pfVar10 + 2) + 0x14) < fVar15) {
        *(uint *)(param_1 + 0xe7) = *(uint *)(param_1 + 0xe7) & ~uVar11;
        if (*param_1 != 0) {
          lVar5 = *(longlong *)(*param_1 + 0x66ee0);
          uVar9 = (uint)(*(ushort *)((longlong)pfVar10 + 0x12) & 0x3ff);
          if (*(short *)((longlong)pfVar10 + 0x12) == -1) {
            uVar9 = 0xffffffff;
          }
          lVar12 = (longlong)(short)uVar9 >> 5;
          uVar4 = *(uint *)(lVar5 + 0x1bc48 + lVar12 * 4);
          if ((uVar4 >> (uVar9 & 0x1f) & 1) != 0) {
            *(uint *)(lVar5 + 0x1bc48 + lVar12 * 4) = uVar4 & ~(1 << (uVar9 & 0x1f));
            piVar2 = (int *)(lVar5 + 0x1bc88);
            *piVar2 = *piVar2 + -1;
            if (*piVar2 < 0) {
              *(undefined4 *)(lVar5 + 0x1bc88) = 0;
            }
          }
        }
        puVar3 = (uint *)(*(longlong *)
                           (*(longlong *)
                             (*(longlong *)param_1[1] + (ulonglong)*(byte *)(pfVar10 + 4) * 8) +
                           0x110) + 0x1fc + (ulonglong)*(byte *)((longlong)pfVar10 + 0x11) * 0x520);
        *puVar3 = *puVar3 | 0x400000;
      }
    }
    uVar11 = uVar11 << 1 | (uint)((int)uVar11 < 0);
    pfVar10 = pfVar10 + 0xe;
    lVar14 = lVar14 + -1;
  } while (lVar14 != 0);
  if (bVar6) {
    lVar14 = *(longlong *)(*(longlong *)(*(longlong *)param_1[1] + (ulonglong)bVar13 * 8) + 0x110);
    FUN_1401518d0(*(longlong *)(lVar14 + 0x1b8) + 0xad0,*param_1,lVar14 + 600,lVar14 + 0x268,
                  (longlong)param_1 + 0x744,(longlong)param_1 + 0x74c,(int)param_1[0xe8]);
    if (*(uint *)(param_1 + 0xe8) < 0x10) {
      *(uint *)(param_1 + 0xe8) = *(uint *)(param_1 + 0xe8) + 1;
    }
  }
  return;
}

