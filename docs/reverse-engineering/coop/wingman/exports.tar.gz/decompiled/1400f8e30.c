/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f8e30; RVA 0xf8e30
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400f8e30(longlong param_1,undefined8 param_2)

{
  undefined1 (*pauVar1) [16];
  longlong lVar2;
  longlong lVar3;
  bool bVar4;
  bool bVar5;
  bool bVar6;
  undefined8 uVar7;
  bool bVar8;
  int iVar9;
  float fVar10;
  undefined4 uVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  undefined1 auVar20 [16];
  undefined1 auVar21 [64];
  undefined8 local_res10;
  undefined1 local_e8 [8];
  float fStack_e0;
  undefined4 uStack_dc;
  float local_d8;
  float local_d4;
  float local_d0;
  undefined4 local_cc;
  undefined1 local_c8 [176];
  
  lVar2 = *(longlong *)(*(longlong *)**(undefined8 **)(param_1 + 0x2f8) + 0x110);
  lVar3 = *(longlong *)(lVar2 + 0x1b8);
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x20;
  fVar19 = (float)*(int *)(param_1 + 0x378) / (float)*(byte *)(param_1 + 0x3d1);
  pauVar1 = (undefined1 (*) [16])(lVar2 + 600);
  local_e8._0_4_ = *(undefined4 *)*pauVar1;
  bVar4 = (float)local_e8._0_4_ < *(float *)(param_1 + 0x348);
  local_e8._4_4_ = *(float *)(lVar2 + 0x25c);
  uVar7 = *(undefined8 *)*pauVar1;
  local_d0 = *(float *)(lVar2 + 0x260);
  bVar6 = *(float *)(param_1 + 0x350) < (float)local_e8._0_4_;
  bVar5 = local_d0 < *(float *)(param_1 + 0x34c);
  bVar8 = bVar5 || (bVar6 || bVar4);
  local_cc = *(undefined4 *)(lVar2 + 0x264);
  auVar20 = *pauVar1;
  if (local_d0 <= *(float *)(param_1 + 0x354)) {
    if (!bVar5 && (!bVar6 && !bVar4)) goto LAB_1400f8fc5;
  }
  else {
    bVar8 = true;
  }
  if ((*(byte *)(param_1 + 0x3d0) & 1) != 0) {
    *(byte *)(lVar3 + 0x1da7) = *(byte *)(lVar3 + 0x1da7) | 1;
    *(undefined4 *)(lVar3 + 0x1d78) = 0xbe800000;
    *(undefined4 *)(lVar3 + 0x1d7c) = 0x3f800000;
    *(byte *)(lVar3 + 0x1863) = *(byte *)(lVar3 + 0x1863) | 1;
    *(undefined4 *)(lVar3 + 0x185c) = 0;
    if ((*(uint *)(lVar3 + 0x2058) >> 0xd & 1) == 0) {
      *(uint *)(lVar3 + 0x2058) = *(uint *)(lVar3 + 0x2058) | 0x2000;
      *(undefined1 *)(lVar3 + 0x2095) = *(undefined1 *)(lVar3 + 0x2094);
    }
    *(undefined1 *)(lVar3 + 0x2096) = 1;
    local_e8._4_4_ = SUB84((ulonglong)uVar7 >> 0x20,0);
    local_e8._0_4_ = SUB84(uVar7,0);
  }
LAB_1400f8fc5:
  if ((*(byte *)(lVar2 + 0x1f0) & 1) != 0) {
    *(short *)(param_1 + 0x3be) = *(short *)(param_1 + 0x3be) + 1;
  }
  local_d8 = (float)local_e8._0_4_ + DAT_1402d2a54;
  local_c8._0_16_ = ZEXT416(0);
  local_d0 = local_d0 + DAT_1402d2a54;
  local_d4 = (float)local_e8._4_4_ + DAT_1402d2a54;
  local_res10 = param_2;
  _local_e8 = auVar20;
  iVar9 = FUN_1400782c0(*(undefined8 *)(lVar3 + 0x2038),local_c8,&local_res10,&local_d8,local_e8);
  auVar21 = ZEXT464((uint)DAT_1402d22d0);
  if (iVar9 == 0) {
    fVar12 = fVar19 + DAT_1402d24d0;
  }
  else {
    fVar12 = (DAT_1402d22d0 - (float)local_c8._12_4_) * DAT_1402d2544 + fVar19 + DAT_1402d23c0;
  }
  fVar12 = fVar12 - (float)(int)*(short *)(param_1 + 0x3be) / (float)*(byte *)(param_1 + 0x3d1);
  fVar17 = fVar12 * DAT_1402d287c + (float)local_e8._0_4_;
  fVar15 = fVar12 * DAT_1402d287c + fStack_e0;
  fVar18 = fStack_e0 - fVar15;
  fVar16 = fVar12 * DAT_1402d287c + (float)local_e8._4_4_;
  fVar12 = (float)local_e8._0_4_ - fVar17;
  fVar13 = (float)local_e8._4_4_ - fVar16;
  fVar10 = SQRT(fVar18 * fVar18 + fVar13 * fVar13 + fVar12 * fVar12);
  fVar14 = DAT_1402d22d0 / fVar10;
  uVar11 = uStack_dc;
  FUN_1401fbec0(fVar10);
  FUN_140014960(param_1 + 0xe0,lVar3 + 0x10b0);
  auVar20 = vmaxss_avx(ZEXT416((uint)(fVar14 * fVar13)),ZEXT416(DAT_1402d2d64));
  auVar20 = vminss_avx(auVar20,auVar21._0_16_);
  *(float *)(param_1 + 0x110) = fVar17;
  *(float *)(param_1 + 0x114) = fVar16;
  *(float *)(param_1 + 0x118) = fVar15;
  *(undefined4 *)(param_1 + 0x11c) = uVar11;
  uVar11 = FUN_140272150(auVar20._0_8_);
  *(undefined4 *)(param_1 + 0x120) = uVar11;
  uVar11 = FUN_140272370(CONCAT44(_UNK_1402d3774,(uint)(fVar14 * fVar12) ^ DAT_1402d3770),
                         CONCAT44(_UNK_1402d3774,(uint)(fVar14 * fVar18) ^ DAT_1402d3770));
  *(undefined8 *)(param_1 + 0x128) = 0;
  *(undefined4 *)(param_1 + 0x124) = uVar11;
  FUN_1401fbec0(param_1 + 0xe0);
  auVar20 = auVar21._0_16_;
  if ((*(byte *)(lVar2 + 0x1f0) & 2) == 0) {
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x48;
    FUN_1401c56d0();
    FUN_1401c6590();
    auVar20 = auVar21._0_16_;
  }
  if ((*(char *)(param_1 + 0x3da) != '\x01') &&
     (fVar12 = (float)*(ushort *)(param_1 + 0x3ba) / (float)*(byte *)(param_1 + 0x3d1),
     fVar12 - DAT_1402d236c <= fVar19)) {
    auVar20 = vminss_avx(ZEXT416((uint)((fVar19 - fVar12) + DAT_1402d236c)),auVar20);
    *(int *)(param_1 + 0x3a0) = auVar20._0_4_;
  }
  if (*(int *)(param_1 + 0x378) < (int)(uint)*(ushort *)(param_1 + 0x3ba)) {
    if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
      *(int *)(param_1 + 0x378) = *(int *)(param_1 + 0x378) + 1;
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x378) = 0;
    if (bVar8) {
      *(undefined1 *)(param_1 + 0x3cc) = 6;
    }
    else {
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x40000;
      *(undefined1 *)(param_1 + 0x3cc) = 8;
      *(undefined1 *)(*(longlong *)(param_1 + 0x340) + 0xa8820) = 2;
      *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
    }
  }
  return;
}

