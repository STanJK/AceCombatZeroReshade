/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14013dae0; RVA 0x13dae0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14013dae0(longlong *param_1)

{
  int *piVar1;
  uint *puVar2;
  undefined1 uVar3;
  byte bVar4;
  ushort uVar5;
  uint uVar6;
  longlong *plVar7;
  byte bVar8;
  undefined1 auVar9 [16];
  char cVar10;
  undefined2 uVar11;
  int iVar12;
  int iVar13;
  undefined1 *puVar14;
  longlong lVar15;
  undefined4 *puVar16;
  longlong lVar17;
  undefined1 *puVar18;
  longlong lVar19;
  uint uVar20;
  longlong lVar21;
  uint uVar22;
  ulonglong uVar23;
  longlong lVar24;
  longlong unaff_GS_OFFSET;
  float fVar25;
  undefined4 uVar26;
  ulonglong uVar27;
  undefined8 uVar28;
  undefined1 auVar29 [16];
  undefined1 auVar30 [16];
  undefined1 extraout_var [56];
  undefined1 extraout_var_00 [56];
  undefined1 extraout_var_01 [56];
  undefined1 extraout_var_02 [56];
  undefined1 extraout_var_03 [56];
  undefined1 extraout_var_04 [56];
  undefined1 extraout_var_05 [56];
  float fVar31;
  float fVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  undefined1 auVar37 [64];
  undefined1 auVar38 [64];
  undefined1 auVar39 [64];
  undefined1 auVar40 [64];
  undefined1 in_ZMM11 [64];
  undefined1 auVar41 [64];
  undefined1 auVar42 [64];
  undefined1 auVar43 [64];
  uint uVar44;
  float local_res10 [2];
  undefined2 local_res18 [4];
  float local_res20;
  longlong in_stack_fffffffffffffdc0;
  undefined4 uVar45;
  uint local_208;
  undefined1 local_200 [8];
  float fStack_1f8;
  float fStack_1f4;
  uint local_1f0;
  undefined8 local_1e8;
  undefined8 uStack_1e0;
  float local_1d8;
  undefined1 local_1d0 [12];
  float fStack_1c4;
  undefined1 local_1c0 [4];
  undefined1 auStack_1bc [12];
  uint local_1b0;
  int local_1ac;
  longlong *local_1a8;
  float local_1a0;
  float fStack_19c;
  float fStack_198;
  float fStack_194;
  uint local_190;
  ulonglong local_188;
  undefined4 local_178;
  float local_174;
  uint local_170;
  float local_16c;
  float local_168;
  float local_164;
  float local_160;
  float local_15c;
  uint local_158;
  float local_154;
  undefined4 local_150;
  float local_14c;
  float local_148;
  float local_144;
  float local_140;
  float local_13c;
  float local_138;
  float local_134;
  float local_130;
  float local_12c;
  float local_128;
  float local_124;
  float local_120;
  float local_11c;
  float local_118;
  float local_114;
  float local_110;
  float local_10c;
  float local_108;
  float local_104;
  float local_100;
  float local_fc;
  longlong local_f8;
  longlong local_f0;
  longlong local_e8;
  undefined1 local_98 [16];
  
  local_98 = in_ZMM11._0_16_;
  _local_1d0 = ZEXT816(0);
  _local_200 = ZEXT816(0);
  local_1ac = 0;
  uVar20 = 1;
  lVar24 = 0;
  uVar26 = 0;
  fVar25 = DAT_1402d1ef8;
  uVar44 = DAT_1402d3770;
  do {
    auVar29 = _local_200;
    iVar12 = local_1ac;
    if ((*(uint *)(param_1 + 0xdd) & uVar20) != 0) {
      fVar34 = *(float *)(lVar24 + 0x180 + (longlong)param_1);
      local_1a0 = *(float *)(lVar24 + 0x158 + (longlong)param_1);
      fVar35 = *(float *)(lVar24 + 0x178 + (longlong)param_1);
      fStack_198 = *(float *)(lVar24 + 0x160 + (longlong)param_1);
      fStack_19c = *(float *)(lVar24 + 0x15c + (longlong)param_1);
      fVar36 = *(float *)(lVar24 + 0x17c + (longlong)param_1);
      fStack_194 = *(float *)(lVar24 + 0x164 + (longlong)param_1);
      fVar33 = *(float *)(lVar24 + 0x184 + (longlong)param_1);
      uVar23 = (ulonglong)*(byte *)(lVar24 + 0x19c + (longlong)param_1);
      fVar32 = fVar35 + local_1a0;
      local_200._0_4_ = fVar32;
      auVar30 = _local_200;
      fStack_1f4 = auVar29._12_4_;
      local_200 = auVar30._0_8_;
      fStack_1f8 = fVar34 + fStack_198;
      local_200._4_4_ = fVar36 + fStack_19c;
      fStack_1f4 = fVar33 + fStack_194;
      lVar19 = *(longlong *)param_1[1];
      local_190 = (uint)*(byte *)(param_1[1] + 0x34);
      local_208 = 0;
      fVar34 = SQRT(fVar33 * fVar33 + fVar34 * fVar34 + fVar36 * fVar36 + fVar35 * fVar35);
      local_res20 = fVar34;
      local_188 = uVar23;
      local_e8 = lVar19;
      if (local_190 != 0) {
        local_f0 = 0;
        do {
          uVar27 = 0;
          local_1a8 = (longlong *)(*(longlong *)param_1[1] + local_f0);
          lVar21 = *local_1a8;
          if ((*(byte *)(lVar21 + 0x120) & 4) != 0) {
            if ((&DAT_1402accc0)
                [(ulonglong)*(byte *)(lVar21 + 0x15d) +
                 (ulonglong)*(byte *)(*(longlong *)(lVar19 + uVar23 * 8) + 0x15d) * 8] != '\0') {
              local_f8 = (longlong)*(int *)(lVar21 + 0x118);
              local_1b0 = 0;
              if (0 < local_f8) {
                auVar29._8_8_ = 0;
                auVar29._0_8_ = auStack_1bc._4_8_;
                _local_1c0 = auVar29 << 0x40;
                bVar8 = (byte)iVar12 & 0x1f;
                uVar20 = 1 << bVar8 | 1U >> 0x20 - bVar8;
                uVar23 = uVar27;
                local_1f0 = uVar20;
                do {
                  uVar22 = (uint)uVar27;
                  if ((local_208 != *(byte *)(lVar24 + 0x19c + (longlong)param_1)) ||
                     (uVar22 != *(byte *)(lVar24 + 0x19d + (longlong)param_1))) {
                    lVar19 = *(longlong *)(*local_1a8 + 0x110) + uVar23;
                    if ((*(byte *)(lVar19 + 0x1f0) & 1) != 0) {
                      fVar35 = *(float *)*(undefined1 (*) [16])(lVar19 + 600) - local_1a0;
                      fVar36 = *(float *)(lVar19 + 0x25c) - fStack_19c;
                      fVar33 = *(float *)(lVar19 + 0x260) - fStack_198;
                      _local_1d0 = *(undefined1 (*) [16])(lVar19 + 600);
                      fVar34 = fVar34 + *(float *)(lVar19 + 0x41c);
                      if (fVar33 * fVar33 + fVar36 * fVar36 + fVar35 * fVar35 <= fVar34 * fVar34) {
                        lVar21 = **(longlong **)(lVar19 + 0x1a0);
                        if (*(short *)(lVar21 + 0x6c) == 0x46) {
                          uVar44 = *(uint *)(lVar19 + 0x268);
                          auVar43 = ZEXT464(*(uint *)(lVar19 + 0x26c));
                          auVar39._0_8_ = FUN_14026f3b0(uVar44);
                          auVar39._8_56_ = extraout_var;
                          auVar29 = auVar39._0_16_;
                          auVar41 = ZEXT1664(auVar29);
                          fVar34 = (float)((uint)auVar39._0_8_ ^ DAT_1402d3770);
                          auVar29 = vshufps_avx(auVar29,auVar29,1);
                          auVar40 = ZEXT1664(auVar29);
                          auVar37._0_8_ = FUN_14026f3b0(auVar43._0_8_);
                          auVar37._8_56_ = extraout_var_00;
                          auVar29 = auVar37._0_16_;
                          auVar39 = ZEXT1664(auVar29);
                          auVar29 = vshufps_avx(auVar29,auVar29,1);
                          auVar42 = ZEXT1664(auVar29);
                          fVar25 = 0.0;
                          local_res10[0] = (float)((uint)(float)auVar37._0_8_ ^ DAT_1402d3770);
                          if (auVar29._0_4_ * auVar40._0_4_ * fVar33 +
                              fVar34 * fVar36 + (float)auVar37._0_8_ * auVar40._0_4_ * fVar35 < 0.0)
                          {
                            _local_1c0 = *(undefined1 (*) [16])(lVar24 + 0x178 + (longlong)param_1);
                            auVar37 = ZEXT1664(_local_1c0);
                            auVar38._0_8_ = FUN_14026f3b0(uVar44 ^ DAT_1402d3770);
                            auVar38._8_56_ = extraout_var_01;
                            auVar38 = ZEXT1664(auVar38._0_16_);
                            auVar30._4_12_ = ZEXT812(0);
                            auVar30._0_4_ = auVar43._0_4_ ^ DAT_1402d3770;
                            uVar44 = DAT_1402d3770;
                            auVar43._0_8_ = FUN_14026f3b0(auVar30._0_8_,0);
                            auVar43._8_56_ = extraout_var_02;
                            auVar29 = vshufps_avx(auVar43._0_16_,auVar43._0_16_,1);
                            auVar30 = vshufps_avx(auVar37._0_16_,auVar37._0_16_,0xaa);
                            fVar35 = (float)auVar43._0_8_ * auVar30._0_4_ +
                                     auVar29._0_4_ * auVar37._0_4_;
                            fVar32 = fVar35 * 0.0 + (float)auStack_1bc._8_4_;
                            auVar9 = vshufps_avx(auVar38._0_16_,auVar38._0_16_,1);
                            fVar36 = auVar9._0_4_ * (float)auStack_1bc._0_4_ +
                                     (float)((uint)(auVar38._0_4_ *
                                                   (auVar29._0_4_ * auVar30._0_4_ -
                                                   (float)auVar43._0_8_ * auVar37._0_4_)) ^ uVar44);
                            fVar33 = (float)((uint)(fVar36 * DAT_1402d2158 + fVar35 * DAT_1402d2158)
                                             & _DAT_1402d3760 ^ uVar44);
                            fVar31 = SQRT(fVar32 * fVar32 +
                                          fVar33 * fVar33 + fVar36 * fVar36 + fVar35 * fVar35);
                            auStack_1bc._8_4_ = fVar32;
                            _local_1c0 = auStack_1bc << 0x20;
                            if (fVar31 != fVar25) {
                              fVar31 = DAT_1402d22d0 / fVar31;
                              fVar35 = fVar31 * fVar35;
                              fVar36 = fVar36 * fVar31;
                              fVar33 = fVar33 * fVar31;
                              fVar32 = fVar31 * fVar32;
                            }
                            auStack_1bc._8_4_ = fVar32;
                            fVar25 = fVar36 * auVar41._0_4_ + auVar40._0_4_ * fVar33;
                            fVar32 = fVar35 * local_res10[0] + fVar25 * auVar42._0_4_;
                            auVar37 = ZEXT464((uint)fVar32);
                            fVar25 = fVar35 * auVar42._0_4_ + fVar25 * auVar39._0_4_;
                            auVar39 = ZEXT464((uint)fVar25);
                            local_1c0 = (undefined1  [4])fVar25;
                            uVar26 = FUN_140272370(fVar36 * auVar40._0_4_ + fVar34 * fVar33,
                                                   SQRT(fVar32 * fVar32 + fVar25 * fVar25));
                            *(undefined4 *)(lVar24 + 0x168 + (longlong)param_1) = uVar26;
                            fVar25 = (float)FUN_140272370(auVar39._0_8_,auVar37._0_8_);
                            fVar34 = DAT_1402d2420;
                            fVar25 = fVar25 + DAT_1402d2420;
                            *(float *)(lVar24 + 0x16c + (longlong)param_1) = fVar25;
                            *(undefined8 *)(lVar24 + 0x170 + (longlong)param_1) = 0;
                            if (fVar34 < fVar25) {
                              *(float *)(lVar24 + 0x16c + (longlong)param_1) =
                                   fVar25 - DAT_1402d249c;
                            }
                            *(undefined2 *)(lVar24 + 0x19a + (longlong)param_1) = 0xffff;
                            *(undefined1 *)(lVar24 + 0x19c + (longlong)param_1) =
                                 *(undefined1 *)(lVar19 + 0x234);
                            *(undefined1 *)(lVar24 + 0x19d + (longlong)param_1) =
                                 *(undefined1 *)(lVar19 + 0x235);
                            goto LAB_14013e1f8;
                          }
                          fVar25 = DAT_1402d1ef8;
                          uVar44 = DAT_1402d3770;
                        }
                        fVar34 = 0.0;
                        plVar7 = *(longlong **)(lVar19 + 0x3a0);
                        if (*(char *)(lVar21 + 0x6f) == '\x01') {
                          uVar27 = (ulonglong)*(uint *)(lVar21 + 0x40);
                        }
                        else if (plVar7 == (longlong *)0x0) {
                          uVar27 = (ulonglong)DAT_1402d2698;
                        }
                        else {
                          uVar27 = (**(code **)(*plVar7 + 0xa0))(plVar7);
                        }
                        iVar12 = FUN_14014d070(&local_1a0,local_200,local_1d0,uVar27);
                        if (iVar12 != 0) {
                          if (*(char *)(lVar21 + 0x6f) != '\x02') {
                            fVar35 = DAT_1402d22d0;
LAB_14013e3eb:
                            uVar22 = *(uint *)(lVar19 + 0x1f0);
                            puVar14 = operator_new((longlong)*(int *)(*local_1a8 + 0x118));
                            iVar12 = 0;
                            if (0 < *(int *)(*local_1a8 + 0x118)) {
                              puVar18 = puVar14;
                              do {
                                *puVar18 = 0;
                                puVar18 = puVar18 + 1;
                                iVar12 = iVar12 + 1;
                              } while (iVar12 < *(int *)(*local_1a8 + 0x118));
                            }
                            lVar21 = *(longlong *)
                                      (*(longlong *)
                                        (*(longlong *)param_1[1] +
                                        (ulonglong)*(byte *)(lVar24 + 0x19c + (longlong)param_1) * 8
                                        ) + 0x110) +
                                     (ulonglong)*(byte *)(lVar24 + 0x19d + (longlong)param_1) *
                                     0x520;
                            in_stack_fffffffffffffdc0 = lVar21;
                            FUN_140118040(lVar19,&local_1a8,puVar14,
                                          *(undefined1 *)
                                           (*(longlong *)(lVar24 + 0x188 + (longlong)param_1) + 0x49
                                           ),1,lVar21,3);
                            auVar29 = _local_1d0;
                            if (((*(uint *)(lVar19 + 0x1f0) >> 0x18 & 1) == 0) &&
                               ((0 < *(short *)(lVar19 + 0x428) ||
                                ((*(uint *)(lVar19 + 0x1f0) & 1) != 0)))) {
                              if (*param_1 != 0) {
                                uStack_1e0._0_4_ = (float)local_1d0._8_4_;
                                fStack_1c4 = fVar35;
                                local_1e8 = auVar29._0_8_;
                                uStack_1e0._4_4_ = fVar35;
                                iVar12 = FUN_140242630();
                                local_1e8._0_4_ =
                                     (float)(iVar12 % 0x7d1 + -1000) * fVar25 + (float)local_1e8;
                                iVar12 = FUN_140242630();
                                local_1e8 = CONCAT44((float)(iVar12 % 0x3e9) * fVar25 +
                                                     local_1e8._4_4_,(float)local_1e8);
                                iVar12 = FUN_140242630();
                                local_1d8 = 1.4013e-45;
                                uStack_1e0 = CONCAT44(uStack_1e0._4_4_,
                                                      (float)(iVar12 % 0x7d1 + -1000) * fVar25 +
                                                      (float)uStack_1e0);
                                FUN_140031f80(*(undefined8 *)(*param_1 + 0x66ee0),0x33,&local_1e8,0)
                                ;
                                uVar5 = *(ushort *)(lVar24 + 0x198 + (longlong)param_1);
                                lVar15 = *(longlong *)(*param_1 + 0x66ee0);
                                uVar20 = (uint)(uVar5 & 0x3ff);
                                if (uVar5 == 0xffff) {
                                  uVar20 = 0xffffffff;
                                }
                                lVar17 = (longlong)(short)uVar20 >> 5;
                                uVar6 = *(uint *)(lVar15 + 0x1bc48 + lVar17 * 4);
                                if ((uVar6 >> (uVar20 & 0x1f) & 1) != 0) {
                                  *(uint *)(lVar15 + 0x1bc48 + lVar17 * 4) =
                                       uVar6 & ~(1 << (uVar20 & 0x1f));
                                  piVar1 = (int *)(lVar15 + 0x1bc88);
                                  *piVar1 = *piVar1 + -1;
                                  if (*piVar1 < 0) {
                                    *(undefined4 *)(lVar15 + 0x1bc88) = 0;
                                  }
                                }
                              }
                              lVar15 = *(longlong *)(lVar19 + 0x1b8);
                              uVar28 = FUN_1401c56d0();
                              if (lVar15 == 0) {
                                local_1e8 = _DAT_1402d35f0;
                                uStack_1e0 = _UNK_1402d35f8;
                                in_stack_fffffffffffffdc0 =
                                     CONCAT44((int)((ulonglong)in_stack_fffffffffffffdc0 >> 0x20),
                                              DAT_1402d2100);
                                cVar10 = FUN_1401c6a00(DAT_1402d2100,1,0x1b,local_200,&local_1e8,
                                                       in_stack_fffffffffffffdc0,DAT_1402d234c,
                                                       DAT_1402d2458,fVar34,0,1);
                                if ((((cVar10 != '\0') &&
                                     (lVar15 = FUN_1401c97a0(), '\x01' < *(char *)(lVar15 + 0x3dc2))
                                     ) && (uVar5 = *(ushort *)(lVar15 + 0x138),
                                          (~*(byte *)(*(longlong *)
                                                       (&DAT_14032d5a8 + (ulonglong)uVar5 * 0x18) +
                                                     0x882) & 1) != 0)) &&
                                   (puVar16 = (undefined4 *)FUN_1401c9e60(lVar15),
                                   puVar16 != (undefined4 *)0x0)) {
                                  *(ushort *)(puVar16 + 0x11) = uVar5;
                                  *(undefined2 *)((longlong)puVar16 + 0x46) = 0x1b;
                                  *puVar16 = local_200._0_4_;
                                  puVar16[1] = local_200._4_4_;
                                  puVar16[2] = fStack_1f8;
                                  puVar16[3] = fStack_1f4;
                                  *(undefined8 *)(puVar16 + 4) = 0;
                                  puVar16[6] = 0;
                                  puVar16[7] = 0x3f800000;
                                  puVar16[8] = 0x3ea3d70a;
                                  puVar16[9] = 0x3fb33333;
                                  *(undefined8 *)(puVar16 + 10) = 0x40800000;
                                  puVar16[0xf] = 0x3f800000;
                                  *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
                                  *(byte *)(puVar16 + 0x1c) =
                                       *(byte *)(puVar16 + 0x1c) & 0xee | 0x26;
                                  *(code **)(puVar16 + 0xc) = FUN_1401caa00;
                                }
                              }
                              else {
                                cVar10 = *(char *)(lVar15 + 0x2094);
                                if (cVar10 == '\0') {
                                  uVar11 = 0x59;
                                }
                                else if (cVar10 == '\x02') {
                                  uVar11 = 0x5a;
                                }
                                else {
                                  if (cVar10 != '\x01') goto LAB_14013e673;
                                  uVar11 = 0x5b;
                                }
                                local_res10[0] = (float)CONCAT22(local_res10[0]._2_2_,uVar11);
                                local_res18[0] = 1;
                                FUN_1401c6150(uVar28,local_res18,local_res10);
                              }
                            }
LAB_14013e673:
                            uVar20 = local_1f0;
                            if (((*(uint *)(lVar19 + 0x1f0) & 0x1000000) == 0) ||
                               ((uVar22 >> 1 & 1) == 0)) {
                              cVar10 = *(char *)(**(longlong **)(lVar19 + 0x388) + 0x15d);
                              if ((cVar10 == '\0') || (cVar10 == '\x02')) {
                                *(undefined4 *)(lVar19 + 0x214) = 0;
                              }
                            }
                            else {
                              *(undefined4 *)(lVar19 + 0x214) = 0xffffffff;
                            }
                            uVar3 = *(undefined1 *)(lVar19 + 0x235);
                            *(undefined1 *)(lVar21 + 0x240) = *(undefined1 *)(lVar19 + 0x234);
                            *(undefined1 *)(lVar21 + 0x241) = uVar3;
                            *(uint *)(param_1 + 0xdd) = *(uint *)(param_1 + 0xdd) & ~local_1f0;
                            thunk_FUN_1402500f0(puVar14);
                            uVar23 = _local_1c0;
                            uVar22 = local_1b0;
                            goto LAB_14013e1f8;
                          }
                          if (plVar7 != (longlong *)0x0) {
                            auVar40._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar19 + 0x26c));
                            auVar40._8_56_ = extraout_var_03;
                            auVar29 = vshufps_avx(auVar40._0_16_,auVar40._0_16_,1);
                            local_158 = (uint)auVar40._0_8_;
                            local_170 = local_158 ^ uVar44;
                            local_178 = auVar29._0_4_;
                            local_164 = DAT_1402d22d0;
                            local_13c = DAT_1402d22d0;
                            fVar35 = DAT_1402d22d0;
                            local_174 = fVar34;
                            local_16c = fVar34;
                            local_168 = fVar34;
                            local_160 = fVar34;
                            local_15c = fVar34;
                            local_154 = fVar34;
                            local_150 = local_178;
                            local_14c = fVar34;
                            local_148 = fVar34;
                            local_144 = fVar34;
                            local_140 = fVar34;
                            auVar41._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar19 + 0x268));
                            auVar41._8_56_ = extraout_var_04;
                            auVar29 = vshufps_avx(auVar41._0_16_,auVar41._0_16_,1);
                            local_120 = (float)auVar41._0_8_;
                            local_114 = (float)((uint)local_120 ^ uVar44);
                            local_124 = auVar29._0_4_;
                            local_138 = fVar35;
                            local_134 = fVar34;
                            local_130 = fVar34;
                            local_12c = fVar34;
                            local_128 = fVar34;
                            local_11c = fVar34;
                            local_118 = fVar34;
                            local_110 = local_124;
                            local_10c = fVar34;
                            local_108 = fVar34;
                            local_104 = fVar34;
                            local_100 = fVar34;
                            local_fc = fVar35;
                            FUN_140005940(&local_178,&local_178,&local_138);
                            auVar42._0_8_ = FUN_14026f3b0(*(undefined4 *)(lVar19 + 0x270));
                            auVar42._8_56_ = extraout_var_05;
                            auVar29 = vshufps_avx(auVar42._0_16_,auVar42._0_16_,1);
                            local_134 = (float)auVar42._0_8_;
                            local_128 = (float)((uint)local_134 ^ uVar44);
                            local_138 = auVar29._0_4_;
                            local_124 = local_138;
                            local_120 = fVar34;
                            local_114 = fVar34;
                            local_110 = fVar35;
                            FUN_140005940(&local_178,&local_178,&local_138);
                            local_148 = local_148 + *(float *)(lVar19 + 600);
                            local_144 = local_144 + *(float *)(lVar19 + 0x25c);
                            local_140 = local_140 + *(float *)(lVar19 + 0x260);
                            iVar12 = (**(code **)(*plVar7 + 0x120))
                                               (plVar7,local_1d0,&local_178,&local_1a0,local_200);
                            if (iVar12 != 0) goto LAB_14013e3eb;
                          }
                        }
                        uVar20 = local_1f0;
                      }
LAB_14013e1f8:
                      fVar34 = local_res20;
                    }
                  }
                  local_1b0 = uVar22 + 1;
                  uVar27 = (ulonglong)local_1b0;
                  uVar23 = uVar23 + 0x520;
                  local_f8 = local_f8 + -1;
                  _local_1c0 = uVar23;
                  fVar25 = DAT_1402d1ef8;
                } while (local_f8 != 0);
                local_f8 = 0;
                lVar19 = local_e8;
                iVar12 = local_1ac;
              }
            }
            uVar23 = local_188;
          }
          local_208 = local_208 + 1;
          local_f0 = local_f0 + 8;
        } while ((int)local_208 < (int)local_190);
        uVar26 = 0;
      }
      local_res10[0] = 0.0;
      iVar13 = FUN_1400782c0(param_1[2],local_1d0,local_res10,&local_1a0,local_200);
      fVar34 = local_res10[0];
      uVar45 = (undefined4)((ulonglong)in_stack_fffffffffffffdc0 >> 0x20);
      if (iVar13 != 0) {
        *(uint *)(param_1 + 0xdd) = *(uint *)(param_1 + 0xdd) & ~uVar20;
        lVar21 = (ulonglong)*(byte *)(lVar24 + 0x19d + (longlong)param_1) * 0x520;
        lVar19 = *(longlong *)
                  (*(longlong *)
                    (*(longlong *)param_1[1] +
                    (ulonglong)*(byte *)(lVar24 + 0x19c + (longlong)param_1) * 8) + 0x110);
        puVar2 = (uint *)(lVar19 + 0x1fc + lVar21);
        *puVar2 = *puVar2 | 0x100000;
        uVar3 = *(undefined1 *)(lVar24 + 0x19b + (longlong)param_1);
        *(undefined1 *)(lVar19 + 0x240 + lVar21) =
             *(undefined1 *)(lVar24 + 0x19a + (longlong)param_1);
        *(undefined1 *)(lVar19 + 0x241 + lVar21) = uVar3;
        bVar8 = *(byte *)(lVar24 + 0x19a + (longlong)param_1);
        bVar4 = *(byte *)(lVar24 + 0x19b + (longlong)param_1);
        if ((bVar8 != 0xff) && (bVar4 != 0xff)) {
          lVar21 = (ulonglong)bVar4 * 0x520;
          lVar19 = *(longlong *)
                    (*(longlong *)(*(longlong *)param_1[1] + (ulonglong)bVar8 * 8) + 0x110);
          puVar2 = (uint *)(lVar19 + 0x1fc + lVar21);
          *puVar2 = *puVar2 | 0x800;
          uVar3 = *(undefined1 *)(lVar24 + 0x19d + (longlong)param_1);
          *(undefined1 *)(lVar19 + 0x23c + lVar21) =
               *(undefined1 *)(lVar24 + 0x19c + (longlong)param_1);
          *(undefined1 *)(lVar19 + 0x23d + lVar21) = uVar3;
        }
        if (*param_1 != 0) {
          uVar5 = *(ushort *)(lVar24 + 0x198 + (longlong)param_1);
          lVar19 = *(longlong *)(*param_1 + 0x66ee0);
          uVar22 = (uint)(uVar5 & 0x3ff);
          if (uVar5 == 0xffff) {
            uVar22 = 0xffffffff;
          }
          lVar21 = (longlong)(short)uVar22 >> 5;
          uVar6 = *(uint *)(lVar19 + 0x1bc48 + lVar21 * 4);
          if ((uVar6 >> (uVar22 & 0x1f) & 1) != 0) {
            *(uint *)(lVar19 + 0x1bc48 + lVar21 * 4) = uVar6 & ~(1 << (uVar22 & 0x1f));
            piVar1 = (int *)(lVar19 + 0x1bc88);
            *piVar1 = *piVar1 + -1;
            if (*piVar1 < 0) {
              *(undefined4 *)(lVar19 + 0x1bc88) = 0;
            }
          }
          uStack_1e0 = CONCAT44(DAT_1402d22d0,local_1d0._8_4_);
          local_1e8 = local_1d0._0_8_;
          local_1d8 = local_res10[0];
          FUN_140031f80(*(undefined8 *)(*param_1 + 0x66ee0),0x33,&local_1e8,0);
        }
        iVar13 = *(int *)(**(longlong **)(unaff_GS_OFFSET + 0x58) + 4);
        if (fVar34 == 2.8026e-45) {
          if ((iVar13 < DAT_1437dad18) && (FUN_14022d540(&DAT_1437dad18), DAT_1437dad18 == -1)) {
            _DAT_1437daef0 = 0;
            _DAT_1437daee0 = _DAT_1402d3500;
            uRam00000001437daee8 = _UNK_1402d3508;
            DAT_1437daef4 = 0;
            _Init_thread_footer(&DAT_1437dad18);
          }
          local_1e8 = _DAT_1402d35f0;
          uStack_1e0 = _UNK_1402d35f8;
          in_stack_fffffffffffffdc0 = CONCAT44(uVar45,DAT_1402d2100);
          cVar10 = FUN_1401c6a00(DAT_1402d2100,1,0x2e,local_200,&local_1e8,in_stack_fffffffffffffdc0
                                 ,DAT_1402d236c,DAT_1402d2458,uVar26,0,1);
          if ((((cVar10 != '\0') && (lVar19 = FUN_1401c97a0(), '\x01' < *(char *)(lVar19 + 0x3dc2)))
              && (uVar5 = *(ushort *)(lVar19 + 0x138),
                 (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar5 * 0x18) + 0xe72) & 1)
                 != 0)) &&
             (puVar16 = (undefined4 *)FUN_1401c9e60(lVar19), puVar16 != (undefined4 *)0x0)) {
            *(ushort *)(puVar16 + 0x11) = uVar5;
            *(undefined2 *)((longlong)puVar16 + 0x46) = 0x2e;
            *puVar16 = local_200._0_4_;
            puVar16[1] = local_200._4_4_;
            puVar16[2] = fStack_1f8;
            puVar16[3] = fStack_1f4;
            *(undefined8 *)(puVar16 + 4) = 0;
            puVar16[6] = 0;
            puVar16[7] = 0x3f800000;
            puVar16[8] = 0x3ea3d70a;
            puVar16[9] = 0x3fc00000;
            *(undefined8 *)(puVar16 + 10) = 0x40800000;
            puVar16[0xf] = 0x3f800000;
            *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
            *(byte *)(puVar16 + 0x1c) = *(byte *)(puVar16 + 0x1c) & 0xee | 0x26;
            *(code **)(puVar16 + 0xc) = FUN_1401caa00;
          }
        }
        else {
          if ((iVar13 < DAT_1437dad18) && (FUN_14022d540(&DAT_1437dad18), DAT_1437dad18 == -1)) {
            _DAT_1437daef0 = 0;
            _DAT_1437daee0 = _DAT_1402d3500;
            uRam00000001437daee8 = _UNK_1402d3508;
            DAT_1437daef4 = 0;
            _Init_thread_footer(&DAT_1437dad18);
          }
          local_1e8 = _DAT_1402d35f0;
          uStack_1e0 = _UNK_1402d35f8;
          in_stack_fffffffffffffdc0 = CONCAT44(uVar45,DAT_1402d2100);
          cVar10 = FUN_1401c6a00(DAT_1402d2100,1,0x1b,local_200,&local_1e8,in_stack_fffffffffffffdc0
                                 ,DAT_1402d234c,DAT_1402d2458,uVar26,0,1);
          if (((cVar10 != '\0') && (lVar19 = FUN_1401c97a0(), '\x01' < *(char *)(lVar19 + 0x3dc2)))
             && ((uVar5 = *(ushort *)(lVar19 + 0x138),
                 (~*(byte *)(*(longlong *)(&DAT_14032d5a8 + (ulonglong)uVar5 * 0x18) + 0x882) & 1)
                 != 0 && (puVar16 = (undefined4 *)FUN_1401c9e60(lVar19),
                         puVar16 != (undefined4 *)0x0)))) {
            *(ushort *)(puVar16 + 0x11) = uVar5;
            *(undefined2 *)((longlong)puVar16 + 0x46) = 0x1b;
            *puVar16 = local_200._0_4_;
            puVar16[1] = local_200._4_4_;
            puVar16[2] = fStack_1f8;
            puVar16[3] = fStack_1f4;
            *(undefined8 *)(puVar16 + 4) = 0;
            puVar16[6] = 0;
            puVar16[7] = 0x3f800000;
            puVar16[8] = 0x3ea3d70a;
            puVar16[9] = 0x3fb33333;
            *(undefined8 *)(puVar16 + 10) = 0x40800000;
            puVar16[0xf] = 0x3f800000;
            *(undefined2 *)((longlong)puVar16 + 0x4a) = 0;
            *(byte *)(puVar16 + 0x1c) = *(byte *)(puVar16 + 0x1c) & 0xee | 0x26;
            *(code **)(puVar16 + 0xc) = FUN_1401caa00;
          }
        }
      }
    }
    local_1ac = iVar12 + 1;
    uVar20 = uVar20 << 1 | (uint)((int)uVar20 < 0);
    lVar24 = lVar24 + 0x58;
    if (0xf < local_1ac) {
      return;
    }
  } while( true );
}

