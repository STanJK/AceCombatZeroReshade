/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140166de0; RVA 0x166de0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_140166de0(undefined8 param_1,ulonglong param_2)

{
  FUN_140166e20();
  if ((param_2 & 1) != 0) {
    thunk_FUN_1402500f0(param_1,0x2c30);
  }
  return param_1;
}

