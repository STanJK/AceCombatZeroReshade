/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400f5b60; RVA 0xf5b60
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400f5b60(longlong param_1,longlong *param_2)

{
  undefined1 auVar1 [16];
  undefined1 auVar2 [16];
  char cVar3;
  ushort uVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  longlong lVar8;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  longlong lVar13;
  int iVar14;
  undefined1 uVar15;
  undefined1 uVar16;
  int iVar17;
  undefined *puVar18;
  undefined4 uVar19;
  undefined4 uVar20;
  undefined4 uVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  undefined4 uVar26;
  float fVar27;
  float fVar29;
  float fVar28;
  int local_78 [2];
  char local_6f;
  int local_58;
  
  if (param_2 == (longlong *)0x0) {
    return;
  }
  puVar6 = *(undefined8 **)(param_1 + 0x2f8);
  if (puVar6 == (undefined8 *)0x0) {
    return;
  }
  lVar7 = *param_2;
  uVar16 = 0xff;
  uVar15 = 0xff;
  if (lVar7 != 0) {
    uVar16 = *(undefined1 *)(lVar7 + 0x90);
    uVar15 = *(undefined1 *)(lVar7 + 0x91);
  }
  cVar3 = *(char *)(param_1 + 0x3cc);
  *(undefined1 *)(param_1 + 0x3e6) = 0;
  fVar27 = DAT_1402d22d0;
  fVar28 = 0.0;
  fVar29 = 0.0;
  if (cVar3 == '\0') {
    fVar28 = fVar29;
    FUN_1400f6380();
    goto LAB_1400f6239;
  }
  if (cVar3 == '\x02') {
    fVar28 = fVar29;
    FUN_1400f7050();
    goto LAB_1400f6239;
  }
  if (cVar3 == '\x03') {
    fVar28 = fVar29;
    FUN_1400f7540();
    goto LAB_1400f6239;
  }
  if (cVar3 == '\x04') {
    fVar28 = fVar29;
    FUN_1400f8910();
    goto LAB_1400f6239;
  }
  if (cVar3 == '\x05') {
    fVar28 = fVar29;
    FUN_1400f8e30();
    goto LAB_1400f6239;
  }
  if (cVar3 == '\x06') {
    fVar28 = fVar29;
    FUN_14010e220(*(undefined8 *)(*(longlong *)(*(longlong *)*puVar6 + 0x110) + 0x1b8),0);
    *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x20;
    *(undefined4 *)(param_1 + 0x3a0) = 0;
    goto LAB_1400f6239;
  }
  if (cVar3 == '\b') {
    *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
    *(undefined4 *)(param_1 + 0x378) = 0;
    lVar13 = *(longlong *)(*(longlong *)(*(longlong *)*puVar6 + 0x110) + 0x1b8);
    *(undefined1 *)(lVar13 + 0xc38) = 0;
    *(undefined8 *)(lVar13 + 0xccc) = 0;
    *(undefined8 *)(lVar13 + 0xcd4) = 0;
    *(undefined4 *)(lVar13 + 0xcdc) = 0;
    *(undefined4 *)(lVar13 + 0xce4) = 0x42480000;
    *(undefined4 *)(lVar13 + 0xce0) = 0x42480000;
    *(undefined1 *)(param_1 + 0x3cc) = 9;
    goto LAB_1400f6239;
  }
  if (cVar3 == '\t') {
    uVar5 = *(uint *)(param_1 + 0x3a8);
    iVar14 = *(int *)(param_1 + 0x378);
    if ((uVar5 >> 0x11 & 1) == 0) {
      if ((uVar5 >> 0x13 & 1) == 0) {
        if (iVar14 < (int)(uint)*(byte *)(param_1 + 0x3d1)) {
          iVar14 = iVar14 + 1;
          *(int *)(param_1 + 0x378) = iVar14;
        }
      }
      else if (0 < iVar14) {
        iVar14 = iVar14 + -1;
        *(int *)(param_1 + 0x378) = iVar14;
      }
      *(uint *)(param_1 + 0x3a8) = uVar5 & 0xfff7ffff;
    }
    else if (iVar14 < 1) {
      *(undefined1 *)(param_1 + 0x3cc) = 10;
      *(uint *)(param_1 + 0x3a8) = uVar5 & 0xfff5ffff;
    }
    else {
      iVar14 = iVar14 + -1;
      *(int *)(param_1 + 0x378) = iVar14;
    }
    *(float *)(param_1 + 0x3a0) = fVar27 - (float)iVar14 / (float)*(byte *)(param_1 + 0x3d1);
    goto LAB_1400f6239;
  }
  if (cVar3 == '\n') {
    if (1 < *(byte *)(*(longlong *)(param_1 + 0x340) + 0xa87e4)) {
      *(undefined1 *)(param_1 + 0x3cc) = 7;
    }
    goto LAB_1400f6239;
  }
  if (cVar3 != '\v') {
    if (cVar3 == '\f') {
      FUN_1400f92b0();
    }
    else if (cVar3 == '\r') {
      cVar3 = *(char *)(param_1 + 0x3d6);
      lVar13 = *(longlong *)(*(longlong *)*puVar6 + 0x110);
      lVar8 = *(longlong *)(lVar13 + 0x1b8);
      if ((cVar3 == '\n') || (cVar3 == '\x1e')) {
        *(undefined4 *)(lVar13 + 600) = 0x4673ec00;
        *(undefined4 *)(lVar13 + 0x25c) = 0x45d3e000;
        *(undefined4 *)(lVar13 + 0x260) = 0xc6a1ce00;
        *(undefined8 *)(lVar13 + 0x264) = 0;
        *(undefined8 *)(lVar13 + 0x26c) = 0x40490fdb;
        *(undefined4 *)(lVar13 + 0x274) = 0;
      }
      else if (cVar3 == '\x14') {
        *(undefined4 *)(lVar13 + 600) = 0x46874200;
        *(undefined4 *)(lVar13 + 0x25c) = 0x45d87000;
        *(undefined8 *)(lVar13 + 0x260) = 0x46bcb800;
        *(undefined8 *)(lVar13 + 0x268) = 0;
        *(undefined8 *)(lVar13 + 0x270) = 0;
      }
      auVar1 = *(undefined1 (*) [16])(lVar13 + 600);
      auVar2 = *(undefined1 (*) [16])(lVar13 + 0x268);
      uVar25 = auVar1._0_4_;
      *(undefined4 *)(lVar8 + 0x10e0) = uVar25;
      auVar9 = vshufps_avx(auVar2,auVar2,0x55);
      auVar10 = vshufps_avx(auVar2,auVar2,0xaa);
      auVar11 = vshufps_avx(auVar2,auVar2,0xff);
      auVar12 = vshufps_avx(auVar1,auVar1,0x55);
      uVar24 = auVar12._0_4_;
      *(undefined4 *)(lVar8 + 0x10e4) = uVar24;
      auVar12 = vshufps_avx(auVar1,auVar1,0xaa);
      uVar23 = auVar12._0_4_;
      *(undefined4 *)(lVar8 + 0x10e8) = uVar23;
      auVar1 = vshufps_avx(auVar1,auVar1,0xff);
      uVar22 = auVar1._0_4_;
      *(undefined4 *)(lVar8 + 0x10ec) = uVar22;
      uVar26 = auVar2._0_4_;
      *(undefined4 *)(lVar8 + 0x10f0) = uVar26;
      uVar21 = auVar9._0_4_;
      *(undefined4 *)(lVar8 + 0x10f4) = uVar21;
      uVar20 = auVar10._0_4_;
      *(undefined4 *)(lVar8 + 0x10f8) = uVar20;
      uVar19 = auVar11._0_4_;
      *(undefined4 *)(lVar8 + 0x10fc) = uVar19;
      *(undefined8 *)(lVar8 + 0x12a0) = 0;
      *(undefined4 *)(lVar8 + 0x12a8) = 0;
      *(undefined4 *)(lVar8 + 0x12ac) = 0x3f800000;
      *(undefined4 *)(lVar8 + 0x12b0) = uVar26;
      *(undefined4 *)(lVar8 + 0x12b4) = uVar21;
      *(undefined4 *)(lVar8 + 0x12b8) = uVar20;
      *(undefined4 *)(lVar8 + 0x12bc) = uVar19;
      *(undefined4 *)(lVar8 + 0x70) = uVar25;
      *(undefined4 *)(lVar8 + 0x80) = uVar26;
      *(undefined4 *)(lVar8 + 0x74) = uVar24;
      *(undefined4 *)(lVar8 + 0x78) = uVar23;
      *(undefined4 *)(lVar8 + 0x7c) = uVar22;
      *(undefined4 *)(lVar8 + 0x84) = uVar21;
      *(undefined4 *)(lVar8 + 0x88) = uVar20;
      *(undefined4 *)(lVar8 + 0x8c) = uVar19;
      *(undefined4 *)(lVar8 + 0x17f8) = uVar25;
      *(undefined4 *)(lVar8 + 0x1808) = uVar26;
      *(undefined4 *)(lVar8 + 0x17fc) = uVar24;
      *(undefined4 *)(lVar8 + 0x1800) = uVar23;
      *(undefined4 *)(lVar8 + 0x1804) = uVar22;
      *(undefined4 *)(lVar8 + 0x180c) = uVar21;
      *(undefined4 *)(lVar8 + 0x1810) = uVar20;
      *(undefined4 *)(lVar8 + 0x1814) = uVar19;
      if ((*(uint *)(lVar8 + 0x2058) >> 0xd & 1) == 0) {
        *(uint *)(lVar8 + 0x2058) = *(uint *)(lVar8 + 0x2058) | 0x2000;
        *(undefined1 *)(lVar8 + 0x2095) = *(undefined1 *)(lVar8 + 0x2094);
      }
      *(undefined1 *)(lVar8 + 0x2096) = 1;
      *(undefined1 *)(param_1 + 0x3cc) = 0xe;
    }
    else if (cVar3 == '\x0e') {
      FUN_1400f9a50();
    }
    else if (cVar3 == '\x0f') {
      FUN_1400f9bd0();
    }
    else if (cVar3 == '\x10') {
      uVar5 = *(uint *)(param_1 + 0x3a8);
      *(uint *)(param_1 + 0x3a8) = uVar5 | 0x20;
      if (*(int *)(param_1 + 0x37c) < (int)((uint)*(byte *)(param_1 + 0x3d1) * 5)) {
        if ((uVar5 & 4) == 0) {
          *(int *)(param_1 + 0x37c) = *(int *)(param_1 + 0x37c) + 1;
        }
      }
      else {
        lVar13 = *(longlong *)(*(longlong *)(*(longlong *)*puVar6 + 0x110) + 0x1b8);
        if ((*(uint *)(lVar13 + 0x2058) >> 0xd & 1) == 0) {
          *(uint *)(lVar13 + 0x2058) = *(uint *)(lVar13 + 0x2058) | 0x2000;
          *(undefined1 *)(lVar13 + 0x2095) = *(undefined1 *)(lVar13 + 0x2094);
        }
        *(undefined1 *)(lVar13 + 0x2096) = 2;
        *(undefined1 *)(param_1 + 0x3cc) = 0x12;
        *(undefined4 *)(param_1 + 0x3a0) = 0;
      }
    }
    else {
      if (cVar3 != '\x11') {
        if (cVar3 == '\x12') {
          fVar28 = fVar29;
          FUN_1400fa240();
        }
        else if (cVar3 == '\x13') {
          if ((*(uint *)(param_1 + 0x3a8) >> 0x18 & 1) == 0) {
            *(undefined4 *)(param_1 + 0x3a0) = 0;
          }
          else {
            *(undefined1 *)(param_1 + 0x3cc) = 0x14;
            *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xfeffffff;
            *(float *)(param_1 + 0x3a0) = fVar27;
          }
        }
        else if (cVar3 == '\x14') {
          FUN_1400fa550();
          fVar28 = fVar29;
          FUN_1400ff220(param_1,1);
        }
        else if (cVar3 == '\x15') {
          FUN_1400fa7c0();
          fVar28 = fVar29;
          FUN_1400ff220(param_1,1);
        }
        else if (cVar3 == '\x16') {
          FUN_1400faa80();
          fVar28 = fVar29;
          FUN_1400ff220(param_1,1);
        }
        else if (cVar3 == '\x17') {
          FUN_1400fac60();
          fVar28 = fVar29;
          FUN_1400ff220(param_1,1);
        }
        else if (cVar3 == '\x18') {
          FUN_1400faf80();
          fVar28 = fVar29;
          FUN_1400ff220(param_1,1);
        }
        else if (cVar3 == '\x19') {
          FUN_1400fb1d0();
          fVar28 = fVar29;
          FUN_1400ff220(param_1,1);
        }
        else if (cVar3 == '\x1a') {
          fVar28 = fVar29;
          FUN_1400fb540();
        }
        goto LAB_1400f6239;
      }
      FUN_1400f9e90();
    }
    fVar28 = fVar29;
    FUN_1400fd650(param_1,uVar16,uVar15,1);
    goto LAB_1400f6239;
  }
  *(undefined4 *)(param_1 + 0x404) =
       *(undefined4 *)(*(longlong *)(*(longlong *)*puVar6 + 0x110) + 0x420);
  FUN_1400d5780(*(undefined8 *)(param_1 + 0x340));
  fVar28 = fVar29;
  lVar13 = FUN_1401c56d0();
  if ((DAT_14031f8b1 & 1) == 0) {
    lVar13 = (longlong)*(short *)(lVar13 + 4);
    puVar18 = &DAT_14031f000;
    iVar14 = FUN_140187060((int)(char)(&DAT_14031f8a8)[lVar13 + (ulonglong)DAT_14031f8b0 * 4],
                           local_78);
    if (iVar14 == 0) {
      if (local_6f == '\x01') {
        iVar14 = 2;
        iVar17 = 0x18000;
      }
      else {
        if (local_6f != '\x02') goto LAB_1400f5e6d;
        iVar14 = 3;
        iVar17 = 0x20000;
      }
      if (local_78[0] - local_58 < iVar17) {
        iVar14 = 0;
      }
      else {
        iVar14 = local_58 * 7 >> iVar14;
      }
      *(int *)(param_1 + 0x2c4) = iVar14;
      *(undefined4 *)(param_1 + 0x2c8) = *(undefined4 *)(puVar18 + lVar13 * 4 + 0x898);
      FUN_140187110((int)(char)puVar18[lVar13 + (ulonglong)DAT_14031f8b0 * 4 + 0x8a8],3000);
    }
  }
LAB_1400f5e6d:
  *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xff7fffff;
  *(undefined1 *)(param_1 + 0x3cc) = 0xc;
LAB_1400f6239:
  if (((*(byte *)(param_1 + 0x3a8) & 4) == 0) && ((*(uint *)(lVar7 + 0x40) & 0x200) != 0)) {
    uVar4 = *(ushort *)(lVar7 + 0x52);
    if (uVar4 != 0xffff) {
      puVar6 = *(undefined8 **)(param_1 + 0x300);
      lVar13 = puVar6[3];
      if (lVar13 != 0) {
        if ((((undefined8 *)*puVar6 != (undefined8 *)0x0) && (uVar4 < **(ushort **)*puVar6)) &&
           (*(short *)(lVar13 + (ulonglong)uVar4 * 2) == 1)) {
          if (*(float *)(param_1 + 0x398) < fVar27) {
            fVar27 = fVar27 / ((float)*(byte *)(param_1 + 0x3d1) * *(float *)(lVar7 + 0x34)) +
                     *(float *)(param_1 + 0x398);
          }
          *(float *)(param_1 + 0x398) = fVar27;
          return;
        }
        if ((((undefined8 *)*puVar6 != (undefined8 *)0x0) && (uVar4 < **(ushort **)*puVar6)) &&
           (*(short *)(lVar13 + (ulonglong)uVar4 * 2) != 0)) {
          return;
        }
      }
      if (*(float *)(param_1 + 0x398) <= fVar28) {
        *(undefined4 *)(param_1 + 0x398) = 0;
      }
      else {
        *(float *)(param_1 + 0x398) =
             *(float *)(param_1 + 0x398) -
             fVar27 / ((float)*(byte *)(param_1 + 0x3d1) * *(float *)(lVar7 + 0x34));
      }
    }
  }
  return;
}

