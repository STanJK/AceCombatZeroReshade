/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400934e0; RVA 0x934e0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8
FUN_1400934e0(longlong param_1,undefined1 (*param_2) [16],byte param_3,ulonglong param_4,
             float param_5,undefined4 param_6)

{
  longlong lVar1;
  undefined1 auVar2 [16];
  float fVar3;
  undefined1 auVar4 [16];
  int iVar5;
  longlong lVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined1 auVar14 [64];
  undefined4 local_res18 [2];
  undefined1 local_128 [8];
  undefined8 uStack_120;
  undefined1 local_118 [8];
  float fStack_110;
  float fStack_10c;
  float local_108;
  float local_104;
  float local_100;
  float local_fc;
  undefined8 local_f8;
  undefined8 uStack_f0;
  float local_e8;
  float local_e4;
  float local_e0;
  float local_dc;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  
  lVar6 = (param_4 & 0xff) * 0x520;
  lVar1 = *(longlong *)
           (*(longlong *)(**(longlong **)(param_1 + 0x10) + (ulonglong)param_3 * 8) + 0x110);
  if ((char)param_6 == '\0') {
    local_118._4_4_ = *(undefined4 *)(lVar1 + 0x25c + lVar6);
    local_118._0_4_ = *(undefined4 *)(lVar1 + 600 + lVar6);
    fStack_110 = (float)*(undefined4 *)(lVar1 + 0x260 + lVar6);
    fStack_10c = (float)*(undefined4 *)(lVar1 + 0x264 + lVar6);
  }
  else {
    _local_118 = *param_2;
  }
  fVar9 = (param_5 + *(float *)(*(longlong *)(lVar1 + 0x1b8 + lVar6) + 0x1848)) * DAT_1402d2d8c;
  local_c8 = 0;
  uStack_c0 = 0;
  local_a8 = 0;
  uStack_a0 = 0;
  local_d8 = 0;
  uStack_d0 = 0;
  local_b8 = 0;
  uStack_b0 = 0;
  FUN_140202920(&local_d8,lVar1 + 0x268 + lVar6);
  fVar12 = fVar9 * (float)uStack_b0 + (float)uStack_a0;
  fVar10 = fVar9 * local_b8._4_4_ + local_a8._4_4_;
  fVar13 = fVar9 * (float)local_b8 + (float)local_a8;
  local_f8 = 0;
  uStack_f0 = 0;
  local_100 = fStack_110;
  uStack_120._0_4_ = fStack_110;
  local_108 = (float)local_118._0_4_;
  param_6 = 0;
  local_128._4_4_ = (float)local_118._4_4_ + DAT_1402d2998 + DAT_1402d2a34;
  local_128._0_4_ = local_118._0_4_;
  local_104 = (float)DAT_1402d2e9c;
  local_fc = DAT_1402d22d0;
  uStack_120._4_4_ = DAT_1402d22d0;
  fVar11 = DAT_1402d22d0;
  iVar5 = FUN_1400782c0(*(undefined8 *)(param_1 + 0x18),&local_f8,local_res18,local_128,&local_108);
  fVar9 = 0.0;
  if (iVar5 == 0) {
    fVar7 = 0.0;
  }
  else {
    param_6 = local_res18[0];
    fVar7 = local_f8._4_4_;
  }
  fVar3 = fVar10 * DAT_1402d206c;
  fVar8 = fVar10 * fVar10 * DAT_1402d1f8c - ((float)local_118._4_4_ - fVar7) * DAT_1402d2dc0;
  if (fVar8 < 0.0) {
    return 0xffffffff;
  }
  fVar8 = SQRT(fVar8);
  auVar2 = vmaxss_avx(ZEXT416((uint)(((float)((uint)fVar3 ^ DAT_1402d3770) - fVar8) * DAT_1402d2cd8)
                             ),ZEXT416((uint)((fVar8 - fVar3) * DAT_1402d2cd8)));
  auVar14 = ZEXT1664(auVar2);
  fVar8 = auVar2._0_4_;
  if (fVar8 < 0.0) {
    return 0xffffffff;
  }
  *(float *)*param_2 = fVar8 * fVar13 + (float)local_118._0_4_;
  *(float *)(*param_2 + 8) = fVar12 * fVar8 + fStack_110;
  _local_128 = ZEXT416(0);
  *(undefined4 *)(*param_2 + 0xc) = 0;
  *(float *)(*param_2 + 4) = fVar7;
  *(undefined4 *)(*param_2 + 0xc) = 0x3f800000;
  if (fVar13 * fVar13 + fVar12 * fVar12 == 0.0) {
    if (fVar10 <= 0.0) {
      return 0;
    }
    return 0xffffffff;
  }
  local_e8 = (float)local_118._0_4_;
  local_e0 = fStack_110;
  local_e4 = (float)local_118._4_4_;
  if (0.0 < fVar10) {
    fVar3 = fVar3 * DAT_1402d2000;
    local_108 = fVar3 * fVar13 + (float)local_118._0_4_;
    local_104 = -(fVar3 * fVar3 * DAT_1402d2470) + fVar3 * fVar10 + (float)local_118._4_4_;
    local_100 = fVar3 * fVar12 + fStack_110;
    fVar9 = 0.0;
    local_fc = fVar11;
    iVar5 = FUN_1400782c0(*(undefined8 *)(param_1 + 0x18),local_128,&param_6,local_118,&local_108);
    fVar8 = auVar14._0_4_;
    if (iVar5 != 0) goto LAB_140093865;
    local_118._4_4_ = local_104;
    local_118._0_4_ = local_108;
    fStack_110 = local_100;
    fStack_10c = local_fc;
    fVar10 = 0.0;
    local_e8 = local_108;
    local_e0 = local_100;
    local_e4 = local_104;
  }
  fVar8 = fVar8 * DAT_1402d2168;
  local_104 = -(fVar8 * fVar8 * DAT_1402d2470) + fVar10 * fVar8 + local_e4;
  local_108 = fVar13 * fVar8 + local_e8;
  local_100 = fVar12 * fVar8 + local_e0;
  auVar2 = *param_2;
  auVar4 = vshufps_avx(auVar2,auVar2,0x55);
  fVar12 = auVar4._0_4_ - local_104;
  fVar10 = auVar2._0_4_ - local_108;
  auVar2 = vshufps_avx(auVar2,auVar2,0xaa);
  fVar13 = auVar2._0_4_ - local_100;
  fVar7 = SQRT(fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10);
  if (fVar7 != fVar9) {
    fVar7 = fVar11 / fVar7;
    fVar10 = fVar10 * fVar7;
    fVar12 = fVar7 * fVar12;
    fVar13 = fVar13 * fVar7;
  }
  local_f8 = CONCAT44(fVar12 * DAT_1402d2ae8 + local_104,fVar10 * DAT_1402d2ae8 + local_108);
  uStack_f0 = CONCAT44(fVar11,fVar13 * DAT_1402d2ae8 + local_100);
  local_fc = fVar11;
  local_dc = fVar11;
  iVar5 = FUN_1400782c0(*(undefined8 *)(param_1 + 0x18),local_128,&param_6,&local_e8,&local_108);
  if ((iVar5 == 0) &&
     (iVar5 = FUN_1400782c0(*(undefined8 *)(param_1 + 0x18),local_128,&param_6,&local_108,&local_f8)
     , iVar5 == 0)) {
    return 0;
  }
LAB_140093865:
  *(undefined1 (*) [8])*param_2 = local_128;
  *(undefined8 *)(*param_2 + 8) = uStack_120;
  *(undefined4 *)(*param_2 + 0xc) = 0x3f800000;
  return 0;
}

