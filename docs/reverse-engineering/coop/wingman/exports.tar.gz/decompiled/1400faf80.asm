0x1400faf80  PUSH RDI
0x1400faf82  SUB RSP,0x30
0x1400faf86  MOV RAX,qword ptr [RCX + 0x2f8]
0x1400faf8d  XOR R10D,R10D
0x1400faf90  VMOVAPS xmmword ptr [RSP + 0x20],XMM6
0x1400faf96  MOV RDI,RCX
0x1400faf99  MOV RDX,qword ptr [RAX]
0x1400faf9c  MOV RAX,qword ptr [RDX]
0x1400faf9f  MOV R8,qword ptr [RAX + 0x110]
0x1400fafa6  MOV EAX,dword ptr [RCX + 0x3a8]
0x1400fafac  OR EAX,0x20
0x1400fafaf  MOV RDX,qword ptr [R8 + 0x1b8]
0x1400fafb6  MOV dword ptr [RCX + 0x3a8],EAX
0x1400fafbc  TEST byte ptr [R8 + 0x1f0],0x2
0x1400fafc4  JNZ 0x1400fafe4
0x1400fafc6  CMP byte ptr [RCX + 0x3e6],0x5
0x1400fafcd  MOV dword ptr [RCX + 0x37c],R10D
0x1400fafd4  MOV byte ptr [RCX + 0x3cc],0x19
0x1400fafdb  JZ 0x1400fafe4
0x1400fafdd  MOV byte ptr [RCX + 0x3e6],0x4
0x1400fafe4  VMOVSS XMM6,dword ptr [0x1402d22d0]
0x1400fafec  TEST AL,0x4
0x1400fafee  JNZ 0x1400fb002
0x1400faff0  VADDSS XMM1,XMM6,dword ptr [R8 + 0x25c]
0x1400faff9  VMOVSS dword ptr [R8 + 0x25c],XMM1
0x1400fb002  MOVZX R9D,byte ptr [RCX + 0x3d1]
0x1400fb00a  MOV ECX,dword ptr [RCX + 0x37c]
0x1400fb010  LEA EAX,[R9 + R9*0x8]
0x1400fb014  CMP ECX,EAX
0x1400fb016  JGE 0x1400fb0a4
0x1400fb01c  TEST byte ptr [RDI + 0x3a8],0x4
0x1400fb023  JNZ 0x1400fb02d
0x1400fb025  INC ECX
0x1400fb027  MOV dword ptr [RDI + 0x37c],ECX
0x1400fb02d  VXORPS XMM0,XMM0,XMM0
0x1400fb031  VCVTSI2SS XMM0,XMM0,R9D
0x1400fb036  VXORPS XMM1,XMM1,XMM1
0x1400fb03a  VCVTSI2SS XMM1,XMM1,ECX
0x1400fb03e  VDIVSS XMM2,XMM1,XMM0
0x1400fb042  VMULSS XMM3,XMM2,dword ptr [0x1402d1fb4]
0x1400fb04a  VADDSS XMM0,XMM3,dword ptr [0x1402d20b0]
0x1400fb052  VMOVSS dword ptr [RDX + 0x1d7c],XMM0
0x1400fb05a  VMOVSS dword ptr [RDX + 0x1d78],XMM3
0x1400fb062  MOVZX ECX,byte ptr [RDI + 0x3d1]
0x1400fb069  MOV EAX,dword ptr [RDI + 0x37c]
0x1400fb06f  VXORPS XMM0,XMM0,XMM0
0x1400fb073  LEA EDX,[RCX*0x8]
0x1400fb07a  CMP EAX,EDX
0x1400fb07c  JL 0x1400fb090
0x1400fb07e  SUB EAX,EDX
0x1400fb080  VXORPS XMM1,XMM1,XMM1
0x1400fb084  VCVTSI2SS XMM1,XMM1,EAX
0x1400fb088  VCVTSI2SS XMM0,XMM0,ECX
0x1400fb08c  VDIVSS XMM0,XMM1,XMM0
0x1400fb090  VMOVSS dword ptr [RDI + 0x3a0],XMM0
0x1400fb098  VMOVAPS XMM6,xmmword ptr [RSP + 0x20]
0x1400fb09e  ADD RSP,0x30
0x1400fb0a2  POP RDI
0x1400fb0a3  RET
0x1400fb0a4  MOV RAX,qword ptr [RDI + 0x320]
0x1400fb0ab  MOV qword ptr [RSP + 0x40],RBX
0x1400fb0b0  MOV qword ptr [RSP + 0x48],RBP
0x1400fb0b5  TEST RAX,RAX
0x1400fb0b8  JZ 0x1400fb0f2
0x1400fb0ba  AND byte ptr [RAX + 0x2b],0xfd
0x1400fb0be  MOV RCX,qword ptr [RAX + 0x10]
0x1400fb0c2  TEST RCX,RCX
0x1400fb0c5  JZ 0x1400fb0ce
0x1400fb0c7  AND dword ptr [RCX + 0x56c],0xfffffffe
0x1400fb0ce  MOV RCX,qword ptr [RAX + 0x18]
0x1400fb0d2  TEST RCX,RCX
0x1400fb0d5  JZ 0x1400fb0db
0x1400fb0d7  AND byte ptr [RCX + 0x23],0xfb
0x1400fb0db  MOV RAX,qword ptr [RDI + 0x320]
0x1400fb0e2  MOV RCX,qword ptr [RAX + 0x10]
0x1400fb0e6  TEST RCX,RCX
0x1400fb0e9  JZ 0x1400fb0f2
0x1400fb0eb  AND dword ptr [RCX + 0x40],0xfbffffff
0x1400fb0f2  MOV ECX,dword ptr [RDX + 0x2058]
0x1400fb0f8  BT ECX,0xd
0x1400fb0fc  JNC 0x1400fb10f
0x1400fb0fe  MOVZX EAX,byte ptr [RDX + 0x2095]
0x1400fb105  BTR ECX,0xd
0x1400fb109  MOV byte ptr [RDX + 0x2096],AL
0x1400fb10f  AND byte ptr [RDX + 0x1da7],0xfe
0x1400fb116  BTR ECX,0x7
0x1400fb11a  MOV qword ptr [RDX + 0x1d78],R10
0x1400fb121  MOV EBP,0x1
0x1400fb126  AND byte ptr [RDX + 0x1677],0xfe
0x1400fb12d  AND byte ptr [RDX + 0x1676],0xfc
0x1400fb134  AND byte ptr [RDX + 0x1863],0xfb
0x1400fb13b  MOV dword ptr [RDX + 0x2058],ECX
0x1400fb141  MOVZX EAX,byte ptr [R8 + 0x42a]
0x1400fb149  MOV word ptr [R8 + 0x428],AX
0x1400fb151  MOV RBX,qword ptr [RDI + 0x2f8]
0x1400fb158  MOV RBX,qword ptr [RBX]
0x1400fb15b  MOV RAX,qword ptr [RBX]
0x1400fb15e  CMP dword ptr [RAX + 0x118],EBP
0x1400fb164  JLE 0x1400fb1aa
0x1400fb166  MOV qword ptr [RSP + 0x50],RSI
0x1400fb16b  MOV ESI,0x520
0x1400fb170  MOV RAX,qword ptr [RAX + 0x110]
0x1400fb177  MOV RCX,qword ptr [RAX + RSI*0x1 + 0x1c0]
0x1400fb17f  TEST RCX,RCX
0x1400fb182  JZ 0x1400fb191
0x1400fb184  MOV RCX,qword ptr [RCX + 0x10]
0x1400fb188  MOV RAX,qword ptr [RCX]
0x1400fb18b  CALL qword ptr [RAX + 0x1c8]
0x1400fb191  MOV RAX,qword ptr [RBX]
0x1400fb194  INC EBP
0x1400fb196  ADD RSI,0x520
0x1400fb19d  CMP EBP,dword ptr [RAX + 0x118]
0x1400fb1a3  JL 0x1400fb170
0x1400fb1a5  MOV RSI,qword ptr [RSP + 0x50]
0x1400fb1aa  MOV byte ptr [RDI + 0x3cc],0x1a
0x1400fb1b1  VMOVSS dword ptr [RDI + 0x3a0],XMM6
0x1400fb1b9  MOV RBP,qword ptr [RSP + 0x48]
0x1400fb1be  MOV RBX,qword ptr [RSP + 0x40]
0x1400fb1c3  VMOVAPS XMM6,xmmword ptr [RSP + 0x20]
0x1400fb1c9  ADD RSP,0x30
0x1400fb1cd  POP RDI
0x1400fb1ce  RET
