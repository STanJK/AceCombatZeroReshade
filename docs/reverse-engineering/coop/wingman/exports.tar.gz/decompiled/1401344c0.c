/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401344c0; RVA 0x1344c0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401344c0(longlong param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined1 auVar4 [16];
  char cVar5;
  char cVar6;
  byte bVar7;
  byte bVar8;
  byte bVar9;
  longlong *plVar10;
  longlong lVar11;
  undefined8 *puVar12;
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 auVar15 [12];
  bool bVar16;
  bool bVar17;
  int iVar18;
  undefined8 uVar19;
  byte *pbVar20;
  int iVar21;
  float *pfVar22;
  longlong lVar23;
  longlong lVar24;
  longlong lVar25;
  ulonglong uVar26;
  int iVar27;
  longlong lVar28;
  uint uVar29;
  float *pfVar30;
  int iVar31;
  longlong lVar32;
  bool bVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  undefined1 in_ZMM6 [64];
  float fVar37;
  float fVar38;
  float fVar39;
  float fVar40;
  undefined1 auStack_238 [32];
  undefined1 local_218 [16];
  undefined1 local_208 [8];
  float fStack_200;
  float fStack_1fc;
  undefined1 local_1f8 [8];
  float fStack_1f0;
  float fStack_1ec;
  undefined1 local_1e8 [8];
  float fStack_1e0;
  float fStack_1dc;
  undefined1 local_1d8 [8];
  float fStack_1d0;
  float fStack_1cc;
  int local_1c8;
  float local_1c0;
  float fStack_1bc;
  float fStack_1b8;
  float fStack_1b4;
  undefined8 local_1a8;
  undefined8 uStack_1a0;
  undefined1 local_198 [16];
  longlong local_188;
  float local_178;
  float local_174;
  float local_170;
  float local_16c;
  float local_168;
  float local_164;
  float local_160;
  float local_15c;
  float local_158;
  float local_154;
  float local_150;
  float local_14c;
  undefined1 local_148 [16];
  undefined1 local_138 [8];
  float fStack_130;
  float fStack_12c;
  undefined1 local_128 [8];
  float fStack_120;
  float fStack_11c;
  undefined1 local_118 [8];
  float fStack_110;
  float fStack_10c;
  float local_108;
  undefined4 local_104;
  undefined4 local_100;
  undefined4 uStack_fc;
  undefined4 local_f8;
  undefined4 local_f4;
  undefined4 local_f0;
  undefined4 local_ec;
  undefined4 local_e8;
  undefined4 local_e4;
  undefined4 local_e0;
  undefined4 local_dc;
  undefined4 local_d8;
  undefined4 local_d4;
  undefined4 local_d0;
  undefined8 local_cc;
  ulonglong local_b8;
  undefined1 local_38 [16];
  
  local_b8 = DAT_140309040 ^ (ulonglong)auStack_238;
  FUN_1401278c0();
  if ((*(byte *)(param_1 + 0xf6) & 1) == 0) {
    uVar26 = 0;
    local_108 = 0.0;
    local_100 = 0;
    local_f8 = 0;
    local_f0 = 0;
    local_e8 = 0;
    local_e0 = 0;
    local_d8 = 0;
    local_d0 = 0;
    local_104 = 0xffff;
    uStack_fc = 0xffff;
    local_f4 = 0xffff;
    local_ec = 0xffff;
    local_e4 = 0xffff;
    local_dc = 0xffff;
    local_d4 = 0xffff;
    local_cc = 0xffff;
    if (((*(byte *)(param_1 + 0xf0) & 0x80) != 0) && ((*(byte *)(param_1 + 0x120) & 0x10) == 0)) {
      plVar10 = *(longlong **)(param_1 + 0x140);
      iVar27 = 0;
      if (*(char *)((longlong)plVar10 + 0x34) != '\0') {
        lVar32 = 0;
        do {
          lVar28 = *plVar10;
          if ((*(byte *)(*(longlong *)(lVar32 + lVar28) + 0x120) & 2) != 0) {
            cVar5 = *(char *)(*(longlong *)(lVar32 + lVar28) + 0x15d);
            cVar6 = *(char *)(param_1 + 0x15d);
            if (cVar6 != cVar5) {
              if (cVar6 == '\0') {
LAB_1401345f8:
                if (cVar5 == '\x01') goto LAB_14013470a;
              }
              else if (cVar6 == '\x01') {
                if ((cVar5 == '\0') || (cVar5 == '\x02')) goto LAB_14013470a;
              }
              else if (cVar6 == '\x02') goto LAB_1401345f8;
              lVar24 = *(longlong *)(lVar32 + lVar28);
              iVar31 = 0;
              if (0 < *(int *)(lVar24 + 0x118)) {
                lVar23 = 0;
                do {
                  auVar4 = local_218;
                  lVar11 = *(longlong *)(lVar24 + 0x110);
                  if ((*(byte *)(lVar11 + 0x1f0 + lVar23) & 2) != 0) {
                    auVar14 = *(undefined1 (*) [16])(lVar11 + 600 + lVar23);
                    fVar35 = auVar14._0_4_ - *(float *)(param_1 + 8);
                    auVar13 = vshufps_avx(auVar14,auVar14,0xaa);
                    fVar36 = auVar13._0_4_ - *(float *)(param_1 + 0x10);
                    auVar13 = vshufps_avx(auVar14,auVar14,0x55);
                    fVar37 = auVar13._0_4_ - *(float *)(param_1 + 0xc);
                    auVar14 = vshufps_avx(auVar14,auVar14,0xff);
                    fVar38 = auVar14._0_4_ - *(float *)(param_1 + 0x14);
                    fVar35 = SQRT(fVar38 * fVar38 +
                                  fVar36 * fVar36 + fVar37 * fVar37 + fVar35 * fVar35);
                    if (fVar35 < *(float *)(param_1 + 0xdc)) {
                      auVar15._1_11_ = local_218._5_11_;
                      auVar15[0] = *(undefined1 *)(lVar11 + 0x234 + lVar23);
                      local_218._0_5_ = auVar15._0_5_ << 0x20;
                      lVar25 = 0;
                      local_218[5] = *(undefined1 *)(lVar11 + 0x235 + lVar23);
                      local_218[6] = *(undefined1 *)(lVar24 + 0x15d);
                      iVar18 = 0;
                      local_218._8_8_ = auVar4._8_8_;
                      local_218[7] = 0;
                      local_218._0_4_ = fVar35;
                      iVar21 = (int)uVar26;
                      if (0 < iVar21) {
LAB_1401346c0:
                        if ((&local_108)[lVar25 * 2] <= fVar35) goto code_r0x0001401346cc;
                        for (lVar24 = (longlong)(iVar21 + -1); lVar25 < lVar24; lVar24 = lVar24 + -1
                            ) {
                          *(undefined8 *)(&local_108 + lVar24 * 2) =
                               *(undefined8 *)(local_118 + lVar24 * 8 + 8);
                        }
                        *(undefined8 *)(&local_108 + lVar25 * 2) = local_218._0_8_;
                        uVar26 = (ulonglong)(int)local_cc._4_4_;
                        if ((int)local_cc._4_4_ < 8) {
                          uVar19 = *(undefined8 *)
                                    (&local_108 + (longlong)(int)(local_cc._4_4_ + -1) * 2);
                          goto LAB_1401346e2;
                        }
                        goto LAB_1401346ef;
                      }
LAB_1401346d5:
                      if (iVar21 < 8) {
                        uVar26 = (ulonglong)iVar21;
                        uVar19 = local_218._0_8_;
LAB_1401346e2:
                        *(undefined8 *)(&local_108 + uVar26 * 2) = uVar19;
                        uVar26 = (ulonglong)(local_cc._4_4_ + 1);
                        local_cc = CONCAT44(local_cc._4_4_ + 1,(undefined4)local_cc);
                      }
                    }
                  }
LAB_1401346ef:
                  lVar24 = *(longlong *)(lVar32 + lVar28);
                  iVar31 = iVar31 + 1;
                  lVar23 = lVar23 + 0x520;
                } while (iVar31 < *(int *)(lVar24 + 0x118));
              }
            }
          }
LAB_14013470a:
          iVar27 = iVar27 + 1;
          lVar32 = lVar32 + 8;
        } while (iVar27 < (int)(uint)*(byte *)((longlong)plVar10 + 0x34));
      }
    }
    local_1c8 = 0;
    if (0 < *(int *)(param_1 + 0x118)) {
      local_38 = in_ZMM6._0_16_;
      local_188 = 0;
      do {
        pfVar22 = (float *)(param_1 + 0x48);
        lVar32 = *(longlong *)(param_1 + 0x110) + local_188;
        if (((*(uint *)(lVar32 + 0x1f0) & 0x4000) == 0) ||
           (*(float **)(lVar32 + 0x10) == (float *)0x0)) {
          pfVar30 = *(float **)(lVar32 + 8);
          if (((uint)pfVar30[0x2a] & 0x400) == 0) {
            bVar17 = false;
          }
          else {
            *(undefined1 *)((longlong)pfVar30 + 0xae) = 0;
            FUN_1401278c0(pfVar30);
            bVar17 = true;
            pfVar22 = pfVar30;
          }
        }
        else {
          bVar17 = true;
          pfVar22 = *(float **)(lVar32 + 0x10);
        }
        *(float *)(lVar32 + 0x218) = pfVar22[0x26];
        FUN_140119950(lVar32);
        if ((*(byte *)(lVar32 + 500) & 8) == 0) {
          uVar29 = *(uint *)(lVar32 + 0x1f0);
          if (((uint)pfVar22[0x2a] & 1) == 0) {
LAB_1401348d2:
            uVar29 = uVar29 & 0xfffff7ff;
            *(uint *)(lVar32 + 0x1f0) = uVar29;
          }
          else {
            uVar29 = uVar29 | 0x800;
            *(uint *)(lVar32 + 0x1f0) = uVar29;
            auVar4 = *(undefined1 (*) [16])(param_1 + 8);
            fVar35 = auVar4._0_4_ - *(float *)(lVar32 + 600);
            auVar14 = vshufps_avx(auVar4,auVar4,0xaa);
            fVar36 = auVar14._0_4_ - *(float *)(lVar32 + 0x260);
            auVar14 = vshufps_avx(auVar4,auVar4,0x55);
            fVar37 = auVar14._0_4_ - *(float *)(lVar32 + 0x25c);
            auVar4 = vshufps_avx(auVar4,auVar4,0xff);
            fVar38 = auVar4._0_4_ - *(float *)(lVar32 + 0x264);
            if (*(float *)**(undefined8 **)(param_1 + 0x130) <=
                SQRT(fVar38 * fVar38 + fVar36 * fVar36 + fVar37 * fVar37 + fVar35 * fVar35))
            goto LAB_1401348d2;
          }
          puVar12 = *(undefined8 **)(lVar32 + 0x1a8);
          local_218._0_8_ = puVar12;
          lVar28 = **(longlong **)(lVar32 + 0x1a0);
          if ((uVar29 & 2) != 0) {
            if ((((uint)pfVar22[0x2a] & 0x80) != 0) && ((*(byte *)(param_1 + 0x120) & 0x10) == 0)) {
              bVar7 = *(byte *)(lVar32 + 0x236);
              if ((bVar7 == 0xff) && (*(char *)(lVar32 + 0x237) == -1)) {
                bVar7 = *(byte *)((longlong)pfVar22 + 0xb6);
                if (bVar7 != 0xff) {
                  bVar8 = *(byte *)((longlong)pfVar22 + 0xb7);
                  if (bVar8 == 0xff) {
                    if (((char)(*(longlong **)(param_1 + 0x140))[0xd] != '\x01') &&
                       ((((*(char *)(param_1 + 0x15d) == '\x04' ||
                          (*(char *)(param_1 + 0x15d) == '\x05')) &&
                         (*(char *)(lVar28 + 0x70) != '\x02')) &&
                        (iVar27 = 0, 0 < (int)local_cc._4_4_)))) {
                      lVar24 = 0;
                      do {
                        if ((*(char *)((longlong)&local_104 + lVar24) == '\0') &&
                           (*(char *)((longlong)&local_104 + lVar24 + 1) == '\0')) {
                          *(uint *)(lVar32 + 0x1f0) = *(uint *)(lVar32 + 0x1f0) | 8;
                          *(undefined2 *)(lVar32 + 0x236) = 0;
                          goto LAB_140134d59;
                        }
                        iVar27 = iVar27 + 1;
                        lVar24 = lVar24 + 8;
                      } while (iVar27 < (int)local_cc._4_4_);
                    }
                    iVar27 = 0;
                    if (0 < (int)local_cc._4_4_) {
                      pfVar30 = &local_108;
                      do {
                        bVar8 = *(byte *)(pfVar30 + 1);
                        if (bVar8 == bVar7) {
                          bVar9 = *(byte *)((longlong)pfVar30 + 5);
                          lVar24 = (ulonglong)bVar9 * 0x520 +
                                   *(longlong *)
                                    (*(longlong *)
                                      (**(longlong **)(param_1 + 0x140) + (ulonglong)bVar8 * 8) +
                                    0x110);
                          cVar5 = *(char *)(**(longlong **)(lVar32 + 0x388) + 0x15d);
                          if ((cVar5 != '\0') && (cVar5 != '\x02')) {
                            if (*(char *)(lVar28 + 0x70) == '\x01') {
                              bVar33 = *(char *)(lVar24 + 0x42b) == '\x02';
LAB_140134aed:
                              if (bVar33) goto LAB_140134afc;
                            }
                            else if (*(char *)(lVar28 + 0x70) == '\x02') {
                              bVar33 = *(char *)(lVar24 + 0x42b) == '\x01';
                              goto LAB_140134aed;
                            }
                            if (*(float *)(lVar28 + 0x44) < *pfVar30) goto LAB_140134afc;
                          }
                          if ((((bVar8 == 0xff) && (bVar9 == 0xff)) &&
                              (*(byte *)(lVar32 + 0x236) != 0xff)) &&
                             (((*(char *)(lVar32 + 0x237) == -1 &&
                               ((*(uint *)(lVar32 + 0x1f8) & 0x100) != 0)) &&
                              (lVar28 = *(longlong *)
                                         (*(longlong *)
                                           (**(longlong **)(lVar32 + 0x180) +
                                           (ulonglong)*(byte *)(lVar32 + 0x236) * 8) + 0x110),
                              lVar28 != -0x51ae0)))) {
                            *(uint *)(lVar28 + 0x51cdc) = *(uint *)(lVar28 + 0x51cdc) | 0x10;
                            *(undefined1 *)(lVar28 + 0x51d1e) = *(undefined1 *)(lVar32 + 0x234);
                            *(undefined1 *)(lVar28 + 0x51d1f) = *(undefined1 *)(lVar32 + 0x235);
                          }
                          *(uint *)(lVar32 + 0x1f0) = *(uint *)(lVar32 + 0x1f0) | 8;
                          *(byte *)(lVar32 + 0x236) = bVar8;
                          *(byte *)(lVar32 + 0x237) = bVar9;
                          goto LAB_140134d59;
                        }
LAB_140134afc:
                        iVar27 = iVar27 + 1;
                        pfVar30 = pfVar30 + 2;
                      } while (iVar27 < (int)local_cc._4_4_);
                    }
                  }
                  else {
                    lVar23 = (ulonglong)bVar8 * 0x520;
                    lVar24 = *(longlong *)
                              (*(longlong *)
                                (**(longlong **)(param_1 + 0x140) + (ulonglong)bVar7 * 8) + 0x110);
                    if ((*(byte *)(lVar24 + 0x1f0 + lVar23) & 2) != 0) {
                      auVar4 = *(undefined1 (*) [16])(lVar32 + 600);
                      fVar35 = auVar4._0_4_ - *(float *)(lVar24 + 600 + lVar23);
                      auVar14 = vshufps_avx(auVar4,auVar4,0x55);
                      fVar36 = auVar14._0_4_ - *(float *)(lVar24 + 0x25c + lVar23);
                      auVar14 = vshufps_avx(auVar4,auVar4,0xaa);
                      fVar37 = auVar14._0_4_ - *(float *)(lVar24 + 0x260 + lVar23);
                      auVar4 = vshufps_avx(auVar4,auVar4,0xff);
                      fVar38 = auVar4._0_4_ - *(float *)(lVar24 + 0x264 + lVar23);
                      if (pfVar22[0x25] <=
                          SQRT(fVar38 * fVar38 + fVar37 * fVar37 + fVar36 * fVar36 + fVar35 * fVar35
                              )) {
                        *(undefined2 *)(lVar32 + 0x236) = 0xffff;
                      }
                      else {
                        *(byte *)(lVar32 + 0x236) = bVar7;
                        *(byte *)(lVar32 + 0x237) = bVar8;
                      }
                      goto LAB_140134d59;
                    }
                  }
                }
                iVar27 = 0;
                if (0 < (int)local_cc._4_4_) {
                  pfVar30 = &local_108;
                  do {
                    bVar7 = *(byte *)((longlong)pfVar30 + 5);
                    bVar8 = *(byte *)(pfVar30 + 1);
                    lVar24 = (ulonglong)bVar7 * 0x520 +
                             *(longlong *)
                              (*(longlong *)
                                (**(longlong **)(param_1 + 0x140) + (ulonglong)bVar8 * 8) + 0x110);
                    if ((*(byte *)(**(longlong **)(lVar32 + 0x388) + 0x15d) & 0xfd) == 0) {
LAB_140134c3f:
                      if ((((bVar8 == 0xff) && (bVar7 == 0xff)) &&
                          (*(byte *)(lVar32 + 0x236) != 0xff)) &&
                         (((*(char *)(lVar32 + 0x237) == -1 &&
                           ((*(uint *)(lVar32 + 0x1f8) & 0x100) != 0)) &&
                          (lVar28 = *(longlong *)
                                     (*(longlong *)
                                       (**(longlong **)(lVar32 + 0x180) +
                                       (ulonglong)*(byte *)(lVar32 + 0x236) * 8) + 0x110),
                          lVar28 != -0x51ae0)))) {
                        *(uint *)(lVar28 + 0x51cdc) = *(uint *)(lVar28 + 0x51cdc) | 0x10;
                        *(undefined1 *)(lVar28 + 0x51d1e) = *(undefined1 *)(lVar32 + 0x234);
                        *(undefined1 *)(lVar28 + 0x51d1f) = *(undefined1 *)(lVar32 + 0x235);
                      }
                      *(uint *)(lVar32 + 0x1f0) = *(uint *)(lVar32 + 0x1f0) | 8;
                      *(byte *)(lVar32 + 0x236) = bVar8;
                      *(byte *)(lVar32 + 0x237) = bVar7;
                      break;
                    }
                    if (*(char *)(lVar28 + 0x70) == '\x02') {
                      bVar33 = *(char *)(lVar24 + 0x42b) == '\x01';
LAB_140134c0a:
                      if (!bVar33) goto LAB_140134c0c;
                    }
                    else {
                      if (*(char *)(lVar28 + 0x70) == '\x01') {
                        bVar33 = *(char *)(lVar24 + 0x42b) == '\x02';
                        goto LAB_140134c0a;
                      }
LAB_140134c0c:
                      if (((*pfVar30 <= *(float *)(lVar28 + 0x44)) &&
                          ((*(uint *)(lVar32 + 0x1f0) & 0x10000) == 0)) &&
                         ((*(byte *)(lVar28 + 0x73) & 8) == 0)) goto LAB_140134c3f;
                    }
                    iVar27 = iVar27 + 1;
                    pfVar30 = pfVar30 + 2;
                  } while (iVar27 < (int)local_cc._4_4_);
                }
              }
              else {
                if ((*(byte *)(*(longlong *)
                                (*(longlong *)
                                  (**(longlong **)(param_1 + 0x140) + (ulonglong)bVar7 * 8) + 0x110)
                               + 0x1f0 + (ulonglong)*(byte *)(lVar32 + 0x237) * 0x520) & 2) == 0) {
                  *(uint *)(lVar32 + 0x1f0) = uVar29 & 0xffffff77;
                }
                else {
                  if (*(byte *)((longlong)pfVar22 + 0xb6) == bVar7) goto LAB_140134d59;
                  uVar26 = (ulonglong)local_cc._4_4_;
                  bVar16 = false;
                  bVar33 = false;
                  if (0 < (int)local_cc._4_4_) {
                    pbVar20 = (byte *)((longlong)&local_104 + 1);
                    do {
                      if (pbVar20[-1] == bVar7) {
                        bVar33 = bVar16;
                        if (*pbVar20 == *(byte *)(lVar32 + 0x237)) {
                          bVar33 = true;
                          bVar16 = true;
                        }
                      }
                      pbVar20 = pbVar20 + 8;
                      uVar26 = uVar26 - 1;
                    } while (uVar26 != 0);
                    if (bVar33) goto LAB_140134d59;
                  }
                  *(uint *)(lVar32 + 0x1f0) = *(uint *)(lVar32 + 0x1f0) & 0xffffff77;
                }
                *(undefined1 *)(lVar32 + 0x249) = 0;
                *(undefined2 *)(lVar32 + 0x236) = 0xffff;
              }
            }
LAB_140134d59:
            if (((uint)pfVar22[0x2a] & 0x40) == 0) {
              if (bVar17) {
                *(float *)(lVar32 + 600) = *pfVar22;
                *(float *)(lVar32 + 0x25c) = pfVar22[1];
                *(float *)(lVar32 + 0x260) = pfVar22[2];
                *(float *)(lVar32 + 0x264) = pfVar22[3];
              }
              else {
                pfVar30 = (float *)*puVar12;
                _local_208 = ZEXT816(0);
                _local_1f8 = ZEXT816(0);
                _local_1e8 = _local_208;
                _local_1d8 = _local_1f8;
                FUN_140202920(local_208,pfVar22 + 4);
                fVar35 = *pfVar30;
                fVar36 = pfVar30[1];
                fVar37 = pfVar30[2];
                fVar38 = pfVar22[1];
                fVar39 = pfVar22[2];
                *(float *)(lVar32 + 600) =
                     fVar36 * (float)local_1f8._0_4_ + fVar35 * (float)local_208._0_4_ +
                     fVar37 * (float)local_1e8._0_4_ + (float)local_1d8._0_4_ + *pfVar22;
                *(float *)(lVar32 + 0x264) =
                     fVar36 * fStack_1ec + fVar35 * fStack_1fc + fVar37 * fStack_1dc + fStack_1cc;
                *(float *)(lVar32 + 0x25c) =
                     fVar36 * (float)local_1f8._4_4_ + fVar35 * (float)local_208._4_4_ +
                     fVar37 * (float)local_1e8._4_4_ + (float)local_1d8._4_4_ + fVar38;
                *(float *)(lVar32 + 0x260) =
                     fVar36 * fStack_1f0 + fVar35 * fStack_200 + fVar37 * fStack_1e0 +
                     fStack_1d0 + fVar39;
              }
              *(float *)(lVar32 + 0x268) = pfVar22[4];
              *(float *)(lVar32 + 0x26c) = pfVar22[5];
              *(float *)(lVar32 + 0x270) = pfVar22[6];
              *(float *)(lVar32 + 0x274) = pfVar22[7];
            }
            else if ((SUB41(pfVar22[0x2a],0) < '\0') && ((*(byte *)(param_1 + 0x120) & 0x10) == 0))
            {
              if (((*(byte *)(lVar32 + 0x236) == 0xff) && (*(char *)(lVar32 + 0x237) == -1)) ||
                 (*(longlong *)(lVar32 + 0x368) != 0)) {
                if (bVar17) {
                  fVar35 = pfVar22[7];
                  fVar36 = pfVar22[6];
                  fVar37 = pfVar22[5];
                  fVar38 = pfVar22[4];
                  fVar39 = pfVar22[3];
                  fVar34 = pfVar22[2];
                  fVar40 = pfVar22[1];
                  fVar1 = *pfVar22;
                }
                else {
                  pfVar22 = (float *)*puVar12;
                  _local_208 = ZEXT816(0);
                  _local_1f8 = ZEXT816(0);
                  _local_1e8 = _local_208;
                  _local_1d8 = _local_1f8;
                  FUN_140202920(local_208,param_1 + 0x18);
                  fVar1 = pfVar22[1];
                  fVar2 = *pfVar22;
                  fVar3 = pfVar22[2];
                  fVar35 = *(float *)(param_1 + 0x24);
                  fVar36 = *(float *)(param_1 + 0x20);
                  fVar37 = *(float *)(param_1 + 0x1c);
                  fVar38 = *(float *)(param_1 + 0x18);
                  fVar39 = fVar1 * fStack_1ec + fVar2 * fStack_1fc + fVar3 * fStack_1dc + fStack_1cc
                  ;
                  fVar34 = fVar1 * fStack_1f0 + fVar2 * fStack_200 + fVar3 * fStack_1e0 +
                           fStack_1d0 + *(float *)(param_1 + 0x10);
                  fVar40 = fVar1 * (float)local_1f8._4_4_ + fVar2 * (float)local_208._4_4_ +
                           fVar3 * (float)local_1e8._4_4_ +
                           (float)local_1d8._4_4_ + *(float *)(param_1 + 0xc);
                  fVar1 = fVar1 * (float)local_1f8._0_4_ + fVar2 * (float)local_208._0_4_ +
                          fVar3 * (float)local_1e8._0_4_ +
                          (float)local_1d8._0_4_ + *(float *)(param_1 + 8);
                }
                plVar10 = *(longlong **)(lVar32 + 0x358);
                if (plVar10 != (longlong *)0x0) {
                  local_178 = fVar38;
                  local_174 = fVar37;
                  local_170 = fVar36;
                  local_16c = fVar35;
                  local_168 = fVar1;
                  local_164 = fVar40;
                  local_160 = fVar34;
                  local_15c = fVar39;
                  (**(code **)(*plVar10 + 8))(plVar10,&local_168,&local_178);
                }
              }
              else {
                plVar10 = *(longlong **)(lVar32 + 0x358);
                if (plVar10 != (longlong *)0x0) {
                  lVar28 = (ulonglong)*(byte *)(lVar32 + 0x237) * 0x520 +
                           *(longlong *)
                            (*(longlong *)
                              (**(longlong **)(param_1 + 0x140) +
                              (ulonglong)*(byte *)(lVar32 + 0x236) * 8) + 0x110);
                  if ((*(longlong **)(lVar32 + 0x1a0) == (longlong *)0x0) ||
                     ((cVar5 = *(char *)(**(longlong **)(lVar32 + 0x1a0) + 0x75), cVar5 != '\0' &&
                      (cVar5 != '\x01')))) {
                    local_1a8 = *(undefined8 *)(lVar28 + 0x268);
                    uStack_1a0 = *(undefined8 *)(lVar28 + 0x270);
                    local_218 = *(undefined1 (*) [16])(lVar28 + 600);
                    (**(code **)(*plVar10 + 8))(plVar10,local_218,&local_1a8);
                  }
                  else {
                    local_148 = ZEXT816(0);
                    _local_138 = ZEXT816(0);
                    _local_128 = local_148;
                    _local_118 = _local_138;
                    FUN_140202920(local_148,lVar28 + 0x268);
                    local_1a8 = *(undefined8 *)(lVar28 + 0x268);
                    uStack_1a0 = *(undefined8 *)(lVar28 + 0x270);
                    iVar27 = (uint)*(byte *)(lVar28 + 0x42d) * 0x20;
                    fVar36 = (float)iVar27;
                    fVar35 = (float)(iVar27 + 0x100);
                    local_158 = fVar35 * (float)local_128._0_4_ + fVar36 * (float)local_138._0_4_ +
                                (float)local_118._0_4_ + *(float *)(lVar28 + 600);
                    local_154 = fVar35 * (float)local_128._4_4_ + fVar36 * (float)local_138._4_4_ +
                                (float)local_118._4_4_ + *(float *)(lVar28 + 0x25c);
                    local_150 = fVar35 * fStack_120 + fVar36 * fStack_130 +
                                fStack_110 + *(float *)(lVar28 + 0x260);
                    local_14c = fVar35 * fStack_11c + fVar36 * fStack_12c + fStack_10c;
                    (**(code **)(**(longlong **)(lVar32 + 0x358) + 8))
                              (*(longlong **)(lVar32 + 0x358),&local_158,&local_1a8);
                    *(char *)(lVar28 + 0x42d) = *(char *)(lVar28 + 0x42d) + '\x01';
                  }
                }
              }
            }
            else {
              if (bVar17) {
                local_198 = *(undefined1 (*) [16])(pfVar22 + 4);
                local_1c0 = *pfVar22;
                fStack_1bc = pfVar22[1];
                fStack_1b8 = pfVar22[2];
                fStack_1b4 = pfVar22[3];
              }
              else {
                pfVar30 = (float *)*puVar12;
                _local_208 = ZEXT816(0);
                _local_1f8 = ZEXT816(0);
                _local_1e8 = _local_208;
                _local_1d8 = _local_1f8;
                FUN_140202920(local_208,param_1 + 0x18);
                fVar35 = *pfVar30;
                fVar36 = pfVar30[1];
                fVar37 = pfVar30[2];
                local_1c0 = fVar36 * (float)local_1f8._0_4_ + fVar35 * (float)local_208._0_4_ +
                            fVar37 * (float)local_1e8._0_4_ +
                            (float)local_1d8._0_4_ + *(float *)(param_1 + 8);
                fStack_1bc = fVar36 * (float)local_1f8._4_4_ + fVar35 * (float)local_208._4_4_ +
                             fVar37 * (float)local_1e8._4_4_ +
                             (float)local_1d8._4_4_ + *(float *)(param_1 + 0xc);
                fStack_1b8 = fVar36 * fStack_1f0 + fVar35 * fStack_200 + fVar37 * fStack_1e0 +
                             fStack_1d0 + *(float *)(param_1 + 0x10);
                local_198 = *(undefined1 (*) [16])(param_1 + 0x18);
                fStack_1b4 = fVar36 * fStack_1ec + fVar35 * fStack_1fc + fVar37 * fStack_1dc +
                             fStack_1cc;
              }
              if (((uint)pfVar22[0x2a] & 0x100) != 0) {
                fVar35 = (float)FUN_140079410(*(undefined8 *)(param_1 + 0x148),local_1c0,fStack_1b8)
                ;
                fStack_1bc = fStack_1bc + fVar35;
              }
              if (*(longlong **)(lVar32 + 0x3a0) != (longlong *)0x0) {
                fVar35 = (float)(**(code **)(**(longlong **)(lVar32 + 0x3a0) + 0xa8))();
                fStack_1bc = fStack_1bc + fVar35;
              }
              if ((((*(byte *)(lVar32 + 0x236) != 0xff) && (*(char *)(lVar32 + 0x237) == -1)) &&
                  ((*(uint *)(lVar32 + 0x1f8) & 0x100) != 0)) &&
                 (lVar28 = *(longlong *)
                            (*(longlong *)
                              (**(longlong **)(lVar32 + 0x180) +
                              (ulonglong)*(byte *)(lVar32 + 0x236) * 8) + 0x110), lVar28 != -0x51ae0
                 )) {
                *(uint *)(lVar28 + 0x51cdc) = *(uint *)(lVar28 + 0x51cdc) | 0x10;
                *(undefined1 *)(lVar28 + 0x51d1e) = *(undefined1 *)(lVar32 + 0x234);
                *(undefined1 *)(lVar28 + 0x51d1f) = *(undefined1 *)(lVar32 + 0x235);
              }
              plVar10 = *(longlong **)(lVar32 + 0x358);
              *(undefined2 *)(lVar32 + 0x236) = 0xffff;
              if (plVar10 != (longlong *)0x0) {
                local_218._4_4_ = fStack_1bc;
                local_218._0_4_ = local_1c0;
                local_218._8_4_ = fStack_1b8;
                local_218._12_4_ = fStack_1b4;
                local_1a8 = local_198._0_8_;
                uStack_1a0 = local_198._8_8_;
                (**(code **)(*plVar10 + 8))(plVar10,local_218,&local_1a8);
              }
            }
          }
        }
        local_1c8 = local_1c8 + 1;
        local_188 = local_188 + 0x520;
      } while (local_1c8 < *(int *)(param_1 + 0x118));
    }
  }
  return;
code_r0x0001401346cc:
  iVar18 = iVar18 + 1;
  lVar25 = lVar25 + 1;
  if (iVar21 <= iVar18) goto LAB_1401346d5;
  goto LAB_1401346c0;
}

