/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x14011b0d0; RVA 0x11b0d0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

undefined8 FUN_14011b0d0(void)

{
  return 1;
}

