/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x140170390; RVA 0x170390
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_140170390(undefined8 param_1,longlong *param_2)

{
  if (DAT_14033bba8 < 6) {
    if ((&PTR_FUN_1402910e0)[DAT_14033bba8] != (undefined *)0x0) {
      DAT_14030c8cc = 0;
      (&DAT_140328458)[DAT_14030cab4] = (&PTR_FUN_1402910e0)[DAT_14033bba8];
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0001401703cc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_2 + 0x20))(param_2);
  return;
}

