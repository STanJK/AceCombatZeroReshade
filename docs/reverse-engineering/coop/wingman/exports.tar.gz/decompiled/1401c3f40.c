/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1401c3f40; RVA 0x1c3f40
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1401c3f40(longlong *param_1)

{
  int iVar1;
  int iVar2;
  longlong *plVar3;
  char *pcVar4;
  longlong lVar5;
  undefined *puVar6;
  int *piVar7;
  
  puVar6 = &DAT_140316e78;
  if (DAT_14031cf18 == '\0') {
    puVar6 = &DAT_140310ec0;
  }
  piVar7 = &DAT_140291a24;
  *(undefined4 *)(param_1 + 0x17) = 0;
  do {
    iVar1 = piVar7[-1];
    if (puVar6[(longlong)iVar1 * 5 + 300] != '\0') {
      lVar5 = 1;
      pcVar4 = puVar6 + (longlong)iVar1 * 3 + 0x1e1;
      do {
        if (*pcVar4 != '\0') {
          *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
          *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
          break;
        }
        lVar5 = lVar5 + 1;
        pcVar4 = pcVar4 + 1;
      } while (lVar5 < 3);
    }
    iVar1 = *piVar7;
    if (puVar6[(longlong)iVar1 * 5 + 300] != '\0') {
      lVar5 = 1;
      pcVar4 = puVar6 + (longlong)iVar1 * 3 + 0x1e1;
      do {
        if (*pcVar4 != '\0') {
          *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
          *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
          break;
        }
        lVar5 = lVar5 + 1;
        pcVar4 = pcVar4 + 1;
      } while (lVar5 < 3);
    }
    iVar1 = piVar7[1];
    if (puVar6[(longlong)iVar1 * 5 + 300] != '\0') {
      lVar5 = 1;
      pcVar4 = puVar6 + (longlong)iVar1 * 3 + 0x1e1;
      do {
        if (*pcVar4 != '\0') {
          *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
          *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
          break;
        }
        lVar5 = lVar5 + 1;
        pcVar4 = pcVar4 + 1;
      } while (lVar5 < 3);
    }
    iVar1 = piVar7[2];
    if (puVar6[(longlong)iVar1 * 5 + 300] != '\0') {
      lVar5 = 1;
      pcVar4 = puVar6 + (longlong)iVar1 * 3 + 0x1e1;
      do {
        if (*pcVar4 != '\0') {
          *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
          *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
          break;
        }
        lVar5 = lVar5 + 1;
        pcVar4 = pcVar4 + 1;
      } while (lVar5 < 3);
    }
    iVar1 = piVar7[3];
    if (puVar6[(longlong)iVar1 * 5 + 300] != '\0') {
      lVar5 = 1;
      pcVar4 = puVar6 + (longlong)iVar1 * 3 + 0x1e1;
      do {
        if (*pcVar4 != '\0') {
          *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
          *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
          break;
        }
        lVar5 = lVar5 + 1;
        pcVar4 = pcVar4 + 1;
      } while (lVar5 < 3);
    }
    iVar1 = piVar7[4];
    if (puVar6[(longlong)iVar1 * 5 + 300] != '\0') {
      lVar5 = 1;
      pcVar4 = puVar6 + (longlong)iVar1 * 3 + 0x1e1;
      do {
        if (*pcVar4 != '\0') {
          *(int *)((longlong)param_1 + (longlong)(int)param_1[0x17] * 4 + 0x28) = iVar1;
          *(int *)(param_1 + 0x17) = (int)param_1[0x17] + 1;
          break;
        }
        lVar5 = lVar5 + 1;
        pcVar4 = pcVar4 + 1;
      } while (lVar5 < 3);
    }
    piVar7 = piVar7 + 6;
  } while ((longlong)piVar7 < 0x140291ab4);
  lVar5 = param_1[1];
  iVar1 = (**(code **)(*param_1 + 0x20))(param_1);
  if ((int)lVar5 == -1) {
    if (0 < iVar1) {
      *(undefined4 *)(param_1 + 1) = 0;
    }
    iVar1 = 0;
    if ((int)param_1[0x17] < 1) {
LAB_1401c41b2:
      *(undefined4 *)((longlong)param_1 + 0xc4) = 0;
    }
    else {
      plVar3 = param_1 + 5;
      do {
        if ((int)*plVar3 == *(int *)(puVar6 + (longlong)(int)param_1[4] * 4 + 0x24c)) {
          iVar2 = (**(code **)(*param_1 + 0x20))(param_1);
          if (iVar1 < iVar2) {
            *(int *)(param_1 + 1) = iVar1;
          }
          goto LAB_1401c41b2;
        }
        iVar1 = iVar1 + 1;
        plVar3 = (longlong *)((longlong)plVar3 + 4);
      } while (iVar1 < (int)param_1[0x17]);
      *(undefined4 *)((longlong)param_1 + 0xc4) = 0;
    }
  }
  else if ((iVar1 <= (int)lVar5) && (iVar1 = (**(code **)(*param_1 + 0x20))(param_1), 0 < iVar1)) {
    *(undefined4 *)(param_1 + 1) = 0;
  }
  *(byte *)(param_1[2] + 0x26cd) = *(byte *)(param_1[2] + 0x26cd) & 0xfd;
                    /* WARNING: Could not recover jumptable at 0x0001401c41f3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x10))(param_1);
  return;
}

