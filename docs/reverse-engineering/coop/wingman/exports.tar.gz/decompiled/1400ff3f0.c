/* ACZ SHA256: 43814d4b3292efd0a07fd71bef2f1670c0e5ac7cf2595c9e136d78451380a664
 * VA 0x1400ff3f0; RVA 0xff3f0
 * Ghidra-generated research pseudocode, inferred types, not original source. */

void FUN_1400ff3f0(longlong param_1,longlong *param_2)

{
  char cVar1;
  uint uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  int iVar7;
  longlong lVar8;
  float fVar9;
  float fVar10;
  undefined1 local_28 [16];
  undefined1 local_18 [16];
  
  *(undefined1 *)(param_1 + 0x3e6) = 0;
  if ((param_2 != (longlong *)0x0) &&
     (plVar3 = *(longlong **)(param_1 + 0x2f8), plVar3 != (longlong *)0x0)) {
    cVar1 = *(char *)(param_1 + 0x3cc);
    if (cVar1 == '\0') {
      FUN_1400ff700(param_1,param_2);
    }
    else if (cVar1 == '\x01') {
      lVar4 = *param_2;
      lVar5 = *(longlong *)(*(longlong *)(*(longlong *)*plVar3 + 0x110) + 0x1b8);
      *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) | 0x10020;
      lVar8 = (ulonglong)*(byte *)(lVar4 + 0x21) * 0x520;
      lVar6 = *(longlong *)(*(longlong *)(*plVar3 + (ulonglong)*(byte *)(lVar4 + 0x20) * 8) + 0x110)
      ;
      *(undefined8 *)(lVar6 + 0x3a0 + lVar8) = *(undefined8 *)(lVar6 + 0x390 + lVar8);
      if ((*(byte *)(param_1 + 0x3a8) & 4) == 0) {
        fVar9 = (float)*(byte *)(param_1 + 0x3d1);
        if (*(int *)(param_1 + 0x378) < (int)((int)(fVar9 * *(float *)(lVar4 + 4)) & 0xffffU)) {
          iVar7 = *(int *)(param_1 + 0x378) + 1;
          *(int *)(param_1 + 0x378) = iVar7;
          if (iVar7 < (int)(uint)*(byte *)(param_1 + 0x3d1)) {
            *(float *)(param_1 + 0x3a0) = DAT_1402d22d0 - (float)iVar7 / fVar9;
          }
          fVar10 = (float)iVar7 / (fVar9 * *(float *)(lVar4 + 4));
          fVar9 = fVar10 * DAT_1402d1ff8 + DAT_1402d224c;
          *(float *)(lVar5 + 0x1d78) = fVar10 * DAT_1402d1ff8 - DAT_1402d1ff8;
          *(float *)(lVar5 + 0x1d7c) = fVar9;
        }
        else {
          FUN_140101cc0(param_1,local_28);
          FUN_140101a80(param_1,local_18);
          *(undefined2 *)(param_1 + 0x3d7) = 0xffff;
          *(undefined4 *)(param_1 + 0x390) = 0;
          *(undefined4 *)(param_1 + 0x3a0) = 0;
          if (*(char *)(param_1 + 0x3da) == '\x01') {
            *(uint *)(param_1 + 0x3a8) = *(uint *)(param_1 + 0x3a8) & 0xffffffdf;
          }
          *(byte *)(lVar5 + 0x1863) = *(byte *)(lVar5 + 0x1863) & 0xfe;
          *(undefined4 *)(lVar5 + 0x185c) = 0;
          *(byte *)(lVar5 + 0x1da7) = *(byte *)(lVar5 + 0x1da7) & 0xfe;
          *(undefined8 *)(lVar5 + 0x1d78) = 0;
          if ((*(uint *)(lVar5 + 0x2058) >> 0xd & 1) != 0) {
            *(uint *)(lVar5 + 0x2058) = *(uint *)(lVar5 + 0x2058) & 0xffffdfff;
            *(undefined1 *)(lVar5 + 0x2096) = *(undefined1 *)(lVar5 + 0x2095);
          }
          *(undefined4 *)(param_1 + 0x378) = 0;
          *(undefined1 *)(param_1 + 0x3cc) = 2;
          *(undefined1 *)(param_1 + 0x3e6) = 1;
        }
      }
    }
    else if (cVar1 == '\x02') {
      FUN_140100070(param_1,param_2);
    }
    else if (cVar1 == '\x03') {
      FUN_1401006b0(param_1,param_2);
    }
    else if (cVar1 == '\x04') {
      FUN_140101050();
    }
    else if (cVar1 == '\x06') {
      *(undefined1 *)(param_1 + 0x3cc) = 7;
      *(undefined4 *)(param_1 + 0x378) = 0;
      *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
    }
    else if (cVar1 == '\a') {
      uVar2 = *(uint *)(param_1 + 0x3a8);
      iVar7 = *(int *)(param_1 + 0x378);
      if ((uVar2 >> 0x11 & 1) == 0) {
        if ((uVar2 >> 0x13 & 1) == 0) {
          if (iVar7 < (int)(uint)*(byte *)(param_1 + 0x3d1)) {
            iVar7 = iVar7 + 1;
            *(int *)(param_1 + 0x378) = iVar7;
          }
        }
        else if (0 < iVar7) {
          iVar7 = iVar7 + -1;
          *(int *)(param_1 + 0x378) = iVar7;
        }
        *(uint *)(param_1 + 0x3a8) = uVar2 & 0xfff7ffff;
      }
      else if (iVar7 < 1) {
        *(undefined1 *)(param_1 + 0x3cc) = 8;
        *(uint *)(param_1 + 0x3a8) = uVar2 & 0xfff5ffff;
      }
      else {
        iVar7 = iVar7 + -1;
        *(int *)(param_1 + 0x378) = iVar7;
      }
      *(float *)(param_1 + 0x3a0) = DAT_1402d22d0 - (float)iVar7 / (float)*(byte *)(param_1 + 0x3d1)
      ;
    }
    else if (cVar1 == '\b') {
      *(undefined4 *)(param_1 + 0x3a0) = 0x3f800000;
    }
    FUN_1401013c0(param_1,param_2);
  }
  return;
}

